/* 
 * Copyright (C) 1996-1998 Szeredi Miklos
 * Email: mszeredi@inf.bme.hu
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version. See the file COPYING. 
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

#include "config.h"

#include "spperif.h"

#include "spscr.h"
#include "spscr_p.h"
#include "xscr.h"
#include "xkey.h"

#include "ax.h"

#include "icon.xbm"
#include "iconmask.xbm"

#include <X11/Xutil.h>
#include <X11/Xatom.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#ifdef HAVE_MITSHM
#include <sys/ipc.h>
#include <sys/shm.h>
#include <X11/extensions/XShm.h>

static XShmSegmentInfo shminfo;
static int is_shm_image;

#endif

#define MAX_SEARCH_DEPTH 8

static int wwidth;
static int wheight;

static int shm_avail;
static int no_shm;
static int shm_first_check;

int xscr_delayed_expose = 1;

static int exp_xmin, exp_xmax, exp_ymin, exp_ymax;
static int exp_need = 0;


#define SCRMULMAX 4

#ifdef SCRMUL
#  if SCRMUL < 1 || SCRMUL > SCRMULMAX
#    error Illegal value of "SCRMUL"
#  endif
#else
#  ifdef HAVE_MITSHM
#    define SCRMUL 2
#  else
#    define SCRMUL 1
#  endif
#endif

int scrmul = SCRMUL;

#define TV_WIDTH   320
#define TV_HEIGHT  256

#define WIDTH      256
#define HEIGHT     192

#define X_OFF      ((TV_WIDTH - WIDTH) / 2)
#define Y_OFF      ((TV_HEIGHT - HEIGHT) / 2)

#ifdef MIN
#undef MIN
#endif

#ifdef MAX
#undef MAX
#endif

#define MIN(x, y) ((x) < (y) ? (x) : (y))
#define MAX(x, y) ((x) > (y) ? (x) : (y))

Window xsp_win;
Display *xsp_disp;
int xsp_scr;

static GC gc;
static XImage *imag;

static int immed_image;
static int bpp;
static Visual *visual;
static int depth;
static Atom delete_atom;

typedef unsigned long pixt;

static pixt xsp_colors[16];

static char *idp;


static int bits_per_pixel(int dp)
{
  int count;
  XPixmapFormatValues *fvp;
  int i;

  fvp = XListPixmapFormats(xsp_disp, &count);
  for(i = 0; i < count; i++) 
    if(fvp[i].depth == dp) return fvp[i].bits_per_pixel;

  return 0;
}


static void translate_image(void)
{
  if(bpp == 8 && scrmul == 2) {

    int i, j;
    char *zip, *rip1, *rip2;
    
    zip = sp_image;
    rip1 = imag->data;
    rip2 = imag->data + TV_WIDTH * 2;
    
    for(i = 0; i < TV_HEIGHT; i++) {

      if(sp_border_update || 
         (i >= Y_OFF && i < TV_HEIGHT - Y_OFF && 
          sp_imag_mark[i - Y_OFF])) {

        if(i >= Y_OFF && i < TV_HEIGHT - Y_OFF) 
          sp_imag_mark[i - Y_OFF] = 0;
        
#ifdef I386_ASM
        for(j = TV_WIDTH / 4; j; j--) {
          asm volatile(
                       "movl (%2), %%eax\n\t"
                       "movb %%ah, %%dl\n\t"
                       "movb %%ah, %%dh\n\t"
                       "shll $16, %%edx\n\t"
                       "movb %%al, %%dl\n\t"
                       "movb %%al, %%dh\n\t"
                       "movl %%edx, (%0)\n\t"
                       "addl $4, %2\n\t"
                       "movl %%edx, (%1)\n\t"
                       
                       "shrl $16, %%eax\n\t"
                       "movb %%ah, %%dl\n\t"
                       "movb %%ah, %%dh\n\t"
                       "addl $8, %1\n\t"
                       "shll $16, %%edx\n\t"
                       "movb %%al, %%dl\n\t"
                       "movb %%al, %%dh\n\t"
                       "movl %%edx, 4(%0)\n\t"
                       "movl %%edx, -4(%1)\n\t"
                       "addl $8, %0\n\t"
                       :
                       "=r" ((int) rip1), "=r" ((int) rip2), 
                       "=r" ((int) zip)
                       :"0" ((int) rip1), "1" ((int) rip2), 
                       "2" ((int) zip)
                       :"dx", "ax");
        }
#else
        for(j = TV_WIDTH; j; j--) {
          *rip1++ = *rip2++ = *zip;
          *rip1++ = *rip2++ = *zip;
          zip++;
        }
#endif
      rip1 += TV_WIDTH * 2;
      rip2 += TV_WIDTH * 2;
      }
      else {
        rip1 += 4 * TV_WIDTH;
        rip2 += 4 * TV_WIDTH;
        zip += TV_WIDTH;
      }
    }
    return;
  }

  if(bpp == 8) {

    int i, j;
    char k;
    char *zip;
    char *rip1, *rip2, *rip3, *rip4;

    zip = sp_image;
    rip1 = (char *) imag->data;

    switch (scrmul) {
      case 3:
        rip2 = rip1 + 3 * TV_WIDTH;
        rip3 = rip2 + 3 * TV_WIDTH;
        for(i = 0; i < TV_HEIGHT; i++) {
          if(sp_border_update ||
            (i >= Y_OFF && i < TV_HEIGHT - Y_OFF &&
            sp_imag_mark[i - Y_OFF])) {
            if(i >= Y_OFF && i < TV_HEIGHT - Y_OFF)
              sp_imag_mark[i - Y_OFF] = 0;
            for(j = TV_WIDTH; j; j--) {
              k = *zip++;
              *rip1++ = *rip2++ = *rip3++ = k;
              *rip1++ = *rip2++ = *rip3++ = k;
              *rip1++ = *rip2++ = *rip3++ = k;
            }
            rip1 += 6 * TV_WIDTH;  rip2 += 6 * TV_WIDTH;
            rip3 += 6 * TV_WIDTH;
          }
          else {
            rip1 += 9 * TV_WIDTH;  rip2 += 9 * TV_WIDTH;
            rip3 += 9 * TV_WIDTH;
            zip += TV_WIDTH;
          }
        }
        return;

      case 4:
        rip2 = rip1 + 4 * TV_WIDTH;
        rip3 = rip2 + 4 * TV_WIDTH;
        rip4 = rip3 + 4 * TV_WIDTH;
        for(i = 0; i < TV_HEIGHT; i++) {
          if(sp_border_update ||
            (i >= Y_OFF && i < TV_HEIGHT - Y_OFF &&
            sp_imag_mark[i - Y_OFF])) {
            if(i >= Y_OFF && i < TV_HEIGHT - Y_OFF)
              sp_imag_mark[i - Y_OFF] = 0;
            for(j = TV_WIDTH; j; j--) {
              k = *zip++;
              *rip1++ = *rip2++ = *rip3++ = *rip4++ = k;
              *rip1++ = *rip2++ = *rip3++ = *rip4++ = k;
              *rip1++ = *rip2++ = *rip3++ = *rip4++ = k;
              *rip1++ = *rip2++ = *rip3++ = *rip4++ = k;
            }
            rip1 += 12 * TV_WIDTH;  rip2 += 12 * TV_WIDTH;
            rip3 += 12 * TV_WIDTH;  rip4 += 12 * TV_WIDTH;
          }
          else {
            rip1 += 16 * TV_WIDTH;  rip2 += 16 * TV_WIDTH;
            rip3 += 16 * TV_WIDTH;  rip4 += 16 * TV_WIDTH;
            zip += TV_WIDTH;
          }
        }
        return;
    }
  }

  if(bpp == 16) {

    int i, j;
    dbyte k;
    char *zip;
    dbyte *rip1, *rip2, *rip3, *rip4;

    zip = sp_image;
    rip1 = (dbyte *) imag->data;

    switch (scrmul) {
      case 1:
        for(i = 0; i < TV_HEIGHT; i++) {
          if(sp_border_update ||
            (i >= Y_OFF && i < TV_HEIGHT - Y_OFF &&
            sp_imag_mark[i - Y_OFF])) {
            if(i >= Y_OFF && i < TV_HEIGHT - Y_OFF)
              sp_imag_mark[i - Y_OFF] = 0;
            for(j = TV_WIDTH; j; j--) {
              *rip1++ = (dbyte) xsp_colors[(int) ((unsigned char) *zip++)];
            }
          }
          else {
            rip1 += TV_WIDTH;
            zip += TV_WIDTH;
          }
        }
        return;

      case 2:
        rip2 = rip1 + 2 * TV_WIDTH;
        for(i = 0; i < TV_HEIGHT; i++) {
          if(sp_border_update ||
            (i >= Y_OFF && i < TV_HEIGHT - Y_OFF &&
            sp_imag_mark[i - Y_OFF])) {
            if(i >= Y_OFF && i < TV_HEIGHT - Y_OFF)
              sp_imag_mark[i - Y_OFF] = 0;
            for(j = TV_WIDTH; j; j--) {
              k = (dbyte) xsp_colors[(int) ((unsigned char) *zip++)];
              *rip1++ = *rip2++ = k;
              *rip1++ = *rip2++ = k;
            }
            rip1 += 2 * TV_WIDTH;  rip2 += 2 * TV_WIDTH;
          }
          else {
            rip1 += 4 * TV_WIDTH;  rip2 += 4 * TV_WIDTH;
            zip += TV_WIDTH;
          }
        }
        return;

      case 3:
        rip2 = rip1 + 3 * TV_WIDTH;
        rip3 = rip2 + 3 * TV_WIDTH;
        for(i = 0; i < TV_HEIGHT; i++) {
          if(sp_border_update ||
            (i >= Y_OFF && i < TV_HEIGHT - Y_OFF &&
            sp_imag_mark[i - Y_OFF])) {
            if(i >= Y_OFF && i < TV_HEIGHT - Y_OFF)
              sp_imag_mark[i - Y_OFF] = 0;
            for(j = TV_WIDTH; j; j--) {
              k = (dbyte) xsp_colors[(int) ((unsigned char) *zip++)];
              *rip1++ = *rip2++ = *rip3++ = k;
              *rip1++ = *rip2++ = *rip3++ = k;
              *rip1++ = *rip2++ = *rip3++ = k;
            }
            rip1 += 6 * TV_WIDTH;  rip2 += 6 * TV_WIDTH;
            rip3 += 6 * TV_WIDTH;
          }
          else {
            rip1 += 9 * TV_WIDTH;  rip2 += 9 * TV_WIDTH;
            rip3 += 9 * TV_WIDTH;
            zip += TV_WIDTH;
          }
        }
        return;

      case 4:
        rip2 = rip1 + 4 * TV_WIDTH;
        rip3 = rip2 + 4 * TV_WIDTH;
        rip4 = rip3 + 4 * TV_WIDTH;
        for(i = 0; i < TV_HEIGHT; i++) {
          if(sp_border_update ||
            (i >= Y_OFF && i < TV_HEIGHT - Y_OFF &&
            sp_imag_mark[i - Y_OFF])) {
            if(i >= Y_OFF && i < TV_HEIGHT - Y_OFF)
              sp_imag_mark[i - Y_OFF] = 0;
            for(j = TV_WIDTH; j; j--) {
              k = (dbyte) xsp_colors[(int) ((unsigned char) *zip++)];
              *rip1++ = *rip2++ = *rip3++ = *rip4++ = k;
              *rip1++ = *rip2++ = *rip3++ = *rip4++ = k;
              *rip1++ = *rip2++ = *rip3++ = *rip4++ = k;
              *rip1++ = *rip2++ = *rip3++ = *rip4++ = k;
            }
            rip1 += 12 * TV_WIDTH;  rip2 += 12 * TV_WIDTH;
            rip3 += 12 * TV_WIDTH;  rip4 += 12 * TV_WIDTH;
          }
          else {
            rip1 += 16 * TV_WIDTH;  rip2 += 16 * TV_WIDTH;
            rip3 += 16 * TV_WIDTH;  rip4 += 16 * TV_WIDTH;
            zip += TV_WIDTH;
          }
        }
        return;
    }
  }

  if(bpp == 32) {

    int i, j;
    qbyte k;
    char *zip;
    qbyte *rip1, *rip2, *rip3, *rip4;

    zip = sp_image;
    rip1 = (qbyte *) imag->data;

    switch (scrmul) {
      case 1:
        for(i = 0; i < TV_HEIGHT; i++) {
          if(sp_border_update ||
            (i >= Y_OFF && i < TV_HEIGHT - Y_OFF &&
            sp_imag_mark[i - Y_OFF])) {
            if(i >= Y_OFF && i < TV_HEIGHT - Y_OFF)
              sp_imag_mark[i - Y_OFF] = 0;
            for(j = TV_WIDTH; j; j--) {
              *rip1++ = (qbyte) xsp_colors[(int) ((unsigned char) *zip++)];
            }
          }
          else {
            rip1 += TV_WIDTH;
            zip += TV_WIDTH;
          }
        }
        return;

      case 2:
        rip2 = rip1 + 2 * TV_WIDTH;
        for(i = 0; i < TV_HEIGHT; i++) {
          if(sp_border_update ||
            (i >= Y_OFF && i < TV_HEIGHT - Y_OFF &&
            sp_imag_mark[i - Y_OFF])) {
            if(i >= Y_OFF && i < TV_HEIGHT - Y_OFF)
              sp_imag_mark[i - Y_OFF] = 0;
            for(j = TV_WIDTH; j; j--) {
              k = (qbyte) xsp_colors[(int) ((unsigned char) *zip++)];
              *rip1++ = *rip2++ = k;
              *rip1++ = *rip2++ = k;
            }
            rip1 += 2 * TV_WIDTH;  rip2 += 2 * TV_WIDTH;
          }
          else {
            rip1 += 4 * TV_WIDTH;  rip2 += 4 * TV_WIDTH;
            zip += TV_WIDTH;
          }
        }
        return;

      case 3:
        rip2 = rip1 + 3 * TV_WIDTH;
        rip3 = rip2 + 3 * TV_WIDTH;
        for(i = 0; i < TV_HEIGHT; i++) {
          if(sp_border_update ||
            (i >= Y_OFF && i < TV_HEIGHT - Y_OFF &&
            sp_imag_mark[i - Y_OFF])) {
            if(i >= Y_OFF && i < TV_HEIGHT - Y_OFF)
              sp_imag_mark[i - Y_OFF] = 0;
            for(j = TV_WIDTH; j; j--) {
              k = (qbyte) xsp_colors[(int) ((unsigned char) *zip++)];
              *rip1++ = *rip2++ = *rip3++ = k;
              *rip1++ = *rip2++ = *rip3++ = k;
              *rip1++ = *rip2++ = *rip3++ = k;
            }
            rip1 += 6 * TV_WIDTH;  rip2 += 6 * TV_WIDTH;
            rip3 += 6 * TV_WIDTH;
          }
          else {
            rip1 += 9 * TV_WIDTH;  rip2 += 9 * TV_WIDTH;
            rip3 += 9 * TV_WIDTH;
            zip += TV_WIDTH;
          }
        }
        return;

      case 4:
        rip2 = rip1 + 4 * TV_WIDTH;
        rip3 = rip2 + 4 * TV_WIDTH;
        rip4 = rip3 + 4 * TV_WIDTH;
        for(i = 0; i < TV_HEIGHT; i++) {
          if(sp_border_update ||
            (i >= Y_OFF && i < TV_HEIGHT - Y_OFF &&
            sp_imag_mark[i - Y_OFF])) {
            if(i >= Y_OFF && i < TV_HEIGHT - Y_OFF)
              sp_imag_mark[i - Y_OFF] = 0;
            for(j = TV_WIDTH; j; j--) {
              k = (qbyte) xsp_colors[(int) ((unsigned char) *zip++)];
              *rip1++ = *rip2++ = *rip3++ = *rip4++ = k;
              *rip1++ = *rip2++ = *rip3++ = *rip4++ = k;
              *rip1++ = *rip2++ = *rip3++ = *rip4++ = k;
              *rip1++ = *rip2++ = *rip3++ = *rip4++ = k;
            }
            rip1 += 12 * TV_WIDTH;  rip2 += 12 * TV_WIDTH;
            rip3 += 12 * TV_WIDTH;  rip4 += 12 * TV_WIDTH;
          }
          else {
            rip1 += 16 * TV_WIDTH;  rip2 += 16 * TV_WIDTH;
            rip3 += 16 * TV_WIDTH;  rip4 += 16 * TV_WIDTH;
            zip += TV_WIDTH;
          }
        }
        return;
    }
  }

  fprintf(stderr, "Translation not implemented (bpp: %i; scrmul: %i)\n",
          bpp, scrmul);
  exit(1);
}


static void put_image(int x, int y, int w, int h, int toflush) 
{
#if 0
  static int serial = 0, num = 0;
  static int percent = 0;

  percent += (w * h) * 100 / (wwidth * wheight);
  if(toflush) {
    fprintf(stderr, "put_image/%i  %i  %i%%\n", 
	    ++num, serial++, percent), num = 0, percent = 0;
    getchar();
  }

  else num++;
#endif

#ifdef HAVE_MITSHM
  if(is_shm_image) {
    XShmPutImage(xsp_disp, xsp_win, gc, imag, x, y, x, y, w, h, False);
    if(toflush) XSync(xsp_disp, False);
    return;
  }
#endif
  XPutImage(xsp_disp, xsp_win, gc, imag, x, y, x, y, w, h);
  if(toflush) XFlush(xsp_disp);

}

static void get_min_max(int val, int btnum, int *minp, int *maxp)
{
  int i, j, m;

  for(i = btnum, j = 0; i && !(val & 1); val >>= 1, j++, i--);
  *minp = j;
  for(m = 0; i; val >>=1, j++, i--) if(val & 1) m = j;
  *maxp = m;
}

void update_screen()
{
  if(!immed_image && (sp_border_update || sp_imag_horiz)) translate_image();
  
  if(sp_border_update && sp_imag_horiz) put_image(0, 0, wwidth, wheight, 1);
  else {
    if(exp_need) {
      int exmin, exmax, eymin, eymax;
      
      exmin = MAX(0, MIN(wwidth, exp_xmin));
      exmax = MAX(0, MIN(wwidth, exp_xmax));
      
      eymin = MAX(0, MIN(wheight, exp_ymin));
      eymax = MAX(0, MIN(wheight, exp_ymax));

          
      put_image(exmin, eymin, exmax - exmin, eymax - eymin, 
		(!sp_border_update && !sp_imag_horiz));
    }    
    if(sp_border_update) {
      register int bhw, bvw, rh;
      
      bhw = X_OFF * scrmul;
      bvw = Y_OFF * scrmul;
      rh = HEIGHT * scrmul;
      
      put_image(0, 0, wwidth, bvw, 0);
      put_image(0, bvw, bhw, rh, 0);
      put_image((X_OFF+WIDTH) * scrmul, bvw, bhw, rh, 0);
      put_image(0, (Y_OFF+HEIGHT) * scrmul, wwidth, bvw, 1);
    }
    else if(sp_imag_horiz) {
      int xmin, xmax;
      int ymin, ymax;
      
      get_min_max(sp_imag_horiz, 32, &xmin, &xmax);
      get_min_max(sp_imag_vert, 24, &ymin, &ymax);
      
      put_image((xmin * 8 + X_OFF) * scrmul, 
		(ymin * 8 + Y_OFF) * scrmul, 
		(xmax - xmin + 1) * 8 * scrmul,
		(ymax - ymin + 1) * 8 * scrmul, 1);
    }
  }

  exp_need = 0;
}

static void expose_call(XEvent *ev)
{
  int x1, x2, y1, y2;

  x1 = (*ev).xexpose.x;
  x2 = x1 + (*ev).xexpose.width;

  y1 = (*ev).xexpose.y;
  y2 = y1 +(*ev).xexpose.height;

  if(!exp_need) {
    exp_xmin = x1;
    exp_xmax = x2;
    exp_ymin = y1;
    exp_ymax = y2;
    exp_need = 1;
  }
  else {
    exp_xmin = MIN(exp_xmin, x1);
    exp_xmax = MAX(exp_xmax, x2);
    exp_ymin = MIN(exp_ymin, y1);
    exp_ymax = MAX(exp_ymax, y2);
  }

  if((*ev).xexpose.count == 0) {
    if(!xscr_delayed_expose) {
      int xmin, xmax, ymin, ymax;

      xmin = MAX(0, MIN(wwidth, exp_xmin));
      xmax = MAX(0, MIN(wwidth, exp_xmax));
      
      ymin = MAX(0, MIN(wheight, exp_ymin));
      ymax = MAX(0, MIN(wheight, exp_ymax));

      put_image(xmin, ymin, xmax - xmin, ymax - ymin, 1);
      exp_need = 0;
    }
  }
}


static void misc_event(XEvent *ev)
{
  if(ev->type == ClientMessage) {
    /* If we get a client message which has the value of the delete
     * atom, it means the window manager wants us to die.
     */
    if ((*ev).xclient.data.l[0] == (unsigned char) delete_atom) exit(0);
  }
}


static unsigned cdist(XColor *c1, XColor *c2)
{
  int dr, dg, db;

  dr = (c1->red - c2->red) >> 8;
  dg = (c1->green - c2->green) >> 8;
  db =  (c1->blue - c2->blue) >> 8;

  return dr * dr + dg * dg + db * db;
}

static int already_alloced(pixt *colors, int num, pixt pix)
{
  int i;

  for(i = 0; i < num; i++) if(colors[i] == pix) return 1;
  return 0;
}

static int search_colors(void)
{
  int c;
  XColor xcolor, tmpcolor;
  pixt pix;

  Colormap cmap;
  int dp;

  XColor *scrcolors = NULL;
  unsigned  ncolors = 0;
  unsigned dist, mindist;
  pixt minpix;
  int failed = 0, lfailed;

  cmap = DefaultColormap(xsp_disp, xsp_scr);
  dp = DisplayPlanes(xsp_disp, xsp_scr);

  if(dp < 4) failed = 1;
  if(!failed) {
    if(dp <= MAX_SEARCH_DEPTH) {
      ncolors = 1 << dp;
      scrcolors = malloc(sizeof(XColor) * ncolors);

      if(scrcolors != NULL) {
	for(pix = 0; pix < ncolors; pix++) scrcolors[pix].pixel = pix;
	XQueryColors(xsp_disp, cmap, scrcolors, ncolors);
      }
    }
    
    
    for(c = 0; c < COLORNUM; c++) {
      xcolor.red = spscr_crgb[c].r << 10;
      xcolor.green = spscr_crgb[c].g << 10;
      xcolor.blue = spscr_crgb[c].b << 10;
      lfailed = 0;
      if(!XAllocColor(xsp_disp, cmap, &xcolor) || 
         already_alloced(xsp_colors, c, xcolor.pixel)) {
        
        if(scrcolors != NULL) {
#ifdef CRT_COLOR_DEBUG
          fprintf(stderr, "XAllocColor failed, searching all colors...\n");
#endif
          mindist = (unsigned) -1;
          
          for(pix = 0; pix < ncolors; pix++) {
            dist = cdist(&scrcolors[pix], &xcolor);
            if(dist < mindist) {
              tmpcolor.red = scrcolors[pix].red;
              tmpcolor.green = scrcolors[pix].green;
              tmpcolor.blue = scrcolors[pix].blue;
              if(XAllocColor(xsp_disp, cmap, &tmpcolor) &&
                 !already_alloced(xsp_colors, c, tmpcolor.pixel)) {
                if(mindist != (unsigned) -1) 
                  XFreeColors(xsp_disp, cmap, &minpix, 1, 0);
                mindist = dist;
                minpix = pix;
              }
            }
          }
          
          if(mindist == (unsigned) -1) {
            lfailed = 1;
#ifdef CRT_COLOR_DEBUG
            fprintf(stderr, "Search failed\n");
#endif
          }
          else xsp_colors[c] = minpix;
        }
        else {
#ifdef CRT_COLOR_DEBUG  
          fprintf(stderr, "XAllocColor failed\n");
#endif
          lfailed = 1;
        }
      }
      else xsp_colors[c] = xcolor.pixel;
      
      if(lfailed) failed = 1;
      
#ifdef CRT_COLOR_DEBUG
      tmpcolor.pixel = xsp_colors[c];
      XQueryColor(xsp_disp, cmap, &tmpcolor);
      
      
      fprintf(stderr, 
              "Color %2i (%3i %3i %3i) -> Pixel %5lu (%3i %3i %3i)\n",
              c, spscr_crgb[c].r, spscr_crgb[c].g, spscr_crgb[c].b,
              xsp_colors[c], tmpcolor.red>>10, tmpcolor.green>>10, 
              tmpcolor.blue>>10);
#endif    
      
    }
  }
  if(scrcolors != NULL) free(scrcolors);

  if(failed) return 0;
  return 1;
}


#ifdef HAVE_MITSHM

extern int      XShmQueryExtension (Display * dpy);
static int      haderror;
static int      (*origerrorhandler) (Display *, XErrorEvent *);

static int shmattacherrorhandler(Display *disp, XErrorEvent *err)
{
  if (err->error_code == BadAccess) haderror = 1;
  else (*origerrorhandler) (disp, err);

  return 0;
}

static char *create_shm_image(int width, int height, 
                            Visual *vis, int dp, int bits)
{
  int scmsize;
  int status;

  scmsize = (bits * width * height) / 8;

  is_shm_image = 0;

  imag = XShmCreateImage(xsp_disp, vis, 
                         dp, ZPixmap, 0, &shminfo, 
                         width, height);

  if(imag == NULL) {
    fprintf(stderr, "XShmCreateImage failed\n");
    return NULL;
  }

  shminfo.shmid = shmget(IPC_PRIVATE, scmsize, IPC_CREAT | 0777);

  if(shminfo.shmid < 0) {
    fprintf(stderr, "Warning: shmget failed: %s\n", strerror(errno));
    return NULL;
  }

  shminfo.shmaddr = (char *) shmat(shminfo.shmid, 0, 0);
  
  if(shminfo.shmaddr == ((char *) -1)) {
    fprintf(stderr, "Warning: shmat failed: %s\n", strerror(errno));
    return NULL;
  }
 
  imag->data = shminfo.shmaddr;

  shminfo.readOnly = False;

  haderror = 0;
  origerrorhandler = XSetErrorHandler(shmattacherrorhandler);
  status = XShmAttach(xsp_disp, &shminfo);
  XSync(xsp_disp, True);
  XSetErrorHandler (origerrorhandler);

  if(!status || haderror) {
    fprintf(stderr, "XShmAttach failed\n");

    shmctl(shminfo.shmid, IPC_RMID, 0);
    shmdt(shminfo.shmaddr);
    shm_avail = 0;
    return NULL;
  }


  if(shmctl(shminfo.shmid, IPC_RMID, 0) < 0) {
    fprintf(stderr, "shmctl failed: %s\n", strerror(errno));
    exit(1);
  }

  is_shm_image = 1;

  return shminfo.shmaddr;
}

static void destroy_shm_image(void)
{
  XDestroyImage(imag);

  XShmDetach(xsp_disp, &shminfo);
  shmdt(shminfo.shmaddr);
}

#endif /* HAVE_MITSHM */

static char *create_image(int width, int height,
                         Visual *vis, int dp, int bits)
{
  int scmsize;
  char *idat;

  scmsize = (bits * width * height) / 8;

  idat = (char *) malloc(scmsize);
  if(idat == NULL) {
    fprintf(stderr, "Out of memory!\n");
    exit(1);
  }

  imag = XCreateImage(xsp_disp, vis, 
                      dp, ZPixmap, 0, idat, 
                      width, height, 32, 0);

  return idat;
}

static void destroy_image(void)
{
  XDestroyImage(imag);
}



void init_spect_scr()
{
  idp = NULL;

#ifdef HAVE_MITSHM
  if(shm_avail && !no_shm) 
    idp = create_shm_image(wwidth, wheight, visual, depth, bpp);
#endif

  if(idp == NULL) {
    if(shm_first_check) {
      fprintf(stderr, "Note: MITSHM extension not available.\n");
      shm_first_check = 0;
    }

    idp = create_image(wwidth, wheight, visual, depth, bpp);
  }
  
  if(scrmul != 1 || bpp != 8) {
    immed_image = 0;
    sp_image = (char *) malloc(TV_WIDTH * TV_HEIGHT);
    if(sp_image == NULL) {
      fprintf(stderr, "Out of memory!\n");
      exit(1);
    }

  }
  else {
    immed_image = 1;
    sp_image = idp;
  }

  if(bpp == 8) {
    int i;
    for(i = 0; i < 16; i++) sp_colors[i] = (unsigned char) xsp_colors[i];
  }
  else {
    int i;
    for(i = 0; i < 16; i++) sp_colors[i] = (unsigned char) i;
  }

  XMapWindow(xsp_disp, xsp_win);  

  XSync(xsp_disp, False);

  spscr_init_mask_color();

  spscr_init_line_pointers(TV_HEIGHT);
}

void destroy_spect_scr()
{
  XSync(xsp_disp, False);
  
  if(!immed_image) free(sp_image);

#ifdef HAVE_MITSHM
  if(is_shm_image) {
    destroy_shm_image();
    idp = NULL;
  }
#endif
  
  if(idp != NULL) {
    destroy_image();
    idp = NULL;
  }

  sp_image = NULL;
}


void resize_spect_scr(int s)
{
  if(s == scrmul || s > SCRMULMAX || s < 1) return;

  XResizeWindow(xsp_disp, xsp_win, TV_WIDTH * s, TV_HEIGHT *s);
}

static void resize_call(XEvent *ev)
{
  int w, h, x, y, s;

#if 0
  fprintf(stderr,"Resize Call: %d %d\n",
	  (*ev).xconfigure.width, (*ev).xconfigure.height);
#endif

  w = (*ev).xconfigure.width;
  h = (*ev).xconfigure.height;

  if(w == wwidth && h == wheight) return;

  x = (w + TV_WIDTH / 2) / TV_WIDTH;
  y = (h + TV_HEIGHT / 2) / TV_HEIGHT;
  s = MAX(x,y);

  if(s < 1) s = 1;
  else if(s > SCRMULMAX) s = SCRMULMAX;  
  if(s != scrmul) {
    destroy_spect_scr();
    scrmul = s;
    
    wwidth = TV_WIDTH * scrmul;
    wheight = TV_HEIGHT * scrmul;

    init_spect_scr();
    
    sp_init_screen_mark();           /* Redraw screen */
  }

  if(wwidth != w || wheight != h) 
    XResizeWindow(xsp_disp, xsp_win, wwidth, wheight);


}

static void map_event(XEvent *ev)
{
  if(ev->type == MapNotify) { 
    screen_visible = 1;
    accept_keys = 1;
  }
  else {
    screen_visible = 0;
    accept_keys = 0;
  }
}

static void visibility_event(XEvent *ev)
{
  if((*ev).xvisibility.state == VisibilityFullyObscured) screen_visible = 0;
  else screen_visible = 1;
}


void init_x_scr(aX_default_resources* defres, int *argcp, char *argv[])
{
  XSetWindowAttributes attr;

  XSizeHints    *size_hints;
  XClassHint    *class_hints;
  XWMHints      *wm_hints;
  XTextProperty window_name, *wnp;
  XTextProperty icon_name, *inp;

  pixt valuemask;
  XGCValues values;
  Atom proto_atom;


  shm_avail = 0;
  no_shm = 0;
  shm_first_check = 1;


  xsp_disp = defres->disp;
  xsp_scr = defres->scr;

#ifdef HAVE_MITSHM
  shm_avail = 1;
#ifdef HAVE_SHMQUERY
  if (!XShmQueryExtension(xsp_disp)) shm_avail = 0;
#endif
#endif

  if(!shm_avail) {
    fprintf(stderr, "Note: MITSHM extension not available.\n");
    shm_first_check = 0;
  }

  if(!search_colors()) {
    fprintf(stderr, "Could not allocate colors\n");
    exit(1);
  }

  visual = DefaultVisual(xsp_disp, xsp_scr);
  depth = DisplayPlanes(xsp_disp, xsp_scr);

  bpp = bits_per_pixel(depth);

  if(!shm_avail) scrmul = 1;

  while(scrmul > 1 &&
        (DisplayWidth(xsp_disp, xsp_scr) < TV_WIDTH * scrmul ||
         DisplayHeight(xsp_disp, xsp_scr) < TV_HEIGHT * scrmul)) scrmul--;


  wwidth = TV_WIDTH * scrmul;
  wheight = TV_HEIGHT * scrmul;
  
  xsp_win = XCreateSimpleWindow(xsp_disp, 
                            RootWindow(xsp_disp, xsp_scr),
                            0, 0,                     /* x, y */
                            wwidth, wheight,          /* width, height */
                            0, 0,                     /* bw, bc */
                            xsp_colors[7]);

 
  attr.bit_gravity = ForgetGravity;
  XChangeWindowAttributes(xsp_disp, xsp_win,
                          CWBitGravity, &attr);

  
  size_hints = XAllocSizeHints();
  if(size_hints != NULL) {
    size_hints->min_width = TV_WIDTH;
    size_hints->min_height = TV_HEIGHT;
    size_hints->max_width = SCRMULMAX * TV_WIDTH;
    size_hints->max_height = SCRMULMAX * TV_HEIGHT;
    size_hints->width_inc = TV_WIDTH;
    size_hints->height_inc = TV_HEIGHT;
    size_hints->min_aspect.x = TV_WIDTH;
    size_hints->min_aspect.y = TV_HEIGHT;
    size_hints->max_aspect.x = TV_WIDTH;
    size_hints->max_aspect.y = TV_HEIGHT;
    size_hints->base_width = 0;
    size_hints->base_height = 0;
#if 1
    size_hints->flags = PMinSize | PMaxSize | PResizeInc | PAspect | PBaseSize;
#else
    size_hints->flags = 0;
#endif
  }

  wm_hints = XAllocWMHints();
  if(wm_hints != NULL) {
    wm_hints->input = True;
    wm_hints->initial_state = NormalState;
    wm_hints->icon_pixmap = XCreateBitmapFromData(xsp_disp, xsp_win, icon_bits,
						 icon_width, icon_height);
    wm_hints->icon_mask = XCreateBitmapFromData(xsp_disp, xsp_win, 
					       iconmask_bits, iconmask_width, 
					       iconmask_height);
    wm_hints->flags = InputHint | StateHint | IconPixmapHint | IconMaskHint;
  }

  class_hints = XAllocClassHint();
  if(class_hints != NULL) {
    class_hints->res_name  = (char *) defres->prog_name;
    class_hints->res_class = (char *) defres->class_name;
  }
  
  wnp = &window_name;
  if(!XStringListToTextProperty(&defres->window_name, 1, wnp)) wnp = NULL;
  
  inp = &icon_name;
  if(!XStringListToTextProperty(&defres->icon_name, 1, inp)) inp = NULL;

  XSetWMProperties(xsp_disp, xsp_win, wnp, inp, argv, *argcp, 
		   size_hints, wm_hints, class_hints);
  
  if(size_hints != NULL)  XFree((void *) size_hints);
  if(wm_hints != NULL)    XFree((void *) wm_hints);
  if(class_hints != NULL) XFree((void *) class_hints);

  /* Delete-Window-Message black magic copied from xloadimage. */
  proto_atom  = XInternAtom(xsp_disp,"WM_PROTOCOLS", False);
  delete_atom = XInternAtom(xsp_disp,"WM_DELETE_WINDOW", False);
  if ((proto_atom != None) && (delete_atom != None)) {
    XChangeProperty(xsp_disp, xsp_win, proto_atom, XA_ATOM, 32,
                      PropModePrepend, (unsigned char*)&delete_atom, 1);
  }

  valuemask = GCForeground;
  values.foreground = xsp_colors[0];

  gc = XCreateGC(xsp_disp, xsp_win, valuemask, &values);

  aX_add_event_proc(xsp_win, FocusIn, 
                    xkey_focus_change_call, FocusChangeMask);
  aX_add_event_proc(xsp_win, FocusOut, 
                    xkey_focus_change_call, FocusChangeMask);

  aX_add_event_proc(xsp_win, Expose, expose_call, ExposureMask);

  aX_add_event_proc(xsp_win, ClientMessage, misc_event, 0);
  aX_add_event_proc(xsp_win, MappingNotify, misc_event, 0);

  aX_add_event_proc(xsp_win, ConfigureNotify, resize_call, 
		    StructureNotifyMask);

  aX_add_event_proc(xsp_win, CirculateNotify, misc_event, StructureNotifyMask);
  aX_add_event_proc(xsp_win, CreateNotify,    misc_event, StructureNotifyMask);
  aX_add_event_proc(xsp_win, GravityNotify,   misc_event, StructureNotifyMask);
  aX_add_event_proc(xsp_win, ReparentNotify,  misc_event, StructureNotifyMask);
  aX_add_event_proc(xsp_win, DestroyNotify,   misc_event, StructureNotifyMask);

  aX_add_event_proc(xsp_win, MapNotify,   map_event, StructureNotifyMask);
  aX_add_event_proc(xsp_win, UnmapNotify, map_event, StructureNotifyMask);
  

  aX_add_event_proc(xsp_win, VisibilityNotify, visibility_event, 
		    VisibilityChangeMask);

}
