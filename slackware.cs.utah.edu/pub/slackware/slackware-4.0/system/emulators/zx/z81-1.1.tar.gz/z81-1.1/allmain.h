/* allmain.h - functions provided by {,x,txt}main.c needed by common*.c.
 */

extern void dontpanic(int a);
extern void update_scrn();
extern void check_events();
