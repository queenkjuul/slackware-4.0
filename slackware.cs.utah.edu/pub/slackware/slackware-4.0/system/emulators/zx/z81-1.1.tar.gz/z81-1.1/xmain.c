/* xz81, an X-based ZX81 emulator (based on Z81, xnc100em, and xz80).
 * Copyright (C) 1994 Ian Collier. xz81 changes (C) 1995-8 Russell Marks.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/* most of this file is heavily based on xz80's xspectrum.c,
 * to the extent that some of the indentation is a crazy
 * mix-and-match affair. :-)
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/time.h>
#include <sys/time.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/keysym.h>
#include <X11/Intrinsic.h>

#ifdef MITSHM
#include <sys/ipc.h>
#include <sys/shm.h>
#include <X11/extensions/XShm.h>
#endif

#ifdef HAS_UNAME
#include <sys/utsname.h>
#endif

#include "z80.h"
#include "common.h"
#include "allmain.h"

#define MAX_DISP_LEN 256

#include "xz81.icon"

#define BORDER_WIDTH	(20*SCALE)
int rrshm=2,rrnoshm=4,mitshm=1;

int hsize=256*SCALE,vsize=192*SCALE;

#ifdef SunKludge
char *shmat();
char *getenv();
#endif

/* remember, this table is ignoring shifts... */
static struct {unsigned char port,mask;} keytable[]={
/*  SP      !        "        #        $        %        &        '  */
{7,0xfe},{8,0xff},{3,0xfd},{8,0xff},{5,0xf7},{8,0xff},{8,0xff},{8,0xff},
/*  (       )        *        +        ,        -        .        /  */
{5,0xfb},{5,0xfd},{4,0xfb},{6,0xfb},{7,0xfd},{6,0xf7},{7,0xfd},{0,0xef},
/*  0       1        2        3        4        5        6        7  */
{4,0xfe},{3,0xfe},{3,0xfd},{3,0xfb},{3,0xf7},{3,0xef},{4,0xef},{4,0xf7},
/*  8       9        :        ;        <        =        >        ?  */
{4,0xfb},{4,0xfd},{0,0xfd},{0,0xfb},{7,0xf7},{6,0xfb},{7,0xfb},{0,0xef},
/*  @       A        B        C        D        E        F        G  */
{8,0xff},{1,0xfe},{7,0xef},{0,0xf7},{1,0xfb},{2,0xfb},{1,0xf7},{1,0xef},
/*  H       I        J        K        L        M        N        O  */
{6,0xef},{5,0xfb},{6,0xf7},{6,0xfb},{6,0xfd},{7,0xfb},{7,0xf7},{5,0xfd},
/*  P       Q        R        S        T        U        V        W  */
{5,0xfe},{2,0xfe},{2,0xf7},{1,0xfd},{2,0xef},{5,0xf7},{0,0xef},{2,0xfd},
/*  X       Y        Z        [        \        ]        ^        _  */
{0,0xfb},{5,0xef},{0,0xfd},{8,0xff},{8,0xff},{8,0xff},{8,0xff},{8,0xff},
/*  `       a        b        c        d        e        f        g  */
{8,0xff},{1,0xfe},{7,0xef},{0,0xf7},{1,0xfb},{2,0xfb},{1,0xf7},{1,0xef},
/*  h       i        j        k        l        m        n        o  */
{6,0xef},{5,0xfb},{6,0xf7},{6,0xfb},{6,0xfd},{7,0xfb},{7,0xf7},{5,0xfd},
/*  p       q        r        s        t        u        v        w  */
{5,0xfe},{2,0xfe},{2,0xf7},{1,0xfd},{2,0xef},{5,0xf7},{0,0xef},{2,0xfd},
/*  x       y        z        {        |        }        ~       DEL */
{0,0xfb},{5,0xef},{0,0xfd},{8,0xff},{8,0xff},{8,0xff},{8,0xff},{8,0xff}
};


static Display *display;
static Screen *scrptr;
static int screen;
static Window root;
static Colormap cmap;
static GC maingc;
static GC fggc, bggc;
static Window borderwin, mainwin;
static XImage *ximage;
static unsigned char *image;
static int linelen,imagebpp,byteorder;
static int black,white;
static unsigned char black_bits0to7,black_bits8to15;
static unsigned char black_bits16to23,black_bits24to31;
static unsigned char white_bits0to7,white_bits8to15;
static unsigned char white_bits16to23,white_bits24to31;
#ifdef MITSHM
static XShmSegmentInfo xshminfo;
#endif
static int invert=0;
static int borderchange=1;


void closedown(){
#ifdef MITSHM
   if(mitshm){
      XShmDetach(display,&xshminfo);
      XDestroyImage(ximage);
      shmdt(xshminfo.shmaddr);
      shmctl(xshminfo.shmid,IPC_RMID,0);
   }
#endif
   XAutoRepeatOn(display);
   XCloseDisplay(display);
}


void dontpanic(int a)
{
closedown();
exit(1);
}



static int is_local_server(name)
char *name;
{
#ifdef HAS_UNAME
   struct utsname un;
#else
   char sysname[MAX_DISP_LEN];
#endif

   if(name[0]==':')return 1;
   if(!strncmp(name,"unix",4))return 1;
   if(!strncmp(name,"localhost",9))return 1;

#ifdef HAS_UNAME
   uname(&un);
   if(!strncmp(name,un.sysname,strlen(un.sysname)))return 1;
   if(!strncmp(name,un.nodename,strlen(un.nodename)))return 1;
#else
   gethostname(sysname,MAX_DISP_LEN);
   if(!strncmp(name,sysname,strlen(sysname)))return 1;
#endif
   return 0;
}


static Display *open_display()
{
   char *ptr;
   char dispname[MAX_DISP_LEN];
   Display *display;

   if((ptr=getenv("DISPLAY")))
     strcpy(dispname,ptr);
   else
     strcpy(dispname,":0.0");
   
   if(!(display=XOpenDisplay(dispname))){
      fprintf(stderr,"Unable to open display %s\n",dispname);
      exit(1);
   }

#ifdef MITSHM   
   mitshm=1;
#else
   mitshm=0;
#endif
   
   if(mitshm && !is_local_server(dispname)){
      fputs("Disabling MIT-SHM on remote X server\n",stderr);
      mitshm=0;
   }
   return display;
}


static int image_init()
{
#ifdef MITSHM
   if(mitshm){
      ximage=XShmCreateImage(display,DefaultVisual(display,screen),
             DefaultDepth(display,screen),ZPixmap,NULL,&xshminfo,
             hsize,vsize);
      if(!ximage){
         fputs("Couldn't create X image\n",stderr);
         return 1;
      }
      xshminfo.shmid=shmget(IPC_PRIVATE,
               ximage->bytes_per_line*(ximage->height+1),IPC_CREAT|0777);
      if(xshminfo.shmid == -1){
         perror("Couldn't perform shmget");
         return 1;
      }
      xshminfo.shmaddr=ximage->data=shmat(xshminfo.shmid,0,0);
      if(!xshminfo.shmaddr){
         perror("Couldn't perform shmat");
         return 1;
      }
      xshminfo.readOnly=0;
      if(!XShmAttach(display,&xshminfo)){
         perror("Couldn't perform XShmAttach");
         return 1;
      }
      scrn_freq=rrshm;
   } else
#endif
   {
      ximage=XCreateImage(display,DefaultVisual(display,screen),
             DefaultDepth(display,screen),ZPixmap,0,NULL,hsize,vsize,
             8,0);
      if(!ximage){
         perror("XCreateImage failed");
         return 1;
      }
      ximage->data=malloc(ximage->bytes_per_line*(ximage->height+1));
      if(!ximage->data){
         perror("Couldn't get memory for XImage data");
         return 1;
      }
      scrn_freq=rrnoshm;
   }
   linelen=ximage->bytes_per_line/SCALE;
   /* 32 1-bit, 128 4-bit, 256 8-bit, 512 15/16-bit, 768 24-bit, 1024 32-bit */
   if(linelen!=32 && linelen!=128 && linelen!=256 && linelen!=512 &&
      linelen!=768 && linelen!=1024)
      fprintf(stderr,"Line length=%d; expect strange results!\n",linelen);
#if 0
   if(linelen==32 &&
         (BitmapBitOrder(display)!=MSBFirst || ImageByteOrder(display)!=MSBFirst))
      fprintf(stderr,"BitmapBitOrder=%s and ImageByteOrder=%s.\n",
         BitmapBitOrder(display)==MSBFirst?"MSBFirst":"LSBFirst",
         ImageByteOrder(display)==MSBFirst?"MSBFirst":"LSBFirst"),
      fputs("If the display is mixed up, please mail me these values\n",stderr),
      fputs("and describe the display as accurately as possible.\n",stderr);
#endif
   ximage->data+=linelen;
   image=ximage->data;
   
   imagebpp=DefaultDepth(display,screen);
   /* if 24-bit but padded to 32-bit, use the 32-bit code. */
   if(imagebpp==24 && linelen==1024)
     imagebpp=32;
   /* if 4-bit but padded to 8-bit, use 8-bit code. */
   if(imagebpp==4 && linelen==256)
     imagebpp=8;
   
   /* byte order is important for 15/16/24-bit */
   byteorder=ImageByteOrder(display);
   
   /* get bytes which make up black/white to save time later */
   black_bits0to7=(black&255);
   black_bits8to15=((black>>8)&255);
   black_bits16to23=((black>>16)&255);
   black_bits24to31=((black>>24)&255);
   white_bits0to7=(white&255);
   white_bits8to15=((white>>8)&255);
   white_bits16to23=((white>>16)&255);
   white_bits24to31=((white>>24)&255);

#if SCALE>1
   if(imagebpp==1)
     fprintf(stderr,
       "Warning: xz81 doesn't support SCALE>1 in mono, expect oddities!\n");
#endif
   
   return 0;
}


static void notify()
{
   Pixmap icon;
   XWMHints xwmh;
   XSizeHints xsh;
   XClassHint xch;
   XTextProperty appname, iconname;
   char *apptext;
   char *icontext="xz81";

   icon=XCreatePixmapFromBitmapData(display,root,icon_bits,
        icon_width,icon_height,black,white,DefaultDepth(display,screen));
   apptext="xz81";
   xsh.flags=PSize|PMinSize|PMaxSize;
   xsh.min_width=hsize;
   xsh.min_height=vsize;
   xsh.max_width=hsize+BORDER_WIDTH*2;
   xsh.max_height=vsize+BORDER_WIDTH*2;
   if(!XStringListToTextProperty(&apptext,1,&appname)){
      fputs("Can't create a TextProperty!",stderr);
      return;
   }
   if(!XStringListToTextProperty(&icontext,1,&iconname)){
      fputs("Can't create a TextProperty!",stderr);
      return;
   }
   xwmh.initial_state=NormalState;
   xwmh.input=1;
   xwmh.icon_pixmap=icon;
   xwmh.flags=StateHint|IconPixmapHint|InputHint;
   xch.res_name="xz81";
   xch.res_class="Xz81";
   XSetWMProperties(display,borderwin,&appname,&iconname,NULL,0,
      &xsh,&xwmh,&xch);
}


void startup()
{
   display=open_display();
   if(!display){
      fputs("Failed to open X display\n",stderr);
      exit(1);
   }
   invert=0;
   screen=DefaultScreen(display);
   scrptr=DefaultScreenOfDisplay(display);
   root=DefaultRootWindow(display);
   white=WhitePixel(display,screen);
   black=BlackPixel(display,screen);
   maingc=XCreateGC(display,root,0,NULL);
   XCopyGC(display,DefaultGC(display,screen),~0,maingc);
   XSetGraphicsExposures(display,maingc,0);
   fggc=XCreateGC(display,root,0,NULL);
   XCopyGC(display,DefaultGC(display,screen),~0,fggc);
   XSetGraphicsExposures(display,fggc,0);
   bggc=XCreateGC(display,root,0,NULL);
   XCopyGC(display,DefaultGC(display,screen),~0,bggc);
   XSetGraphicsExposures(display,bggc,0);
   cmap=DefaultColormap(display,screen);
   if(image_init()){
      if(mitshm){
         fputs("Failed to create X image - trying again with mitshm off\n",stderr);
         mitshm=0;
         if(image_init())exit(1);
      }
      else exit(1);
   }

   borderwin=XCreateSimpleWindow(display,root,0,0,
             hsize+BORDER_WIDTH*2,vsize+BORDER_WIDTH*2,0,0,0);
   mainwin=XCreateSimpleWindow(display,borderwin,BORDER_WIDTH,
             BORDER_WIDTH,hsize,vsize,0,0,0);
   notify();
   XSelectInput(display,borderwin,KeyPressMask|KeyReleaseMask|
      ExposureMask|VisibilityChangeMask|EnterWindowMask|LeaveWindowMask|
      StructureNotifyMask);
   XMapRaised(display,borderwin);
   XMapRaised(display,mainwin);
   XFlush(display);
   refresh_screen=1;
}


/* x is in chars, y in pixels. d is byte with bitmap in. */
#ifdef INLINE_DRAWPIX
inline
#endif
void drawpix(int x,int y,int d)
{
unsigned char *tmp;
int mask=256;
#if SCALE>1
int j,k,m;
#endif

/* is just me, or was this approach not worth the effort in the end? :-/ */

switch(imagebpp)
  {
  case 32:
    tmp=image+(y*hsize+x*8)*4*SCALE;
    while((mask>>=1))
      {
#if SCALE>1
      for(j=0;j<SCALE;j++,tmp+=(hsize-SCALE)*4)
        for(k=0;k<SCALE;k++)
#endif
          if(byteorder==LSBFirst)
            {
            *tmp++=(d&mask)?black_bits0to7:white_bits0to7;
            *tmp++=(d&mask)?black_bits8to15:white_bits8to15;
            *tmp++=(d&mask)?black_bits16to23:white_bits16to23;
            *tmp++=(d&mask)?black_bits24to31:white_bits24to31;
            }
          else
            {
            *tmp++=(d&mask)?black_bits24to31:white_bits24to31;
            *tmp++=(d&mask)?black_bits16to23:white_bits16to23;
            *tmp++=(d&mask)?black_bits8to15:white_bits8to15;
            *tmp++=(d&mask)?black_bits0to7:white_bits0to7;
            }
#if SCALE>1
      /* we want to move one scaled-up pixel up, then one right */
      tmp-=(hsize*SCALE-SCALE)*4;
#endif
      }
    break;
  
  case 24:
    tmp=image+(y*hsize+x*8)*3*SCALE;
    while((mask>>=1))
      {
#if SCALE>1
      for(j=0;j<SCALE;j++,tmp+=(hsize-SCALE)*3)
        for(k=0;k<SCALE;k++)
#endif
          if(byteorder==LSBFirst)
            {
            *tmp++=(d&mask)?black_bits0to7:white_bits0to7;
            *tmp++=(d&mask)?black_bits8to15:white_bits8to15;
            *tmp++=(d&mask)?black_bits16to23:white_bits16to23;
            }
          else
            {
            *tmp++=(d&mask)?black_bits16to23:white_bits16to23;
            *tmp++=(d&mask)?black_bits8to15:white_bits8to15;
            *tmp++=(d&mask)?black_bits0to7:white_bits0to7;
            }
#if SCALE>1
      /* we want to move one scaled-up pixel up, then one right */
      tmp-=(hsize*SCALE-SCALE)*3;
#endif
      }
    break;
  
  case 15: case 16:
    tmp=image+(y*hsize+x*8)*2*SCALE;
    while((mask>>=1))
      {
#if SCALE>1
      for(j=0;j<SCALE;j++,tmp+=(hsize-SCALE)*2)
        for(k=0;k<SCALE;k++)
#endif
          if(byteorder==LSBFirst)
            {
            *tmp++=(d&mask)?black_bits0to7:white_bits0to7;
            *tmp++=(d&mask)?black_bits8to15:white_bits8to15;
            }
          else
            {
            *tmp++=(d&mask)?black_bits8to15:white_bits8to15;
            *tmp++=(d&mask)?black_bits0to7:white_bits0to7;
            }
#if SCALE>1
      /* we want to move one scaled-up pixel up, then one right */
      tmp-=(hsize*SCALE-SCALE)*2;
#endif
      }
    break;
  
  case 8:
    tmp=image+(y*hsize+x*8)*SCALE;
    while((mask>>=1))
#if SCALE<2
      /* i.e. actual size */
      *tmp++=(d&mask)?black:white;
#else
      {
      m=((d&mask)?black:white);
      for(j=0;j<SCALE;j++)
        for(k=0;k<SCALE;k++)
          tmp[j*hsize+k]=m;
      tmp+=SCALE;
      }
#endif
    break;
  
  /* XXX neither 4-bit nor 1-bit support SCALE>1.
   * XXX also, they might not work on servers with LSBFirst bit order.
   */
  case 4:
    /* XFree86's VGA16 server seems to act like an 8-bit one
     * which mysteriously has hardly any colours ;-), and I don't
     * have access to any other 4-bit server, so this is untested.
     */
    tmp=image+((y*hsize+x*8)>>1);
    while((mask>>=1))
      {
      static int oldmask;
      oldmask=mask; mask>>=1;
      *tmp++=((((d&oldmask)?black:white)<<4)|((d&mask)?black:white));
      }
    break;
  
  default:	/* assume mono */
    image[y*linelen+x]=~d;
  }
}


void drawhelp()
{
int x,y;

if(!refresh_screen) return;

/* we do it the noddy way as speed's not really a concern for this */

for(y=0;y<192;y++)
  for(x=0;x<32;x++)
    drawpix(x,y,helpscrn[y*32+x]);

#ifdef MITSHM
if(mitshm)
  XShmPutImage(display,mainwin,maingc,ximage,0,0,0,0,256*SCALE,192*SCALE,0);
else
#endif
  XPutImage(display,mainwin,maingc,ximage,0,0,0,0,256*SCALE,192*SCALE);

XFlush(display);
refresh_screen=0;
}


void loadhelp()
{
FILE *in;
char buf[128];

if((in=fopen(libdir(zx80?"zx80kybd.pbm":"zx81kybd.pbm"),"rb"))!=NULL)
  {
  /* ditch header lines */
  fgets(buf,sizeof(buf),in);
  fgets(buf,sizeof(buf),in);
  if((helpscrn=calloc(256*192/8,1))==NULL)
    {
    printf("Couldn't allocate memory for help screen.\n");
    exit(1);
    }
  fread(helpscrn,1,256*192/8,in);
  fclose(in);
  }
else
  {
  printf("Couldn't load help screen.\n");
  exit(1);
  }
}


static void process_keypress(kev)
XKeyEvent *kev;
{
   char buf[3];
   KeySym ks;

   XLookupString(kev,buf,2,&ks,NULL);

   switch(ks){
      case XK_F1:
        refresh_screen=1;
        if(help)
          help=0;
        else
          help=1,drawhelp();
        break;
      
      case XK_F10:
        dontpanic(0);
        /* doesn't return */
        break;
      
      case XK_Escape:
        if(!ignore_esc) reset81();
        break;
      
      case XK_Return: 
              keyports[6]&=0xfe; break;
      case XK_Control_L: case XK_Shift_L: case XK_Shift_R:
      case XK_Alt_L: case XK_Alt_R: case XK_Meta_L: case XK_Meta_R:
              keyports[0]&=0xfe; break;
      case XK_BackSpace: case XK_Delete:
      case XK_Tab:
      case XK_Up:
      case XK_Down:
      case XK_Left:
      case XK_Right:
              /* XXX unmapped */ break;
#if 0	/* XXX */
      case XK_minus:
              keyports[8]|=0x02; break;
      case XK_underscore:
              keyports[8]|=0x02; break;
      case XK_equal:
              keyports[7]|=0x01; break;
      case XK_plus:
              keyports[7]|=0x01; break;
      case XK_semicolon:
              keyports[9]|=0x10; break;
      case XK_colon:
              keyports[9]|=0x10; break;
      case XK_apostrophe:
              keyports[8]|=0x10; break;
      case XK_quotedbl:
              keyports[3]|=0x02; break;
      case XK_exclam:
              keyports[2]|=0x04; break;
      case XK_at:
              keyports[8]|=0x10; break;
      case XK_numbersign:
              keyports[6]|=0x10; break;
      case XK_dollar:
              keyports[4]|=0x01; break;
      case XK_percent:
              keyports[1]|=0x40; break;
      case XK_asciicircum:
              keyports[6]|=0x01; break;
      case XK_ampersand:
              keyports[7]|=0x02; break;
      case XK_asterisk:
              keyports[8]|=0x01; break;
      case XK_parenleft:
              keyports[9]|=0x02; break;
      case XK_parenright:
              keyports[9]|=0x01; break;
      case XK_comma:
              keyports[8]|=0x80; break;
      case XK_less:
              keyports[8]|=0x80; break;
      case XK_period:
              keyports[9]|=0x80; break;
      case XK_greater:
              keyports[9]|=0x80; break;
      case XK_slash:
              keyports[6]|=0x20; break;
      case XK_question:
              keyports[6]|=0x20; break;
      case XK_backslash: case XK_bar:
              keyports[7]|=0x04; break;
              break;
#endif
      default:
              if((int)(ks-=32)>=0 && ks<128)
                 keyports[keytable[ks].port]&=keytable[ks].mask;
   }
}


static void process_keyrelease(kev)
XKeyEvent *kev;
{
   char buf[3];
   KeySym ks;

   XLookupString(kev,buf,2,&ks,NULL);

   switch(ks){
      case XK_Return: 
              keyports[6]|=1; break;
      case XK_Control_L: case XK_Shift_L: case XK_Shift_R:
      case XK_Alt_L: case XK_Alt_R: case XK_Meta_L: case XK_Meta_R:
              keyports[0]|=1; break;
      case XK_BackSpace: case XK_Delete:
      case XK_Escape:
      case XK_Tab:
      case XK_Up:
      case XK_Down:
      case XK_Left:
      case XK_Right:
              /* XXX unmapped */ break;
#if 0	/* XXX */
      case XK_minus:
              keyports[8]&=~0x02; break;
      case XK_underscore:
              keyports[8]&=~0x02; break;
      case XK_equal:
              keyports[7]&=~0x01; break;
      case XK_plus:
              keyports[7]&=~0x01; break;
      case XK_semicolon:
              keyports[9]&=~0x10; break;
      case XK_colon:
              keyports[9]&=~0x10; break;
      case XK_apostrophe:
              keyports[8]&=~0x10; break;
      case XK_quotedbl:
              keyports[3]&=~0x02; break;
      case XK_exclam:
              keyports[2]&=~0x04; break;
      case XK_at:
              keyports[8]&=~0x10; break;
      case XK_numbersign:
              keyports[6]&=~0x10; break;
      case XK_dollar:
              keyports[4]&=~0x01; break;
      case XK_percent:
              keyports[1]&=~0x40; break;
      case XK_asciicircum:
              keyports[6]&=~0x01; break;
      case XK_ampersand:
              keyports[7]&=~0x02; break;
      case XK_asterisk:
              keyports[8]&=~0x01; break;
      case XK_parenleft:
              keyports[9]&=~0x02; break;
      case XK_parenright:
              keyports[9]&=~0x01; break;
      case XK_comma:
              keyports[8]&=~0x80; break;
      case XK_less:
              keyports[8]&=~0x80; break;
      case XK_period:
              keyports[9]&=~0x80; break;
      case XK_greater:
              keyports[9]&=~0x80; break;
      case XK_slash:
              keyports[6]&=~0x20; break;
      case XK_question:
              keyports[6]&=~0x20; break;
      case XK_backslash: case XK_bar:
              keyports[7]&=~0x04; break;
              break;
#endif
      default:
              if((int)(ks-=32)>=0 && ks<96)
                 keyports[keytable[ks].port]|=~keytable[ks].mask;
   }
   return;
}


void check_events()
{
   static XEvent xev;
   XConfigureEvent *conf_ev;
   XCrossingEvent *cev;
   
   while (XEventsQueued(display,QueuedAfterReading)){
      XNextEvent(display,&xev);
      switch(xev.type){
         case VisibilityNotify:		/* surely shouldn't need this!? :-( */
         case Expose:
            refresh_screen=1;
            break;
         case ConfigureNotify:
            conf_ev=(XConfigureEvent *)&xev;
            XMoveWindow(display,mainwin,(conf_ev->width-hsize)/2,
                        (conf_ev->height-vsize)/2);
            break;
         case MapNotify: case UnmapNotify: case ReparentNotify:
            break;
         case EnterNotify:
            cev=(XCrossingEvent *)&xev;
            if(cev->detail!=NotifyInferior)
               XAutoRepeatOff(display),XFlush(display);
            break;
         case LeaveNotify:
            cev=(XCrossingEvent *)&xev;
            if(cev->detail!=NotifyInferior)
               XAutoRepeatOn(display),XFlush(display);
            break;
         case KeyPress: process_keypress((XKeyEvent *)&xev);
            break;
         case KeyRelease: process_keyrelease((XKeyEvent *)&xev);
            break;
         default:
            fprintf(stderr,"unhandled X event, type %d\n",xev.type);
      }
   }
}




/* to redraw the (low-res, at least) screen, we translate it into
 * a more normal char. map, then find the smallest rectangle which
 * covers all the changes, and update that.
 */

void update_scrn(){
   unsigned char *ptr,*cptr;
   int x,y,b,c,d,inv;
   int pasteol;
   int xmin,ymin,xmax,ymax;
   int ofs;
     
   if(borderchange>0)
     {
     XSetWindowBackground(display,borderwin,white);
     XClearWindow(display,borderwin);
     XFlush(display);
     borderchange=0;
     }
   
   /* help is drawn via drawhelp (no, really? :-)) */
   if(help)
     {
     drawhelp();
     return;
     }

   /* frustratingly, hi and lo-res modes are sufficiently different to
    * require separate code for each, but similar enough to mean that
    * some code has to be duplicated. :-( (And of course, speed concerns
    * `prevent' us from moving the duplicated code out into a separate
    * function.)
    */
   
   if(hires)
     {
     /* draw hi-res screen */
     ptr=mem+hiscrn;
     
     xmin=31; ymin=23; xmax=0; ymax=0;
     
     ofs=0;
     for(y=0;y<192;y++,ptr++)
       {
       for(x=0;x<32;x++,ptr++,ofs++)
         {
         c=*ptr;
         
         if((himap[ofs]=c)!=himap_old[ofs] || refresh_screen)
           {
           /* update size of area to be drawn */
           if(x<xmin) xmin=x;
           if(y/8<ymin) ymin=y/8;
           if(x>xmax) xmax=x;
           if(y/8>ymax) ymax=y/8;
           
           /* draw byte into image */
           inv=(c&128); c&=63;
           d=iptr[c*8]; if(inv) d^=255;
           drawpix(x,y,d);
           }
         }
       }
     
     /* now, copy new to old for next time */
     memcpy(himap_old,himap,32*192);
     
     /* end of hi-res screen drawing */
     }
   else
     {
     /* draw normal lo-res screen */
     
     /* translate to char map, comparing against previous */
     
     ptr=mem+fetch2(16396);	/* D_FILE */
     
     /* since we can't just do "don't bother if it's junk" as we always
      * need to draw a screen, just draw *valid* junk that won't result
      * in a segfault or anything. :-)
      */
     if(ptr-mem<0 || ptr-mem>0xf000) ptr=mem+0xf000;
     ptr++;	/* skip first HALT */
     
     cptr=mem+0x1e00-zx80*0x1000;	/* char. set */
     
     xmin=31; ymin=23; xmax=0; ymax=0;
     
     ofs=0;
     for(y=0;y<24;y++,ptr++)
       {
       pasteol=0;
       for(x=0;x<32;x++,ptr++,ofs++)
         {
         if(pasteol || (*ptr)==0x76)
           {
           pasteol=1;
           c=0;		/* space */
           ptr--;
           }
         else
           c=*ptr;
         
         if((chrmap[ofs]=c)!=chrmap_old[ofs] || refresh_screen)
           {
           /* update size of area to be drawn */
           if(x<xmin) xmin=x;
           if(y<ymin) ymin=y;
           if(x>xmax) xmax=x;
           if(y>ymax) ymax=y;
           
           /* draw character into image */
           inv=(c&128); c&=63;
           
           for(b=0;b<8;b++)
             {
             d=cptr[c*8+b]; if(inv) d^=255;
             drawpix(x,y*8+b,d);
             }
           }
         }
       }
     
     /* now, copy new to old for next time */
     memcpy(chrmap_old,chrmap,768);
     
     /* end of lo-res screen drawing */
     }

/* next bit happens for both hi and lo-res */

if(refresh_screen) xmin=0,ymin=0,xmax=31,ymax=23;

if(xmax>=xmin && ymax>=ymin)
  {     
#ifdef MITSHM
   if(mitshm)
     XShmPutImage(display,mainwin,maingc,ximage,
       xmin*8*SCALE,ymin*8*SCALE,xmin*8*SCALE,ymin*8*SCALE,
       (xmax-xmin+1)*8*SCALE,(ymax-ymin+1)*8*SCALE,0);
   else
#endif
     XPutImage(display,mainwin,maingc,ximage,
       xmin*8*SCALE,ymin*8*SCALE,xmin*8*SCALE,ymin*8*SCALE,
       (xmax-xmin+1)*8*SCALE,(ymax-ymin+1)*8*SCALE);
  }

XFlush(display);
refresh_screen=0;
}


int main(int argc,char *argv[])
{
parseoptions(argc,argv);

initmem();
startup();
loadhelp();

startsigsandtimer();
mainloop();

/* doesn't ever get here really, but all the same... */
closedown();
exit(0);
}
