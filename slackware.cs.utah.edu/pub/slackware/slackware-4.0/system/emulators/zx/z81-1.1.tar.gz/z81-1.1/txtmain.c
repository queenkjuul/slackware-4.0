/* Z81txt, a text-mode ZX81 emulator for Linux consoles.
 * Copyright (C) 1994 Ian Collier. Z81 changes (C) 1995-8,1998 Russell Marks.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>
#include <termios.h>
#include <sys/ioctl.h>
#include <sys/time.h>
#include <fcntl.h>
#include <unistd.h>
#include "txtrawkey.h"
#include "z80.h"
#include "common.h"
#include "allmain.h"


int hsize=256,vsize=192;

int vcsa_fd=-1;
int scrnwidth=0;


struct termios new_termio,old_termio;


/* using escape sequences for this is a bit odd when I'm using /dev/vcsa0
 * for everything else, but it's so easy... :-)
 */
void screenon()
{
printf("\x1b[H\x1b[J");
/* use IBM chars */
printf("\x1b(U");
/* cursor off */
printf("\x1b[?25l");
fflush(stdout);

/* use cbreak mode and don't echo */
ioctl(0,TCGETS,&old_termio);
new_termio=old_termio;
new_termio.c_iflag=0; /*&=~(IXON|IXOFF);*/
new_termio.c_cflag|=CREAD;
new_termio.c_lflag&=~(ICANON|ISIG|ECHO);
ioctl(0,TCSETSW,&new_termio);
}


void screenoff()
{
/* back to VT100 and norm attrs */
printf("\x1b(B\x1b[0m");
printf("\x1b[H\x1b[J");		/* and cls */
printf("\x1b[?25h");		/* cursor on */
fflush(stdout);
ioctl(0,TCSETSW,&old_termio);
}


void dontpanic(int a)
{
rawmode_exit();
close(vcsa_fd);
screenoff();
exit(1);
}



/* conversion table used by screen drawing routine */
/* only 0-63 - 64-127 unused, 128-191 inverted 0-63, 192-255 unused.
 * pity about the top/bottom greys :-(
 */
static char zx2twochr[64][3]={
/* 000-009 */ "  ", "\337 ", " \337", "\337\337", "\334 ",
              "\333 ", "\334\337", "\333\337", "\261\261", "..",
/* 010-019 */ "''","\" ", "\234 ", "$ ", ": ", "? ", "( ", ") ", "> ", "< ",
/* 020-029 */ "= ", "+ ", "- ", "* ", "/ ", "; ", ", ", ". ", "0 ", "1 ",
/* 030-039 */ "2 ", "3 ", "4 ", "5 ", "6 ", "7 ", "8 ", "9 ", "A ", "B ",
/* 040-049 */ "C ", "D ", "E ", "F ", "G ", "H ", "I ", "J ", "K ", "L ",
/* 050-059 */ "M ", "N ", "O ", "P ", "Q ", "R ", "S ", "T ", "U ", "V ",
/* 060-063 */ "W ", "X ", "Y ", "Z "
};

/* similar table for ZX80 */
static char zx802twochr[64][3]={
/* 000-009 */ "  ", "\" ", "\333 ", "\334\334", "\337 ",
              " \337", "\334 ", " \334", "\334\337", "\261\261",
/* 010-019 */ "..","''","\234 ","$ ", ": ", "? ", "( ", ") ", "- ", "+ ",
/* 020-029 */ "* ", "/ ", "= ", "> ", "< ", "; ", ", ", ". ", "0 ", "1 ",
/* 030-039 */ "2 ", "3 ", "4 ", "5 ", "6 ", "7 ", "8 ", "9 ", "A ", "B ",
/* 040-049 */ "C ", "D ", "E ", "F ", "G ", "H ", "I ", "J ", "K ", "L ",
/* 050-059 */ "M ", "N ", "O ", "P ", "Q ", "R ", "S ", "T ", "U ", "V ",
/* 060-063 */ "W ", "X ", "Y ", "Z "
};

#define ATTR_NORM	(0x70)
#define ATTR_INV	(0x07)

#define MOVEXY(xx,yy)	lseek(vcsa_fd,4+(scrnwidth*(yy)+(xx))*2,0)


/* redraw the screen */
void update_scrn()
{
int x,y,c,inv;
unsigned char *ptr;
int xi;
int pasteol;
unsigned char buf[4];

ptr=mem+fetch2(16396);	/* D_FILE */
/* don't bother if it's junk */
if(ptr-mem<0 || ptr-mem>0xf000) return;
ptr++;	/* skip first HALT */

for(y=0;y<24;y++)
  {
  MOVEXY(8,y);
  pasteol=0;
  for(x=0;x<32;x++)
    {
    if(pasteol || (*ptr)==0x76)
      {
      pasteol=1;
      c=0;	/* space */
      ptr--;
      }
    else
      c=((*ptr)&0xBF);	/* strip bit 6 */
    inv=(c&128); c&=63;
    
#ifdef WHITE_ON_BLACK
    xi=(inv?ATTR_NORM:ATTR_INV);
#else
    xi=(inv?ATTR_INV:ATTR_NORM);
#endif
    if(zx80)
      {
      buf[0]=zx802twochr[c][0];
      buf[2]=zx802twochr[c][1];
      }
    else
      {
      buf[0]=zx2twochr[c][0];
      buf[2]=zx2twochr[c][1];
      }
    buf[1]=buf[3]=xi;
    write(vcsa_fd,buf,4);
    
    ptr++;
    }
  ptr++;
  }
}


/* read keyboard and update keyports[] */
void check_events()
{
int b,y;

for(y=0;y<20;y++) scan_keyboard();	/* bleah */

if(is_key_pressed(ESCAPE_KEY) && !ignore_esc)
  reset81();

if(is_key_pressed(FUNC_KEY(10)))
  {
  while(is_key_pressed(FUNC_KEY(10))) { usleep(20000); scan_keyboard(); };
  dontpanic(0);	/* F10 = quit */
  }

/* (no F1 help key for Z81txt) */

/* ugly, but there's no pleasant way to do this */
/* OTOH, there's definitely a better way than this pile of cack :-) */

/* XXX ideally want to support DEL etc. */

for(y=0;y<8;y++)		/* 8 half-rows */
  {
  b=0;	/* we set bits in b as appropriate */
  switch(y)	/* below comments given in order b1->b5 */
    {
    /* left-hand side */
    case 0:	/* sft,z,x,c,v */
      if(is_key_pressed(LEFT_SHIFT) || is_key_pressed(RIGHT_SHIFT) ||
         is_key_pressed(LEFT_CTRL))
        b|=1;
      if(is_key_pressed(scancode_trans('z'))) b|=2;
      if(is_key_pressed(scancode_trans('x'))) b|=4;
      if(is_key_pressed(scancode_trans('c'))) b|=8;
      if(is_key_pressed(scancode_trans('v'))) b|=16;
      break;
    case 1:	/* a,s,d,f,g */
      if(is_key_pressed(scancode_trans('a'))) b|=1;
      if(is_key_pressed(scancode_trans('s'))) b|=2;
      if(is_key_pressed(scancode_trans('d'))) b|=4;
      if(is_key_pressed(scancode_trans('f'))) b|=8;
      if(is_key_pressed(scancode_trans('g'))) b|=16;
      break;
    case 2:	/* q,w,e,r,t */
      if(is_key_pressed(scancode_trans('q'))) b|=1;
      if(is_key_pressed(scancode_trans('w'))) b|=2;
      if(is_key_pressed(scancode_trans('e'))) b|=4;
      if(is_key_pressed(scancode_trans('r'))) b|=8;
      if(is_key_pressed(scancode_trans('t'))) b|=16;
      break;
    case 3:	/* 1,2,3,4,5 */
      if(is_key_pressed(scancode_trans('1'))) b|=1;
      if(is_key_pressed(scancode_trans('2'))) b|=2;
      if(is_key_pressed(scancode_trans('3'))) b|=4;
      if(is_key_pressed(scancode_trans('4'))) b|=8;
      if(is_key_pressed(scancode_trans('5'))) b|=16;
      break;

    /* right-hand side */
    case 4:	/* 0,9,8,7,6 */
      if(is_key_pressed(scancode_trans('0'))) b|=1;
      if(is_key_pressed(scancode_trans('9'))) b|=2;
      if(is_key_pressed(scancode_trans('8'))) b|=4;
      if(is_key_pressed(scancode_trans('7'))) b|=8;
      if(is_key_pressed(scancode_trans('6'))) b|=16;
      break;
    case 5:	/* p,o,i,u,y */
      if(is_key_pressed(scancode_trans('p'))) b|=1;
      if(is_key_pressed(scancode_trans('o'))) b|=2;
      if(is_key_pressed(scancode_trans('i'))) b|=4;
      if(is_key_pressed(scancode_trans('u'))) b|=8;
      if(is_key_pressed(scancode_trans('y'))) b|=16;
      break;
    case 6:	/* ent,l,k,j,h */
      if(is_key_pressed(ENTER_KEY)) b|=1;
      if(is_key_pressed(scancode_trans('l'))) b|=2;
      if(is_key_pressed(scancode_trans('k'))) b|=4;
      if(is_key_pressed(scancode_trans('j'))) b|=8;
      if(is_key_pressed(scancode_trans('h'))) b|=16;
      break;
    case 7:	/* spc,dot,m,n,b */
      if(is_key_pressed(scancode_trans(' '))) b|=1;
      if(is_key_pressed(scancode_trans('.'))) b|=2;
      if(is_key_pressed(scancode_trans('m'))) b|=4;
      if(is_key_pressed(scancode_trans('n'))) b|=8;
      if(is_key_pressed(scancode_trans('b'))) b|=16;
      break;
    }
  
  keyports[y]=((b^31)|0xe0);	/* some things need top bits to be 1 */
  }
}




int main(int argc,char *argv[])
{
unsigned char c;

if((vcsa_fd=open("/dev/vcsa0",O_RDWR))<0)
  {
  printf("Couldn't open /dev/vcsa0 for writing.\n");
  exit(1);
  }

read(vcsa_fd,&c,1);	/* drop 1st byte (no. lines) */
read(vcsa_fd,&c,1);	/* get no. columns */
scrnwidth=c;

setuid(getuid());
setgid(getgid());

parseoptions(argc,argv);

initmem();

screenon();

rawmode_init();
set_switch_functions(screenoff,screenon);
allow_switch(1);

startsigsandtimer();
mainloop();

rawmode_exit();
close(vcsa_fd);
screenoff();
exit(0);
}
