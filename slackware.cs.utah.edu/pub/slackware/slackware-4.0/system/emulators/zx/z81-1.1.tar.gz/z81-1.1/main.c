/* Z81, a VGA ZX81 emulator for Linux.
 * Copyright (C) 1994 Ian Collier. Z81 changes (C) 1995-6,1998 Russell Marks.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <sys/time.h>
#include <vga.h>
#include <vgakeyboard.h>
#include "z80.h"
#include "common.h"
#include "allmain.h"



int hsize=256,vsize=192;
unsigned char *vptr;


void dontpanic(int a)
{
keyboard_close();
vga_setmode(TEXT);
exit(1);
}


void screenon()
{
vga_setmode(G320x200x256);
memset(vptr,15,320*200);
refresh_screen=1;
}


void screenoff()
{
vga_setmode(TEXT);
}


void loadhelp()
{
FILE *in;
char buf[128];
unsigned char helptmpbmp[256*192/8];
int x,y,i,mask;

if((in=fopen(libdir(zx80?"zx80kybd.pbm":"zx81kybd.pbm"),"rb"))!=NULL)
  {
  /* ditch header lines */
  fgets(buf,sizeof(buf),in);
  fgets(buf,sizeof(buf),in);
  if((helpscrn=calloc(320*200,1))==NULL)
    {
    printf("Couldn't allocate memory for help screen.\n");
    exit(1);
    }
  fread(helptmpbmp,1,256*192/8,in);
  fclose(in);
  }
else
  {
  printf("Couldn't load help screen.\n");
  exit(1);
  }

for(y=0;y<192;y++)
  for(x=0;x<32;x++)
    {
    for(i=0,mask=128;i<8;i++,mask>>=1)
      helpscrn[(y+4)*320+32+x*8+i]=(helptmpbmp[y*32+x]&mask)?0:15;
    }
}


void drawhelp()
{
memcpy(vptr,helpscrn,320*200);
}


/* draw "hi-res" screen */
void drawhires()
{
int x,y,c,d,inv,mask,a,ofs;
unsigned char *tmp,*ptr;

ptr=mem+hiscrn;

ofs=0;
for(y=0;y<192;y++,ptr++)
  {
  for(x=0;x<32;x++,ptr++,ofs++)
    {
    c=*ptr;
    
    if((himap[ofs]=c)!=himap_old[ofs] || refresh_screen)
      {
      inv=(c&128); c&=63;
      
      tmp=vptr+4*320+32+y*320+x*8;
      d=iptr[c*8]; if(inv) d^=255;
      mask=128;
      for(a=0;a<8;a++,mask>>=1)
        *tmp++=(d&mask)?0:15;
      }
    }
  }

/* now, copy new to old for next time */
memcpy(himap_old,himap,32*192);
refresh_screen=0;
}


/* redraw the screen */
void update_scrn()
{
int x,y,a,b,c,d,inv,mask;
unsigned char *ptr,*cptr,*tmp;
int pasteol;
int ofs;

/* only if not showing help screen */
if(help) return;

if(hires)
  {
  drawhires();
  return;
  }

ptr=mem+fetch2(16396);	/* D_FILE */
/* don't bother if it's junk */
if(ptr-mem<0 || ptr-mem>0xf000) return;
ptr++;	/* skip first HALT */

cptr=mem+0x1e00-zx80*0x1000;

ofs=0;
for(y=0;y<24;y++,ptr++)
  {
  pasteol=0;
  for(x=0;x<32;x++,ptr++,ofs++)
    {
    if(pasteol || (*ptr)==0x76)
      {
      pasteol=1;
      c=0;	/* space */
      ptr--;
      }
    else
      c=*ptr;
    
    if((chrmap[ofs]=c)!=chrmap_old[ofs] || refresh_screen)
      {
      inv=(c&128); c&=63;
      
      for(b=0;b<8;b++)
        {
        tmp=vptr+4*320+32+(y*8+b)*320+x*8;
        d=cptr[c*8+b]; if(inv) d^=255;
        mask=128;
        for(a=0;a<8;a++,mask>>=1)
          *tmp++=(d&mask)?0:15;
        }
      }
    }
  }

/* now, copy new to old for next time */
memcpy(chrmap_old,chrmap,768);
refresh_screen=0;
}


/* read keyboard and update keyports[] */
void check_events()
{
int b,y;
char *keymap=keyboard_getstate();

keyboard_update();

if(keyboard_keypressed(SCANCODE_ESCAPE) && !ignore_esc)
  reset81();

if(keyboard_keypressed(SCANCODE_F10))
  {
  while(keyboard_keypressed(SCANCODE_F10)) usleep(20000),keyboard_update();
  dontpanic(0);	/* F10 = quit */
  }

if(keyboard_keypressed(SCANCODE_F1))
  {
  if(help)
    memset(vptr,15,320*200),help=0,refresh_screen=1;
  else
    drawhelp(),help=1;
  while(keyboard_keypressed(SCANCODE_F1)) usleep(20000),keyboard_update();
  }

/* ugly, but there's no pleasant way to do this */

/* XXX ideally want to support DEL etc. */

for(y=0;y<8;y++)		/* 8 half-rows */
  {
  b=0;	/* we set bits in b as appropriate */
  switch(y)	/* below comments given in order b1->b5 */
    {
    /* left-hand side */
    case 0:	/* sft,z,x,c,v */
      if(keymap[SCANCODE_LEFTSHIFT] ||
         keymap[SCANCODE_RIGHTSHIFT] ||
         keymap[SCANCODE_LEFTCONTROL] ||
         keymap[SCANCODE_RIGHTCONTROL])
        b|=1;
      if(keymap[SCANCODE_Z]) b|=2;
      if(keymap[SCANCODE_X]) b|=4;
      if(keymap[SCANCODE_C]) b|=8;
      if(keymap[SCANCODE_V]) b|=16;
      break;
    case 1:	/* a,s,d,f,g */
      if(keymap[SCANCODE_A]) b|=1;
      if(keymap[SCANCODE_S]) b|=2;
      if(keymap[SCANCODE_D]) b|=4;
      if(keymap[SCANCODE_F]) b|=8;
      if(keymap[SCANCODE_G]) b|=16;
      break;
    case 2:	/* q,w,e,r,t */
      if(keymap[SCANCODE_Q]) b|=1;
      if(keymap[SCANCODE_W]) b|=2;
      if(keymap[SCANCODE_E]) b|=4;
      if(keymap[SCANCODE_R]) b|=8;
      if(keymap[SCANCODE_T]) b|=16;
      break;
    case 3:	/* 1,2,3,4,5 */
      if(keymap[SCANCODE_1]) b|=1;
      if(keymap[SCANCODE_2]) b|=2;
      if(keymap[SCANCODE_3]) b|=4;
      if(keymap[SCANCODE_4]) b|=8;
      if(keymap[SCANCODE_5]) b|=16;
      break;

    /* right-hand side */
    case 4:	/* 0,9,8,7,6 */
      if(keymap[SCANCODE_0]) b|=1;
      if(keymap[SCANCODE_9]) b|=2;
      if(keymap[SCANCODE_8]) b|=4;
      if(keymap[SCANCODE_7]) b|=8;
      if(keymap[SCANCODE_6]) b|=16;
      break;
    case 5:	/* p,o,i,u,y */
      if(keymap[SCANCODE_P]) b|=1;
      if(keymap[SCANCODE_O]) b|=2;
      if(keymap[SCANCODE_I]) b|=4;
      if(keymap[SCANCODE_U]) b|=8;
      if(keymap[SCANCODE_Y]) b|=16;
      break;
    case 6:	/* ent,l,k,j,h */
      if(keymap[SCANCODE_ENTER]) b|=1;
      if(keymap[SCANCODE_L]) b|=2;
      if(keymap[SCANCODE_K]) b|=4;
      if(keymap[SCANCODE_J]) b|=8;
      if(keymap[SCANCODE_H]) b|=16;
      break;
    case 7:	/* spc,dot,m,n,b */
      if(keymap[SCANCODE_SPACE]) b|=1;
      if(keymap[SCANCODE_PERIOD]) b|=2;
      if(keymap[SCANCODE_M]) b|=4;
      if(keymap[SCANCODE_N]) b|=8;
      if(keymap[SCANCODE_B]) b|=16;
      break;
    }
  
  keyports[y]=((b^31)|0xe0);	/* some things need top bits to be 1 */
  }
}



int main(int argc,char *argv[])
{
vga_init();

parseoptions(argc,argv);

initmem();
loadhelp();

vga_setmode(G320x200x256);
vptr=vga_getgraphmem();
screenon();
keyboard_init();
keyboard_translatekeys(DONT_CATCH_CTRLC);

startsigsandtimer();
mainloop();

keyboard_close();
vga_setmode(TEXT);
exit(0);
}
