/* Z81, a VGA ZX81 emulator for Linux.
 * Copyright (C) 1994 Ian Collier. Z81 changes (C) 1995-6,1998 Russell Marks.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *
 * common.c - various routines/vars common to Z81/Z81txt/xz81.
 *		yanked out of {,x,txt}main.c to give the code
 *		some semblance of sanity.
 */

#define Z81_VER		"1.1"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#ifdef SELECTOR
#include <sys/types.h>
#include <dirent.h>
#endif
#include <sys/time.h>
#include "z80.h"
#include "common.h"
#include "allmain.h"

unsigned char mem[65536],*helpscrn;
unsigned char *memptr[4]={mem,mem+0x4000,mem+0x8000,mem+0xc000};
unsigned char *iptr=mem;
unsigned char keyports[9]={0xff,0xff,0xff,0xff, 0xff,0xff,0xff,0xff, 0xff};
unsigned long tstates=0,tsmax=(1<<30);
int hires=0,hiscrn;
int help=0;
int memattr[4]={0,2,1,1};

int screen_dirty;
volatile int interrupted=0;
int forcejp=0;
int scrn_freq=2;
int booting=1;
int input_wait=0;
int fastboot=1;

unsigned char chrmap_old[24*32],chrmap[24*32];
unsigned char himap_old[192*32],himap[192*32];

int refresh_screen=1;

/* =1 if emulating ZX80 rather than ZX81 */
int zx80=0;

int autoload=0,autoload_failed=0;
char autoload_filename[1024];

int ignore_esc=0;


/* not too many prototypes needed... :-) */
char *load_selector();



void sighandler(int a)
{
if(interrupted<2) interrupted=1;
}


char *libdir(char *file)
{
static char buf[1024];
sprintf(buf,"%s/%s",LIBDIR,file);
return(buf);
}


void autoload_setup(char *filename)
{
if(zx80) return;
autoload=1;
strcpy(autoload_filename,filename);
}


void startsigsandtimer()
{
struct sigaction sa;
struct itimerval itv;
int tmp=1000/50;	/* 50 ints/sec */

sigemptyset(&sa.sa_mask);
sa.sa_handler=dontpanic;
sa.sa_flags=SA_ONESHOT;

sigaction(SIGINT, &sa,NULL);
sigaction(SIGHUP, &sa,NULL);
sigaction(SIGILL, &sa,NULL);
sigaction(SIGTERM,&sa,NULL);
sigaction(SIGQUIT,&sa,NULL);
sigaction(SIGSEGV,&sa,NULL);

sa.sa_handler=sighandler;
sa.sa_flags=SA_RESTART;

sigaction(SIGALRM,&sa,NULL);

itv.it_interval.tv_sec=  tmp/1000;
itv.it_interval.tv_usec=(tmp%1000)*1000;
itv.it_value.tv_sec=itv.it_interval.tv_sec;
itv.it_value.tv_usec=itv.it_interval.tv_usec;
setitimer(ITIMER_REAL,&itv,NULL);
}


void loadrom(unsigned char *x)
{
FILE *in;

if((in=fopen(libdir(zx80?"zx80.rom":"zx81.rom"),"rb"))!=NULL)
  {
  int siz=(zx80?4096:8192);
  fread(x,1,siz,in);
  /* fill up rest of first 16k with extra copies of it */
  memcpy(x+siz,x,siz);
  if(zx80)
    memcpy(x+siz*2,x,siz*2);
  fclose(in);
  }
else
  {
  printf("Couldn't load ROM. (Have you done `make install' yet?)\n");
  exit(1);
  }
}


void do_fastboot()
{
static unsigned char bit1[32]=
  {
  0xFF,0x01,0xFC,0x7F,0x00,0x80,0x00,0x00,
  0x00,0x00,0x00,0x00,0x7D,0x40,0x96,0x43,
  0x96,0x43,0x00,0x00,0x97,0x43,0x99,0x43,
  0x00,0x00,0x99,0x43,0x99,0x43,0xFF,0x00
  };
static unsigned char bit2[20]=
  {
  0x98,0x43,0x94,0x43,
  0x93,0x00,0x00,0x08,0x00,0x00,0x00,0x08,
  0x00,0x08,0x00,0x00,0x97,0x04,0x00,0x3E
  };
int f;

memset(mem+0x4000,0,0x4000);
forcejp=0x4c7;
memcpy(mem+0x4000,bit1,32);	/* copy 4000h-401fh */
memcpy(mem+0x7fec,bit2,20);	/* copy 7fech-7fffh */
mem[0x4022]=0x02; mem[0x4039]=0x21; mem[0x403b]=0x80;
for(f=0;f<25;f++) mem[0x407d+f*33]=0x76;
mem[0x4375]=0xb0;
mem[0x4396]=0x80; mem[0x4397]=0x7f; mem[0x4398]=0x76;
input_wait=1;
}


void zx81hacks()
{
/* remove fast mode stuff which screws it all up */
mem[0x4cc]=mem[0x4cd]=mem[0x4ce]=0;

/* replace kybd routine itself, with ld hl,(lastk):ret */
mem[0x2bb]=0x2a; mem[0x2bc]=0x25; mem[0x2bd]=0x40; mem[0x2be]=0xc9;

/* a `force F/0' at 66h; ok, as we simulate NMI effects by other means */
mem[0x66]=0xcf; mem[0x67]=0x0e;

/* patch save routine */
mem[0x2fc]=0xed; mem[0x2fd]=0xfd;
mem[0x2fe]=0xc3; mem[0x2ff]=0x07; mem[0x300]=0x02;

/* patch load routine */
mem[0x347]=0xeb;
mem[0x348]=0xed; mem[0x349]=0xfc;
mem[0x34a]=0xc3; mem[0x34b]=0x07; mem[0x34c]=0x02;

/* make fast/slow more traceable (directly modify bit 7 rather than
 * bit 6 of CDFLAGS)
 */
mem[0xf29]=0xbe;
mem[0xf2e]=0xfe;

/* do `out (0),a' when waiting for input (for fast mode display check) */
mem[0x4ca]=0xd3; mem[0x4cb]=0;			/* out (0),a */
mem[0x4cc]=0xcb; mem[0x4cd]=0x46;		/* loop: bit 0,(hl) */
mem[0x4ce]=0x28; mem[0x4cf]=0xfc;		/* jr z,loop */
mem[0x4d0]=0xd3; mem[0x4d1]=1;			/* out (1),a */
mem[0x4d2]=0;	/* nop, as filler */

/* skip some more weird fast mode stuff */
mem[0x2ec]=0xc9;

/* we need the following crock to support `PAUSE'... */

mem[0xf3b]=0x29;	/* call 0229h */

mem[0x229]=0x22;	/* ld (04034h),hl:nop */
mem[0x22c]=0;

mem[0x23e]=0x2a; mem[0x23f]=0x25; mem[0x240]=0x40;	/* ld hl,(0403bh) */
mem[0x241]=0x23;					/* inc hl */
mem[0x242]=0x3e; mem[0x243]=0x7f;			/* ld a,07fh */
mem[0x244]=0xa4;					/* and h */
mem[0x245]=0xb5;					/* or l */
mem[0x246]=0xc0;					/* ret nz */

mem[0x247]=0x2a;	/* ld hl,(04034h) */
mem[0x248]=0x34;
mem[0x249]=0x40;

mem[0x24a]=0xc3;	/* jp 022dh */
mem[0x24b]=0x2d;
mem[0x24c]=0x02;

/* nop out ld (04034h),hl */
mem[0x23a]=0; mem[0x23a]=0; mem[0x23a]=0;

/* nop out call to 207h */
mem[0xf41]=0; mem[0xf42]=0; mem[0xf43]=0;

/* if booting quickly, put booted-zx81 snapshot in place */
if(fastboot) do_fastboot();
}


void zx80hacks()
{
/* patch save routine */
mem[0x1b6]=0xed; mem[0x1b7]=0xfd;
mem[0x1b8]=0xc3; mem[0x1b9]=0x83; mem[0x1ba]=0x02;

/* patch load routine */
mem[0x206]=0xed; mem[0x207]=0xfc;
mem[0x208]=0xc3; mem[0x209]=0x83; mem[0x20a]=0x02;
}


void initmem()
{
loadrom(mem);
memset(mem+0x4000,0,0x4000);
memset(mem+0x8000,0xff,0x8000);
memset(chrmap_old,0xff,768);
if(zx80)
  zx80hacks();
else
  zx81hacks();
}


unsigned int in(int h,int l)
{
if(l==0xfe)	/* keyboard */
  switch(h)
    {
    case 0xfe:	return(keyports[0]);
    case 0xfd:	return(keyports[1]);
    case 0xfb:	return(keyports[2]);
    case 0xf7:	return(keyports[3]);
    case 0xef:	return(keyports[4]);
    case 0xdf:	return(keyports[5]);
    case 0xbf:	return(keyports[6]);
    case 0x7f:	return(keyports[7]);
    default:
      {
      int i,mask,retval=0xff;
      
      /* some games (e.g. ZX Galaxians) do smart-arse things
       * like zero more than one bit. What we have to do to
       * support this is and together any for which the corresponding
       * bit is zero.
       */
      for(i=0,mask=0x80;i<8;i++,mask>>=1)
        if(!(h&mask))
          retval&=keyports[i];
      return(retval);
      }
    }

fprintf(stderr," in l=%02X\n",l);
return(255);
}


unsigned int out(int h,int l,int a)
{
if(zx80) return(0);	/* none on that yet... */

if(l==0xfd)
  store(16443,128|fetch(16443)); /* i.e. set slow mode */
if(l==0x00) input_wait=1;	/* waiting for input */
if(l==0x01) input_wait=0;	/* not waiting for input :-) */

if(autoload && input_wait)
  {
  /* machine has booted up - do auto-loading now.
   * (This is admittedly rather kludgey...)
   */
  load_p(-1);
  autoload=0;
  if(autoload_failed)
    return(0);
  store(0x4001,0x80);
  store2(0x4007,0xfffe);
  store2(0x7ffc,0x0676);
  store2(0x7ffe,0x3e00);
  forcejp=0x5b;
  }

return(0);
}


void hireschk(int ix)
{
if(zx80) return;

refresh_screen=1;

if(ix<0x4000)
  hires=0;
else
  {
  int f,g,v;
  
  /* now try to find the hi-res screen.
   * we do this by looking for somewhere in ram where there
   * are 192 suitably-spaced EOL chars. The EOL char could theoretically be
   * a few different things, so we just test that it's the same.
   * this is SLOW, but it doesn't matter; this'll only need to
   * happen once, when the hi-res screen is set up.
   *
   * (um, ok, it's a little different now; I just kept hacking until
   * it worked with all three hi-res programs I tried it on :-))
   */
   
  for(f=0x8000-6400;f>=0x4000;f--)
    {
    v=mem[f+32];
    if((v&64)==0) continue;
    hires=1;
    for(g=0;g<192 && hires;g++)
      {
      if(mem[f+33*g]&64) hires=0;
      if(mem[f+32+33*g]!=v) hires=0;
      }
    if(hires)
      {
      hiscrn=f;
      return;
      }
    }
  }
}


void hireschki(int i)
{
iptr=mem+(i<<8);
}


/* the ZX81 char is used to index into this, to give the ascii.
 * awkward chars are mapped to '_' (underscore), and the ZX81's
 * all-caps is converted to lowercase.
 * The mapping is also valid for the ZX80 for alphanumerics.
 * WARNING: this only covers 0<=char<=63!
 */
static char zx2ascii[64]={
/*  0- 9 */ ' ', '_', '_', '_', '_', '_', '_', '_', '_', '_', 
/* 10-19 */ '_', '\'','#', '$', ':', '?', '(', ')', '>', '<', 
/* 20-29 */ '=', '+', '-', '*', '/', ';', ',', '.', '0', '1', 
/* 30-39 */ '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 
/* 40-49 */ 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 
/* 50-59 */ 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 
/* 60-63 */ 'w', 'x', 'y', 'z'
};


void save_p(int a)
{
static char fname[128];
unsigned char *ptr=mem+a,*dptr=fname;
FILE *out;

if(zx80)
  strcpy(fname,"zx80prog.p");
else
  {
  /* so the filename is at ptr, in the ZX81 char set, with the last char
   * having bit 7 set. First, get that name in ASCII.
   */
  
  memset(fname,0,sizeof(fname));
  do
    *dptr++=zx2ascii[(*ptr)&63];
  while((*ptr++)<127);
  
  /* add '.p' */
  strcat(fname,".p");
  }

/* now open the file */
if((out=fopen(fname,"wb"))==NULL)
  {
  if(!zx80) forcejp=0x66;
  return;
  }

/* work out how much to write, and write it.
 * we need to write from 0x4009 (0x4000 on ZX80) to E_LINE inclusive.
 */
if(zx80)
  fwrite(mem+0x4000,1,fetch2(16394)-0x4000+1,out);
else
  fwrite(mem+0x4009,1,fetch2(16404)-0x4009+1,out);

fclose(out);
}


void load_p(int a)
{
static char fname[256];
unsigned char *ptr=mem+(a&32767),*dptr=fname;
FILE *in;

if(zx80)
  strcpy(fname,"zx80prog.p");
else
  {
  if(a>=32768) 	/* they did LOAD "" */
    {
    char *ret=load_selector();
    
    if(ret==NULL)
      {
      forcejp=0x66;
      return;
      }
    else
      {
      strcpy(fname,ret);
      goto got_ascii_name;	/* you ain't seen me, right? */
      }
    }
  
  /* so the filename is at ptr, in the ZX81 char set, with the last char
   * having bit 7 set. First, get that name in ASCII.
   */
  
  if(a==-1)
    {
    /* called by autoload stuff, so filename's autoload_filename
     * and is ascii already.
     */
    strcpy(fname,autoload_filename);
    
    /* strip off any .p, as we add it below */
    if(strlen(fname)>=2 && strcmp(fname+strlen(fname)-2,".p")==0)
      fname[strlen(fname)-2]=0;
    }
  else
    {
    /* test for Xtender-style LOAD " STOP " to quit */
    if(*ptr==227) dontpanic(0);
    
    memset(fname,0,sizeof(fname));
    do
      *dptr++=zx2ascii[(*ptr)&63];
    while((*ptr++)<127);
    }
  
  /* add '.p' */
  strcat(fname,".p");
  }

got_ascii_name:
/* now open the file */
if((in=fopen(fname,"rb"))==NULL)
  {
  if(!zx80 && !autoload) forcejp=0x66;
  if(autoload) autoload_failed=1;
  return;
  }

/* just read it all */
fread(mem+(zx80?0x4000:0x4009),1,16384,in);

fclose(in);

/* don't ask me why, but the ZX80 ROM load routine does this if it
 * works...
 */
if(zx80)
  store(0x400b,fetch(0x400b)+1);
}


void fix_tstates()
{
tstates=0;
pause();
}


void update_kybd()
{
int y,b;
int lastk0=0,lastk1=0;	/* values for lastk and lastk+1 */
static int oldlk0=0,oldlk1=0;
int f;

/* bump frames */
if(!zx80)
  {
  /* frames goes down on zx81 (so to speak :-)) */
  f=(fetch2(16436)&32767);
  if(f>0) f--;
  store2(16436,(fetch2(16436)&32768)|f);
  }

/* set max T-states per 1/50th to get the right speed */
if(!zx80 && (fetch(16443)&128))
  {
  /* slow mode - 0.8 MHz, 16000 T-states per 1/50th */
  tsmax=16000;
  }
else
  {
  /* fast mode - 3.2 MHz, 64000 T-states per 1/50th */
  tsmax=64000;
  }

/* fix top bits of key ports, and generate lastk */

for(y=0;y<8;y++)		/* 8 half-rows */
  {
  b=(keyports[y]|=0xe0);
  
  /* contribute to lastk if key was pressed */
  if((b&31)!=31)
    {
    /* set y bit in lastk0 if not shift */
    if(!(y==0 && ((b&31)|1)==31)) lastk0|=(1<<y);
    
    /* now set pos-in-half-row bit(s) in lastk1 */
    b=(((~b)&31)<<1);
    /* move bit 1 of b back down to bit 0 if it's shift bit */
    if(y==0) b=((b&0xfc)|((b&2)>>1));
  
    lastk1|=b;
    }
  }

if(!zx80)	/* no LAST_K on ZX80 (!) (nor MARGIN) */
  {
  /* see if this is different to prev. lastk[01] */
  store(16443,(fetch(16443)&0xfe)|
  	((((lastk1&0xfe)|lastk0) && (oldlk0!=lastk0 || oldlk1!=lastk1))?1:0));
  
  oldlk0=lastk0; oldlk1=lastk1;
  
  /* fix lastk values */
  lastk0^=255; lastk1^=255;
  
  /* put lastk stuff in place */
  store(16421,lastk0);
  store(16422,lastk1);
  
  /* and FWIW, set MARGIN */
  store(16424,55);
  }
}


void do_interrupt()
{
static int count=0;

if(zx80) booting=0;

if(booting)
  if(input_wait)
    booting=0;
  else
    return;

/* only do screen update every 1/Nth */
count++;
if(count>=scrn_freq)
  count=0,update_scrn();
check_events();	/* on X checks events, on VGA/txt scans kybd */

/* being careful here not to screw up any pending reset... */
if(interrupted==1)
  {
  update_kybd();
  interrupted=0;
  }
}


/* despite the name, this also works for the ZX80 */
void reset81()
{
interrupted=2;	/* will cause a reset */
memset(mem+16384,0xff,49152);
iptr=mem;
tsmax=(1<<30);
hires=0; refresh_screen=1;
booting=1; input_wait=0;
if(!zx80 && fastboot) do_fastboot();
}


void usage_help(char *cmd)
{
printf("Z81 v%s - (c) 1995-1998 Russell Marks for improbabledesigns.\n\n",
		Z81_VER);
printf("usage: %s [-ho] [-r refresh_rate] [filename.p]\n",cmd);
printf("\

	-h	this usage help.
	-o	emulate `old ROM' machine, i.e. emulate a ZX80.
	-r	set how often the screen is redrawn in 1/50ths of a second.
	-s	boot (ZX81) more slowly by actually going through the
        	boot-up procedure rather than using a booted-machine snapshot.

	filename.p	load the specified program on startup.
");
}


void parseoptions(int argc,char *argv[])
{
int done=0;

opterr=0;

do
  switch(getopt(argc,argv,"hor:s"))
    {
    case 'h':
      usage_help(argv[0]);
      exit(1);
    case 'o':	/* old rom machine, i.e. ZX80 */
      zx80=1;
      break;
    case 'r':	/* refresh rate */
      scrn_freq=atoi(optarg);
      if(scrn_freq<1) scrn_freq=1;
      if(scrn_freq>50) scrn_freq=50;
      break;
    case 's':
      fastboot=0;
      break;
    case '?':
      switch(optopt)
        {
        case 'r':
          fprintf(stderr,"The -r option needs a refresh rate as argument.\n");
          break;
        default:
          fprintf(stderr,"Option `%c' not recognised.\n",optopt);
        }
      exit(1);
    case -1:
      done=1;
    }
while(!done);

if(optind==argc-1)	/* if a filename given... */
  if(!zx80)
    autoload_setup(argv[optind]);
}



#ifdef SELECTOR
static char ascii2zx[96]=
  {
   0, 0,11,12,13, 0, 0,11,16,17,23,21,26,22,27,24,
  28,29,30,31,32,33,34,35,36,37,14,25,19,20,18,15,
  23,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,
  53,54,55,56,57,58,59,60,61,62,63,16,24,17,11,22,
  11,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,
  53,54,55,56,57,58,59,60,61,62,63,16,24,17,11, 0
  };


void draw_files(unsigned char *scrn,int top,int cursel,int numfiles,
	char *filearr,int elmtsiz)
{
int x,y,n,xor,c,len;
unsigned char *sptr;

/* since this is quick and easy (and incrementally updated for us :-)),
 * we redraw each time no matter what.
 */

/* clear filenames area */
for(y=3;y<21;y++)
  memset(scrn+1+y*33+1,0,30);

n=top;
for(y=3;y<21;y++,n++)
  {
  if(n>=numfiles) break;
  xor=128*(n==cursel);
  sptr=scrn+1+y*33+1;
  len=strlen(filearr+elmtsiz*n);
  if(len>30) len=30;
  for(x=0;x<len;x++)
    {
    c=(filearr+elmtsiz*n)[x]-32;
    if(c<0 || c>95) c=0;
    c=ascii2zx[c];
    *sptr++=(c^xor);
    }
  }
}


void draw_load_frame(unsigned char *scrn)
{
int x,y;
unsigned char *sptr=scrn+1;
/* these must be exactly 32 chars long */
/*           01234567890123456789012345678901 */
char *text1="    choose a program to load    ";
char *text2=" q=up a=dn enter=load spc=abort ";

memset(sptr,131,32);
sptr[33*2]=7;
memset(sptr+33*2+1,3,30);
sptr[33*2+31]=132;
for(y=3;y<21;y++)
  sptr[33*y]=5,sptr[33*y+31]=133;
sptr[33*21]=130;
memset(sptr+33*21+1,131,30);
sptr[33*21+31]=129;
for(x=0;x<32;x++)
  {
  sptr[33   +x]=128+ascii2zx[text1[x]-32];
  sptr[33*22+x]=128+ascii2zx[text2[x]-32];
  }
memset(sptr+33*23,3,32);
}


char *load_selector()
{
static char returned_filename[256];
static unsigned char old_e000_contents[1024];
unsigned char *scrn=mem+0xe000;
int old_dfile=fetch2(16396);	/* D_FILE */
int y,f,height=18;
char *files=NULL;
int files_size=0x4000,files_incr=0x2000;
DIR *dirfile;
int files_ofs=0;
int numfiles=0;
struct dirent *entry;
int len,maxlen=-1;
int top=0,cursel=0;
int quit=0,got_one=0;
char *filearr;
char *ptr;
int krwait=25,krwrep=3;	/* wait before key rpt and wait before next rpt */
int krheld=0,krsubh=0;
int oldkey,key,virtkey;

/* should never get here if emulating ZX80, but FWIW... */
if(zx80) return(NULL);

ignore_esc=1;		/* avoid possibility of esc screwing things up */

if((dirfile=opendir("."))==NULL)
  {
  fprintf(stderr,"couldn't read current directory!\n");
  ignore_esc=0;
  return(NULL);
  }

if((files=malloc(files_size))==NULL)
  {
  fprintf(stderr,"not enough memory for file selector!\n");
  ignore_esc=0;
  return(NULL);
  }

/* save old contents of e000h-e3ffh and setup screen there */
memcpy(old_e000_contents,scrn,1024);
memset(scrn,0,33*24);
for(y=0;y<25;y++) scrn[y*33]=0x76;
store2(16396,0xe000);

/* read list of .p files */
while((entry=readdir(dirfile))!=NULL)
  {
  /* better to test for both than require strcasecmp I s'pose */
  if((len=strlen(entry->d_name))>2 &&
     (strcmp(entry->d_name+len-2,".p")==0 ||
      strcmp(entry->d_name+len-2,".P")==0))
    {
    /* make array of filenames bigger if needed */
    if(files_ofs+len+1>=files_size)
      {
      files_size+=files_incr;
      if((files=realloc(files,files_size))==NULL)
        {
        memcpy(scrn,old_e000_contents,1024);
        store2(16396,old_dfile);
        fprintf(stderr,"not enough memory for file selector!\n");
        ignore_esc=0;
        return(NULL);
        }
      }
    
    /* copy filename */
    strcpy(files+files_ofs,entry->d_name);
    files_ofs+=len+1;
    if(len+1>maxlen) maxlen=len+1;
    numfiles++;
    }
  }

closedir(dirfile);

/* have to put them into something more like a normal array to
 * use qsort...
 */

if(numfiles==0 || (filearr=malloc(maxlen*numfiles))==NULL)
  {
  memcpy(scrn,old_e000_contents,1024);
  store2(16396,old_dfile);
  free(files);
  if(numfiles!=0)
    fprintf(stderr,"not enough memory for file selector!\n");
  ignore_esc=0;
  return(NULL);
  }

/* copy filenames */
ptr=files;
for(f=0;f<numfiles;f++)
  {
  strcpy(filearr+maxlen*f,ptr);
  ptr+=strlen(ptr)+1;
  }

free(files);

/* and sort */
qsort(filearr,numfiles,maxlen,(int (*)(const void *,const void *))strcmp);


/* now do the file selector stuff */

draw_load_frame(scrn);	/* draw everything apart from files list */

oldkey=-1;
while(!quit && !got_one)
  {
  draw_files(scrn,top,cursel,numfiles,filearr,maxlen);
  
  fix_tstates();
  do_interrupt();
  
  key=fetch2(16421);	/* LAST_K */
  
  /* auto-repeat stuff */
  virtkey=key;
  if(key!=oldkey)
    krheld=0,krsubh=0;
  else
    {
    krheld++;
    if(krheld<krwait)
      virtkey=-1;
    else
      if(krheld>krwait)
        {
        krsubh++;
        if(krsubh<krwrep)
          virtkey=-1;
        else
          krsubh=0;
        }
    }
  
  switch(virtkey)
    {
    case 0xfdfb:	/* q */
      cursel--; break;
    case 0xfdfd:	/* a */
      cursel++; break;
    case 0xfdbf:	/* enter */
      got_one=1; break;
    case 0xfd7f:	/* space */
      quit=1; break;
    }
  if(cursel<0) cursel=0;
  if(cursel>=numfiles) cursel=numfiles-1;
  if(cursel<top) top--;
  if(cursel>=top+height) top++;
  
  oldkey=key;
  }

memcpy(scrn,old_e000_contents,1024);
store2(16396,old_dfile);
if(got_one)
  strcpy(returned_filename,filearr+cursel*maxlen);
free(filearr);
store(16443,fetch(16443)&0xfe);		/* use up last key */
ignore_esc=0;
if(quit) return(NULL);
return(returned_filename);
}

#else	/* !SELECTOR */

char *load_selector()
{
return(NULL);
}

#endif	/* !SELECTOR */
