/* Z81, a VGA ZX81 emulator for Linux.
 * Copyright (C) 1994 Ian Collier. Z81 changes (C) 1995-6 Russell Marks.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *
 * common.h - prototypes etc. for common.c.
 */

extern unsigned char mem[],*helpscrn;
extern unsigned char *memptr[4];
extern unsigned char *iptr;
extern unsigned char keyports[9];
extern unsigned long tstates,tsmax;
extern int hires,hiscrn;
extern int help;
extern int memattr[4];

extern int screen_dirty;
extern volatile int interrupted;
extern int forcejp;
extern int scrn_freq;
extern int booting;
extern int input_wait;

extern unsigned char chrmap_old[],chrmap[];
extern unsigned char himap_old[],himap[];

extern int refresh_screen;
extern int zx80;
extern int ignore_esc;


extern void sighandler(int a);
extern char *libdir(char *file);
extern void startsigsandtimer();
extern void loadrom(unsigned char *x);
extern void initmem();
extern void hacks();
extern unsigned int in(int h,int l);
extern unsigned int out(int h,int l,int a);
extern void hireschk(int ix);
extern void hireschki(int i);
extern void do_interrupt();
extern void save_p(int a);
extern void load_p(int a);
extern void fix_tstates();
extern void update_kybd();
extern void do_interrupt();
extern void reset81();
extern void parseoptions(int argc,char *argv[]);
