/* zxsend
 * getoptn.h - header for getoptn.c.
 */

extern int optnopt,optnerr,optnind;
extern char *optnarg;
extern int getoptn(int argc,char *argv[],char *optstring);
