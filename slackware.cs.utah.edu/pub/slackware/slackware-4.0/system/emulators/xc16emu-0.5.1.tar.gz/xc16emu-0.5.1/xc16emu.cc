/*GPL*START*
 * xc16emu - commodore c16/c116/plus/4 emulator for X11 using Qt
 * Copyright (C) 1998 by Johannes Overmann <overmann@iname.com>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 * *GPL*END*/  

#include <qapp.h>
#include <qpixmap.h>

#include "xc16emu.h"

#include "tappconfig.h"

#include "mainwidget.h"

#include "icon64.xpm"

// start: unknown

// 1998:
// 18 Sept: 0.5.1 preparing for sunsite, icons

// globals
bool verbose;

const char *options[] ={
   "#usage='Usage: %n [OPTIONS]\n'",
     "#trailer='\nX toolkit options (like -display, -geometry, -fg, -font ...) are also available\n\n%n version %v *** (C) 1997 by Johannes Overmann\ncomments, bugs and suggestions welcome: overmann@i6.informatik.rwth-aachen.de\n'",

     "name=ram, type=int, char=r, lower=16, upper=64, default=64, help='initial size of emulated machine ram in K (valid are 16, 32 and 64)', headline='emulator options:'",
     "name=zoom, type=int, char=z, lower=1, upper=4, default=1, help=initial display zoom factor",
     
     "name=rompath, type=string, char=p, default='/usr/local/lib/xc16emu_roms', help='absolute path to rom images: basrom.dat (0x8000-0xbfff) and sysrom.dat (0xc000-0xffff) are required'",
     
     "name=verbose, type=switch, char=v, help=verbose execution, headline='common options:'",
     "EOL"
};


int main(int ac, char *av[]) {
   QApplication::setFont(QFont("helvetica", 12, QFont::Bold));
   QApplication qa(ac, av);
   TAppConfig ta(options, "options", ac, av, "XC16EMU_OPT", "xc16emurc", VERSION);
   verbose = ta("verbose");
   
   MainWidget w;
   
   qa.setMainWidget(&w);
   string capt(ta.getString("application-name")+" V"+ta.getString("application-version"));
   w.setCaption(capt);
   w.setIcon(QPixmap(icon_xpm));
   w.setMinimumSize(10,10);
   w.show();
   return qa.exec();
}













