/*GPL*START*
 * 
 * Copyright (C) 1998 by Johannes Overmann <overmann@iname.com>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 * *GPL*END*/  

#ifndef _qemuwid_h_
#define _qemuwid_h_

#include <stdio.h>
#include <qwidget.h>
#include <qcolor.h>
#include <qpaintd.h>
#include <qrect.h>
#include <qimage.h>
#include "tassocarray.h"





class EmuWid: public QWidget {
  
   Q_OBJECT;
  
 public:
   // cons & des;
   EmuWid(QWidget *parent=0);
   ~EmuWid();
      
 public slots:
   void setRam(int size_in_k);
   void setZoom(int zoom);
   void setSmallBorder(bool small);
   void emuReset();
   void setRomEnable(bool So, bool E1, bool E2);
   
   signals: 
   void frameRate(double frames_per_second);

 protected:
   // qt events
   void paintEvent(QPaintEvent *);
   void keyPressEvent(QKeyEvent *e);
   void keyReleaseEvent(QKeyEvent *e);
//   void resizeEvent(QResizeEvent *p);
   void mousePressEvent(QMouseEvent *) {}
   void mouseReleaseEvent(QMouseEvent *) {}
//   void mouseMoveEvent(QMouseEvent *e);
   void focusInEvent(QFocusEvent *) {}
   void focusOutEvent(QFocusEvent *) {}
   
 private slots:
   void mainLoop();

   
 private:
   // private methods

      
   // private data
   QColor col[128];
   int scr_width;
   int scr_height;
   int scr_zoom;
   int scr_off;
   int scr_voff;
   TAssocArray<int,int> qtkey;
   TArray<int> keybuf;
   int frame;
   double last_time;
   QImage *img;
   int small_xoff;
   int small_yoff;
   bool small_border;
   uchar *rline;
   uchar *screen;
   bool *scrdirty;
   
 private:
   // 6510 emulator
   void execute6510(ushort *a);
   void illegalInstr(ushort *,uchar);

   void loadRom(uchar *rom, const char *fname, bool fatal);
   void initKeyTrans();
   void testKey();
   double getElapsed();
   void blinkPhaseOn();
   void blinkPhaseOff();
   uchar *scanLine(int line);
   void paintLine(int line);
   void renderLine(int line, uchar *pix);

   int window2screen(int line) {return (line+scr_height-scr_voff)%scr_height;}
   int screen2window(int line) {return (line+scr_voff)%scr_height;}
   uchar *screenLine(int line) {return screen + line*scr_width;}
   
   uchar peekMem(ushort a) {
      if((a>=0xfd00)&&(a<0xff40)) return peekMemHard(a);
      if((a<0x8000)||RamEnable) return Ram[a&Ram_Mask];      
      if(a<0xc000) return Mod_Lo[a&0x3fff];
      if(a<0xfc00) return Mod_Hi[a&0x3fff];
      else         return Sys_Rom[a&0x3fff];
   }

   void pokeMem(ushort a, uchar b) {
      if((a<0xfd00)||(a>=0xff40)) Ram[a&Ram_Mask]=b;
      else pokeMemHard(a, b);
   }

   uchar getSR() {
      uchar b=32;
      
      if(Cflag)b|=1;
      if(Zflag)b|=2;
      if(Iflag)b|=4;
      if(Dflag)b|=8;
      if(Vflag)b|=64;
      if(Nflag)b|=128;
      return(b);
   }


   void setSR(uchar b) {
      Cflag=(b&1)>0;
      Zflag=(b&2)>0;
      Iflag=(b&4)>0;
      Dflag=(b&8)>0;
      Vflag=(b&64)>0;
      Nflag=(b&128)>0;
   }


   uchar peekMemHard(ushort a);
   uchar peekIEC(ushort a);
   uchar peekTED(ushort a);

   void pokeMemHard(ushort a,uchar b);
   void pokeIEC(ushort a,uchar b);
   void pokeTED(ushort a, uchar b);

   uchar *getBankPtr(uchar b);
   void setPixel(int x, uchar c);


   // 6510 cpu:
   bool Zflag,Nflag,Cflag,Vflag,Dflag,Iflag;
   uchar cpuX,cpuY,cpuA,cpuSP,cpuSR;
   ushort cpuPC;

   // ram and roms:
   uchar Ram[65536];
   uchar Bas_Rom[16384];
   uchar Sys_Rom[16384];
   uchar SoL_Rom[16384];
   uchar SoH_Rom[16384];
   uchar E1L_Rom[16384];
   uchar E1H_Rom[16384];
   uchar E2L_Rom[16384];
   uchar E2H_Rom[16384];
   uchar *Mod_Lo, *Mod_Hi;
   
   // misc:
   bool RamEnable;
   ushort Ram_Mask;
   uchar Port6529;
   ushort Instr_per_Line; 

   // TED chip register:
   uchar TED_CB;
   uchar TED_BMB;
   uchar TED_VM; 
   uchar TED_VM2;
   uchar TED_CON1;
   uchar TED_CON2;
   uchar TED_C0;
   uchar TED_C1;
   uchar TED_C2;
   uchar TED_C3;
   uchar TED_C4;
   uchar TED_IRQ;
   uchar TED_EIRQ;
   uchar TED_KEY;
   ushort Timer1;
   ushort Timer2;
   ushort Timer3;
   ushort RTimer1;
   ushort RTimer2;
   ushort RTimer3;
   uchar KeyPort;
   uchar KeyMatrix[8];

   // IEC floppy simulation
   uchar IECPort;
   uchar IECCom;
   uchar IECStatus;
   uchar IECFlag;
   uchar IECFNPtr;
   bool IECGetFile;
   bool OfileR;
   uchar IECFileN[256];
   FILE *Ofile;

   // video:
   ushort IRLine;
   ushort CursorPos;
   uchar *BitMapBank;
   uchar *CharBank;
   uchar *VideoMatrix;
   ushort RLine;
   ushort RHori;
   ushort VLine;
   ushort Blink;
   uchar *VideoMatrixI;
   uchar IBit[8]; 
   uchar Bit[8]; 
};

#endif




