/*GPL*START*
 * 
 * Copyright (C) 1998 by Johannes Overmann <overmann@iname.com>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 * *GPL*END*/  

#ifndef _mainwidget_h_
#define _mainwidget_h_


#include <qwidget.h>


class EmuWid;
class QMenuBar;
class QPopupMenu;
class QLabel;

class MainWidget: public QWidget {
  
  Q_OBJECT;
  
public:
   // cons & des;
   MainWidget(QWidget *parent=0);
   ~MainWidget();
   

public slots:

signals:
  

protected:


private slots:
   void set_ram16();
   void set_ram32();
   void set_ram64();
   void set_zoom1();
   void set_zoom2();
   void set_zoom3();
   void set_zoom4();
   void tog_enSo();
   void tog_enE1();
   void tog_enE2();
   void tog_small();
   void showFrameRate(double rate);
   void aboutQt();
   void about();
   void info();

   
private:
   // private methods


   // private data
   QMenuBar *menu;
   QPopupMenu *opt;
   QLabel *stat;
   EmuWid *emu;
   
   int ram16Id, ram32Id, ram64Id;   
   int zoom1Id, zoom2Id, zoom3Id, zoom4Id;
   int enSoId, enE1Id, enE2Id, smallId;
};




#endif
