/*GPL*START*
 * 
 * Copyright (C) 1998 by Johannes Overmann <overmann@iname.com>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 * *GPL*END*/  

#include <sys/time.h>
#include <unistd.h>
#include <limits.h>
#include <ctype.h>
#include <math.h>
#include <stdio.h>
#include <qpainter.h>
#include <qpixmap.h>
#include <qtimer.h>
#include <qapp.h>
#include <qkeycode.h>

#include "emuwid.h"
#include "tappconfig.h"
#include "string.h"
#include "minmax.h"

#include "xc16emu.h"



#define FRAMERATE_FRAMES 50

#define KEY_BUFFER_SIZE 20



static double gettime() {
   struct timeval t;
   gettimeofday(&t, 0);
   return double(t.tv_sec) + double(t.tv_usec)/1000000.0;
}



int ColTab[16*3]={0,0,0, 255,255,255, 255,0,0, 0,255,255, 
   127,0,255, 0,255,0, 0,0,255, 255,255,0,
   255,128,0, 128,128,0, 128,255,0, 200,0,200, 
   0,255,128, 0,128,255, 0,32,255, 128,255,128};


enum EmuKeys {
   K_Inst,       K_Return,   K_Pfund,     K_Help,    K_F1,        K_F2,      K_F3,      K_At,
   K_3,          K_W,        K_A,         K_4,       K_Z,         K_S,       K_E,       K_Shift,
   K_5,          K_R,        K_D,         K_6,       K_C,         K_F,       K_T,       K_X,
   K_7,          K_Y,        K_G,         K_8,       K_B,         K_H,       K_U,       K_V,
   K_9,          K_I,        K_J,         K_0,       K_M,         K_K,       K_O,       K_N,
   K_CDn,        K_P,        K_L,         K_CUp,     K_Gr,        K_Colon,   K_Minus,   K_Kl,
   K_CLe,        K_Ast,      K_Semi,      K_CRi,     K_Escape,    K_Gl,      K_Plus,    K_Quest,
   K_1,          K_Clear,    K_Ctrl,      K_2,       K_Space,     K_Como,    K_Q,       K_RunStop,
   K_None,
   
   // modifier control
   K_SHIFT    =0x0100,
   K_CTRL     =0x0200,
   K_COMO     =0x0400,
   K_FORCENONE=0x8000, 

   // internal control
   K_RELEASE    =0x800000,
   K_SEQUENCE   =0x400000,
   K_RELEASEALL =0x200000,

};


  

EmuWid::EmuWid(QWidget *parent): QWidget(parent),
scr_width(320+112), scr_height(200+112), small_xoff(112/2-4), small_yoff(112/2-4), small_border(false)
{
   // init key events
   setFocusPolicy(QWidget::StrongFocus);
   setFocus();
   initKeyTrans();
   
   // init screen
   img = new QImage(scr_width, 1, 8, 256);
   scr_off = (scr_width-320)/2;
   scr_voff = (scr_height-200)/2-3;
   screen = new uchar[scr_width * scr_height];
   rline = new uchar[scr_width];
   scrdirty = new bool[scr_height+10];
   setZoom(1);

   // init colors 
   int i,c,h;   
   int hel[]={30,44,58,72,86,100,114,128};
   for(i=0; i<128; i++) {
      c=i&0xf;
      h=(i>>4);
      img->setColor(i, qRgb((ColTab[c*3+0]*hel[h])>>7, 
			    (ColTab[c*3+1]*hel[h])>>7, 
			    (ColTab[c*3+2]*hel[h])>>7));
      col[i].setRgb((ColTab[c*3+0]*hel[h])>>7, 
		    (ColTab[c*3+1]*hel[h])>>7, 
		    (ColTab[c*3+2]*hel[h])>>7);
   }   

   // init roms
   memset(Ram, 0, 65536);
   string path(tApp->getString("rompath"));
   loadRom(Bas_Rom, path+"/basrom.dat", true);
   loadRom(Sys_Rom, path+"/sysrom.dat", true);
   
   // start emu
   Instr_per_Line = 40;
   for(i=128, c=0; i; i>>=1, c++) IBit[c] = i;
   for(i=1, c=0; i<=128; i<<=1, c++) Bit[c] = i;
   Ram_Mask = 0xffff;
   setRomEnable(true, true, true);
   frame=0;
   last_time = gettime();
   emuReset();
   QTimer::singleShot(0, this, SLOT(mainLoop()));
}


EmuWid::~EmuWid() {
   delete img;
}


void EmuWid::loadRom(uchar *rom, const char *fname, bool fatal) {
   FILE *f = 0;
   
   f = fopen(fname, "rb");
   if(f==0) goto error;
   if(fread(rom, 1, 16384, f)!=16384) goto error;
   if(verbose) 
     printf("rom image '%s' successfully loaded\n", fname);	   
   fclose(f);
   return;

   error:
   if(f) fclose(f);
   if(fatal) {
      fprintf(stderr, "error while loading rom image from file '%s'!\n", fname);
      exit(1);
   } else {
      if(verbose) 
	printf("rom image '%s' not found: rom cleared\n", fname);	
   }
}


void EmuWid::setZoom(int zoom) {
   if(zoom<1) {
      fprintf(stderr, "EmuWid::setZoom(%d) ignored! (must be >0)\n", zoom);
      return;
   }
   scr_zoom = zoom;
   if(small_border) 
     setFixedSize(zoom*(scr_width-2*small_xoff), zoom*(scr_height-2*small_yoff));
   else 
     setFixedSize(zoom*scr_width, zoom*scr_height);
}


void EmuWid::setSmallBorder(bool small) {
   small_border = small;
   if(small_border) 
     setFixedSize(scr_zoom*(scr_width-2*small_xoff), scr_zoom*(scr_height-2*small_yoff));
   else 
     setFixedSize(scr_zoom*scr_width, scr_zoom*scr_height);
}


void EmuWid::setRam(int size_in_k) {
   switch(size_in_k) {
    case 16:
      Ram_Mask = 0x3fff;
      break;
    case 32:
      Ram_Mask = 0x7fff;
      break;
    case 64:
      Ram_Mask = 0xffff;
      break;
    default:
      fprintf(stderr, "EmuWid::setRam(%d) ignored! (must be 16,32 or 64)\n", size_in_k);
      break;
   }
   memset(Ram,0,65536);
   emuReset();
}


void EmuWid::setRomEnable(bool So, bool E1, bool E2) {
   string path(tApp->getString("rompath"));

   // clear roms
   memset(SoL_Rom, 0, 16384);
   memset(SoH_Rom, 0, 16384);
   memset(E1L_Rom, 0, 16384);
   memset(E1H_Rom, 0, 16384);
   memset(E2L_Rom, 0, 16384);
   memset(E2H_Rom, 0, 16384);
   
   // perhaps load roms
   if(So) {
      loadRom(SoL_Rom, path + "/solrom.dat", false);
      loadRom(SoH_Rom, path + "/sohrom.dat", false);
   }
   if(E1) {
      loadRom(E1L_Rom, path + "/e1lrom.dat", false);
      loadRom(E1H_Rom, path + "/e1hrom.dat", false);
   }
   if(E2) {
      loadRom(E2L_Rom, path + "/e2lrom.dat", false);
      loadRom(E2H_Rom, path + "/e2hrom.dat", false);      
   }
   
   // reset
   emuReset();
}


// qt events:


void EmuWid::paintEvent(QPaintEvent *e) {
   int lo = e->rect().top()/scr_zoom;
   int hi = (e->rect().bottom() + scr_zoom - 1)/scr_zoom;

   if(small_border) {
      lo += scr_voff-1;
      hi += scr_voff;
   }
   for(int i=lo; i<=hi; i++) scrdirty[window2screen(i)] = true;
}



#define setKey(key) {KeyMatrix[(key)>>3] |= 1 << ((key)&7);}
#define relKey(key) {KeyMatrix[(key)>>3] &= ~(1 << ((key)&7));}

void EmuWid::testKey() {
   next:
   if(keybuf.num() > 0) {
      if(keybuf[0] & K_RELEASEALL) {
	 KeyMatrix[0]=0;
	 KeyMatrix[1]=0;
	 KeyMatrix[2]=0;
	 KeyMatrix[3]=0;
	 KeyMatrix[4]=0;
	 KeyMatrix[5]=0;
	 KeyMatrix[6]=0;
	 KeyMatrix[7]=0;
      } else {
	 if(keybuf[0] & K_RELEASE) {
	    relKey(keybuf[0] & 63);
	 } else {
	    setKey(keybuf[0] & 63);	 	 
	 }
      }
      
      if(keybuf[0] & K_SEQUENCE) {
	 keybuf.slowRemove(0);
	 goto next;
      } else {
	 keybuf.slowRemove(0);
      }
   }
}


void EmuWid::keyPressEvent(QKeyEvent *e) {   
   if(qtkey.contains(e->key()) && (keybuf.num() < KEY_BUFFER_SIZE)) {
      int key = qtkey[e->key()] & 0x00ff;
      int act = qtkey[e->key()] & 0xff00;
      
      switch(act) {
       case K_FORCENONE:
	 keybuf += (K_Shift + K_RELEASE + K_SEQUENCE);
	 keybuf += (K_Ctrl + K_RELEASE);
	 break;
	 
       case K_SHIFT:
	 keybuf += K_Shift;
	 break;

       case K_CTRL:
	 keybuf += K_Ctrl;
	 break;

       case K_COMO:
	 keybuf += K_Como;
	 break;
      }      

      if(key < K_None) {
	 keybuf += key;
      }
      
      
   } else {
#if 0
      printf("press:   key=%#02x (%d), ascii=%#02x (%d) num=%d\n", 
	     e->key(), e->key(), e->ascii(), e->ascii(), keybuf.num());
#endif
      e->ignore();
   }
}


void EmuWid::keyReleaseEvent(QKeyEvent *) {
   if(keybuf.num()>0) {
      if(keybuf[keybuf.num()-1] != K_RELEASEALL)  
	keybuf += K_RELEASEALL;
   } else {
      keybuf += K_RELEASEALL;
   }
}



// 6510 emulator

#define	Ticks_per_Instr 3
#define	Horizontal_Width	432
#define	RLines_per_Frame	312



#define	setZN(a)	Zflag=(a==0);Nflag=(a>=128)
#define	cpuPush(b)	Ram[0x100+(cpuSP--)]=b
#define	cpuPull()	Ram[0x100+(++cpuSP)]



#define peekZero(a) Ram[a]
#define peekHiRom(a) Sys_Rom[(a)&0x3fff]




void EmuWid::emuReset() {
   TED_VM = 0x08;
   IECCom = 0;
   Blink = 0;
   pokeMemHard(0xfdd0, 0);
   cpuPC = ushort(peekHiRom(0xfffc)) | (ushort(peekHiRom(0xfffd))<<8);
   for(int i=0; i<8; i++) KeyMatrix[i] = 0;
   RamEnable = false;
   VideoMatrix = VideoMatrixI = Ram;
   BitMapBank = CharBank = Ram;
   RLine = VLine = 0;
}


void EmuWid::blinkPhaseOn() {
   for(int i=0; i<128; i++) img->setColor(i+128, img->color(i));
}
   

void EmuWid::blinkPhaseOff() {
   for(int i=0; i<128; i++) img->setColor(i+128, img->color(TED_C0));   
}
   

double EmuWid::getElapsed() {
   double t = gettime();
   double r = t - last_time;
   last_time = t;
   return r;
}


void EmuWid::mainLoop() {
   // simulate keyboard
   testKey();
   
   // emualte one frame
   for(VLine=0; VLine < RLines_per_Frame; RLine++, VLine++) {
      if(RLine>=RLines_per_Frame) {
	 RLine = 0;
	 VLine = 0; // resync of screen
      }
      RHori=0;
      if(RLine==IRLine)TED_IRQ |= 0x82;
      execute6510(&cpuPC);
      renderLine(RLine, rline);
      if(scrdirty[VLine] || memcmp(rline, screenLine(VLine), scr_width)) { 
	 memcpy(screenLine(VLine), rline, scr_width);
	 paintLine(VLine);
	 scrdirty[VLine] = 0;
      }
   }
   
   // update blink phase
   Blink++;
   if(Blink==16) {
      blinkPhaseOn();
   }
   if(Blink==32) {
      blinkPhaseOff();
      Blink=0;      
   }
   
   // get framerate
   frame++;
   if(frame>=FRAMERATE_FRAMES) {
      emit frameRate(FRAMERATE_FRAMES / getElapsed());
      frame=0;
   }
   
   // init next block
   qApp->processEvents();
   QTimer::singleShot(0, this, SLOT(mainLoop()));
}


void EmuWid::execute6510(ushort *a) {
   ushort ad;
   uchar b,c;
   
   for(int j=0; j < Instr_per_Line; j++) {
      ad=0;
      c=peekMem((*a)++); // get opcode
      
      switch(c) {
	 
       case 0x10: //BPL
	 b=peekMem((*a)++);
	 if(!Nflag)*a+=(signed char)b;
	 break;
	 
       case 0x30: //BMI
	 b=peekMem((*a)++);
	 if(Nflag)*a+=(signed char)b;
	 break;
	 
       case 0x50: //BVC
	 b=peekMem((*a)++);
	 if(!Vflag)*a+=(signed char)b;
	 break;
	 
       case 0x70: //BVS
	 b=peekMem((*a)++);
	 if(Vflag)*a+=(signed char)b;
	 break;
	 
       case 0x90: //BCC
	 b=peekMem((*a)++);
	 if(!Cflag)*a+=(signed char)b;
	 break;
	 
       case 0xb0: //BCS
	 b=peekMem((*a)++);
	 if(Cflag)*a+=(signed char)b;
	 break;
	 
       case 0xd0: //BNE
	 b=peekMem((*a)++);
	 if(!Zflag)*a+=(signed char)b;
	 break;
	 
       case 0xf0: //BEQ
	 b=peekMem((*a)++);
	 if(Zflag)*a+=(signed char)b;
	 break;
	 
       case 0x8a: //TXA
	 cpuA=cpuX;
	 setZN(cpuA);
	 break;
	 
       case 0xaa: //TAX
	 cpuX=cpuA;
	 setZN(cpuA);
	 break;
	 
       case 0x98: //TYA
	 cpuA=cpuY;
	 setZN(cpuA);
	 break;
	 
       case 0xa8: //TAY
	 cpuY=cpuA;
	 setZN(cpuA);
	 break;
	 
       case 0xba: //TSX
	 cpuX=cpuSP;
	 setZN(cpuX);
	 break;
	 
       case 0x9a: //TXS
	 cpuSP=cpuX;
	 break;
	 
       case 0x08: //PHP
	 cpuPush(getSR());
	 break;
	 
       case 0x28: //PLP
	 setSR(cpuPull());
	 break;
	 
       case 0x48: //PHA
	 cpuPush(cpuA);
	 break;
	 
       case 0x68: //PLA
	 cpuA=cpuPull();
	 setZN(cpuA);
	 break;
	 
       case 0xea: //NOP
	 // very simple
	 break;
	 
       case 0x18: //CLC
	 Cflag=FALSE;
	 break;
	 
       case 0x38: //SEC
	 Cflag=TRUE;
	 break;
	 
       case 0x58: //CLI
	 Iflag=FALSE;
	 break;
	 
       case 0x78: //SEI
	 Iflag=TRUE;
	 break;
	 
       case 0xb8: //CLV
	 Vflag=FALSE;
	 break;
	 
       case 0xd8: //CLD
	 Dflag=FALSE;
	 break;
	 
       case 0xf8: //SED
	 Dflag=TRUE;
	 break;
	 
       case 0x88: //DEY
	 cpuY--;
	 setZN(cpuY);
	 break;
	 
       case 0xc8: //INY
	 cpuY++;
	 setZN(cpuY);
	 break;
	 
       case 0xca: //DEX
	 cpuX--;
	 setZN(cpuX);
	 break;
	 
       case 0xe8: //INX
	 cpuX++;
	 setZN(cpuX);
	 break;
	 
       case 0x4c: //JMP
	 b=peekMem((*a)++);
	 ad=(peekMem(*a)<<8)+b;
	 *a=ad;
	 break;
	 
       case 0x6c: //JMP()
	 b=peekMem((*a)++);
	 ad=(peekMem(*a)<<8)+b;
	 b=peekMem(ad++);
	 ad=(peekMem(ad)<<8)+b;
	 *a=ad;
	 break;
	 
       case 0x40: //RTI
	 setSR(cpuPull());
	 b=cpuPull();
	 ad=(cpuPull()<<8)+b;
	 *a=ad;
	 break;
	 
       case 0x60: //RTS
	 b=cpuPull();
	 ad=(cpuPull()<<8)+b;
	 *a=ad+1;
	 break;
	 
       case 0x20: //JSR
	 b=peekMem((*a)++);
	 cpuPush((*a)>>8);
	 cpuPush((*a)&255);
	 ad=(peekMem(*a)<<8)+b;
	 *a=ad;
	 break;
	 
       case 0x00: //BRK
	 cpuPush((++(*a))>>8);
	 cpuPush((*a)&255);
	 cpuPush(getSR()|0x10);
	 Iflag=TRUE;
	 *a=peekMem(0xfffe)+(peekMem(0xffff)<<8);
	 break;
	 
       case 0xa0: //LDY #
	 cpuY=peekMem((*a)++);
	 setZN(cpuY);
	 break;
	 
       case 0xa2: //LDX #
	 cpuX=peekMem((*a)++);
	 setZN(cpuX);
	 break;
	 
       case 0x0a: //ASL A
	 Cflag=(cpuA&0x80)>0;
	 cpuA<<=1;
	 cpuA&=0xfe;
	 setZN(cpuA);
	 break;
	 
       case 0x2a: //ROL A
	 c=cpuA;
	 cpuA<<=1;
	 cpuA&=0xfe;
	 if(Cflag)cpuA|=0x01;
	 Cflag=(c&0x80)>0;
	 setZN(cpuA);
	 break;
	 
       case 0x4a: //LSR A
	 Cflag=(cpuA&0x01)>0;
	 cpuA>>=1;
	 cpuA&=0x7f;
	 setZN(cpuA);
	 break;
	 
       case 0x6a: //ROR A
	 c=cpuA;
	 cpuA>>=1;
	 cpuA&=0x7f;
	 if(Cflag)cpuA|=0x80;
	 Cflag=(c&1)>0;
	 setZN(cpuA);
	 break;
	 
       case 0x89: //Illegal (STA #)
       case 0x9c: //			(STY ab,X)
       case 0x9e: //			(STX ab,Y)
	 illegalInstr(a,c);
	 break;
	 
       case 0xc0: //CPY #
	 b=peekMem((*a)++);
	 cpy:		ad=cpuY;
	 ad-=b;
	 b=cpuY-b;
	 setZN(b);
	 Cflag=(ad&0x8000)==0;
	 break;
	 
       case 0xe0: //CPX #
	 b=peekMem((*a)++);
	 cpx:		ad=cpuX;
	 ad-=b;
	 b=cpuX-b;
	 setZN(b);
	 Cflag=(ad&0x8000)==0;
	 break;
	 
       default:
	 b=c&7;
	 if((b==1)||(b==5)||(b==6)) {
	    switch(c&0x1c) {
	       
	     case 0:   //($xx,X)
	       b=peekMem((*a)++)+cpuX;
	       ad=peekZero(b++);
	       ad+=peekZero(b)<<8;
	       break;
	       
	     case 4:   //$xx
	       ad=peekMem((*a)++);
	       break;
	       
	     case 8:   //#$xx
	       ad=(*a)++;
	       break;
	       
	     case 12:  //$xxxx
	       ad=peekMem((*a)++);
	       ad+=peekMem((*a)++)<<8;
	       break;
	       
	     case 16:  //($xx),Y
	       b=peekMem((*a)++);
	       ad=peekZero(b++);
	       ad+=peekZero(b)<<8;
	       ad+=cpuY;
	       break;
	       
	     case 20:  //$xx,X
	       b=peekMem((*a)++);
	       if((c==0x96)||(c==0xb6))b+=cpuY;
	       else b+=cpuX;
	       ad=b;
	       break;
	       
	     case 24:  //$xxxx,Y
	       ad=peekMem((*a)++)+cpuY;
	       ad+=peekMem((*a)++)<<8;
	       break;
	       
	     case 28:  //$xxxx,X
	       ad=peekMem((*a)++);
	       if(c==0xbe)ad+=cpuY;
	       else ad+=cpuX;
	       ad+=peekMem((*a)++)<<8;
	       break;
	    }
	    b=peekMem(ad);
	    switch(c&0xe3) {
	       
	     case 0x01: //ORA
	       cpuA|=b;
	       setZN(cpuA);
	       break;
	       
	     case 0x21: //AND
	       cpuA&=b;
	       setZN(cpuA);
	       break;
	       
	     case 0x41: //EOR
	       cpuA^=b;
	       setZN(cpuA);
	       break;
	       
	     case 0x61: //ADC
	       if(Dflag) {
		  cpuA=(cpuA&15)+(cpuA>>4)*10;
		  b=(b&15)+(b>>4)*10;
		  cpuA+=b;
		  if(Cflag)cpuA++;
		  Cflag=cpuA>99;
		  if(Cflag)cpuA-=100;
		  cpuA=(cpuA/10)*16+(cpuA%10);
		  setZN(cpuA);
	       } else {
		  c=~cpuA;
		  ad=cpuA;
		  ad+=b;
		  if(Cflag)ad++;
		  cpuA=(uchar)ad;
		  setZN(cpuA);
		  Cflag=ad>=256;
		  Vflag=(c&0x80)&&Nflag;	       
	       }
	       break;
	       
	     case 0x81: //STA
	       pokeMem(ad,cpuA);
	       break;
	       
	     case 0xa1: //LDA
	       cpuA=b;
	       setZN(cpuA);
	       break;
	       
	     case 0xc1: //CMP
	       ad=cpuA;
	       ad-=b;
	       b=cpuA-b;
	       setZN(b);
	       Cflag=(ad&0x8000)==0;
	       break;
	       
	     case 0xe1: //SBC
	       if(Dflag) {
		  cpuA=(cpuA&15)+(cpuA>>4)*10;
		  b=(b&15)+(b>>4)*10;
		  cpuA-=b;
		  if(!Cflag)cpuA--;
		  Cflag=cpuA<100;
		  if(Cflag)cpuA+=100;
		  cpuA=(cpuA/10)*16+(cpuA%10);
		  setZN(cpuA);
	       } else {
		  c=cpuA;
		  ad=cpuA;
		  ad-=b;
		  if(!Cflag)ad--;
		  cpuA=(uchar)ad;
		  setZN(cpuA);
		  Cflag=(ad&0x8000)==0;
		  Vflag=(c&0x80)&&Nflag;	       
	       }
	       break;
	       
	     case 0x02: //ASL
	       Cflag=(b&0x80)>0;
	       b<<=1;
	       b&=0xfe;
	       setZN(b);
	       pokeMem(ad,b);
	       break;
	       
	     case 0x22: //ROL
	       c=b;
	       b<<=1;
	       b&=0xfe;
	       if(Cflag)b|=0x01;
	       Cflag=(c&0x80)>0;
	       setZN(b);
	       pokeMem(ad,b);
	       break;
	       
	     case 0x42: //LSR
	       Cflag=(b&0x01)>0;
	       b>>=1;
	       b&=0x7f;
	       setZN(b);
	       pokeMem(ad,b);
	       break;
	       
	     case 0x62: //ROR
	       c=b;
	       b>>=1;
	       b&=0x7f;
	       if(Cflag)b|=0x80;
	       Cflag=(c&1)>0;
	       setZN(b);
	       pokeMem(ad,b);
	       break;
	       
	     case 0x82: //STX
	       pokeMem(ad,cpuX);
	       break;
	       
	     case 0xa2: //LDX
	       cpuX=b;
	       setZN(b);
	       break;
	       
	     case 0xc2: //DEC
	       b--;
	       setZN(b);
	       pokeMem(ad,b);
	       break;
	       
	     case 0xe2: //INC
	       b++;
	       setZN(b);
	       pokeMem(ad,b);
	       break;
	    }
	 } else if(b==4) {
	    b=c>>4;
	    if((b==2)||(b==8)||(b==9)||(b==10)||(b==11)||(b==12)||(b==14)) {
	       ad=peekMem((*a)++);
	       if((c&15)==12) ad+=peekMem((*a)++)<<8;
	       if((b==11)||(b==9))ad+=cpuX;
	       if((c==0xb4)||(c==0x94))ad&=255;
	       switch(b) {
		case 2: //BIT
		  b=peekMem(ad);
		  Nflag=(b&128)>0;
		  Vflag=(b&64)>0;
		  b&=cpuA;
		  Zflag=(b==0);
		  break;
		case 8:
		case 9: //STY
		  pokeMem(ad,cpuY);
		  break;
		case 10:
		case 11: //LDY
		  cpuY=peekMem(ad);
		  setZN(cpuY);
		  break;
		case 12: //CPY
		  b=peekMem(ad);
		  goto cpy;
		case 14: //CPX
		  b=peekMem(ad);
		  goto cpx;
	       }
	    } else illegalInstr(a,c);
	 } else {
	    illegalInstr(a,c);
	    break;
	 }
      }
      
      
      // *** do timer *** 
      
      Timer1-=Ticks_per_Instr;
      Timer2-=Ticks_per_Instr;
      Timer3-=Ticks_per_Instr;
      if(Timer1<Ticks_per_Instr) {
	 Timer1+=RTimer1;
	 TED_IRQ|=0x88;
      }
      if(Timer2<Ticks_per_Instr) {
	 Timer2+=RTimer2;
	 TED_IRQ|=0x90;
      }
      if(Timer3<Ticks_per_Instr) {
	 Timer3+=RTimer3;
	 TED_IRQ|=0xc0;
      }
      
      
      // *** do irq ***
      
      if(!Iflag) {
	 if(TED_IRQ & TED_EIRQ) {
	    cpuPush(cpuPC>>8);
	    cpuPush(cpuPC&0xff);
	    cpuPush(getSR());
	    Iflag = true;
	    cpuPC=ushort(peekHiRom(0xfffe)) | (ushort(peekHiRom(0xffff))<<8);
	 }   
      }
      
      
      // *** do misc ***
      
      RHori++;
   }
}


void EmuWid::illegalInstr(ushort *a, uchar b) { // adr, uchar
   printf("illegal 6510 opcode %#02x at %#04x\n", b, *a);
}


// IO: 0xfd00 <= a < 0xff40
void EmuWid::pokeMemHard(ushort a,uchar b) {
   if(a>=0xff00) pokeTED(a&0x3f,b); 
   else if(a>=0xfe00) pokeIEC(a&0xff,b);
   else {
      switch(a&0xf0) {
       case 0x00: // ACIA	 
	 break;
	 
       case 0x10: // user port
	 Port6529 = b;
	 break;
	 
       case 0x30: // key port
	 KeyPort = b;
	 break;
	 
       case 0xd0: // modul
	 switch(a&3) {
	  case 0: Mod_Lo = Bas_Rom; break;
	  case 1: Mod_Lo = SoL_Rom; break;
	  case 2: Mod_Lo = E1L_Rom; break;
	  case 3: Mod_Lo = E2L_Rom; break;
	 }
	 switch((a>>2)&3) {
	  case 0: Mod_Hi = Sys_Rom; break;
	  case 1: Mod_Hi = SoH_Rom; break;
	  case 2: Mod_Hi = E1H_Rom; break;
	  case 3: Mod_Hi = E2H_Rom; break;
	 }
	 break;
      }
   }
}


// IO: 0xfd00 <= a < 0xff40
uchar EmuWid::peekMemHard(ushort a) {
   if(a>=0xff00)return peekTED(a&0x3f);
   if(a>=0xfe00)return peekIEC(a&0xff);
   switch(a&0xf0) {
    case 0x00:return 0xac; // ACIA
    case 0x10:return Port6529;
    case 0x30:return KeyPort;
   }
   return 0x66; // nothing
}


void EmuWid::pokeIEC(ushort a,uchar b) {
   switch(a) {
      
    case 0xf0:
      switch(IECCom) {
	 
       case 0x82:
	 if((b&0xf0)==0xf0) {
	    IECFNPtr=0;
	    IECGetFile=TRUE;
	 } else if((b&0xf0)==0xe0) {
	    IECGetFile=FALSE;
	    if(Ofile!=0)fclose(Ofile);
	 } else {
	    IECFileN[IECFNPtr]=0;
	    IECGetFile=FALSE;
	    IECFNPtr=0;
	    while(IECFileN[IECFNPtr])if(IECFileN[IECFNPtr++]==':')break;
	    if(IECFileN[IECFNPtr]==0)IECFNPtr=0;
	    if((b&0x0f)==0) {
	       Ofile=fopen((char*)IECFileN+IECFNPtr,"rb");
	       OfileR=TRUE;
	    } else {
	       Ofile=fopen((char*)IECFileN+IECFNPtr,"wb");
	       OfileR=FALSE;
	    }
	 }
	 IECCom=0;
	 break;
	 
       case 0x83:
	 if(IECGetFile) IECFileN[IECFNPtr++]=b;
	 else {
	    if((Ofile!=0)&&(!OfileR)) {
	       fputc(b,Ofile);
	       IECStatus=0;
	    }
	    else IECStatus=1;
	 }
	 
       case 0x81:
	 IECCom=0;
	 break;
	 
       default:
	 switch(b) {
	    
	  case 0x81:
	  case 0x82:
	  case 0x83:
	    IECCom=b;
	    break;
	    
	  case 0x84:
	    if((Ofile!=0)&&OfileR) {
	       IECPort=fgetc(Ofile);
	       fgetc(Ofile);
	       if(feof(Ofile))IECStatus=0x03;
	       else IECStatus=0x00;
	       fseek(Ofile,-1L,SEEK_CUR);
	    } else IECStatus=0x02;
	    break;
	    
	  default:
	    IECPort=b;
	    IECStatus=0;
	    break;
	 }
	 break;
      }
      IECFlag=0x00;
      break;
      
    case 0xf2:
      if(b==0)IECFlag=0xff;
      else IECFlag=0;
      break;
   }
   return;
}


uchar EmuWid::peekIEC(ushort a) {
   switch(a) {
    case 0xf0: return(IECPort);
    case 0xf1: return(IECStatus);
    case 0xf2: return(IECFlag);
   }
   return(0);
}


void EmuWid::pokeTED(ushort a, uchar b) {
   switch(a) {
    case 0x00:
      RTimer1=(RTimer1&0xff00)|b;
      break;
    case 0x01:
      RTimer1=(RTimer1&0x00ff)|(b<<8);
      break;
    case 0x02:
      RTimer2=(RTimer2&0xff00)|b;
      break;
    case 0x03:
      RTimer2=(RTimer2&0x00ff)|(b<<8);
      break;
    case 0x04:
      RTimer3=(RTimer3&0xff00)|b;
      break;
    case 0x05:
      RTimer3=(RTimer3&0x00ff)|(b<<8);
      break;
    case 0x06:
      TED_CON1=b;
      break;
    case 0x07:
      TED_CON2=b;
      break;
    case 0x08:
      TED_KEY=0;
      b=~KeyPort;
      if(b&1)	TED_KEY|=KeyMatrix[0];
      if(b&2)	TED_KEY|=KeyMatrix[1];
      if(b&4)	TED_KEY|=KeyMatrix[2];
      if(b&8)	TED_KEY|=KeyMatrix[3];
      if(b&16)	TED_KEY|=KeyMatrix[4];
      if(b&32)	TED_KEY|=KeyMatrix[5];
      if(b&64)	TED_KEY|=KeyMatrix[6];
      if(b&128)TED_KEY|=KeyMatrix[7];
      TED_KEY=~TED_KEY;
      break;
    case 0x09:
      b&=0x7f;
      TED_IRQ&=0x7f;
      b&=0xde;
      if(b&0x08)Timer1=RTimer1;
      if(b&0x10)Timer2=RTimer2;
      if(b&0x40)Timer3=RTimer3;
      if(b&0x80)TED_IRQ|=b&0x7f;
      else TED_IRQ&=~b;
      if(TED_IRQ&0x7f)TED_IRQ|=0x80;
      break;
    case 0x0a:
      TED_EIRQ=b&0x5e;
      IRLine&=0x0ff;
      if(b&1)IRLine+=0x100;
      break;
    case 0x0b:
      IRLine=(IRLine&0x100)|b;
      break;
    case 0x0c:
      CursorPos=(CursorPos&0x0ff)|((b&0x03)<<8);
      break;
    case 0x0d:
      CursorPos=(CursorPos&0x300)|b;
      break;
      //    case 0x0e:  ... write access ignored ...
      //    case 0x0f:  ... write access ignored ...
      //    case 0x10:  ... write access ignored ...
      //    case 0x11:  ... write access ignored ...
    case 0x12:
      TED_BMB=b&0x3c;
      if((TED_BMB&0x04)&&(TED_BMB>=0x20))
	BitMapBank=getBankPtr((TED_BMB&0x38)<<2)+((TED_BMB&0x08)<<10);
      else BitMapBank=Ram+(((TED_BMB&0x38)<<10)&Ram_Mask);
      break;
    case 0x13:
      TED_CB=b&0xfc;
      if((TED_BMB&0x04)&&(TED_CB>=0x80))
	CharBank=getBankPtr(TED_CB)+((TED_CB&0x3f)<<8);
      else CharBank=Ram+((TED_CB<<8)&Ram_Mask);
      break;
    case 0x14:
      TED_VM2=TED_VM;
      TED_VM=b&0xf8;
      VideoMatrix=Ram+((TED_VM<<8)&Ram_Mask);
      break;
    case 0x15:
      TED_C0=b&0x7f;
      break;
    case 0x16:
      TED_C1=b&0x7f;
      break;
    case 0x17:
      TED_C2=b&0x7f;
      break;
    case 0x18:
      TED_C3=b&0x7f;
      break;
    case 0x19:
      TED_C4=b&0x7f;
      break;
      //    case 0x1a:  ... write access ignored ...
      //    case 0x1b:  ... write access ignored ...
    case 0x1c:
      RLine&=0x0ff;
      if(b&1)RLine+=0x100;
      break;
    case 0x1d:
      RLine=(RLine&0x100)|b;
      break;
      //    case 0x1e:  ... write access ignored ...
      //    case 0x1f:  ... write access ignored ...
    case 0x3e:
      RamEnable = false;
      break;
    case 0x3f:
      RamEnable = true;
      break;
   }
}


uchar EmuWid::peekTED(ushort a) {
   switch(a) {
    case 0x00: return(Timer1&0xff);
    case 0x01: return(Timer1>>8);
    case 0x02: return(Timer2&0xff);
    case 0x03: return(Timer2>>8);
    case 0x04: return(Timer3&0xff);
    case 0x05: return(Timer3>>8);
    case 0x06: return(TED_CON1);
    case 0x07: return(TED_CON2);
    case 0x08: return(TED_KEY);
    case 0x09: return(TED_IRQ);
    case 0x0a: return(TED_EIRQ|(IRLine>>8));
    case 0x0b: return(IRLine&0xff);
    case 0x0c: return(CursorPos>>8);
    case 0x0d: return(CursorPos&0xff);
      //		case 0x0e: ... read access ignored ... returns 0 ...
      //		case 0x0f: ... read access ignored ... returns 0 ...
      //		case 0x10: ... read access ignored ... returns 0 ...
      //		case 0x11: ... read access ignored ... returns 0 ...
    case 0x12: return(TED_BMB);
    case 0x13: return(TED_CB);
    case 0x14: return(TED_VM);
    case 0x15: return(TED_C0);
    case 0x16: return(TED_C1);
    case 0x17: return(TED_C2);
    case 0x18: return(TED_C3);
    case 0x19: return(TED_C4);
      //		case 0x1a: ... read access ignored ... returns 0 ...
      //		case 0x1b: ... read access ignored ... returns 0 ...
    case 0x1c: return(RLine>>8);
    case 0x1d: return(RLine&0xff);
    case 0x1e: return(RHori>>1);
      //		case 0x1f: ... read access ignored ... returns 0 ...
    case 0x3a: return(Instr_per_Line&255); // <=== Magic-TED
      //		case 0x3e: ... read access ignored ... returns 0 ...
      //		case 0x3f: ... read access ignored ... returns 0 ...
   }
   return 0;
}


void EmuWid::paintLine(int line) {
   QPixmap pix;

   memcpy(img->bits(), screenLine(line), scr_width);
   if(!pix.convertFromImage(*img)) {
      fatalError("pix.convertFromImage(img) failed!\n");
   }
   if(scr_zoom!=1) {
      QWMatrix m;
      m.scale(scr_zoom, scr_zoom);
      pix = pix.xForm(m);
   }
   if(small_border) {
      int y = screen2window(line) - small_yoff;
      if((y>=0)&&(y<(scr_height-2*small_yoff))) {
	 bitBlt(this, 0, y*scr_zoom, 
		&pix, scr_zoom*small_xoff, 0, 
		pix.width()-2*scr_zoom*small_xoff, scr_zoom);
      }
   }
   else
     bitBlt(this, 0, scr_zoom*screen2window(line), 
	    &pix, 0, 0, pix.width(), scr_zoom);
}


uchar *EmuWid::getBankPtr(uchar b) {
   if(b<0xc0) return Mod_Lo;
   else       return Mod_Hi;
}


void EmuWid::renderLine(int line, uchar *pix) {
#define setPixel(x,c) pix2[(x)]=((c)&0x7f)
   uchar *pix2 = pix+scr_off;
   ushort x,i,j,a;
   uchar *p;
   uchar *f;
   uchar b;
   ushort f0,f1;

   // border
   memset(pix, TED_C4, scr_width);
   if((line<3) || (line>=203)) return; // border
   if((TED_CON1&0x10)==0) return;      // screen blank
   if((TED_CON1&0x08)==0)
     if((line<7)||(line>=199)) return; // y mask
   
   // blank lines
   memset(pix + scr_off, TED_C0, 320);
   int d = line - (TED_CON1&7); // dy
   if((d>=200)||(d<0)) goto ende;
   
   // complex lines
   if((d&0x07)==0)VideoMatrixI=VideoMatrix;
   j=TED_CON2&7; // dx
   x=j;
   a=(d&0xf8)*5;
   f=VideoMatrixI+a;
   if(TED_CON1&0x20) { //Grafik-Mode 
      p=BitMapBank+(d&0xf8)*40+(d&7);
      if(TED_CON2&0x10) {//Multi	 
	 for(i=0;i<40;i++) {
	    f0=f[0x400]&0x0f;
	    f0|=*f&0x70;
	    f1=f[0x400]>>4;
	    f1|=*f<<4;
	    f1&=0x7f;
	    b=*p;
	    for(j=0;j<4;j++) {
	       switch(b&0xc0) {
		case 0x00:setPixel(x++,TED_C0);
		  setPixel(x++,TED_C0); break;
		case 0x40:setPixel(x++,f1);
		  setPixel(x++,f1);     break;
		case 0x80:setPixel(x++,f0);
		  setPixel(x++,f0);     break;
		case 0xc0:setPixel(x++,TED_C1);
		  setPixel(x++,TED_C1);
	       }
	       b<<=2;
	    }
	    p+=8;
	    f++;
	 }
      } else {            //Normal
	 for(i=0;i<40;i++) {
	    f0=*(f+0x400)&0x0f;
	    f0|=*f&0x70;
	    f1=*(f+0x400)>>4;
	    f1|=(*f<<4);
	    f1&=0x7f;
	    b=*p;
	    for(j=0;j<8;j++) {
	       if(b&IBit[j])setPixel(x++,f1);
	       else setPixel(x++,f0);
	    }
	    p+=8;
	    f++;
	 }
      }
   } else { //Text-Mode
      p=CharBank+(d&7);
      if(TED_CON2&0x10) { //Multi-Color
	 for(i=0;i<40;i++) {
	    f0=*f&0x7f;
	    f1=f[0x400];
	    if((TED_CON2&0x80)==0)f1&=0x7f;
	    b=p[f1<<3];
	    if(f0&0x08) {
	       f0&=0x77;
	       for(j=0;j<4;j++) {
		  switch(b&0xc0) {
		   case 0x00:setPixel(x++,TED_C0);
		     setPixel(x++,TED_C0); break;
		   case 0x40:setPixel(x++,TED_C1);
		     setPixel(x++,TED_C1); break;
		   case 0x80:setPixel(x++,TED_C2);
		     setPixel(x++,TED_C2); break;
		   case 0xc0:setPixel(x++,f0);
		     setPixel(x++,f0);
		  }
		  b<<=2;
	       }
	    } else {
	       for(j=0;j<8;j++) {
		  if(b&IBit[j])setPixel(x++,f0);
		  else setPixel(x++,TED_C0);
	       }
	    }
	    f++;
	 }
      } else if(TED_CON1&0x40) {  //Extended-Color
	 for(i=0;i<40;i++) {
	    f1=*f&0x7f;
	    f0=f[0x400];
	    b=p[(f0&0x3f)<<3];
	    switch(f0&0xc0) {
	     case 0x00:f0=TED_C0; break;
	     case 0x40:f0=TED_C1; break;
	     case 0x80:f0=TED_C2; break;
	     case 0xc0:f0=TED_C3; break;
	    }
	    for(j=0;j<8;j++) {
	       if(b&IBit[j])setPixel(x++,f1);
	       else setPixel(x++,f0);
	    }
	    f++;
	 }
      } else {	//Normal
	 for(i=0;i<40;i++) {
	    f0=*f;
	    f1=f[0x400];
	    b=p[f1<<3];
	    if(((TED_CON2&0x80)==0)&&(f1&0x80)) {
	       b=~p[(f1&0x7f)<<3];
	    }
	    if(Blink&0x10)if(CursorPos==a++)b=~b;
	    for(j=0;j<8;j++) {
	       if(b&IBit[j])setPixel(x++,f0);
	       else setPixel(x++,TED_C0);
	    }
	    f++;
	 }
      }
   }
   
   ende:
   if((TED_CON2&0x08) == 0) { // x mask
      for(x=0; x<8; x++) setPixel(x, TED_C4);
      for(x=312; x<320; x++) setPixel(x, TED_C4);
   }
#undef SetPixel
}




//
// ------------ TED-Chip ---------------------------------------------
// WR Reg  D7     D6     D5     D4     D3     D2     D1     D0    init
// wr$FF00    Timer #1 Reload-Value LOW
// wr$FF01    Timer #1 Reload-Value HI
// wr$FF02    Timer #2 Reload-Value LOW
// wr$FF03    Timer #2 Reload-Value HI
// wr$FF04    Timer #3 Reload-Value LOW
// wr$FF05    Timer #3 Reload-Value Hi
// wr$FF06 Test   ECM    BMM    Blank  ROWS   Y2     Y1     Y0    $1b
// wr$FF07 RVSof  PAL/   Freze  MCM    COLS   X2     X1     X0    $08
// .r$FF08    Keyboard-Latch
// wr$FF09 IRQ    I-T3   :      I-T2   I-T1   I-LP   I-RAS  :
// wr$FF0A :      EI-T3  :      EI-T2  EI-T1  EI-LP  EI-RAS RC8   $02
// wr$FF0B RC7    RC6    RC5    RC4    RC3    RC2    RC1    RC0   $cc
// wr$FF0C :      :      :      :      :      :      CUR9   CUR8
// wr$FF0D CUR7   CUR6   CUR5   CUR4   CUR3   CUR2   CUR1   CUR0
// ..$FF0E S17    S16    S15    S14    S13    S12    S11    S10
// ..$FF0F S27    S26    S25    S24    S23    S22    S21    S20
// ..$FF10 :      :      :      :      :      :      S29    S28
// ..$FF11 SRel   Noise  V2Sel  V1Sel  Vol3   Vol2   Vol1   Vol0
// wr$FF12 :      :      BMB2   BMB1   BMB0   RBank  S19    S18   $04
// wr$FF13 CB5    CB4    CB3    CB2    CB1    CB0    SClck  Status$d0
// wr$FF14 VM4    VM3    VM2    VM1    VM0    :      :      :     $08
// wr$FF15 :      Lum2   Lum1   Lum0   Colr3  Colr2  Colr1  Colr0 $71
// wr$FF16 :      Lum2   Lum1   Lum0   Colr3  Colr2  Colr1  Colr0 $5b
// wr$FF17 :      Lum2   Lum1   Lum0   Colr3  Colr2  Colr1  Colr0 $75
// wr$FF18 :      Lum2   Lum1   Lum0   Colr3  Colr2  Colr1  Colr0 $77
// wr$FF19 :      Lum2   Lum1   Lum0   Colr3  Colr2  Colr1  Colr0 $6e
// ..$FF1A :      :      :      :      :      :      BRE9   BRE8
// ..$FF1B BRE7   BRE6   BRE5   BRE4   BRE3   BRE2   BRE1   BRE0
// wr$FF1C :      :      :      :      :      :      :      VL8
// wr$FF1D VL7    VL6    VL5    VL4    VL3    VL2    VL1    VL0
// .r$FF1E H8     H7     H6     H5     H4     H3     H2     H1
// ..$FF1F :      BL3    BL2    BL1    BL0    VSUB2  VSUB1  VSUB0
// w.$FF3E    ROM-Select
// w.$FF3F    RAM-Select


#if 0

# = used

#define Key_Escape		0x1000		// misc keys
#define Key_Tab			0x1001
define Key_Backtab		0x1002
#define Key_Backspace		0x1003
#define Key_Return		0x1004
#define Key_Enter		0x1005
#define Key_Insert		0x1006
#define Key_Delete		0x1007
#define Key_Pause		0x1008
define Key_Print		0x1009
define Key_SysReq		0x100a
#define Key_Home		0x1010		// cursor movement
define Key_End			0x1011
#define Key_Left		0x1012
#define Key_Up			0x1013
#define Key_Right		0x1014
#define Key_Down		0x1015
define Key_Prior		0x1016
define Key_PageUp		Key_Prior
define Key_Next		0x1017
define Key_PageDown		Key_Next
#define Key_Shift		0x1020		// modifiers
#define Key_Control		0x1021
#define Key_Meta		0x1022
#define Key_Alt			0x1023
define Key_CapsLock		0x1024
define Key_NumLock		0x1025
define Key_ScrollLock		0x1026	// see translateKeyEvent()
#define Key_F1			0x1030		// function keys
#define Key_F2			0x1031
#define Key_F3			0x1032
#define Key_F4			0x1033
#define Key_F5			0x1034
#define Key_F6			0x1035
#define Key_F7			0x1036
#define Key_F8			0x1037
define Key_F9			0x1038
define Key_F10			0x1039
define Key_F11			0x103a
define Key_F12			0x103b
define Key_F13			0x103c
define Key_F14			0x103d
define Key_F15			0x103e
define Key_F16			0x103f
define Key_F17			0x1040
define Key_F18			0x1041
define Key_F19			0x1042
define Key_F20			0x1043
define Key_F21			0x1044
define Key_F22			0x1045
define Key_F23			0x1046
define Key_F24			0x1047
#define Key_Space		0x20		// 7 bit printable ASCII
#define Key_Exclam		0x21
#define Key_QuoteDbl		0x22
#define Key_NumberSign		0x23
#define Key_Dollar		0x24
#define Key_Percent		0x25
#define Key_Ampersand		0x26
#define Key_Apostrophe		0x27
#define Key_ParenLeft		0x28
#define Key_ParenRight		0x29
#define Key_Asterisk		0x2a
#define Key_Plus		0x2b
#define Key_Comma		0x2c
#define Key_Minus		0x2d
#define Key_Period		0x2e
#define Key_Slash		0x2f
#define Key_0			0x30
#define Key_1			0x31
#define Key_2			0x32
#define Key_3			0x33
#define Key_4			0x34
#define Key_5			0x35
#define Key_6			0x36
#define Key_7			0x37
#define Key_8			0x38
#define Key_9			0x39
#define Key_Colon		0x3a
#define Key_Semicolon		0x3b
#define Key_Less		0x3c
#define Key_Equal		0x3d
#define Key_Greater		0x3e
#define Key_Question		0x3f
#define Key_At			0x40
#define Key_A			0x41
#define Key_B			0x42
#define Key_C			0x43
#define Key_D			0x44
#define Key_E			0x45
#define Key_F			0x46
#define Key_G			0x47
#define Key_H			0x48
#define Key_I			0x49
#define Key_J			0x4a
#define Key_K			0x4b
#define Key_L			0x4c
#define Key_M			0x4d
#define Key_N			0x4e
#define Key_O			0x4f
#define Key_P			0x50
#define Key_Q			0x51
#define Key_R			0x52
#define Key_S			0x53
#define Key_T			0x54
#define Key_U			0x55
#define Key_V			0x56
#define Key_W			0x57
#define Key_X			0x58
#define Key_Y			0x59
#define Key_Z			0x5a
#define Key_BracketLeft		0x5b
#define Key_Backslash		0x5c
#define Key_BracketRight	0x5d
#define Key_AsciiCircum		0x5e
#define Key_Underscore		0x5f
define Key_QuoteLeft		0x60
define Key_BraceLeft		0x7b
define Key_Bar			0x7c
define Key_BraceRight		0x7d
#define Key_AsciiTilde		0x7e
// Latin 1 codes adapted from X: keysymdef.h,v 1.21 94/08/28 16:17:06
define Key_nobreakspace	0x0a0
define Key_exclamdown		0x0a1
define Key_cent		0x0a2
#define Key_sterling		0x0a3
define Key_currency		0x0a4
define Key_yen			0x0a5
define Key_brokenbar		0x0a6
define Key_section		0x0a7
define Key_diaeresis		0x0a8
define Key_copyright		0x0a9
define Key_ordfeminine		0x0aa
define Key_guillemotleft	0x0ab	/* left angle quotation mark */
define Key_notsign		0x0ac
define Key_hyphen		0x0ad
define Key_registered		0x0ae
define Key_macron		0x0af
define Key_degree		0x0b0
define Key_plusminus		0x0b1
define Key_twosuperior		0x0b2
define Key_threesuperior	0x0b3
define Key_acute		0x0b4
define Key_mu			0x0b5
#define Key_paragraph		0x0b6
define Key_periodcentered	0x0b7
define Key_cedilla		0x0b8
define Key_onesuperior		0x0b9
define Key_masculine		0x0ba
define Key_guillemotright	0x0bb	/* right angle quotation mark */
define Key_onequarter		0x0bc
define Key_onehalf		0x0bd
define Key_threequarters	0x0be
define Key_questiondown	0x0bf
define Key_Agrave		0x0c0
define Key_Aacute		0x0c1
define Key_Acircumflex		0x0c2
define Key_Atilde		0x0c3
define Key_Adiaeresis		0x0c4
define Key_Aring		0x0c5
define Key_AE			0x0c6
define Key_Ccedilla		0x0c7
define Key_Egrave		0x0c8
define Key_Eacute		0x0c9
define Key_Ecircumflex		0x0ca
define Key_Ediaeresis		0x0cb
define Key_Igrave		0x0cc
define Key_Iacute		0x0cd
define Key_Icircumflex		0x0ce
define Key_Idiaeresis		0x0cf
define Key_ETH			0x0d0
define Key_Ntilde		0x0d1
define Key_Ograve		0x0d2
define Key_Oacute		0x0d3
define Key_Ocircumflex		0x0d4
define Key_Otilde		0x0d5
define Key_Odiaeresis		0x0d6
define Key_multiply		0x0d7
define Key_Ooblique		0x0d8
define Key_Ugrave		0x0d9
define Key_Uacute		0x0da
define Key_Ucircumflex		0x0db
define Key_Udiaeresis		0x0dc
define Key_Yacute		0x0dd
define Key_THORN		0x0de
#define Key_ssharp		0x0df
define Key_agrave		0x0e0
define Key_aacute		0x0e1
define Key_acircumflex		0x0e2
define Key_atilde		0x0e3
define Key_adiaeresis		0x0e4
define Key_aring		0x0e5
define Key_ae			0x0e6
define Key_ccedilla		0x0e7
define Key_egrave		0x0e8
define Key_eacute		0x0e9
define Key_ecircumflex		0x0ea
define Key_ediaeresis		0x0eb
define Key_igrave		0x0ec
define Key_iacute		0x0ed
define Key_icircumflex		0x0ee
define Key_idiaeresis		0x0ef
define Key_eth			0x0f0
define Key_ntilde		0x0f1
define Key_ograve		0x0f2
define Key_oacute		0x0f3
define Key_ocircumflex		0x0f4
define Key_otilde		0x0f5
define Key_odiaeresis		0x0f6
define Key_division		0x0f7
define Key_oslash		0x0f8
define Key_ugrave		0x0f9
define Key_uacute		0x0fa
define Key_ucircumflex		0x0fb
define Key_udiaeresis		0x0fc
define Key_yacute		0x0fd
define Key_thorn		0x0fe
define Key_ydiaeresis		0x0ff
define Key_unknown		0xffff

#endif




// *****



void EmuWid::initKeyTrans() {
   // special   
   qtkey[Key_BracketLeft] = K_Colon + K_SHIFT;
   qtkey[Key_BracketRight] = K_Semi + K_SHIFT;
   qtkey[Key_paragraph] = K_Pfund;
   qtkey[Key_ssharp] = K_Pfund;
   qtkey[Key_Backslash] = K_Pfund;
   qtkey[Key_Underscore] = K_Gl + K_SHIFT;
   qtkey[Key_AsciiTilde] = K_Gl + K_COMO;
   qtkey[Key_Tab] = K_RunStop;
   
   qtkey[Key_Comma] = K_Kl;
   qtkey[Key_Period] = K_Gr;
   qtkey[Key_Slash] = K_Quest + K_FORCENONE;
   
   qtkey[Key_Exclam] = K_1 + K_SHIFT;
   qtkey[Key_QuoteDbl] = K_2 + K_SHIFT;
   qtkey[Key_NumberSign] = K_3 + K_SHIFT;
   qtkey[Key_Dollar] = K_4 + K_SHIFT;
   qtkey[Key_Percent] = K_5 + K_SHIFT;
   qtkey[Key_Ampersand] = K_6 + K_SHIFT;
   qtkey[Key_Apostrophe] = K_7 + K_SHIFT;
   qtkey[Key_ParenLeft] = K_8 + K_SHIFT;
   qtkey[Key_ParenRight] = K_9 + K_SHIFT;
   qtkey[Key_AsciiCircum] = K_0 + K_SHIFT;
   
   qtkey[Key_At] = K_At + K_FORCENONE;
   qtkey[Key_Minus] = K_Minus + K_FORCENONE;
   qtkey[Key_Plus] = K_Plus + K_FORCENONE;
   qtkey[Key_Equal] = K_Gl + K_FORCENONE;
   qtkey[Key_Colon] = K_Colon + K_FORCENONE;
   qtkey[Key_Semicolon] = K_Semi + K_FORCENONE;
   qtkey[Key_Asterisk] = K_Ast + K_FORCENONE;
   qtkey[Key_Insert] = K_Inst + K_SHIFT;
   qtkey[Key_Question] = K_Quest + K_SHIFT;
   qtkey[Key_Less] = K_Kl + K_SHIFT;
   qtkey[Key_Greater] = K_Gr + K_SHIFT;
   
   // modifiers
   qtkey[Key_Shift] = K_Shift;
   qtkey[Key_Control] = K_Ctrl;
   qtkey[Key_Alt] = K_Como;
   qtkey[Key_Meta] = K_Como;

   // special
   qtkey[Key_Escape] = K_Escape;
   qtkey[Key_F1] = K_F1;
   qtkey[Key_F2] = K_F2;
   qtkey[Key_F3] = K_F3;
   qtkey[Key_F4] = K_F1 + K_SHIFT;
   qtkey[Key_F5] = K_F2 + K_SHIFT;
   qtkey[Key_F6] = K_F3 + K_SHIFT;
   qtkey[Key_F7] = K_Help + K_SHIFT;
   qtkey[Key_F8] = K_Help;
   qtkey[Key_Space] = K_Space;
   qtkey[Key_Up] = K_CUp;
   qtkey[Key_Down] = K_CDn;
   qtkey[Key_Left] = K_CLe;
   qtkey[Key_Right] = K_CRi;
   qtkey[Key_Home] = K_Clear;
   qtkey[Key_Return] = K_Return;
   qtkey[Key_Enter] = K_Return;
   qtkey[Key_Pause] = K_RunStop;   
   qtkey[Key_sterling] = K_Pfund;   
   qtkey[Key_Backspace] = K_Inst;
   qtkey[Key_Delete] = K_Inst;
   
   // 0-9A-Z
   qtkey[Key_0] = K_0;
   qtkey[Key_1] = K_1;
   qtkey[Key_2] = K_2;
   qtkey[Key_3] = K_3;
   qtkey[Key_4] = K_4;
   qtkey[Key_5] = K_5;
   qtkey[Key_6] = K_6;
   qtkey[Key_7] = K_7;
   qtkey[Key_8] = K_8;
   qtkey[Key_9] = K_9;
   qtkey[Key_A] = K_A;
   qtkey[Key_B] = K_B;
   qtkey[Key_C] = K_C;
   qtkey[Key_D] = K_D;
   qtkey[Key_E] = K_E;
   qtkey[Key_F] = K_F;
   qtkey[Key_G] = K_G;
   qtkey[Key_H] = K_H;
   qtkey[Key_I] = K_I;
   qtkey[Key_J] = K_J;
   qtkey[Key_K] = K_K;
   qtkey[Key_L] = K_L;
   qtkey[Key_M] = K_M;
   qtkey[Key_N] = K_N;
   qtkey[Key_O] = K_O;
   qtkey[Key_P] = K_P;
   qtkey[Key_Q] = K_Q;
   qtkey[Key_R] = K_R;
   qtkey[Key_S] = K_S;
   qtkey[Key_T] = K_T;
   qtkey[Key_U] = K_U;
   qtkey[Key_V] = K_V;
   qtkey[Key_W] = K_W;
   qtkey[Key_X] = K_X;
   qtkey[Key_Y] = K_Y;
   qtkey[Key_Z] = K_Z;
}




