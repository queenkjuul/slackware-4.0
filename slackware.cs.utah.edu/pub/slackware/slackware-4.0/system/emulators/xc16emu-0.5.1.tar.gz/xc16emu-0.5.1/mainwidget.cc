/*GPL*START*
 * 
 * Copyright (C) 1998 by Johannes Overmann <overmann@iname.com>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 * *GPL*END*/  

#include <stdlib.h>
#include <qapp.h>
#include <qkeycode.h>
#include <qpopmenu.h>
#include <qmsgbox.h>
#include <qlabel.h>
#include <qlayout.h>
#include <qmenubar.h>


#include "mainwidget.h"
#include "tappconfig.h"

#include "emuwid.h"


MainWidget::MainWidget(QWidget *parent): QWidget(parent) {
   // setup emu
   emu = new EmuWid(this);

   // setup menu
   menu = new QMenuBar(this);
   
   // file menu
   QPopupMenu *file = new QPopupMenu();
   file->insertItem("Reset", emu, SLOT(emuReset()), ALT+Key_R);
   file->insertSeparator();
   file->insertItem("Quit", qApp, SLOT(quit()), ALT+Key_Q);
   
   // help
   QPopupMenu *help = new QPopupMenu;
   help->insertItem("Info", this, SLOT(info()));
   help->insertSeparator();
   help->insertItem("About " + tApp->getString("application-name"), this, SLOT(about()), CTRL+Key_H);
   help->insertItem("About Qt", this, SLOT(aboutQt()));
   
   // options
   opt = new QPopupMenu;
   opt->setCheckable(true);
   ram16Id = opt->insertItem("&16K Ram (C16, C116)", this, SLOT(set_ram16()));
   ram32Id = opt->insertItem("&32K Ram (C16, C116 + 16K expansion)", this, SLOT(set_ram32()));
   ram64Id = opt->insertItem("&64K Ram (plus/4)", this, SLOT(set_ram64()));
   opt->insertSeparator();
   smallId = opt->insertItem("&Small Border", this, SLOT(tog_small()));
   zoom1Id = opt->insertItem("Z&oom 1", this, SLOT(set_zoom1()));
   zoom2Id = opt->insertItem("Zoom &2", this, SLOT(set_zoom2()));
   zoom3Id = opt->insertItem("&Zoom 3", this, SLOT(set_zoom3()));
   zoom4Id = opt->insertItem("Zoom &4", this, SLOT(set_zoom4()));
   opt->insertSeparator();
   enSoId = opt->insertItem("&Enable Expansion Rom Bank 1 (plus/4 Software)", this, SLOT(tog_enSo()));
   enE1Id = opt->insertItem("E&nable Expansion Rom Bank 2", this, SLOT(tog_enE1()));
   enE2Id = opt->insertItem("En&able Expansion Rom Bank 3", this, SLOT(tog_enE2()));
   opt->setItemChecked(smallId, false);
   opt->setItemChecked(enSoId, false);
   opt->setItemChecked(enE1Id, false);
   opt->setItemChecked(enE2Id, false);
   
   // menu bar
   menu->insertItem("&File", file);  
   menu->insertItem("&Options", opt);  
   menu->insertSeparator();
   menu->insertItem("&Help", help);  
   
   
   // setup screen
   QBoxLayout *lay0 = new QBoxLayout(this, QBoxLayout::Down);
   QBoxLayout *st_bar = new QBoxLayout(QBoxLayout::LeftToRight);
   lay0->setMenuBar(menu);

   
   lay0->addWidget(emu, 10);
   
   // status bar
   lay0->addLayout(st_bar,0);
   stat = new QLabel("toll", this);
   stat->setMinimumSize(stat->sizeHint());
   st_bar->addWidget(stat, 10);
   stat->setFrameStyle(QFrame::Sunken | QFrame::Panel);
   stat->setLineWidth(2);
   stat->setAlignment(AlignVCenter);
   
   lay0->activate();
   
   
   // connections
   connect(emu, SIGNAL(frameRate(double)), SLOT(showFrameRate(double)));
   
   // end
   set_ram64();
   set_zoom1();
   tog_enSo();
   tog_enE1();
   tog_enE2();
   tog_small();
}


MainWidget::~MainWidget() {
}


void MainWidget::showFrameRate(double rate) {
   char buf[1000];
   
   sprintf(buf, "%.2f fps, speed = %.1f%%", rate, rate/50.0*100.0); 
   stat->setText(buf);   
}


void MainWidget::about() {
   QMessageBox::about(this, "About " + tApp->getString("application-name"), 
		       tApp->getString("application-name") + " V" + 
		       tApp->getString("application-version") + 
		       "\n\n(C) 1997 by\n\nJohannes Overmann"); 
}


void MainWidget::aboutQt() {
  QMessageBox::aboutQt(this, "About Qt");
}


void MainWidget::info() {
   string mes;
   
   mes = "toll";
   
   QMessageBox::information(0, "Info", mes, QMessageBox::Ok + QMessageBox::Default);
}
  

void MainWidget::set_ram16() {
   opt->setItemChecked(ram16Id, true);
   opt->setItemChecked(ram32Id, false);
   opt->setItemChecked(ram64Id, false);
   emu->setRam(16);
}


void MainWidget::set_ram32() {
   opt->setItemChecked(ram16Id, false);
   opt->setItemChecked(ram32Id, true);
   opt->setItemChecked(ram64Id, false);
   emu->setRam(32);
}


void MainWidget::set_ram64() {
   opt->setItemChecked(ram16Id, false);
   opt->setItemChecked(ram32Id, false);
   opt->setItemChecked(ram64Id, true);
   emu->setRam(64);
}


void MainWidget::set_zoom1() {
   opt->setItemChecked(zoom1Id, true);
   opt->setItemChecked(zoom2Id, false);
   opt->setItemChecked(zoom3Id, false);
   opt->setItemChecked(zoom4Id, false);
   emu->setZoom(1);
   setFixedSize(emu->size().width(), emu->height()+stat->sizeHint().height()+menu->height());
}


void MainWidget::set_zoom2() {
   opt->setItemChecked(zoom1Id, false);
   opt->setItemChecked(zoom2Id, true);
   opt->setItemChecked(zoom3Id, false);
   opt->setItemChecked(zoom4Id, false);
   emu->setZoom(2);
   setFixedSize(emu->size().width(), emu->height()+stat->sizeHint().height()+menu->height());
}


void MainWidget::set_zoom3() {
   opt->setItemChecked(zoom1Id, false);
   opt->setItemChecked(zoom2Id, false);
   opt->setItemChecked(zoom3Id, true);
   opt->setItemChecked(zoom4Id, false);
   emu->setZoom(3);
   setFixedSize(emu->size().width(), emu->height()+stat->sizeHint().height()+menu->height());
}


void MainWidget::set_zoom4() {
   opt->setItemChecked(zoom1Id, false);
   opt->setItemChecked(zoom2Id, false);
   opt->setItemChecked(zoom3Id, false);
   opt->setItemChecked(zoom4Id, true);
   emu->setZoom(4);
   setFixedSize(emu->size().width(), emu->height()+stat->sizeHint().height()+menu->height());
}


void MainWidget::tog_small() {   
   opt->setItemChecked(smallId, !opt->isItemChecked(smallId));
   emu->setSmallBorder(opt->isItemChecked(smallId));
   setFixedSize(emu->size().width(), emu->height()+stat->sizeHint().height()+menu->height());
}


void MainWidget::tog_enSo() {   
   opt->setItemChecked(enSoId, !opt->isItemChecked(enSoId));
   emu->setRomEnable(opt->isItemChecked(enSoId), opt->isItemChecked(enE1Id), opt->isItemChecked(enE2Id));
}


void MainWidget::tog_enE1() {   
   opt->setItemChecked(enE1Id, !opt->isItemChecked(enE1Id));
   emu->setRomEnable(opt->isItemChecked(enSoId), opt->isItemChecked(enE1Id), opt->isItemChecked(enE2Id));
}


void MainWidget::tog_enE2() {   
   opt->setItemChecked(enE2Id, !opt->isItemChecked(enE2Id));
   emu->setRomEnable(opt->isItemChecked(enSoId), opt->isItemChecked(enE1Id), opt->isItemChecked(enE2Id));
}






