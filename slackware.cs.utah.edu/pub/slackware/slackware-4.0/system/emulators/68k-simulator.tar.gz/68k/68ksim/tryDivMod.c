#include <math.h>
#include <stdio.h>

main()
{
	int	signnum, signden, signquo, signrem;
	unsigned unnum,unden;

	signnum = -8;
	signden = 3;
	signquo = signnum / signden;
	signrem = signnum % signden;
	printf("\nsignquo = %d", signquo);
	printf("\nsignrem = %d", signrem);

        signnum = 8;
        signden = -3;
        signquo = signnum / signden;
        signrem = signnum % signden;
        printf("\nsignquo = %d", signquo);
        printf("\nsignrem = %d", signrem);

	fflush(stdout);
}
