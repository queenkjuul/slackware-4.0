/* mz700em-specific #define's */

/* these are offsets in mem[] */
#define ROM_START	0		/* monitor rom */
#define VID_START	(4*1024)	/* video ram */
#define RAM_START	(8*1024)	/* 64k normal ram */
