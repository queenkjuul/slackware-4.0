#include <stdio.h>

convert(char[],char[]);

main()
{
	convert("b:system1","system1.bin");
	convert("b:system2","system2.bin");
	convert("b:system3","system3.bin");
	convert("b:system4","system4.bin");
	convert("b:system5","system5.bin");
}

convert(char inname[],char outname[])
{
	FILE *infile,*outfile;
	int i,c;

	printf("\nPress any key to convert %s -> %s ",inname,outname);
	while(!kbhit()); getch();
	printf("\nWorking...\n");

	infile=fopen(inname,"rb");
	outfile=fopen(outname,"wb");

	for(i=0;i<13;i++) fgetc(infile);

	i=0;
	while(!feof(infile))
	{
		c=fgetc(infile);
		if (i++<10) printf("%02x %c\n",c,c);
		fputc(c,outfile);
	}

	fclose(infile);
	fclose(outfile);
}