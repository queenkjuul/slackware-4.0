/* KSCAN emulatie */

/* F1..F10 key code mapping, plus translation of cursor control keys */

int FCTN[]={
  3,  4,  7,  2, 14, 12,  1,  6, 15,  5,
255,255,255, 11, 12,255,  8,255,  9,255,
255, 10,  2,  4,  3};

void KSCAN(void)
{
	if (KBHIT)
	{
		word key;
		key=GETKEY;
#ifndef unix
		if (!key&&KBHIT)
#else
		if ((key==27)&&KBHIT)
#endif
		{
#ifndef unix
			key=GETKEY-59;
#else
			key=GETKEY-49;
#endif
			if (key<26) key=FCTN[key];
		}
		memory_write(WP+12,0x2000);
		memory_write(WP,key<<8);
	}
	else
	{
		memory_write(WP+12,0);
		memory_write(WP,0xFF00);
	}
	PC=0x478;
}
