/* This utility strips off the TIFILES header, produced by the LOADER
   utility, and swaps the hi- and lo- order bytes.
*/

#include <stdio.h>


main()
{
	int i,hibyte,lobyte;
	FILE *infile,*outfile;

	infile=fopen("diskrom.bin","r+b");
	outfile=fopen("diskr.bin","w+b");

	printf("\n\n\n");
	for(i=0;i<134;i++) fgetc(infile);

	while(!feof(infile))
	{
		hibyte=fgetc(infile);
		lobyte=fgetc(infile);
		fputc(lobyte,outfile);
		fputc(hibyte,outfile);
	}
	fclose(infile);
	fclose(outfile);
}