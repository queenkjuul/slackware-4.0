void (*opcode_table[])()={
_TAB2,_TAB2,_TAB2,_TAB2,_TAB2,_TAB2,_TAB2,_TAB2, 	/* 00-0F */
SRA ,SRL ,SLA ,SRC ,ILL ,ILL ,ILL ,ILL ,
JMP ,JLT ,JLE ,JEQ ,JHE ,JGT ,JNE ,JNC ,        /* 10-1F */
JOC ,JNO ,JL  ,JH  ,JOP ,SBO ,SBZ ,TB  ,
COC ,COC ,COC ,COC ,CZC ,CZC ,CZC ,CZC ,	/* 20-2F */
XOR ,XOR ,XOR ,XOR ,XOP ,XOP ,XOP ,XOP ,
LDCR,LDCR,LDCR,LDCR,STCR,STCR,STCR,STCR,	/* 30-3F */
MPY ,MPY ,MPY ,MPY ,DIV ,DIV ,DIV ,DIV ,
SZC ,SZC ,SZC ,SZC ,SZC ,SZC ,SZC ,SZC ,	/* 40-4F */
SZC ,SZC ,SZC ,SZC ,SZC ,SZC ,SZC ,SZC ,
SZCB,SZCB,SZCB,SZCB,SZCB,SZCB,SZCB,SZCB,	/* 50-5F */
SZCB,SZCB,SZCB,SZCB,SZCB,SZCB,SZCB,SZCB,
S   ,S   ,S   ,S   ,S   ,S   ,S   ,S   ,	/* 60-6F */
S   ,S   ,S   ,S   ,S   ,S   ,S   ,S   ,
SB  ,SB  ,SB  ,SB  ,SB  ,SB  ,SB  ,SB  ,	/* 70-7F */
SB  ,SB  ,SB  ,SB  ,SB  ,SB  ,SB  ,SB  ,
C   ,C   ,C   ,C   ,C   ,C   ,C   ,C   ,	/* 80-7F */
C   ,C   ,C   ,C   ,C   ,C   ,C   ,C   ,
CB  ,CB  ,CB  ,CB  ,CB  ,CB  ,CB  ,CB  ,	/* 90-7F */
CB  ,CB  ,CB  ,CB  ,CB  ,CB  ,CB  ,CB  ,
A   ,A   ,A   ,A   ,A   ,A   ,A   ,A   ,	/* A0-AF */
A   ,A   ,A   ,A   ,A   ,A   ,A   ,A   ,
AB  ,AB  ,AB  ,AB  ,AB  ,AB  ,AB  ,AB  ,	/* B0-BF */
AB  ,AB  ,AB  ,AB  ,AB  ,AB  ,AB  ,AB  ,
MOV ,MOV ,MOV ,MOV ,MOV ,MOV ,MOV ,MOV ,	/* C0-CF */
MOV ,MOV ,MOV ,MOV ,MOV ,MOV ,MOV ,MOV ,
MOVB,MOVB,MOVB,MOVB,MOVB,MOVB,MOVB,MOVB,	/* D0-DF */
MOVB,MOVB,MOVB,MOVB,MOVB,MOVB,MOVB,MOVB,
SOC ,SOC ,SOC ,SOC ,SOC ,SOC ,SOC ,SOC ,	/* E0-EF */
SOC ,SOC ,SOC ,SOC ,SOC ,SOC ,SOC ,SOC ,
SOCB,SOCB,SOCB,SOCB,SOCB,SOCB,SOCB,SOCB,	/* F0-FF */
SOCB,SOCB,SOCB,SOCB,SOCB,SOCB,SOCB,SOCB
};

/*

Special opcodes: >0000..>01FF

>0000..>001F: Illegal
>0020..>003F: Disk emulation (use in disk DSR only)
>0040..>004F: Unassigned (illegal)
etc...

*/

void (*low_opcode_table[])()={
ILL ,DISK,ILL ,ILL ,ILL ,ILL ,ILL ,ILL ,	/* 0000-00FF */
ILL ,ILL ,ILL ,ILL ,ILL ,ILL ,ILL ,ILL ,	/* 0100-01FF */
LI  ,AI  ,ANDI,ORI ,CI  ,STWP,STST,LWPI,        /* 0200-02FF */
LIMI,ILL ,ILL ,ILL ,RTWP,ILL ,ILL ,ILL ,	/* 0300-03FF */
BLWP,BLWP,B   ,B   ,eX  ,eX  ,CLR ,CLR ,	/* 0400-04FF */
NEG ,NEG ,INV ,INV ,INC ,INC ,INCT,INCT,	/* 0500-05FF */
DEC ,DEC ,DECT,DECT,BL  ,BL  ,SWPB,SWPB,	/* 0600-06FF */
SETO,SETO,ABS ,ABS ,ILL ,ILL ,ILL ,ILL  };	/* 0700-07FF */
