/* This utility scans & displays a configuration file
 * It is an unnescessary piece of software :-)
 * Ton Brouwer '94
 */

#include <stdio.h>
#include <string.h>

main(int argc,char *argv[])
{
FILE *infile;
char configname[20],line[80],filename[15],memtype;
int base,offset,length;

if (argc>1) strcpy(configname,argv[1]);
else strcpy(configname,"ticonfig.dat");
if ((infile=fopen(configname,"r"))==NULL)
{
	printf("Config file '%s' not found!\n",configname);
	exit(0);
}
else
{
	while(!feof(infile))
	{
		fgets(line,80,infile);
		if ((line[0]!='*')&&(line[0]!=' ')&&(strlen(line)>8))
		{
			if(sscanf(line,"%s %c %x %x %x",filename,
			&memtype,&base,&offset,&length)!=5)
			printf("SYNTAX ERROR in '%s'\n>>> %s <<<\n",
			configname,line);
			else
			{
				printf("Filename: %s\n",filename);
				printf("Memtype : %c\n",memtype);
				printf("Address : %04x\n",base);
				printf("Skip	: %d\n",offset);
				printf("Length  : %04x\n",length);
			}
		}
	}
}
}
