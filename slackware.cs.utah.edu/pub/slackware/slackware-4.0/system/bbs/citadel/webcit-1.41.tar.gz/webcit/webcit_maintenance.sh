#!/bin/bash

# This is a simple script to clean up outdated temporary files.
# Edit it accordingly to reflect the names of the directories
# you're using, and have your system run it periodically.

find /tmp -name webcit.\* -mtime +2 -exec rm -f {} \;
find /var/webcit-dynamic -mtime +5 -exec rm -f {} \;
