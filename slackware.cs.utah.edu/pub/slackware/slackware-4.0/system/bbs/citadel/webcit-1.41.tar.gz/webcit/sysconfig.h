/*
 * This is a generic sysconfig.h for client-side support.
 * There is NO need to change these values.  The large-ish looking structures
 * will not actually be stored on your computer.
 */
#define MAXROOMS	1024		/* Number of rooms in system        */
#define MAXFLOORS	127		/* Do not set higher than 127       */
#define MAILSLOTS	1024		/* Number of mail slots per user    */
#define MSGSPERRM	1024		/* Messages per room                */
#define CALLLOG		1024		/* Number of entries in call log    */
