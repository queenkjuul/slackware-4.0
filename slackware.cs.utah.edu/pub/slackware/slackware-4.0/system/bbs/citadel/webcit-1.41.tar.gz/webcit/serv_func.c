#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include "ipcdef.h"

extern struct serv_info serv_info;

extern void url();

/*
 * get info about the server we've connected to
 */
void get_serv_info() {
	char buf[256];
	int a;

	strcpy(buf,"IDEN 0|4|141|Cit/UX Web Service|");
	if (getenv("REMOTE_HOST")!=NULL) strcat(buf,getenv("REMOTE_HOST"));
	serv_puts(buf);
	serv_gets(buf);

	serv_puts("INFO");
	serv_gets(buf);
	if (buf[0]!='1') return;

	a = 0;
	while(serv_gets(buf), strcmp(buf,"000")) {
	    switch(a) {
		case 0:		serv_info.serv_pid = atoi(buf);
				break;
		case 1:		strcpy(serv_info.serv_nodename,buf);
				break;
		case 2:		strcpy(serv_info.serv_humannode,buf);
				break;
		case 3:		strcpy(serv_info.serv_fqdn,buf);
				break;
		case 4:		strcpy(serv_info.serv_software,buf);
				break;
		case 5:		serv_info.serv_rev_level = atoi(buf);
				break;
		case 6:		strcpy(serv_info.serv_bbs_city,buf);
				break;
		case 7:		strcpy(serv_info.serv_sysadm,buf);
				break;
		case 9:		strcpy(serv_info.serv_moreprompt,buf);
				break;
		}
	    ++a;
	    }
	}


/* 
 * Function to spit out Citadel variformat text in HTML
 * If fp is non-null, it is considered to be the file handle to read the
 * text from.  Otherwise, text is read from the server.
 */
void fmout(fp)
FILE *fp; {

	int intext = 0;
	int bq = 0;
	int a;
	char buf[256];

	while(1) {
		if (fp==NULL) serv_gets(buf);
		if (fp!=NULL) {
			if (fgets(buf,256,fp)==NULL) strcpy(buf,"000");
			buf[strlen(buf)-1] = 0;
			}
		if (!strcmp(buf,"000")) {
			if (bq==1) printf("</I>");
			printf("<P>\n");
			return;
			}
		if ( (intext==1) && (isspace(buf[0])) ) {
			printf("<BR>");
			}
		intext = 1;

		/* Quoted text should be displayed in italics and in a
		 * different colour.  This code understands both Citadel/UX
		 * style " >" quotes and FordBoard-style " :-)" quotes.
		 */
		if ((bq==0)&&
		   ((!strncmp(buf," >",2))||(!strncmp(buf," :-)",4)))) {
			printf("<FONT COLOR=\"000044\"><I>");
			bq = 1;
			}
		else if ((bq==1)&&
		     (strncmp(buf," >",2))&&(strncmp(buf," :-)",4))) {
			printf("</FONT></I>");
			bq = 0;
			}

		/* Activate embedded URL's */
		url(buf);

		escputs(buf);
		printf("\n");
		}
	}
