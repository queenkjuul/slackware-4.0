/*
 * Target frame/window for embedded URL's.  You can set this
 * to "_new" to have every embedded link open up in its own
 * browser window, or set it to any unique non-reserved
 * string to have all embedded links open up in the same
 * browser window.  In either case, the browser window running
 * WebCit stays put.
 */
#define TARGET "webcit01"

/*
 * left and right brackets that won't get escaped out
 */
#define LB	((char)('<'+(char)128))
#define	RB	((char)('>'+(char)128))
#define	QU	((char)('\"'+(char)128))
