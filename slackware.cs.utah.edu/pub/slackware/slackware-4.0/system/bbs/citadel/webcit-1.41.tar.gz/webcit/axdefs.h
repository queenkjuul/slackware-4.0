#ifndef AXDEFS

char *axdefs[7]={
	"Deleted",
	"New User",
	"Problem User",
	"Local User",
	"Network User",
	"Preferred User",
	"Aide"
	};
#define AXDEFS 1

#else

extern char *axdefs[];

#endif
