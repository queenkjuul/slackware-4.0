#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <signal.h>
#include <sys/types.h>
#include <errno.h>

#ifdef USE_SYSLOG
#include <syslog.h>
#endif

#include "ipcdef.h"

/* If you uncomment this debug flag, each and every screen on the browser will
 * begin with a list of all variables which have been transmitted for the
 * transaction.  Great for debugging, but be sure to turn it off when you're
 * done.
 */
/* #define DEBUG  */

struct march {
	struct march *next;
	char march_name[64];
	};

struct bvars {
	struct bvars *next;
	char *bname;
	char *btext;
	};


long atol();

void attach_to_server();
void serv_gets();
void serv_puts();

struct serv_info serv_info;
char axlevel;
int timescalled;
int posted;
unsigned userflags;
long eternal;
unsigned room_flags;
char referer[256];
char user_name[26];
char room_name[20];
char curr_pass[20];
char curr_host[64];
char curr_port[16];
char background[256];
long msgarr[1024];
char ugname[20];
long uglsn;
char is_room_aide = 0;
char floorlist[128][256];
struct march *march = NULL;

char *bstr();


long P;
char S[256];
FILE *pout;
struct bvars *bvars = NULL;

void logoff(int code) {
	char buf[256];

#ifdef USE_SYSLOG
	syslog(LOG_NOTICE, "Exit code %d", code);
#endif

	/* Shut down the server connection, unless the code is 3, in which
	 * case we're exiting because the server was already lost.
	 */
	if (code != 3) {
		serv_puts("QUIT");
		serv_gets(buf);
		}

	/* If the server was in fact lost, try to explain why */
	if (code == 3) {
		printf("Server error: %s<BR>\n",strerror(errno));
		}
		

	/* Make sure the browser stops reading */ 
	printf("</BODY></HTML>\n000BrowserStop\n");
	fclose(stdout);
	fclose(stderr);

	while (march!=NULL) remove_march(march->march_name);

	/* Delete temporary files */
	sprintf(buf,"/tmp/webcit.%ld",P);
	unlink(buf);

	/* Do some housekeeping */
	printf("find /tmp -name webcit.\\* -mtime +2 -exec rm -f {} \\;");
	system(buf);
	sprintf(buf, "find %s -mtime +5 -exec rm -f {} \\;", DYNAMIC_PATH);
	system(buf);

	exit(code);
	}


void sighandler(int code) {
#ifdef USE_SYSLOG
	syslog(LOG_NOTICE, "Received signal %d", code);
#endif
	logoff(code);
	}

void unescape_input(buf)
char buf[]; {
	int a,b;
	char hex[3];

	while ((isspace(buf[strlen(buf)-1]))&&(strlen(buf)>0))
		buf[strlen(buf)-1] = 0;

	for (a=0; a<strlen(buf); ++a) {
		if (buf[a]=='+') buf[a]=' ';	
		if (buf[a]=='%') {
			hex[0]=buf[a+1];
			hex[1]=buf[a+2];
			hex[2]=0;
			sscanf(hex,"%02x",&b);
			buf[a] = (char) b;
			strcpy(&buf[a+1],&buf[a+3]);
			}
		}

	}

void browser_input() {
	static char buf[256];
	char lbuf[256];
	FILE *pin;
	struct bvars *bptr;
	static char first = 0;
	static long last_exp = 0;
	long now;
	int numvars;

	while (bvars != NULL) {
		free(bvars->bname);
		free(bvars->btext);
		bptr = bvars->next;
		free(bvars);
		bvars = bptr;
		}

	if (first==1) {
		printf("</BODY></HTML>\n000BrowserStop\n");
		fclose(stdout);
		}

	sprintf(buf,"/tmp/webcit.%ld",P);
	alarm(BROWSER_TIMEOUT);
	signal(SIGALRM,logoff);
	pin = fopen(buf,"r");
	if (pin == NULL) {
#ifdef USE_SYSLOG
		syslog(LOG_NOTICE, "Cannot open %s: %s", buf, strerror(errno));
#endif
		logoff(98);
		}
	alarm(0);
	

	strcpy(buf,"");
	numvars = 0;
	do {
		alarm(BROWSER_TIMEOUT);
		fgets(buf,256,pin);
		alarm(0);
		while ((isspace(buf[strlen(buf)-1]))&&(strlen(buf)>0))
			buf[strlen(buf)-1] = 0;
		bptr = (struct bvars *)
			malloc((long)sizeof(struct bvars));
		bptr->next = bvars;	
		bvars = bptr;
		bvars->bname = malloc(1L+(long)strlen(buf));
		strcpy(bvars->bname,buf);
		fgets(lbuf,256,pin);
		bvars->btext = malloc((size_t)(8L+atol(lbuf)));
		fgets(bvars->btext,(2+atoi(lbuf)),pin);
		unescape_input(bvars->btext);

		if (++numvars > 100) {
#ifdef USE_SYSLOG
			syslog(LOG_NOTICE, "OVERLOAD!  More than 100 vars\n");
			for (bptr = bvars; bptr!=NULL; bptr=bptr->next) {
				syslog(LOG_NOTICE, "%s = %s",
					bptr->bname, bptr->btext);
				}
#endif
			logoff(99);
			}


		} while (strncmp(buf,"000BrowserStop",14));
	alarm(BROWSER_TIMEOUT);
	fclose(pin);
	alarm(0);

	sprintf(lbuf,"/tmp/webcit.%ld",P);
	freopen(lbuf,"w",stdout);
	printf("Content-type: text/html\n");
	printf("Pragma: no-cache\n\n");
	printf("<HEAD><TITLE>%s</TITLE>\n",
		serv_info.serv_humannode);
	printf("<BODY ");
	if (strlen(background) > 0) printf("BACKGROUND=\"%s\" ", background);
	printf("TEXT=\"#000000\" LINK=\"#004400\">\n");

/*
 * this section is a debugging tool that displays all
 * variable names and values at the top of the page
 */
#ifdef DEBUG
	printf("<TT>");
	for (bptr=bvars; bptr!=NULL; bptr=bptr->next)
		printf("%s=%s<BR>\n",bptr->bname,bptr->btext);
	printf("</TT><HR>");
#endif

/*
 * check for express messages once per minute
 */
	if (first == 1) {
		time(&now);
		if (now-last_exp > 60L) {
			last_exp = now;
			serv_puts("PEXP");
			serv_gets(buf);
			if (buf[0]=='1') {
				printf("<HR><BLINK><PRE>\n");
				while (serv_gets(buf), strcmp(buf,"000")) 
					printf("%s\n",buf);
				printf("</PRE></BLINK><HR>\n");
				}
			}
		}
	else {
		first = 1;
		}
	setup_reconnect(P,curr_host,curr_port,user_name,curr_pass,room_name);
	}


char *bstr(bvname)
char *bvname; {
	struct bvars *bptr;

	for (bptr=bvars; bptr!=NULL; bptr=bptr->next) {
		if (!strcmp(bptr->bname,bvname))
			return(bptr->btext);
		}
	return("");
	}


/*
 * log the user off, print a banner, etc.
 */
void goodbye() {
	int image_available;
	char image_path[256];
	char buf[256];

	printf("<CENTER>");
	image_available = fetch_image(image_path, "goodbye");
	if (image_available == 0) {
		printf("<TABLE><TR><TD><IMG SRC=\"%s\"></TD><TD>", image_path);
		}
	serv_puts("MESG goodbye");
	serv_gets(buf);
	if (buf[0]=='1') fmout(NULL);
	if (image_available == 0) {
		printf("</TD></TR></TABLE>\n");
		}

	if (strlen(referer)>0) {
		printf("<HR><A HREF=\"");
		escputs(referer);
		printf("\">Back to home page</A><BR>\n");
		}

	printf("</CENTER>");

	printf("</BODY></HTML>\n000BrowserStop\n");
	fclose(stdout);
	logoff(0);
	}

main(argc,argv)
int argc;
char *argv[]; {
	char buf[256];
	int a,m;
	int is_aa;
	FILE *fp;

#ifdef USE_SYSLOG
	openlog("webcit", LOG_PID, LOG_USER);
#endif

	if ((argc<4)||(argc>5)) {
		printf("Content-type: text/plain\n\n");
		printf("webcit: usage: webcit <host> <port> <session> [referer]\n");
		printf("(This program is designed to be run by its session\n");
		printf("manager program.  Do not run it directly.)\n");
		exit(1);
		}

	if (argc==5) {
		strcpy(referer,argv[4]);
		}
	else {
		strcpy(referer,"");
		}

	strcpy(curr_host,argv[1]);
	strcpy(curr_port,argv[2]);
	P = atol(argv[3]);
	strcpy(S,"");
	strcpy(user_name,"");
	strcpy(room_name,"");
	strcpy(curr_pass,"");
	strcpy(ugname,"");
	uglsn = 0L;
	strcpy(background, "");

	for (a=2; a<=15; ++a) signal(a,logoff);
	signal(SIGHUP,SIG_IGN);

	/* On some systems this needs to be changed to 'mkfifo' */
#ifdef BSD
	sprintf(buf,"mkfifo /tmp/webcit.%ld",P);
#else
	sprintf(buf,"mknod /tmp/webcit.%ld p",P);
#endif
	system(buf);

	sprintf(buf, "chmod 600 /tmp/webcit.%ld", P);
	system(buf);

	attach_to_server(argc,argv);
	serv_gets(buf);
	if (buf[0] != '2') {
		browser_input();
		printf("<H1>%s</H1><BR><HR>\n", &buf[4]);
		goodbye();
		}

	get_serv_info();
	if (fetch_image(background, "background") != 0) strcpy(background, "");

	browser_input();


	/* authenticate the user */
	strcpy(user_name,bstr("sru"));
	strcpy(curr_pass,bstr("srp"));
	if ((strlen(user_name)>0)&&(strlen(curr_pass)>0)) {
		if (auto_auth(user_name,curr_pass) != 0) {
			auth();
			gotoroom("_BASEROOM_",2);
			is_aa = 0;
			}
		else {
			gotoroom(bstr("room"),0);
			is_aa = 1;
			}
		}
	else {
		m=auth();
		gotoroom("_BASEROOM_",2);
		is_aa = 0;
		}


	/* do the main loop */
	mainloop(is_aa,m);

	/* finish up */
	goodbye();
	}
