/*
 * images.c
 *
 * This module contains code which handles loading graphics from the server.
 */

#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/times.h>
#include <time.h>
#include <utime.h>

#include "ipcdef.h"

#define strucmp(lstr,rstr) struncmp(lstr,rstr,32767)

extern struct serv_info serv_info;
extern long P;
extern char S[];
extern char user_name[];
extern char room_name[];
extern char curr_pass[];
extern char curr_host[];
extern char curr_port[];
extern char axlevel;
extern int timescalled;
extern int posted;
extern unsigned userflags;
extern long eternal;
extern char floorlist[128][256];

extern char *bstr();


/*
 * fetch_image()
 *
 * "imagename" is the name of the desired image on the server.  If it can be
 * loaded, fetch_image() stores the resulting URL in "urlbuf" and returns 0.
 * Otherwise, it returns nonzero.
 */
int fetch_image(char *urlbuf, char *imagename) {
	char image_basename[256];
	char image_filename[256];
	char buf[256];
	char pbuf[4096];
	int a;
	FILE *fp;
	long bytes_received, download_len, plen;

	if (serv_info.serv_rev_level < 490) {
		return(1);	/* Images not supported by server < v4.90 */
		}

	sprintf(buf, "OIMG %s", imagename);
	serv_puts(buf);
	serv_gets(buf);
	if (buf[0] != '2') return(1);

	download_len = extract_long(&buf[4], 0);

	sprintf(image_basename, "%s.%s.%s",
		serv_info.serv_nodename,
		imagename, &buf[4]);
	for (a=0; a<strlen(image_basename); ++a) {
		image_basename[a] = tolower(image_basename[a]);
		if (!isalnum(image_basename[a])) image_basename[a]='.';
		}
	sprintf(image_filename, "%s/%s", DYNAMIC_PATH, image_basename);
	sprintf(urlbuf, "%s/%s", DYNAMIC_URL, image_basename);
	
	/* If we've already got this version of this image cached, go with it!
	 * The call to utime() updates the modification time of the image in
	 * the disk cache.  We do this in order to make it possible to purge
	 * images which haven't been used in a while simply by searching for
	 * files with old modification times.
	 */	
	fp = fopen(image_filename, "rb");
	if (fp != NULL) {
		fclose(fp);
		serv_puts("CLOS");
		serv_gets(buf);
		utime(image_filename, NULL);
		return(0);
		}

	/* Otherwise, fetch the new version from the server. */
	fp = fopen(image_filename, "wb");

	bytes_received = 0L;
	while (bytes_received < download_len) {
		sprintf(buf,"READ %ld|%ld",
			bytes_received,
			( (download_len - bytes_received > 4095)
			  ? 4095 : (download_len - bytes_received) ) );
		serv_puts(buf);
		serv_gets(buf);
		if (buf[0]=='6') {
			plen = extract_long(&buf[4],0);
			serv_read(pbuf,plen);
			fwrite((char *)pbuf,plen,1,fp);
			bytes_received = bytes_received + plen;
			}
		}
	fclose(fp);
	serv_puts("CLOS");
	serv_gets(buf);
	return(0);
	}



/*
 * Fetch an image via HTTP and store it to the server
 */
int fetch_and_store(char *description, char *fetch_url, char *store_cmd) {

	int http_socket;
	char xfer_buf[4096];
	char buf[256];
	int bytes_read;
	int bytes_written;
	int thisblock;
	int block_num = 0;

	http_socket = connectsock(HTTP_PROXY_HOST, HTTP_PROXY_PORT, "tcp");
	if (http_socket < 0) {
		printf("Can't connect to web proxy at %s/%s.  Please\n",
			HTTP_PROXY_HOST, HTTP_PROXY_PORT);
		printf("notify the site administrator about this problem.\n");
		return(1);
		}

	sprintf(xfer_buf, "GET %s\n\n", fetch_url);
	if (write(http_socket, xfer_buf, strlen(xfer_buf)) != strlen(xfer_buf)) {
		printf("Couldn't send GET command.\n");
		close(http_socket);
		return(2);
		}

	while (bytes_read=read(http_socket, xfer_buf, 4096), bytes_read>0) {
		if (block_num == 0) {
			if (struncmp(xfer_buf, "gif", 3)) {
				printf("No GIF image was found at that\n");
				printf("location.  Transfer aborted.\n");
				close(http_socket);
				return(3);
				}
			else {
				serv_puts(store_cmd);
				serv_gets(buf);
				if (buf[0] != '2') {
					printf("%s\n", &buf[4]);
					close(http_socket);
					return(4);
					}
				}
			}

		bytes_written = 0;
		while (bytes_written < bytes_read) {
			sprintf(buf, "WRIT %d", (bytes_read-bytes_written));
			serv_puts(buf);
			serv_gets(buf);
			if (buf[0] == '7') {	
				thisblock = atoi(&buf[4]);
				serv_write(&xfer_buf[bytes_written], thisblock);
				bytes_written = bytes_written + thisblock;
				}
			else {
				serv_puts("UCLS 0");
				serv_gets(buf);
				printf("%s\n", &buf[4]);
				close(http_socket);
				return(5);
				}
			}

		++block_num;
		}

	serv_puts("UCLS 1");
	serv_gets(buf);
	printf("%s has been fetched and stored.<BR>\n", description);
	return(0);
	}






/*
 * display the form for changing your photo
 */
void display_editpic() {
	char buf[256];
	char user[256];

	serv_puts("UIMG 0|_userpic_");
	serv_gets(buf);
	if (buf[0] != '2') {
		printf("<EM>%s</EM><BR>\n", &buf[4]);
		return;
		}


        printf("<TABLE WIDTH=100% BORDER=0 BGCOLOR=770000><TR><TD>");
        printf("<FONT SIZE=+1 COLOR=\"FFFFFF\"");
        printf("<B>Set/change your photo</B>\n");
        printf("</FONT></TD></TR></TABLE>\n");

	printf("<CENTER>\n");

	printf("Enter a URL containing your photo in the form of\n");
	printf("<TT>http://your.site.dom/directory/photoname.gif</TT><BR>\n");
	printf("The photo must be in GIF format and it must be retrievable\n");
	printf("by either HTTP or FTP.<BR>\n");

	printf("Your photo will be retrieved and stored on %s.\n", serv_info.serv_humannode);
	printf("No further links will be made to your website.<BR><BR>\n");

	printf("<FORM METHOD=\"POST\" ACTION=\"session\">\n");
	output_form_reconnect();

	printf("<INPUT TYPE=\"hidden\" NAME=\"oper\" VALUE=\"editpic\">\n");

	printf("Enter URL:<BR>");
	printf("<INPUT TYPE=\"text\" NAME=\"picurl\" MAXLENGTH=80 WIDTH=80>\n");
	printf("<BR><BR>\n");

	printf("<INPUT TYPE=\"submit\" NAME=\"sc\" VALUE=\"Set\">");
	printf("<INPUT TYPE=\"submit\" NAME=\"sc\" VALUE=\"Cancel\"><BR>\n");

	printf("</FORM></CENTER>\n");
	}


/*
 * change your user photo
 */
void editpic() {
	char sc[256];
	char picurl[256];
	char buf[256];
	
	strcpy(picurl,bstr("picurl"));
	strcpy(sc,bstr("sc"));

	if (strcmp(sc,"Set")) {
		printf("<EM>Picture was not set.</EM><BR>\n");
		return;
		}

	if (fetch_and_store("Your photo", picurl, "UIMG 1|_userpic_") == 0) {

		/* If the fetch and store was successful, make sure that the user
		 * has at least a generated bio on file.
		 */

		sprintf(buf, "RBIO %s", user_name);
		serv_puts(buf);
		serv_gets(buf); 

		if (buf[0] == '1') do {		/* There is a bio.  Flush it. */
			serv_gets(buf);
			} while (strcmp(buf, "000"));

		else {				/* No bio -- generate one. */
			serv_puts("EBIO");
			serv_gets(buf);
			if (buf[0] == '4') {
				serv_puts(user_name);
				serv_puts("has not entered a bio, but does have a photo online.");
				serv_puts("000");
				
				/* Tell the user that we took this liberty... */
				printf("<EM>Note:</EM> you do not have a bio on file.\n");
				printf("A simple one has been automatically generated,\n");
				printf("but you really should enter one of your own.<BR>\n");
				}
			}

		}
	}












/*
 * display the form for changing the room graphic
 */
void display_editroompic() {
	char buf[256];
	char user[256];

	serv_puts("UIMG 0|_roompic_");
	serv_gets(buf);
	if (buf[0] != '2') {
		printf("<EM>%s</EM><BR>\n", &buf[4]);
		return;
		}


        printf("<TABLE WIDTH=100% BORDER=0 BGCOLOR=770000><TR><TD>");
        printf("<FONT SIZE=+1 COLOR=\"FFFFFF\"");
        printf("<B>Set/change room banner graphic</B>\n");
        printf("</FONT></TD></TR></TABLE>\n");

	printf("<CENTER>\n");

	printf("Enter a URL containing a graphic for this room's banner\n");
	printf("in the form of\n");
	printf("<TT>http://your.site.dom/directory/imagename.gif</TT><BR>\n");
	printf("The graphic must be in GIF format and it must be\n");
	printf("retrievable by either HTTP or FTP.<BR>\n");

	printf("The image will be retrieved and stored on %s.\n", serv_info.serv_humannode);
	printf("No further links will be made to your website.<BR><BR>\n");

	printf("<FORM METHOD=\"POST\" ACTION=\"session\">\n");
	output_form_reconnect();

	printf("<INPUT TYPE=\"hidden\" NAME=\"oper\" VALUE=\"editroompic\">\n");

	printf("Enter URL:<BR>");
	printf("<INPUT TYPE=\"text\" NAME=\"picurl\" MAXLENGTH=80 WIDTH=80>\n");
	printf("<BR><BR>\n");

	printf("<INPUT TYPE=\"submit\" NAME=\"sc\" VALUE=\"Set\">");
	printf("<INPUT TYPE=\"submit\" NAME=\"sc\" VALUE=\"Cancel\"><BR>\n");

	printf("</FORM></CENTER>\n");
	}


/*
 * change the room graphic
 */
void editroompic() {
	char sc[256];
	char picurl[256];
	char buf[256];
	
	strcpy(picurl,bstr("picurl"));
	strcpy(sc,bstr("sc"));

	if (strcmp(sc,"Set")) {
		printf("<EM>Graphic was not set.</EM><BR>\n");
		return;
		}

	fetch_and_store("Graphic for this room", picurl, "UIMG 1|_roompic_");

	}





/*
 * display the form for changing the floor graphic
 */
void display_editfloorpic() {
	char buf[256];
	int a;

	load_floorlist();

	serv_puts("UIMG 0|_floorpic_|0");
	serv_gets(buf);
	if (buf[0] != '2') {
		printf("<EM>%s</EM><BR>\n", &buf[4]);
		return;
		}


        printf("<TABLE WIDTH=100% BORDER=0 BGCOLOR=770000><TR><TD>");
        printf("<FONT SIZE=+1 COLOR=\"FFFFFF\"");
        printf("<B>Set/change a floor label graphic</B>\n");
        printf("</FONT></TD></TR></TABLE>\n");
	printf("<CENTER>\n");

	printf("Enter a URL containing a graphic for this floor's banner\n");
	printf("in the form of\n");
	printf("<TT>http://your.site.dom/directory/imagename.gif</TT><BR>\n");
	printf("The graphic must be in GIF format and it must be\n");
	printf("retrievable by either HTTP or FTP.<BR>\n");

	printf("The image will be retrieved and stored on %s.\n", serv_info.serv_humannode);
	printf("No further links will be made to your website.<BR><BR>\n");

	printf("<FORM METHOD=\"POST\" ACTION=\"session\">\n");
	output_form_reconnect();

	printf("<INPUT TYPE=\"hidden\" NAME=\"oper\" VALUE=\"editfloorpic\">\n");


	printf("Select a floor: <BR>");

	printf("<SELECT NAME=\"floorname\" SIZE=5>\n");
	for (a=0; a<128; ++a) {
		if (strlen(floorlist[a]) > 0) {
			printf("<OPTION>");
			escputs(floorlist[a]);
			printf("\n");
			}
		}
	printf("</SELECT>\n");
	printf("<BR>\n");

	printf("Enter URL:<BR>");
	printf("<INPUT TYPE=\"text\" NAME=\"picurl\" MAXLENGTH=80 WIDTH=80>\n");
	printf("<BR><BR>\n");

	printf("<INPUT TYPE=\"submit\" NAME=\"sc\" VALUE=\"Set\">");
	printf("<INPUT TYPE=\"submit\" NAME=\"sc\" VALUE=\"Cancel\"><BR>\n");

	printf("</FORM></CENTER>\n");
	}


/*
 * change the floor graphic
 */
void editfloorpic() {
	char sc[256];
	char picurl[256];
	char buf[256];
	int a;
	int floornum;
	
	strcpy(picurl,bstr("picurl"));
	strcpy(sc,bstr("sc"));

	if (strcmp(sc,"Set")) {
		printf("<EM>Graphic was not set.</EM><BR>\n");
		return;
		}

	floornum = (-1);
	strcpy(buf, bstr("floorname"));
	for (a=0; a<128; ++a) {
		if (!strucmp(buf, floorlist[a])) floornum = a;
		}
	if (floornum < 0) {
		printf("<EM>No floor '%s'.</EM><BR>\n", buf);
		return;
		}

	sprintf(buf, "UIMG 1|_floorpic_|%d", floornum);
	fetch_and_store("Graphic for this floor", picurl, buf);

	}





