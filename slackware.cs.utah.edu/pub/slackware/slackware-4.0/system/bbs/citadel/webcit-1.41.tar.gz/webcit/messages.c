#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <signal.h>
#include <sys/types.h>
#include <ctype.h>
#include <string.h>
#include <time.h>
#include "citadel.h"
#include "webcit.h"
#define strucmp(lstr,rstr) struncmp(lstr,rstr,32767)

long atol();

extern struct serv_info serv_info;
extern long P;
extern char user_name[];
extern char axlevel;
extern int timescalled;
extern int posted;
extern unsigned userflags;
extern long eternal;
extern unsigned room_flags;
extern char room_name[];
extern long msgarr[];
extern char S[];
extern char is_room_aide;

char reply_to[256];

char *bstr();


/*
 * Look for URL's embedded in a buffer and make them linkable.  We use a
 * target window in order to keep the BBS session in its own window.
 */
void url(buf)
char buf[]; {

	int pos;
	int start,end;
	char ench;
	char urlbuf[256];
	char outbuf[256];

	start = (-1);
	end = strlen(buf);
	ench = 0;

	for (pos=0; pos<strlen(buf); ++pos) {
		if (!struncmp(&buf[pos],"http://",7)) start = pos;
		if (!struncmp(&buf[pos],"ftp://",6)) start = pos;
		}

	if (start<0) return;

	if ((start>0)&&(buf[start-1]=='<')) ench = '>';
	if ((start>0)&&(buf[start-1]=='[')) ench = ']';
	if ((start>0)&&(buf[start-1]=='(')) ench = ')';
	if ((start>0)&&(buf[start-1]=='{')) ench = '}';

	for (pos=strlen(buf); pos>start; --pos) {
		if ((buf[pos]==' ')||(buf[pos]==ench)) end = pos;
		}

	strncpy(urlbuf,&buf[start],end-start);
	urlbuf[end-start] = 0;


	strncpy(outbuf,buf,start);
	sprintf(&outbuf[start],"%cA HREF=%c%s%c TARGET=%c%s%c%c%s%c/A%c", 
		LB,QU,urlbuf,QU,QU,TARGET,QU,RB,urlbuf,LB,RB);
	strcat(outbuf,&buf[end]);
	strcpy(buf,outbuf);
	}


void read_message(msgnum, oper)
long msgnum;
char *oper; {
	char buf[256];
	char m_subject[256];
	char from[256];
	long now;
	struct tm *tm;
	int format_type = 0;
	int fr = 0;
	int nhdr = 0;
	int bq = 0;



	sprintf(buf,"MSG0 %ld",msgnum);
	serv_puts(buf);
	serv_gets(buf);
	if (buf[0]!='1') {
		printf("<STRONG>ERROR:</STRONG> %s<BR>\n",&buf[4]);
		return;
		}

	printf("<TABLE WIDTH=100% BORDER=0 CELLSPACING=0 CELLPADDING=0 BGCOLOR=000077><TR><TD>\n");
	printf("<FONT COLOR=\"FFFF00\"><B> ");
	strcpy(m_subject,"");

	strcpy(reply_to,"nobody...xxxxx");
	while(serv_gets(buf), struncmp(buf,"text",4)) {
		if (!struncmp(buf,"nhdr=yes",8)) nhdr=1;
		if (nhdr==1) buf[0]='_';
		if (!struncmp(buf,"type=",5))
			format_type=atoi(&buf[5]);
		if (!struncmp(buf,"from=",5)) {
			printf("from %s ",&buf[5]);
			strcpy(from,&buf[5]);
			}
		if (!struncmp(buf,"path=",5))
			strcpy(reply_to,&buf[5]);
		if (!struncmp(buf,"subj=",5))
			strcpy(m_subject,&buf[5]);
		if ((!struncmp(buf,"hnod=",5)) 
		   && (strucmp(&buf[5],serv_info.serv_humannode)))
			printf("(%s) ",&buf[5]);
		if ((!struncmp(buf,"room=",5))
		   && (strucmp(&buf[5],room_name)))
			printf("in %s> ",&buf[5]);

		if (!struncmp(buf,"node=",5)) {
			if ( (room_flags&QR_NETWORK)
			   || ((strucmp(&buf[5],serv_info.serv_nodename)
   			   &&(strucmp(&buf[5],serv_info.serv_fqdn)))))
				{
				printf("@%s ",&buf[5]);
				}
			if ((!strucmp(&buf[5],serv_info.serv_nodename))
   			   ||(!strucmp(&buf[5],serv_info.serv_fqdn)))
				{
				strcpy(reply_to,from);
				}
			else if (haschar(&buf[5],'.')==0) {
				sprintf(reply_to,"%s @ %s",from,&buf[5]);
				}
			}

		if (!struncmp(buf,"rcpt=",5))
			printf("to %s ",&buf[5]);
		if (!struncmp(buf,"time=",5)) {
			now=atol(&buf[5]);
			tm=(struct tm *)localtime(&now);
			strcpy(buf,(char *)asctime(tm)); buf[strlen(buf)-1]=0;
			strcpy(&buf[16],&buf[19]);
			printf("%s ",&buf[4]);
			}
		}

	if (nhdr==1) printf("****");
	printf("</B></FONT></TD>");
	
	if (is_room_aide) {
		printf("<TD ALIGN=RIGHT NOWRAP><FONT COLOR=\"FFFF00\"><B>");

		printf("<A HREF=\"session?%s&oper=confirm_move_msg", S);
		printf("&msgid=%ld", msgnum);
		printf("&referer=%s\">Move</A>", oper);

		printf("&nbsp;&nbsp;");

		printf("<A HREF=\"session?%s&oper=confirm_delete_msg", S);
		printf("&msgid=%ld", msgnum);
		printf("&referer=%s\">Del</A>", oper);

		printf("</B></FONT></TD>");
		}
	
	printf("</TR></TABLE>\n");

	if (strlen(m_subject)>0) {
		printf("Subject: %s<BR>\n",m_subject);
		}

	if (format_type == 0) {
		fmout(NULL);
		}
	else {
		while(serv_gets(buf), strcmp(buf,"000")) {
			while ((strlen(buf)>0)&&(isspace(buf[strlen(buf)-1])))
				buf[strlen(buf)-1] = 0;
			if ((bq==0)&&
((!strncmp(buf,">",1))||(!strncmp(buf," >",2))||(!strncmp(buf," :-)",4)))) {
				printf("<FONT COLOR=\"000044\"><I>");
				bq = 1;
				}
			else if ((bq==1)&&
(strncmp(buf,">",1))&&(strncmp(buf," >",2))&&(strncmp(buf," :-)",4))) {
				printf("</FONT></I>");
				bq = 0;
				}
			printf("<TT>");
			url(buf);
			escputs(buf);
			printf("</TT><BR>\n");
			}
		}
	}



/* 
 * load message pointers from the server
 */
int load_msg_ptrs(servcmd)
char *servcmd; {
	char buf[256];
	int nummsgs;

	nummsgs = 0;
	serv_puts(servcmd);
	serv_gets(buf);
	if (buf[0]!='1') {
		printf("<EM>%s</EM><BR>\n",&buf[4]);
		return(nummsgs);
		}
	while (serv_gets(buf), strcmp(buf,"000")) {
		msgarr[nummsgs] = atol(buf);
		++nummsgs;
		}
	return(nummsgs);
	}


/*
 * command loop for reading messages
 */
int readloop(oper)
char *oper; {
	char cmd[256];
	char buf[256];
	int a;
	int nummsgs;

	printf("<CENTER><H2>%s - ",room_name);
	if (!strcmp(oper,"readnew")) {
		strcpy(cmd,"MSGS NEW");
		printf("new messages");
		}
	else if (!strcmp(oper,"readold")) {
		strcpy(cmd,"MSGS OLD");
		printf("old messages");
		}
	else {
		strcpy(cmd,"MSGS ALL");
		printf("all messages");
		}
	printf("</H2></CENTER>\n");

	nummsgs = load_msg_ptrs(cmd);
	if (nummsgs == 0) {
		if (!strcmp(oper,"readnew")) {
			printf("<EM>No new messages in this room.</EM>\n");
			return(0);
			}
		if (!strcmp(oper,"readold")) {
			printf("<EM>No old messages in this room.</EM>\n");
			return(0);
			}
		printf("<EM>This room is empty.</EM>\n");
		return(0);
		}

	for (a=0; a<nummsgs; ++a) {
		read_message(msgarr[a], oper);
		}

	/* begin controls 
	printf("<CENTER><TABLE border><TR>");
	printf("<TD><A HREF=\"session?%s&oper=display_enter\">Enter a message</A></TD>\n",S);
	printf("<TD><A HREF=\"session?%s&oper=gotonext\">Goto next room</A></TD>\n",S);
	printf("<TD><A HREF=\"session?%s&oper=mainmenu\">\n",S);
	printf("Back to menu</A></TD></TR></TABLE></CENTER><BR>\n");
	 end controls */

	printf("<HR>");
	return(0); /* no controls ... just the main menu instead */
	}

/*
 * prompt for a recipient
 */
void prompt_for_recipient() {

        printf("<TABLE WIDTH=100% BORDER=0 BGCOLOR=007700><TR><TD>");
        printf("<FONT SIZE=+1 COLOR=\"FFFFFF\"");
        printf("<B>Send private e-mail</B>\n");
        printf("</FONT></TD></TR></TABLE>\n");

	printf("<CENTER>");
	printf("<FORM METHOD=\"POST\" ACTION=\"session\">\n");
	output_form_reconnect();

	printf("<INPUT TYPE=\"hidden\" NAME=\"oper\" VALUE=\"display_enter\">\n");

	printf("Enter recipient: ");
	printf("<INPUT TYPE=\"text\" NAME=\"recp\" MAXLENGTH=\"64\"><BR>\n");

	printf("<INPUT TYPE=\"submit\" NAME=\"sc\" VALUE=\"Enter message\">");
	printf("<INPUT TYPE=\"submit\" NAME=\"sc\" VALUE=\"Cancel\">");

	printf("</FORM></CENTER>\n");
	}


/*
 * display the message entry screen
 */
int display_enter() {
	char buf[256];
	long now;
	struct tm *tm;

	if (!strcmp(bstr("sc"),"Cancel")) {
		printf("Cancelled.  Message was not posted.<BR>\n");
		return(0);
		}

	sprintf(buf,"ENT0 0|%s|0|0",bstr("recp"));
	serv_puts(buf);
	serv_gets(buf);

	if (!strncmp(buf,"570",3)) {
		if (strlen(bstr("recp"))>0) {
			printf("<EM>%s</EM><BR>\n",&buf[4]);
			}
		prompt_for_recipient();
		return;
		}


	if (buf[0]!='2') {
		printf("<EM>%s</EM><BR>\n",&buf[4]);
		return(0);
		}

	printf("<CENTER>Enter message below.  Messages are formatted to\n");
	printf("the <EM>reader's</EM> screen width.  To defeat the\n");
	printf("formatting, indent a line at least one space.  \n");
	/* printf("Buttons are at both the top and bottom simply for convenience.\n"); */
	printf("<BR>");

	time(&now);
	tm=(struct tm *)localtime(&now);
	strcpy(buf,(char *)asctime(tm)); buf[strlen(buf)-1]=0;
	strcpy(&buf[16],&buf[19]);
	printf("</CENTER><FONT COLOR=\"440000\"><B> %s ",&buf[4]);
	printf("from %s ",user_name);
	if (strlen(bstr("recp"))>0) printf("to %s ",bstr("recp"));
	printf("in %s&gt; ",room_name);
	printf("</B></FONT><BR><CENTER>\n");

	printf("<FORM METHOD=\"POST\" ACTION=\"session\">\n");
	output_form_reconnect();

	printf("<INPUT TYPE=\"hidden\" NAME=\"oper\" VALUE=\"post\">\n");
	printf("<INPUT TYPE=\"hidden\" NAME=\"recp\" VALUE=\"%s\">\n",
		bstr("recp"));


	printf("<INPUT TYPE=\"submit\" NAME=\"sc\" VALUE=\"Save message\">");
	printf("<INPUT TYPE=\"submit\" NAME=\"sc\" VALUE=\"Cancel\"><BR>\n");

	printf("<TEXTAREA NAME=\"msgtext\" wrap=soft ROWS=30 COLS=80 WIDTH=80></TEXTAREA><P>\n");

	printf("</FORM></CENTER>\n");

	return(1);
	}


/*
 * post message (or don't post message)
 */
void post_message() {
	char buf[256];

	if (strcmp(bstr("sc"),"Save message")) {
		printf("Cancelled.  Message was not posted.<BR>\n");
		return;
		}

	sprintf(buf,"ENT0 1|%s|0|0",bstr("recp"));
	serv_puts(buf);
	serv_gets(buf);
	if (buf[0]!='4') {
		printf("<EM>%s</EM><BR>\n",&buf[4]);
		return;
		}

	text_to_server(bstr("msgtext"));
	serv_puts("000");

	printf("Message has been posted.<BR>\n");
	}	




/*
 * Confirm deletion of a message
 */
int confirm_delete_msg() {
	char buf[256];
	long msgid;

	msgid = atol(bstr("msgid"));
	
	printf("<TABLE WIDTH=100% BORDER=0 BGCOLOR=770000><TR><TD>");
	printf("<FONT SIZE=+1 COLOR=\"FFFFFF\"");
	printf("<B>Confirm deletion of message</B>\n");
	printf("</FONT></TD></TR></TABLE>\n");

	printf("<CENTER>");

	printf("Are you sure you want to delete this message? <BR>\n");

	printf("<A HREF=session?%s", S);
	printf("&oper=delete_msg&referer=%s", bstr("referer"));
	printf("&msgid=%ld", msgid);
	printf(">Yes</A>&nbsp;\n");

	printf("<A HREF=session?%s", S);
	printf("&oper=%s", bstr("referer"));
	printf(">No</A><BR>\n");

	printf("</CENTER>\n");

	return(1);
	}


int delete_msg() {
	long msgid;
	char buf[256];

	msgid = atol(bstr("msgid"));

	sprintf(buf, "DELE %ld", msgid);
	serv_puts(buf);
	serv_gets(buf);
	printf("<EM>%s</EM><BR>\n", &buf[4]);

	return(readloop(bstr("referer")));
	}


/*
 * Move a message (select room and confirm)
 */
int confirm_move_msg() {
	char buf[256];
	char targ[256];
	long msgid;

	msgid = atol(bstr("msgid"));
	
	printf("<TABLE WIDTH=100% BORDER=0 BGCOLOR=770000><TR><TD>");
	printf("<FONT SIZE=+1 COLOR=\"FFFFFF\"");
	printf("<B>Move a message</B>\n");
	printf("</FONT></TD></TR></TABLE>\n");

	printf("<CENTER>");
	printf("<FORM METHOD=\"POST\" ACTION=\"session\">\n");
	output_form_reconnect();

	printf("<INPUT TYPE=\"hidden\" NAME=\"oper\" VALUE=\"move_msg\">\n");
	printf("<INPUT TYPE=\"hidden\" NAME=\"msgid\" VALUE=\"%ld\">\n", msgid);
	printf("<INPUT TYPE=\"hidden\" NAME=\"referer\" VALUE=\"%s\">\n",
		bstr("referer"));

	printf("Please select a room to move this message to:<BR>\n");
 	printf("<SELECT NAME=\"target_room\" SIZE=5>\n");
        serv_puts("LKRA");
        serv_gets(buf);
        if (buf[0]=='1') {
                while(serv_gets(buf), strcmp(buf,"000")) {
                        extract(targ,buf,0);
                        printf("<OPTION>");
                        escputs(targ);
                        printf("\n");
                        }
                }
        printf("</SELECT>\n");
        printf("<BR>\n");

	printf("<INPUT TYPE=\"submit\" NAME=\"sc\" VALUE=\"Move\">");
	printf("<INPUT TYPE=\"submit\" NAME=\"sc\" VALUE=\"Cancel\">");

	printf("</FORM></CENTER>\n");

	return(1);
	}


/*
 * Move a message (do it)
 */
int move_msg() {
	long msgid;
	char buf[256];
	char targ[256];

	strcpy(buf, bstr("sc"));

	if (!strcmp(buf, "Move")) {

		msgid = atol(bstr("msgid"));
		strcpy(targ, bstr("target_room"));
	
		sprintf(buf, "MOVE %ld|%s", msgid, targ);
		serv_puts(buf);
		serv_gets(buf);
		printf("<EM>%s</EM><BR>\n", &buf[4]);

		}

	return(readloop(bstr("referer")));
	}


