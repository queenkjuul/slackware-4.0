#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <signal.h>
#include <sys/types.h>
#include "ipcdef.h"
#include "axdefs.h"
#define strucmp(lstr,rstr) struncmp(lstr,rstr,32767)

extern struct serv_info serv_info;
extern long P;
extern char S[];
extern char user_name[];
extern char room_name[];
extern char curr_pass[];
extern char curr_host[];
extern char curr_port[];
extern char axlevel;
extern int timescalled;
extern int posted;
extern unsigned userflags;
extern long eternal;

extern char *bstr();

/*
 * set up the session reconnect string
 */
void setup_reconnect(sP,scurr_host,scurr_port,suser_name,scurr_pass,scurr_rm)
long sP;
char scurr_host[];
char scurr_port[];
char suser_name[];
char scurr_pass[];
char scurr_rm[]; {
	int b;

	sprintf(S,"session=%ld&",sP);
	sprintf(&S[strlen(S)],"host=%s&",urlesc(scurr_host));
	sprintf(&S[strlen(S)],"port=%s&",urlesc(scurr_port));
	sprintf(&S[strlen(S)],"room=%s&",urlesc(scurr_rm));
	sprintf(&S[strlen(S)],"sru=%s&srp=",urlesc(suser_name));
	for (b=0; b<strlen(scurr_pass); ++b)
		sprintf(&S[strlen(S)],"%%%02x",scurr_pass[b]);
	sprintf(&S[strlen(S)],"&rand=%d",rand());
	}


/*
 * output session reconnect stuff in a form-embeddable format 
 */
void output_form_reconnect() {
	printf("<INPUT TYPE=\"hidden\" NAME=\"session\" VALUE=\"%ld\">\n",P);
	printf("<INPUT TYPE=\"hidden\" NAME=\"host\" VALUE=\"%s\">\n",
		curr_host);
	printf("<INPUT TYPE=\"hidden\" NAME=\"port\" VALUE=\"%s\">\n",
		curr_port);
	printf("<INPUT TYPE=\"hidden\" NAME=\"room\" VALUE=\"%s\">\n",
		room_name);
	printf("<INPUT TYPE=\"hidden\" NAME=\"sru\" VALUE=\"%s\">\n",
		user_name);
	printf("<INPUT TYPE=\"hidden\" NAME=\"srp\" VALUE=\"%s\">\n",
		curr_pass);
	}



/*
 * grab assorted info about the user...
 */
int load_user_info(params,silent)
char *params;
int silent; {
	char buf[256];
	int b;

	extract(user_name,params,0);
	axlevel = extract_int(params,1);
	timescalled = extract_int(params,2);
	posted = extract_int(params,3);
	userflags = extract_int(params,4);
	eternal = extract_long(params,5);
	
if (silent == 0) {
	printf("<CENTER><TABLE><TR>");
	printf("<TD><H1>%s</H1></TD>\n",user_name);
	printf("<TD><EM>Access level:</EM> %d (%s)<BR>",
		axlevel, axdefs[axlevel]);
	printf("<EM>User#:</EM> %ld<BR><EM>Call#:</EM> %d<BR>\n",
		eternal, timescalled);
	printf("</TD></TR></TABLE>\n");
	}

	serv_puts("CHEK");
	serv_gets(buf);
	if (buf[0]=='2') {
		b = extract_int(&buf[4],0);
if (silent==0) {
if (b==1) printf("<EM>You have a new private message in Mail&gt;</EM><BR>\n");
if (b>1)  printf("<EM>You have %d new private messages in Mail&gt;</EM><BR>",b);

		if ((axlevel>=6) && (extract_int(&buf[4],2)>0)) {
			printf("<EM>Users need validation</EM><BR>\n");
			}
	printf("</CENTER>\n");
}

	/* set up the session reconnect string */
	setup_reconnect(P,curr_host,curr_port,user_name,curr_pass,room_name);

	/* display registration form if necessary */
	if (extract_int(&buf[4],1)>0) {
		display_reg();
		return(1);
		}

		}
	return(0);
	}


/*
 * authenticate the user
 */
int auth() {
	char buf[256];
	int m;
	int image_available;
	char image_path[256];

WELCOME:
	printf("<CENTER>");
	image_available = fetch_image(image_path, "hello");
	if (image_available == 0) {
		printf("<TABLE><TR><TD><IMG SRC=\"%s\"></TD><TD ALIGN=CENTER>",
			image_path);
		}
	serv_puts("MESG hello");
	serv_gets(buf);
	if (buf[0]=='1') fmout(NULL);
	if (image_available == 0) {
		printf("</TD></TR></TABLE>\n");
		}
	printf("</CENTER>\n");

LOGAGN:	printf("<HR><UL>\n");
	printf("<LI><EM>If you already have an account on %s,</EM> enter your user name\n",
		serv_info.serv_humannode);
	printf("and password and click \"<TT>Login</TT>.\"<BR>\n");
	printf("<LI><EM>If you are a new user,</EM>\n");
	printf("enter the name and password you wish to use, and click\n");
	printf("\"New User.\"<BR><LI><EM>Please log off properly when finished.");
	printf("</EM></UL><P>\n");

	printf("<FORM ACTION=\"session\" METHOD=\"POST\">\n");
	printf("<INPUT TYPE=\"hidden\" NAME=\"session\" VALUE=\"%ld\">\n",P);
	printf("<CENTER><TABLE border><TR><TD>");
	printf("User Name:</TD><TD><INPUT TYPE=\"text\" NAME=\"name\" MAXLENGTH=\"25\"   >\n");
	printf("</TD></TR><TD>");
	printf("Password:</TD><TD><INPUT TYPE=\"password\" NAME=\"pass\" MAXLENGTH=\"20\">");
	printf("</TD></TR></TABLE>\n");
	printf("<INPUT type=\"submit\" NAME=\"action\" VALUE=\"Login\">\n");
	printf("<INPUT type=\"submit\" NAME=\"action\" VALUE=\"New User\">\n");
	printf("<INPUT type=\"submit\" NAME=\"action\" VALUE=\"Exit\">\n");
	printf("</FORM>\n");
	printf("</CENTER>");

	browser_input();

	if (!strucmp(bstr("action"),"Exit")) goodbye();

	if (!strucmp(bstr("action"),"New User")) {
		sprintf(buf,"NEWU %s",bstr("name"));
		serv_puts(buf);
		serv_gets(buf);
		if (buf[0]!='2') {
			printf("<H1>%s</H1><BR>\n",&buf[4]);
			goto LOGAGN;
			}
		strcpy(curr_pass,bstr("pass"));
		m=load_user_info(&buf[4],0);
		sprintf(buf,"SETP %s",bstr("pass"));
		serv_puts(buf);
		serv_gets(buf);
		if (buf[0]!='2') {
			printf("<H1>%s</H1><BR>\n",&buf[4]);
			}
		return(m);
		}

	if (!strucmp(bstr("action"),"Login")) {
		sprintf(buf,"USER %s",bstr("name"));
		serv_puts(buf);
		serv_gets(buf);
		if (buf[0]!='3') {
			printf("<H1>%s</H1>\n",&buf[4]);
			goto LOGAGN;
			}
		sprintf(buf,"PASS %s",bstr("pass"));
		serv_puts(buf);
		serv_gets(buf);
		if (buf[0]!='2') {
			printf("<H1>%s</H1>\n",&buf[4]);
			goto LOGAGN;
			}
		strcpy(curr_pass,bstr("pass"));
		m=load_user_info(&buf[4],0);
		/* FIX do an enter config here */
		return(m);
		}
	goto WELCOME;
	}


int auto_auth(uname,passw)
char *uname;
char *passw; {
	char buf[256];

	sprintf(buf,"USER %s",uname);
	serv_puts(buf);
	serv_gets(buf);
	if (buf[0]!='3') {
		printf("<H1>%s</H1>\n",&buf[4]);
		return(1);
		}
	sprintf(buf,"PASS %s",passw);
	serv_puts(buf);
	serv_gets(buf);
	if (buf[0]!='2') {
		printf("<H1>%s</H1>\n",&buf[4]);
		return(1);
		}
	strcpy(curr_pass,passw);
	load_user_info(&buf[4],1);
	return(0);
	}


/* 
 * display form for registration
 */
int display_reg() {
	char buf[256];
	int a;

        printf("<TABLE WIDTH=100% BORDER=0 BGCOLOR=007700><TR><TD>");
        printf("<FONT SIZE=+1 COLOR=\"FFFFFF\"");
        printf("<B>Enter registration info</B>\n");
        printf("</FONT></TD></TR></TABLE>\n");

	printf("<CENTER>");
	serv_puts("MESG register");
	serv_gets(buf);
	if (buf[0]=='1') fmout(NULL);

	printf("<FORM ACTION=\"session\" METHOD=\"POST\">\n");
	output_form_reconnect();
	printf("<INPUT TYPE=\"hidden\" NAME=\"oper\" VALUE=\"register\">\n",P);

	serv_puts("GREG _SELF_");
	serv_gets(buf);
	if (buf[0]!='1') {
		printf("<EM>%s</EM><BR>\n",&buf[4]);
		return(0);
		}
	
	printf("<H1>%s</H1><TABLE border>\n",&buf[4]);
	a = 0;
	while (serv_gets(buf), strcmp(buf,"000")) {
		++a;
	printf("<TR><TD>");
		switch(a) {
case 3:	printf("Real Name:</TD><TD><INPUT TYPE=\"text\" NAME=\"realname\" VALUE=\"%s\" MAXLENGTH=\"29\"><BR>\n",buf);
	break;
case 4:	printf("Street Address:</TD><TD><INPUT TYPE=\"text\" NAME=\"address\" VALUE=\"%s\" MAXLENGTH=\"24\"><BR>\n",buf);
	break;
case 5:	printf("City/town:</TD><TD><INPUT TYPE=\"text\" NAME=\"city\" VALUE=\"%s\" MAXLENGTH=\"14\"><BR>\n",buf);
	break;
case 6:	printf("State/province:</TD><TD><INPUT TYPE=\"text\" NAME=\"state\" VALUE=\"%s\" MAXLENGTH=\"2\"><BR>\n",buf);
	break;
case 7:	printf("ZIP code:</TD><TD><INPUT TYPE=\"text\" NAME=\"zip\" VALUE=\"%s\" MAXLENGTH=\"10\"><BR>\n",buf);
	break;
case 8:	printf("Telephone:</TD><TD><INPUT TYPE=\"text\" NAME=\"phone\" VALUE=\"%s\" MAXLENGTH=\"14\"><BR>\n",buf);
	break;
case 9:	printf("E-Mail:</TD><TD><INPUT TYPE=\"text\" NAME=\"email\" VALUE=\"%s\" MAXLENGTH=\"31\"><BR>\n",buf);
	break;
			}
	printf("</TD></TR>\n");
		}
	printf("</TABLE><P>");
	printf("<INPUT type=\"submit\" NAME=\"action\" VALUE=\"Register\">\n");
	printf("<INPUT type=\"submit\" NAME=\"action\" VALUE=\"Cancel\">\n");
	printf("</CENTER>\n");
	return(1);
	}

/*
 * register
 */
void register_user() {
	char buf[256];
	
	if (strcmp(bstr("action"),"Register")) {
		printf("Cancelled.  Registration was not saved.<BR>\n");
		return;
		}

	serv_puts("REGI");
	serv_gets(buf);
	if (buf[0]!='4') {
		printf("<EM>%s</EM><BR>\n",&buf[4]);
		return;
		}

	serv_puts(bstr("realname"));
	serv_puts(bstr("address"));
	serv_puts(bstr("city"));
	serv_puts(bstr("state"));
	serv_puts(bstr("zip"));
	serv_puts(bstr("phone"));
	serv_puts(bstr("email"));
	serv_puts("000");
		
	printf("Registration information has been saved.\n");
	}


/* 
 * display form for changing your password
 */
int display_changepw() {
	char buf[256];
	int a;

        printf("<TABLE WIDTH=100% BORDER=0 BGCOLOR=770000><TR><TD>");
        printf("<FONT SIZE=+1 COLOR=\"FFFFFF\"");
        printf("<B>Change your password</B>\n");
        printf("</FONT></TD></TR></TABLE>\n");

	printf("<CENTER>");
	serv_puts("MESG changepw");
	serv_gets(buf);
	if (buf[0]=='1') fmout(NULL);

	printf("<FORM ACTION=\"session\" METHOD=\"POST\">\n");
	output_form_reconnect();
	printf("<INPUT TYPE=\"hidden\" NAME=\"oper\" VALUE=\"changepw\">\n",P);

	printf("<CENTER><TABLE border><TR><TD>Enter new password:</TD>\n");
	printf("<TD><INPUT TYPE=\"password\" NAME=\"newpass1\" VALUE=\"\" MAXLENGTH=\"20\"></TD></TR>\n");
	printf("<TR><TD>Enter it again to confirm:</TD>\n");
	printf("<TD><INPUT TYPE=\"password\" NAME=\"newpass2\" VALUE=\"\" MAXLENGTH=\"20\"></TD></TR>\n");
	printf("</TABLE>\n");	
	printf("<INPUT type=\"submit\" NAME=\"action\" VALUE=\"Change\">\n");
	printf("<INPUT type=\"submit\" NAME=\"action\" VALUE=\"Cancel\">\n");
	printf("</CENTER>\n");
	return(1);
	}

/*
 * change password
 */
void changepw() {
	char buf[256];
	char newpass1[32], newpass2[32];
	
	if (strcmp(bstr("action"),"Change")) {
		printf("Cancelled.  Password was not changed.<BR>\n");
		return;
		}

	strcpy(newpass1, bstr("newpass1"));
	strcpy(newpass2, bstr("newpass2"));

	if (strucmp(newpass1, newpass2)) {
		printf("They don't match.  Password was not changed.<BR>\n");
		return;
		}

	sprintf(buf, "SETP %s", newpass1);
	serv_puts(buf);
	serv_gets(buf);
	printf("<EM>%s</EM><BR>\n",&buf[4]);
	}


/* 
 * validate new users
 */
int validate_users() {
	char cmd[256];
	char user[256];
	char buf[256];
	int a;

	strcpy(buf,bstr("user"));
	if (strlen(buf)>0) if (strlen(bstr("axlevel"))>0) {
		sprintf(cmd,"VALI %s|%s",buf,bstr("axlevel"));
		serv_puts(cmd);
		serv_gets(buf);
		if (buf[0]!='2') {
			printf("<EM>%s</EM><BR>\n",&buf[4]);
			}
		}
	
	serv_puts("GNUR");
	serv_gets(buf);

	if (buf[0]!='3') {
		printf("<EM>%s</EM><BR>\n",&buf[4]);
		return(0);
		}

	strcpy(user,&buf[4]);
	sprintf(cmd,"GREG %s",user);
	serv_puts(cmd);
	serv_gets(cmd);
	if (cmd[0]=='1') {
		a = 0;
		do {
			serv_gets(buf);
			++a;
			if (a==1) printf("User #%s<BR><H1>%s</H1>",
				buf,&cmd[4]);
			if (a==2) printf("PW: %s<BR>\n",buf);
			if (a==3) printf("%s<BR>\n",buf);
			if (a==4) printf("%s<BR>\n",buf);
			if (a==5) printf("%s, ",buf);
			if (a==6) printf("%s ",buf);
			if (a==7) printf("%s<BR>\n",buf);
			if (a==8) printf("%s<BR>\n",buf);
			if (a==9) printf("Current access level: %d (%s)\n",
				atoi(buf),axdefs[atoi(buf)]);
			} while(strcmp(buf,"000"));
		}
	else {
		printf("<H1>%s</H1>%s<BR>\n",user,&cmd[4]);
		}

	printf("<CENTER><TABLE border><CAPTION>Select access level:");
	printf("</CAPTION><TR>");
	for (a=0; a<=6; ++a) {
		printf(
"<TD><A HREF=\"session?%s&oper=validate&user=%s&axlevel=%d\">%s</A></TD>\n",
				S,urlesc(user),a,axdefs[a]);
		}
	printf("</TR></TABLE><CENTER><BR>\n");

	return(1);
	}
