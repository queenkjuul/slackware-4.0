#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <signal.h>
#include <sys/types.h>
#include <ctype.h>
#include <string.h>
#include "ipcdef.h"
#include "webcit.h"

#define strucmp(lstr,rstr) struncmp(lstr,rstr,32767)

struct sharelist {
	struct sharelist *next;
	char shname[256];
	};


extern struct serv_info serv_info;
extern char S[];

char *bstr();
void server_to_text();


void display_edit_node() {
	char buf[256];
	char node[256];
	char sroom[256];

	strcpy(node, bstr("node"));

	printf("<TABLE WIDTH=100% BORDER=0 BGCOLOR=000077><TR><TD>");
	printf("<FONT SIZE=+1 COLOR=\"FFFFFF\"");
	printf("<B>Edit share list for ");
	escputs(node);
	printf("</B>\n");
	printf("</FONT></TD></TR></TABLE>\n");

	printf("<CENTER>\n");
	printf("<A HREF=\"session?%s&oper=display_share&node=", S);
	urlescputs(node);
	printf("\">Add a shared room</A><BR>\n");

	printf("<A HREF=\"session?%s&oper=display_netconf", S);
	printf("\">Return to network configuration screen</A><BR>\n");

	sprintf(buf, "NSET roomlist|%s", node);
	serv_puts(buf);
	serv_gets(buf);
	if (buf[0] == '1') {
		printf("<TABLE border=0>\n");
		while (serv_gets(buf), strcmp(buf, "000")) {
			extract(sroom, buf, 0);
			printf("<TR><TD><FONT SIZE=+1>");
			escputs(sroom);
			printf("</FONT></TD>");
			printf("<TD><A HREF=\"session?%s&oper=display_confirm_unshare&sroom=", S);
			urlescputs(sroom);
			printf("&node=");
			urlescputs(node);
			printf("\">(UnShare)</A></TD>");
			printf("</TR>\n");
			}
		printf("</TABLE></CENTER>\n");
		}
	
	printf("<HR>\n");
	}
	


void display_netconf() {
	char buf[256];
	char node[256];

	printf("<TABLE WIDTH=100% BORDER=0 BGCOLOR=770000><TR><TD>");
	printf("<FONT SIZE=+1 COLOR=\"FFFFFF\"");
	printf("<B>Network configuration</B>\n");
	printf("</FONT></TD></TR></TABLE>\n");

	printf("<CENTER>");
	printf("<A HREF=\"session?%s&oper=display_add_node\">", S);
	printf("Add a new node</A><BR>\n");
	printf("</CENTER>");

	printf("<TABLE WIDTH=100% BORDER=0 BGCOLOR=000077><TR><TD>");
	printf("<FONT SIZE=+1 COLOR=\"FFFFFF\"");
	printf("<B>Currently configured nodes</B>\n");
	printf("</FONT></TD></TR></TABLE>\n");
	serv_puts("NSET nodelist");
	serv_gets(buf);
	if (buf[0] == '1') {
		printf("<CENTER><TABLE border=0>\n");
		while (serv_gets(buf), strcmp(buf, "000")) {
			extract(node, buf, 0);
			printf("<TR><TD><FONT SIZE=+1>");
			escputs(node);
			printf("</FONT></TD>");
			printf("<TD><A HREF=\"session?%s&oper=display_edit_node&node=", S);
			urlescputs(node);
			printf("\">(Edit)</A></TD>");
			printf("<TD><A HREF=\"session?%s&oper=display_confirm_delete_node&node=", S);
			urlescputs(node);
			printf("\">(Delete)</A></TD>");
			printf("</TR>\n");
			}
		printf("</TABLE></CENTER>\n");
		}
	
	printf("<HR>\n");
	}


void display_confirm_unshare() {
	char node[256];
	char sroom[256];
	char buf[256];

	printf("<TABLE WIDTH=100% BORDER=0 BGCOLOR=770000><TR><TD>");
	printf("<FONT SIZE=+1 COLOR=\"FFFFFF\"");
	printf("<B>Confirm unshare</B>\n");
	printf("</FONT></TD></TR></TABLE>\n");

	strcpy(node, bstr("node"));
	strcpy(sroom, bstr("sroom"));
	printf("<CENTER>Are you sure you want to unshare <FONT SIZE=+1>");
	escputs(sroom);
	printf("</FONT>?<BR>\n");
	printf("<A HREF=\"session?%s&oper=unshare&node=", S);
	urlescputs(node);
	printf("&sroom=");
	urlescputs(sroom);
	printf("\">Yes</A>&nbsp;&nbsp;&nbsp;");
	printf("<A HREF=\"session?%s&oper=display_edit_node&node=", S);
	urlescputs(node);
	printf("\">No</A><BR>\n");
	}


void display_confirm_delete_node() {
	char node[256];
	char buf[256];

	printf("<TABLE WIDTH=100% BORDER=0 BGCOLOR=770000><TR><TD>");
	printf("<FONT SIZE=+1 COLOR=\"FFFFFF\"");
	printf("<B>Confirm delete</B>\n");
	printf("</FONT></TD></TR></TABLE>\n");

	strcpy(node, bstr("node"));
	printf("<CENTER>Are you sure you want to delete <FONT SIZE=+1>");
	escputs(node);
	printf("</FONT>?<BR>\n");
	printf("<A HREF=\"session?%s&oper=delete_node&node=", S);
	urlescputs(node);
	printf("\">Yes</A>&nbsp;&nbsp;&nbsp;");
	printf("<A HREF=\"session?%s&oper=display_netconf\">No</A><BR>\n", S);
	}


void delete_node() {
	char node[256];
	char buf[256];
	
	strcpy(node, bstr("node"));
	sprintf(buf, "NSET deletenode|%s", node);
	serv_puts(buf);
	serv_gets(buf);
	if (buf[0]=='1') {
		server_to_text();
		}
	else {
		printf("<EM>%s</EM><BR>\n", &buf[4]);
		}
	display_netconf();
	}


void unshare() {
	char node[256];
	char sroom[256];
	char buf[256];
	
	strcpy(node, bstr("node"));
	strcpy(sroom, bstr("sroom"));
	sprintf(buf, "NSET unshare|%s|%s", node, sroom);
	serv_puts(buf);
	serv_gets(buf);
	if (buf[0]=='1') {
		server_to_text();
		}
	else {
		printf("<EM>%s</EM><BR>\n", &buf[4]);
		}
	display_edit_node();
	}



void display_add_node() {
	
	printf("<TABLE WIDTH=100% BORDER=0 BGCOLOR=007700><TR><TD>");
	printf("<FONT SIZE=+1 COLOR=\"FFFFFF\"");
	printf("<B>Add a new node</B>\n");
	printf("</FONT></TD></TR></TABLE>\n");

	printf("<CENTER>");
	printf("<FORM METHOD=\"POST\" ACTION=\"session\">\n");
	output_form_reconnect();

	printf("<INPUT TYPE=\"hidden\" NAME=\"oper\" VALUE=\"add_node\">\n");

	printf("Enter name of new node: ");
	printf("<INPUT TYPE=\"text\" NAME=\"node\" MAXLENGTH=\"64\"><BR>\n");

	printf("<INPUT TYPE=\"submit\" NAME=\"sc\" VALUE=\"Add\">");
	printf("<INPUT TYPE=\"submit\" NAME=\"sc\" VALUE=\"Cancel\">");

	printf("</FORM></CENTER>\n");

	}



void add_node() {
	char node[256];
	char buf[256];
	char sc[256];

	strcpy(node, bstr("node"));
	strcpy(sc, bstr("sc"));

	if (!strcmp(sc, "Add")) {
		sprintf(buf, "NSET addnode|%s", node);
		serv_puts(buf);
		serv_gets(buf);
		if (buf[0]=='1') {
			server_to_text();
			}
		else {
			printf("<EM>%s</EM><BR>\n", &buf[4]);
			}
		}

	display_netconf();
	}



void display_share() {
	char buf[256];
	char node[256];
	char sroom[256];
	struct sharelist *shlist = NULL;
	struct sharelist *shptr;
	int already_shared;

	strcpy(node, bstr("node"));
	
	printf("<TABLE WIDTH=100% BORDER=0 BGCOLOR=007700><TR><TD>");
	printf("<FONT SIZE=+1 COLOR=\"FFFFFF\"");
	printf("<B>Add a shared room</B>\n");
	printf("</FONT></TD></TR></TABLE>\n");

	printf("<CENTER>");
	printf("<FORM METHOD=\"POST\" ACTION=\"session\">\n");
	output_form_reconnect();

	printf("<INPUT TYPE=\"hidden\" NAME=\"oper\" VALUE=\"share\">\n");
	printf("<INPUT TYPE=\"hidden\" NAME=\"node\" VALUE=\"");
	urlescputs(node);
	printf("\">\n");

	sprintf(buf, "NSET roomlist|%s", node);
	serv_puts(buf);
	serv_gets(buf);
	if (buf[0]=='1') {
		while(serv_gets(buf), strcmp(buf,"000")) {
			shptr = (struct sharelist *)
				malloc(sizeof(struct sharelist));
			shptr -> next = shlist;
			extract(&shptr->shname, buf, 0);
			shlist = shptr;
			}
		}

	printf("<SELECT NAME=\"sroom\" SIZE=5 WIDTH=30>\n");
	serv_puts("LKRA");
	serv_gets(buf);
	if (buf[0]=='1') {
		while(serv_gets(buf), strcmp(buf,"000")) {
			extract(sroom, buf, 0);
			already_shared = 0;
			for (shptr = shlist; shptr != NULL; shptr = shptr->next) {
				if (!strucmp(sroom, shptr->shname))
					already_shared = 1;
				}

			if (already_shared == 0) {
				printf("<OPTION>");
				escputs(sroom);
				printf("\n");
				}

			}
		}
	printf("</SELECT>\n");
	printf("<BR>\n");

	printf("<INPUT TYPE=\"submit\" NAME=\"sc\" VALUE=\"Share\">");
	printf("<INPUT TYPE=\"submit\" NAME=\"sc\" VALUE=\"Cancel\">");

	printf("</FORM></CENTER>\n");

	/* free the list */
	while (shlist != NULL) {
		shptr = shlist->next;
		free(shlist);
		shlist = shptr;
		}

	}



void share() {
	char node[256];
	char buf[256];
	char sc[256];
	char sroom[256];
	
	strcpy(node, bstr("node"));
	strcpy(sc, bstr("sc"));
	strcpy(sroom, bstr("sroom"));

	if (!strcmp(sc, "Share")) {
		sprintf(buf, "NSET share|%s|%s", node, sroom);
		serv_puts(buf);
		serv_gets(buf);
		if (buf[0]=='1') {
			server_to_text();
			}
		else {
			printf("<EM>%s</EM><BR>\n", &buf[4]);
			}
		}

	display_edit_node();
	}

