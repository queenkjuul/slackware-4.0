#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <signal.h>
#include <sys/types.h>
#include <ctype.h>
#include <string.h>
#include "ipcdef.h"

#define strucmp(lstr,rstr) struncmp(lstr,rstr,32767)

extern struct serv_info serv_info;
extern long P;
extern char S[];
extern char user_name[];
extern char room_name[];
extern char curr_pass[];
extern char curr_host[];
extern char curr_port[];
extern char axlevel;
extern int timescalled;
extern int posted;
extern unsigned userflags;
extern long eternal;
extern char *bstr();
extern char ugname[];
extern long uglsn;
extern char is_room_aide;
extern void whobbs();



/*
 * display the form for paging (x-messaging) another user
 */
void display_page() {
	char buf[256];
	char user[256];

        printf("<TABLE WIDTH=100% BORDER=0 BGCOLOR=007700><TR><TD>");
        printf("<FONT SIZE=+1 COLOR=\"FFFFFF\"");
        printf("<B>Page another user</B>\n");
        printf("</FONT></TD></TR></TABLE>\n");

	printf("This command sends a near-real-time message to any currently\n");
	printf("logged in user.<BR><BR>\n");

	printf("<FORM METHOD=\"POST\" ACTION=\"session\">\n");
	output_form_reconnect();

	printf("<INPUT TYPE=\"hidden\" NAME=\"oper\" VALUE=\"page\">\n");

	printf("Select a user to send a message to: <BR>");

	printf("<SELECT NAME=\"recp\" SIZE=5>\n");
	serv_puts("RWHO");
	serv_gets(buf);
	if (buf[0]=='1') {
		while(serv_gets(buf), strcmp(buf,"000")) {
			extract(user,buf,1);
			printf("<OPTION>");
			escputs(user);
			printf("\n");
			}
		}
	printf("</SELECT>\n");
	printf("<BR>\n");

	printf("Enter message text:<BR>");
	printf("<INPUT TYPE=\"text\" NAME=\"msgtext\" MAXLENGTH=80 SIZE=80>\n");
	printf("<BR><BR>\n");

	printf("<INPUT TYPE=\"submit\" NAME=\"sc\" VALUE=\"Send message\">");
	printf("<INPUT TYPE=\"submit\" NAME=\"sc\" VALUE=\"Cancel\"><BR>\n");

	printf("</FORM></CENTER>\n");
	}

/*
 * page another user
*/
void page_user() {
	char recp[256];
	char msgtext[256];
	char sc[256];
	char buf[256];
	
	strcpy(recp,bstr("recp"));
	strcpy(msgtext,bstr("msgtext"));
	strcpy(sc,bstr("sc"));

	if (strcmp(sc,"Send message")) {
		printf("<EM>Message was not sent.</EM><BR>\n");
		return;
		}

	sprintf(buf,"SEXP %s|%s",recp,msgtext);
	serv_puts(buf);
	serv_gets(buf);	

	if (buf[0] == '2') {
		printf("<EM>Message has been sent.</EM><BR>\n");
		}
	else {
		printf("<EM>%s</EM><BR>\n",&buf[4]);
		}
	}


/*
 * tell 'em we're still building...
 */
void under_construction() {
	printf("<EM>This section is under construction.</EM><HR>\n");
	}


/*
 * advanced options
 */
void display_advanced() {

printf("<TABLE WIDTH=100%><TR VALIGN=TOP><TD>");


printf("<TABLE WIDTH=100% BORDER=0 BGCOLOR=770000><TR><TD>");
printf("<FONT SIZE=+1 COLOR=\"FFFFFF\"");
printf("<B>Interaction</B>\n");
printf("</FONT></TD></TR></TABLE>\n");

printf("<UL>");
printf("<LI><A HREF=\"session?%s&oper=display_page\">\n",S);
printf("Page another user</A>\n");

printf("<LI><A HREF=\"session?%s&oper=chat\">",S);
printf("Chat with other online users</A>\n");

printf("</UL>\n");

printf("</TD><TD>");

printf("<TABLE WIDTH=100% BORDER=0 BGCOLOR=007700><TR><TD>");
printf("<FONT SIZE=+1 COLOR=\"FFFFFF\"");
printf("<B>Your info</B>\n");
printf("</FONT></TD></TR></TABLE>\n");

printf("<UL>");
printf("<LI><A HREF=\"session?%s&oper=display_editbio\">\n",S);
printf("Enter your 'bio' (a few words about yourself)</A>\n");

printf("<LI><A HREF=\"session?%s&oper=display_editpic\">\n",S);
printf("Edit your online photo</A>\n");

printf("<LI><A HREF=\"session?%s&oper=display_reg\">\n",S);
printf("Re-enter your registration info (name, address, etc.)</A>\n");

printf("<LI><A HREF=\"session?%s&oper=display_changepw\">\n",S);
printf("Change your password</A>\n");

printf("</UL>\n");


printf("</TD></TR><TR VALIGN=TOP><TD>");

printf("<TABLE WIDTH=100% BORDER=0 BGCOLOR=000077><TR><TD>");
printf("<FONT SIZE=+1 COLOR=\"FFFFFF\"");
printf("<B>Advanced room commands</B>\n");
printf("</FONT></TD></TR></TABLE>\n");

printf("<UL>");
printf("<LI><A HREF=\"session?%s&oper=display_private\">\n",S);
printf("Go to a 'hidden' room</A>\n");

printf("<LI><A HREF=\"session?%s&oper=display_entroom\">",S);
printf("Create a new room</A>\n");

printf("<LI><A HREF=\"session?%s&oper=display_zap\">",S);
printf("Zap (forget) this room (%s)</A>\n", room_name);

printf("<LI><A HREF=\"session?%s&oper=zapped_list\">",S);
printf("List all forgotten rooms</A>\n");

printf("</UL>\n");

printf("</TD><TD>");

if (is_room_aide) {
	printf("<TABLE WIDTH=100% BORDER=0 BGCOLOR=007777><TR><TD>");
	printf("<FONT SIZE=+1 COLOR=\"FFFFFF\"");
	printf("<B>Administrative functions</B>\n");
	printf("</FONT></TD></TR></TABLE>\n");

	printf("<UL>");
	printf("<LI><A HREF=\"session?%s&oper=display_editroom\">\n",S);
	printf("Edit this room</A>\n");
	
	printf("<LI><A HREF=\"session?%s&oper=confirm_delete_room\">\n",S);
	printf("Delete this room</A>\n");
	
	printf("<LI><A HREF=\"session?%s&oper=display_editroompic\">\n",S);
	printf("Set or change the graphic for this room's banner</A>\n");

	printf("<LI><A HREF=\"session?%s&oper=display_editinfo\">\n",S);
	printf("Edit this room's Info file</A>\n");

	if (axlevel>=6) {
		printf("<LI><A HREF=\"session?%s&oper=validate\">\n",S);
		printf("Validate new users</A>\n");

		printf("<LI><A HREF=\"session?%s&oper=display_editfloorpic\">\n",S);
		printf("Set or change a floor label graphic</A>\n");

		printf("<LI><A HREF=\"session?%s&oper=display_netconf\">\n",S);
		printf("Configure networking with other systems</A>\n");
		}

	printf("</UL>\n");
	}

printf("</TD></TR></TABLE>");

printf("<TABLE WIDTH=100% BORDER=0 BGCOLOR=770077><TR><TD>");
printf("<FONT SIZE=+1 COLOR=\"FFFFFF\"");
printf("<B>Basic commands</B>\n");
printf("</FONT></TD></TR></TABLE>\n");

	}



/* 
 * menu of commands
 */
void mainmenu(display_current_room) {

printf("<CENTER><TABLE border=0><TR>");

printf("<TD>");	/* start of first column */

printf("<UL>");
printf("<LI><B><A HREF=\"session?%s&oper=knrooms\">\n",S);
printf("List known rooms</B></A><BR>\n");
printf("Where can I go from here?</LI>\n");

printf("<LI><B><A HREF=\"session?%s&oper=gotonext\">\n",S);
printf("Goto next room</B></A><BR>\n");
printf("...with <EM>unread</EM> messages</LI>\n");

printf("<LI><B><A HREF=\"session?%s&oper=skip\">\n",S);
printf("Skip to next room</B></A><BR>\n");
printf("(come back here later)</LI>\n");

if ( (strlen(ugname)>0) && (strucmp(ugname,room_name)) ) {
	printf("<LI><B><A HREF=\"session?%s&oper=ungoto\">\n",S);
	printf("Ungoto</B></A><BR>\n");
	printf("(oops! Back to %s)</LI>\n",ugname);
	}

printf("</UL>\n");

printf("</TD><TD>\n"); /* start of second column */

printf("<UL>");
printf("<LI><B><A HREF=\"session?%s&oper=readnew\">\n",S);
printf("Read new messages</B></A><BR>...in this room</LI>\n");

printf("<LI><B><A HREF=\"session?%s&oper=readfwd\">\n",S);
printf("Read all messages</B></A><BR>...old <EM>and</EM> new</LI>\n");

printf("<LI><B><A HREF=\"session?%s&oper=display_enter\">\n",S);
printf("Enter a message</B></A><BR>(post in this room)</LI>");
printf("</UL>\n");

printf("</TD><TD>"); /* start of third column */

printf("<UL>");
printf("<LI><B><A HREF=\"session?%s&oper=whobbs\">\n",S);
printf("Who is online?</B></A><BR>(users <EM>currently</EM> logged on)</LI>\n");

printf("<LI><B><A HREF=\"session?%s&oper=userlist\">\n",S);
printf("User list</B></A><BR>(all registered users)</LI>\n");

printf("<LI><B><A HREF=\"session?%s&oper=advanced\">\n",S);
printf("Advanced options</B></A><BR>...and maintenance</LI>\n");

printf("<LI><B><A HREF=\"session?%s&oper=termquit\">\n",S);
printf("Log off</B></A><BR>Bye!</LI>\n");
printf("</UL>\n");

printf("</TR></TABLE>\n");

if (display_current_room) printf("Current room: %s",room_name);
printf("</CENTER>\n");
	

}


/*
 * "ps ax" cmd for debugging and maintenance
 */
void psax() {
	printf("<PRE>");
	fflush(stdout);
	system("ps ax");
	printf("</PRE>");
	}



/*
 * multiuser chat
 */
void do_chat() {

        printf("<TABLE WIDTH=100% BORDER=0 BGCOLOR=000077><TR><TD>");
        printf("<FONT SIZE=+1 COLOR=\"FFFFFF\"");
        printf("<B>Real-time chat</B>\n");
        printf("</FONT></TD></TR></TABLE>\n");

	printf("A chat window should be appearing on your screen ");
	printf("momentarily.  When you're ");
	printf("done, type <TT>/quit</TT> to exit.  You can also ");
	printf("type <TT>/help</TT> for more commands.\n");

	printf("<applet codebase=\"%s\" ", STATIC_URL);
	printf("code=\"wcchat\" width=2 height=2>\n");
	printf("<PARAM NAME=username VALUE=\"%s\">\n", user_name);
	printf("<PARAM NAME=password VALUE=\"%s\">\n", curr_pass);
	printf("<H2>Oops!</H2>Looks like your browser doesn't support Java, ");
	printf("so you won't be able to access Chat.  Sorry.\n");
	printf("</applet>\n");
	}

/*
 * main loop of system
 */
void mainloop(is_aa,m)
int is_aa;
int m; {
	char oper[256];
	char buf[256];
	int f = 0;
	
	/* if ((is_aa == 0) && (m==0)) mainmenu(); */
	if ((is_aa == 0) && (m==0)) {
		printf("<HR>");
		if (readloop("readnew")==0) mainmenu(1);
		}

	do {
		f = 0;

		if (is_aa == 0) browser_input();
		is_aa = 0;

		strcpy(oper,bstr("oper"));

		/* change rooms if we have to */
		if (strlen(bstr("room"))>0) {
			if (struncmp(room_name,bstr("room"))) {
				gotoroom(bstr("room"),0);
				}
			}

		/* set f to 1 when we don't want the main menu displayed */
		/* set f to 2 to display the room banner again */

		if (!strcmp(oper,"mainmenu")) {
			f = 2;
			}

		if (!strcmp(oper,"psax")) {
			psax();
			}

		if (!strcmp(oper,"whobbs")) {
			whobbs();
			}

		if (!strcmp(oper, "chat")) {
			do_chat();
			}

		if (!strcmp(oper,"termquit")) {
			slrp_highest();
			f = 1;
			}

		if (!strcmp(oper,"knrooms")) {
			list_all_rooms_by_floor();
			}

		if (!strcmp(oper,"zapped_list")) {
			zapped_list();
			}

		if (!strcmp(oper,"dotgoto")) {
			slrp_highest();
			dotgoto();
			}

		if (!strcmp(oper,"readfwd")) {
			f=readloop(oper);
			}

		if (!strcmp(oper,"readnew")) {
			f=readloop(oper);
			}

		if (!strcmp(oper,"readold")) {
			f=readloop(oper);
			}

		if (!strcmp(oper,"gotonext")) {
			slrp_highest();
			gotonext();
			}

		if (!strcmp(oper,"skip")) {
			gotonext();
			}

		if (!strcmp(oper,"ungoto")) {
			ungoto();
			}

		if (!strcmp(oper,"display_enter")) {
			f = display_enter();
			}

		if (!strcmp(oper,"post")) {
			post_message();
			f = 2;
			}

		if (!strcmp(oper,"display_reg")) {
			f = display_reg();
			}

		if (!strcmp(oper,"register")) {
			register_user();
			f = 2;
			}

		if (!strcmp(oper,"display_changepw")) {
			f = display_changepw();
			}

		if (!strcmp(oper,"changepw")) {
			changepw();
			f = 2;
			}

		if (!strcmp(oper,"validate")) {
			f = validate_users();
			}

		if (!strcmp(oper,"userlist")) {
			userlist();
			}
	
		if (!strcmp(oper,"readinfo")) {
			readinfo(1);
			}

		if (!strcmp(oper,"display_editroom")) {
			f = display_editroom();
			}

		if (!strcmp(oper,"editroom")) {
			f = editroom();
			}

		if (!strcmp(oper, "confirm_delete_room")) {
			f = confirm_delete_room();
			}

		if (!strcmp(oper, "delete_room")) {
			f = delete_room();
			}

		if (!strcmp(oper, "confirm_delete_msg")) {
			f = confirm_delete_msg();
			}

		if (!strcmp(oper, "delete_msg")) {
			f = delete_msg();
			}

		if (!strcmp(oper, "confirm_move_msg")) {
			f = confirm_move_msg();
			}

		if (!strcmp(oper, "move_msg")) {
			f = move_msg();
			}

		if (!strcmp(oper,"display_editinfo")) {
			f = display_edit("Room info", "EINF 0", "RINF", "editinfo");
			}

		if (!strcmp(oper,"editinfo")) {
			save_edit("Room info", "EINF 1");
			f = 2;
			}

		if (!strcmp(oper,"display_editbio")) {
			sprintf(buf, "RBIO %s", user_name);
			display_edit("Your bio", "NOOP", buf, "editbio");
			f = 0;
			}

		if (!strcmp(oper,"editbio")) {
			save_edit("Your bio", "EBIO");
			f = 2;
			}

		if (!strcmp(oper,"display_editpic")) {
			display_editpic();
			f = 0;
			}

		if (!strcmp(oper,"editpic")) {
			editpic();
			f = 2;
			}

		if (!strcmp(oper,"display_editroompic")) {
			display_editroompic();
			f = 0;
			}

		if (!strcmp(oper,"editroompic")) {
			editroompic();
			f = 2;
			}

		if (!strcmp(oper,"display_editfloorpic")) {
			display_editfloorpic();
			f = 0;
			}

		if (!strcmp(oper,"display_netconf")) {
			display_netconf();
			f = 0;
			}

		if (!strcmp(oper,"display_edit_node")) {
			display_edit_node();
			f = 0;
			}

		if (!strcmp(oper,"display_add_node")) {
			display_add_node();
			f = 0;
			}

		if (!strcmp(oper,"add_node")) {
			add_node();
			f = 0;
			}

		if (!strcmp(oper,"display_share")) {
			display_share();
			f = 0;
			}

		if (!strcmp(oper,"share")) {
			share();
			f = 0;
			}

		if (!strcmp(oper,"display_confirm_unshare")) {
			display_confirm_unshare();
			f = 1;
			}

		if (!strcmp(oper,"display_confirm_delete_node")) {
			display_confirm_delete_node();
			f = 1;
			}

		if (!strcmp(oper,"delete_node")) {
			delete_node();
			f = 0;
			}

		if (!strcmp(oper,"unshare")) {
			unshare();
			f = 0;
			}

		if (!strcmp(oper,"editfloorpic")) {
			editfloorpic();
			f = 2;
			}

		if (!strcmp(oper,"display_entroom")) {
			f = display_entroom();
			}

		if (!strcmp(oper,"entroom")) {
			f = entroom();
			}

		if (!strcmp(oper,"display_page")) {
			display_page();
			f = 1;
			}

		if (!strcmp(oper,"display_private")) {
			display_private("",0);
			f = 1;
			}

		if (!strcmp(oper,"goto_private")) {
			f = goto_private();
			}

		if (!strcmp(oper,"page")) {
			page_user();
			f = 2;
			}

		if (!strcmp(oper,"advanced")) {
			gotoroom(room_name,2);
			display_advanced();
			}

		if (!strcmp(oper,"showuser")) {
			showuser();
			}

		if (!strcmp(oper, "display_zap")) {
			display_zap();
			f = 1;
			}

		if (!strcmp(oper, "zap")) {
			f = zap();
			}

		if (f==0) mainmenu(1);
		if (f==2) {
			gotoroom(room_name,2);	/* display banner again */
			mainmenu(0);
			}
	
		} while(strucmp(oper,"termquit"));
	}
