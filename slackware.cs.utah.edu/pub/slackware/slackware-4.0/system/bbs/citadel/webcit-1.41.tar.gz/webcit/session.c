#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <signal.h>
#include <errno.h>
#include <sys/file.h>

#ifdef USE_SYSLOG
#include <syslog.h>
#endif

/* #define DEBUG 1 */

long atol();

void unescape_input(buf)
char buf[]; {
	int a,b;
	char hex[3];

	while ((isspace(buf[strlen(buf)-1]))&&(strlen(buf)>0))
		buf[strlen(buf)-1] = 0;

	for (a=0; a<strlen(buf); ++a) {
		if (buf[a]=='+') buf[a]=' ';	
		if (buf[a]=='%') {
			hex[0]=buf[a+1];
			hex[1]=buf[a+2];
			hex[2]=0;
			sscanf(hex,"%02x",&b);
			buf[a] = (char) b;
			strcpy(&buf[a+1],&buf[a+3]);
			}
		}

	}


void extract_host_and_port(c_host,c_port,q)
char c_host[];
char c_port[];
char q[]; {
	int a,b;

	for (a=0; a<strlen(q); ++a) {
		if (!strncmp(&q[a],"host=",5)) {
			strncpy(c_host,&q[a+5],255);
			for (b=0; b<strlen(c_host); ++b) {
				if (c_host[b]=='&') c_host[b] = 0;
				}
			}
		if (!strncmp(&q[a],"port=",5)) {
			strncpy(c_port,&q[a+5],255);
			for (b=0; b<strlen(c_port); ++b) {
				if (c_port[b]=='&') c_port[b] = 0;
				}
			}
		}
	}




void main() {

	char q[1024];
	char buf[256];
	char c_host[256];
	char c_port[256];
	char c_sess[32];
	int a,b;
	long p;
	int cpid;
	char wcpipe[256];
	FILE *rp,*sp;
	long cp;
	char *url,*ptr,*up;
	int post = 0;
	int count;


#ifdef USE_SYSLOG
	openlog("session", LOG_PID, LOG_USER);
#endif

	strcpy(c_host,DEFAULT_HOST);
	strcpy(c_port,DEFAULT_PORT);

	if (getenv("QUERY_STRING")==NULL) {
		printf("Content-type: text/html\n\n");
		printf("<HTML><HEAD><TITLE>WebCit for Citadel/UX</TITLE>\n");
		printf("</HEAD><BODY><CENTER><H1>Error</H1>\n");
		printf("<H2>Incorrect CGI script usage.<H2>\n");
		printf("Don't even think of trying to operate this ");
		printf("thing manually.</CENTER></BODY></HTML>\n");
		exit(0);
		}

	if (!strcmp(getenv("REQUEST_METHOD"),"POST")) post=1;

	if (post == 0) {
		strcpy(q, getenv("QUERY_STRING"));
		p = atol(q);
		url = malloc(1L+(long)strlen(q));
		strcpy(url, q);
		}

	if (post == 1) {
		url = malloc(1L+atol(getenv("CONTENT_LENGTH")));
		fread(url,atoi(getenv("CONTENT_LENGTH")),1,stdin);
		}

	ptr = url;
	for (a=0; a<strlen(url); ++a) {
		if (!strncmp(ptr,"session=",8)) {
			strncpy(buf, ptr, 256);
			p = atol(&buf[8]);
			}
		++ptr;
		}

#ifdef DEBUG
	printf("Content-type: text/html\n\n<PRE>");
	printf("Session number is %ld\n",p);
	fflush(stdout);
#endif

	sprintf(wcpipe,"/tmp/webcit.%ld",p);

	if (access(wcpipe,R_OK)+access(wcpipe,W_OK)!=0) {
		time(&p);
		p = p & (long)0xFFFF;
		p = (p | ((long)getpid()<<16L));
		sprintf(c_sess,"%ld",p);
		sprintf(wcpipe,"/tmp/webcit.%ld",p);
		cp = (long)fork();
		if (cp>0L) {
			for (count=0; count<60; ++count) {
				if (access(wcpipe,R_OK)+access(wcpipe,W_OK)==0) goto STUFF;
				sleep(1);
				}
			printf("Content-type: text/html\n\n");
			printf("Error: Could not create session.\n");
			exit(1);
			}
		if (cp==0L) {
			extract_host_and_port(c_host, c_port, q);
			unescape_input(c_host);
			unescape_input(c_port);
#ifdef DEBUG
			printf("Starting webcit, pid=%d, ",getpid());
			printf("host=%s, port=%s<BR>\n",c_host,c_port);
			fflush(stdout);
#endif
			signal(SIGHUP,SIG_IGN);
			execlp("webcit","webcit",c_host,c_port,c_sess,getenv("HTTP_REFERER"),NULL);
			execlp("./webcit","webcit",c_host,c_port,c_sess,getenv("HTTP_REFERER"),NULL);
			printf("Content-type: text/html\n\n");
			printf("<TITLE>Web Citadel/UX</TITLE>\n");
			printf("<CENTER><H1>Error</H1>\n");
			printf("<H2>Could not execute webcit.<H2>\n");
			free(url);
			exit(0);
			}
		}

STUFF:	sprintf(wcpipe,"/tmp/webcit.%ld",p);

	if (access(wcpipe,R_OK)+access(wcpipe,W_OK)==0) {
#ifdef DEBUG
		printf("access is ok - pipe exists<BR>\n");
		fflush(stdout);
#endif

		sp = fopen(wcpipe,"w");
		if (sp == NULL) {
			printf("ERROR - cannot open %s (write): %s\n",
				wcpipe, strerror(errno));
#ifdef USE_SYSLOG
			syslog(LOG_NOTICE, "cannot open %s (write): %s",
				wcpipe, strerror(errno));
#endif
			}

		/* lock the pipe so we get exclusive access */
		if (flock(fileno(sp),LOCK_EX)!=0) {
			printf("flock() error %d (%s)\n",
				errno,strerror(errno));
			}

		up = url;
		while (strlen(up)>0) {
				
			/* locate the = sign */
			strncpy(buf,up,255);
			b = (-1);
			for (a=255; a>=0; --a) if (buf[a]=='=') b=a;
			if (b<0) goto DONE;
			buf[b]=0;

			/* output the variable name */
#ifdef DEBUG
			printf("name=%-16s ",buf);
			fflush(stdout);
#endif
			fprintf(sp,"%s\n",buf);
			fflush(sp);

			/* now chop that part off */
			for (a=0; a<=b; ++a) ++up;

			/* locate the & sign */
			ptr = up;
			b = strlen(up);
			for (a=0; a<strlen(up); ++a) {
				if (!strncmp(ptr,"&",1)) {
					b=a;
					goto FOUNDIT;
					}
				++ptr;
				}
FOUNDIT:		ptr = up;
			for (a=0; a<b; ++a) ++ptr;
			strcpy(ptr,"");
				
#ifdef DEBUG
			printf("len=%-5d ",strlen(up));
			printf("text=%s\n",up);
			fflush(stdout);
#endif
			fprintf(sp,"%d\n%s\n",strlen(up),up);
			fflush(sp);
			
			up = ptr;
			++up;

			}

DONE:		fprintf(sp,"000BrowserStop\n14\n000BrowserStop\n");
#ifdef DEBUG
		printf("000BrowserStop<BR>\n");
		fflush(stdout);
#endif

		/* remove the lock */
		if (flock(fileno(sp),LOCK_UN)!=0) {
			printf("flock() error %d (%s)\n",
				errno,strerror(errno));
			}

		fclose(sp);

#ifdef DEBUG
		printf("getting data...</PRE><BR><HR>\n");
		fflush(stdout);
#endif
		rp = fopen(wcpipe,"r");
		if (rp==NULL) {
			printf("ERROR - cannot open %s (read): %s\n",
				wcpipe, strerror(errno));
#ifdef USE_SYSLOG
			syslog(LOG_NOTICE, "cannot open %s (read): %s",
				wcpipe, strerror(errno));
#endif
			}
		fflush(stdout);
		while (fgets(buf,256,rp), strncmp(buf,"000BrowserStop",14)) {
			printf("%s",buf);
			fflush(stdout);
			}
		fclose(rp);
		}

	else {
		printf("Content-type: text/html\n\n");
		printf("<HTML><HEAD><TITLE>Web Citadel/UX</TITLE></HEAD>\n");
		printf("<BODY><CENTER><H1>Session timed out</H1>\n");
		printf("<H2>Your session timed out because you waited ");
		printf("too long between transmits.  Blame it on the ");
		printf("horribly inefficient protocols used on the ");
		printf("Web.</CENTER></BODY></HTML>\n");
		free(url);
		exit(0);
		}

	free(url);
	exit(0);
	}

