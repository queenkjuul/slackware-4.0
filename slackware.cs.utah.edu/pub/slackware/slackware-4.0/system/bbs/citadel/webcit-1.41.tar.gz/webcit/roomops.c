#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <signal.h>
#include <sys/types.h>
#include "citadel.h"

struct march {
	struct march *next;
	char march_name[64];
	};

extern struct serv_info serv_info;
extern long P;
extern char S[];
extern char user_name[];
extern char room_name[];
extern char curr_host[];
extern char curr_port[];
extern char curr_pass[];
extern char axlevel;
extern int timescalled;
extern int posted;
extern unsigned userflags;
extern unsigned room_flags;
extern long eternal;
extern struct march *march;
extern char ugname[];
extern long uglsn;
extern char is_room_aide;

long atol();
char *bstr();

extern char floorlist[128][256];


/*
 * load the list of floors
 */
void load_floorlist() {
	int a;
	char buf[256];

	for (a=0; a<128; ++a) floorlist[a][0] = 0;

	serv_puts("LFLR");
	serv_gets(buf);
	if (buf[0]!='1') {
		strcpy(floorlist[0],"Main Floor");
		return;
		}
	while (serv_gets(buf), strcmp(buf,"000")) {
		extract(floorlist[extract_int(buf,0)],buf,1);
		}
	}



/*
 * remove a room from the march list
 */
void remove_march(aaa)
char *aaa; {
	struct march *mptr,*mptr2;

	if (march==NULL) return;

	if (!strucmp(march->march_name,aaa)) {
		mptr = march->next;
		free(march);
		march = mptr;
		return;
		}

	mptr2 = march;
	for (mptr=march; mptr!=NULL; mptr=mptr->next) {
		if (!strucmp(mptr->march_name,aaa)) {
			mptr2->next = mptr->next;
			free(mptr);
			mptr=mptr2;
			}
		else {
			mptr2=mptr;
			}
		}
	}


void listrms(variety)
char *variety; {
	char buf[256];
	char rmname[64];
	int f;

	serv_puts(variety);
	serv_gets(buf);
	if (buf[0]!='1') return;
	while (serv_gets(buf), strcmp(buf,"000")) {
		extract(rmname,buf,0);
		printf("<A HREF=\"session?%s&oper=dotgoto&room=",S);
		urlescputs(rmname);
		printf("\">");
		escputs1(rmname,1);
		f = extract_int(buf,1);
		if ((f & QR_DIRECTORY) && (f & QR_NETWORK)) printf("}");
		else if (f & QR_DIRECTORY) printf("]");
		else if (f & QR_NETWORK) printf(")");
		else printf("&gt;");
		printf("</A><TT> </TT>\n");
		};
	printf("<BR>\n");
	}



/*
 * list all rooms by floor
 */
void list_all_rooms_by_floor() {
	int a, have_pic;
	char buf[256];
	char pic[256];

	load_floorlist();
	printf("<TABLE width=100% border><TR><TH>Floor</TH>");
	printf("<TH>Rooms with new messages</TH>");
	printf("<TH>Rooms with no new messages</TH></TR>\n");

	for (a=0; a<128; ++a) if (floorlist[a][0]!=0) {

		/* Floor name column */
		printf("<TR><TD>");
		
		sprintf(buf, "_floorpic_|%d", a);
		have_pic = fetch_image(pic, buf);


		if (have_pic == 0) {
			printf("<IMG SRC=\"%s\" ALT=\"%s\">",
				pic, &floorlist[a][0]);
			}
		else {
			printf("%s", &floorlist[a][0]);
			}

		printf("</TD>");

		/* Rooms with new messages column */
		printf("<TD>");
		sprintf(buf,"LKRN %d",a);
		listrms(buf);
		printf("</TD><TD>\n");

		/* Rooms with old messages column */
		sprintf(buf,"LKRO %d",a);
		listrms(buf);
		printf("</TD></TR>\n");
		}
	printf("</TABLE>\n");
	}


/*
 * list all forgotten rooms
 */
void zapped_list() {
	char buf[256];

	printf("<CENTER><H1>Forgotten rooms</H1>\n");
	listrms("LZRM -1");
	printf("</CENTER><HR>\n");
	}
	

/*
 * read this room's info file (set v to 1 for verbose mode)
 */
void readinfo(v)
int v; {
	char buf[256];

	serv_puts("RINF");
	serv_gets(buf);
	if (buf[0]=='1') fmout(NULL);
	else {
		if (v==1) printf("<EM>%s</EM><BR>\n",&buf[4]);
		}
	}


/*
 * generic routine to take the session to a new room
 *
 * display_name values:  0 = goto only
 *                       1 = goto and display
 *                       2 = display only
 */
void gotoroom(gname,display_name)
char *gname;
int display_name; {
	char buf[256];
	char pic[256];
	static long ls = 0L;

	if (display_name != 2) {
		/* store ungoto information */
		strcpy(ugname,room_name);
		uglsn = ls;
		}

	/* move to the new room */
	sprintf(buf,"GOTO %s",gname);
	serv_puts(buf);
	serv_gets(buf);
	if (buf[0]!='2') {
		serv_puts("GOTO _BASEROOM_");
		serv_gets(buf);
		}
	if (buf[0]!='2') {
		printf("<EM>%s</EM><BR>\n",&buf[4]);
		return;
		}

	extract(room_name,&buf[4],0);
	room_flags = extract_int(&buf[4],4);

	remove_march(room_name);
	if (!strucmp(gname,"_BASEROOM_")) remove_march(gname);

	/* Display the room banner */

	if (display_name) {
		printf("<CENTER><TABLE><TR>");

		if ( (strlen(ugname)>0) && (strucmp(ugname,room_name)) ) {
			printf("<TD><A HREF=\"session?%s&oper=ungoto\">", S);
			printf("<IMG SRC=\"%s/back.gif\" border=0></A></TD>", STATIC_URL);
			}

		printf("<TD><TABLE border><TR>");
		printf("<TD><H1>%s</H1>",room_name);
		printf("%d new of %d messages</TD>\n",
			extract_int(&buf[4],1),
			extract_int(&buf[4],2));

		if (!fetch_image(pic, "_roompic_")) {
			printf("<TD><IMG SRC=\"%s\"></TD>", pic);
			}

		printf("<TD>");
		readinfo(0);
		printf("</TD>");
		printf("</TR></TABLE></TD>\n");

		printf("<TD><A HREF=\"session?%s&oper=gotonext\">", S);
		printf("<IMG SRC=\"%s/forward.gif\" border=0></A></TD>", STATIC_URL);

		printf("</TR></TABLE></CENTER>\n");

		}
	/* highest_msg_read = extract_int(&buf[4],6);
	maxmsgnum = extract_int(&buf[4],5);
	is_mail = (char) extract_int(&buf[4],7); */
	is_room_aide = (char) extract_int(&buf[4],8);
	ls = extract_long(&buf[4],6);

	setup_reconnect(P,curr_host,curr_port,user_name,curr_pass,room_name);
	}


/*
 * operation to goto a room
 */
void dotgoto() {
	gotoroom(bstr("room"),1);
	}


/* Goto next room having unread messages.
 * We want to skip over rooms that the user has already been to, and take the
 * user back to the lobby when done.  The room we end up in is placed in
 * newroom - which is set to 0 (the lobby) initially.
 * We start the search in the current room rather than the beginning to prevent
 * two or more concurrent users from dragging each other back to the same room.
 */
gotonext() {
	int a,newroom;
	FILE *fp;
	char buf[256];
	struct march *mptr,*mptr2;
	char next_room[64];

	/* First check to see if the march-mode list is already allocated.
	 * If it is, pop the first room off the list and go there.
	 */

	if (march==NULL) {
		serv_puts("LKRN");
		serv_gets(buf);
		if (buf[0]=='1')
		    while (serv_gets(buf), strcmp(buf,"000")) {
			mptr = (struct march *) malloc(sizeof(struct march));
			mptr->next = NULL;
			extract(mptr->march_name,buf,0);
			if (march==NULL) {
				march = mptr;
				}
			else {
				mptr2 = march;
				while (mptr2->next != NULL)
					mptr2 = mptr2->next;
				mptr2->next = mptr;
				}
			}

/* add _BASEROOM_ to the end of the march list, so the user will end up
 * in the system base room (usually the Lobby>) at the end of the loop
 */
		mptr = (struct march *) malloc(sizeof(struct march));
		mptr->next = NULL;
		strcpy(mptr->march_name,"_BASEROOM_");
		if (march==NULL) {
			march = mptr;
			}
		else {
			mptr2 = march;
			while (mptr2->next != NULL)
				mptr2 = mptr2->next;
			mptr2->next = mptr;
			}
/*
 * ...and remove the room we're currently in, so a <G>oto doesn't make us
 * walk around in circles
 */
		remove_march(room_name);
		}


	if (march!=NULL) {
		strcpy(next_room,march->march_name);
		}
	else {
		strcpy(next_room,"_BASEROOM_");
		}
	gotoroom(next_room,1);
   }



/*
 * mark all messages in current room as having been read
 */
void slrp_highest() {
	char buf[256];

	/* set pointer */
	serv_puts("SLRP HIGHEST");
	serv_gets(buf);
	if (buf[0]!='2') {
		printf("<EM>%s</EM><BR>\n",&buf[4]);
		return;
		}
	}


/*
 * un-goto the previous room
 */
void ungoto() { 
	char buf[256];
	
	if (!strcmp(ugname,"")) return;
	sprintf(buf,"GOTO %s",ugname);
	serv_puts(buf);
	serv_gets(buf);
	if (buf[0]!='2') {
		printf("%s\n",&buf[4]);
		return;
		}
	sprintf(buf,"SLRP %ld",uglsn);
	serv_puts(buf);
	serv_gets(buf);
	if (buf[0]!='2') printf("%s\n",&buf[4]);
	strcpy(buf,ugname);
	strcpy(ugname,"");
	gotoroom(buf,1);
	}

/*
 * display the form for editing a room
 */
int display_editroom() {
	char buf[256];
	char er_name[20];
	char er_password[10];
	char er_dirname[15];
	char er_roomaide[26];
	unsigned er_flags;

	serv_puts("GETR");
	serv_gets(buf);

	if (buf[0]!='2') {
		printf("<EM>%s</EM><BR>\n",&buf[4]);
		return(0);
		}

	extract(er_name,&buf[4],0);
	extract(er_password,&buf[4],1);
	extract(er_dirname,&buf[4],2);
	er_flags=extract_int(&buf[4],3);


        printf("<TABLE WIDTH=100% BORDER=0 BGCOLOR=000077><TR><TD>");
        printf("<FONT SIZE=+1 COLOR=\"FFFFFF\"");
        printf("<B>Edit this room</B>\n");
        printf("</FONT></TD></TR></TABLE>\n");

	printf("<FORM METHOD=\"POST\" ACTION=\"session\">\n");
	output_form_reconnect();

	printf("<INPUT TYPE=\"hidden\" NAME=\"oper\" VALUE=\"editroom\">\n");

	printf("<UL><LI>Name of room: ");	
	printf("<INPUT TYPE=\"text\" NAME=\"er_name\" VALUE=\"%s\" MAXLENGTH=\"19\">\n",er_name);

	printf("<LI>Type of room:<UL>\n");

	printf("<LI><INPUT TYPE=\"radio\" NAME=\"type\" VALUE=\"public\" ");
	if ((er_flags & QR_PRIVATE) == 0) printf("CHECKED ");
	printf("> Public room\n");

	printf("<LI><INPUT TYPE=\"radio\" NAME=\"type\" VALUE=\"guessname\" ");
	if ((er_flags & QR_PRIVATE)&&
	   (er_flags & QR_GUESSNAME)) printf("CHECKED ");
	printf("> Private - guess name\n");

	printf("<LI><INPUT TYPE=\"radio\" NAME=\"type\" VALUE=\"passworded\" ");
	if ((er_flags & QR_PRIVATE)&&
	   (er_flags & QR_PASSWORDED)) printf("CHECKED ");
	printf("> Private - require password:\n");
	printf("<INPUT TYPE=\"text\" NAME=\"er_password\" VALUE=\"%s\" MAXLENGTH=\"9\">\n",er_password);

	printf("<LI><INPUT TYPE=\"radio\" NAME=\"type\" VALUE=\"invonly\" ");
	if ( (er_flags & QR_PRIVATE)
	   && ((er_flags & QR_GUESSNAME) == 0)
	   && ((er_flags & QR_PASSWORDED) == 0) )
		printf("CHECKED ");
	printf("> Private - invitation only\n");

	printf("<LI><INPUT TYPE=\"checkbox\" NAME=\"bump\" VALUE=\"yes\" ");
	printf("> If private, cause current users to forget room\n");

	printf("</UL>\n");

	printf("<LI><INPUT TYPE=\"checkbox\" NAME=\"prefonly\" VALUE=\"yes\" ");
	if (er_flags & QR_PREFONLY) printf("CHECKED ");
	printf("> Preferred users only\n");

	printf("<LI><INPUT TYPE=\"checkbox\" NAME=\"readonly\" VALUE=\"yes\" ");
	if (er_flags & QR_READONLY) printf("CHECKED ");
	printf("> Read-only room\n");

/* directory stuff */
	printf("<LI><INPUT TYPE=\"checkbox\" NAME=\"directory\" VALUE=\"yes\" ");
	if (er_flags & QR_DIRECTORY) printf("CHECKED ");
	printf("> File directory room\n");

	printf("<UL><LI>Directory name: ");
	printf("<INPUT TYPE=\"text\" NAME=\"er_dirname\" VALUE=\"%s\" MAXLENGTH=\"14\">\n",er_dirname);

	printf("<LI><INPUT TYPE=\"checkbox\" NAME=\"ulallowed\" VALUE=\"yes\" ");
	if (er_flags & QR_UPLOAD) printf("CHECKED ");
	printf("> Uploading allowed\n");

	printf("<LI><INPUT TYPE=\"checkbox\" NAME=\"dlallowed\" VALUE=\"yes\" ");
	if (er_flags & QR_DOWNLOAD) printf("CHECKED ");
	printf("> Downloading allowed\n");

	printf("<LI><INPUT TYPE=\"checkbox\" NAME=\"visdir\" VALUE=\"yes\" ");
	if (er_flags & QR_VISDIR) printf("CHECKED ");
	printf("> Visible directory</UL>\n");

/* end of directory stuff */
	
	printf("<LI><INPUT TYPE=\"checkbox\" NAME=\"network\" VALUE=\"yes\" ");
	if (er_flags & QR_NETWORK) printf("CHECKED ");
	printf("> Network shared room\n");

/* start of anon options */

	printf("<LI>Anonymous messages<UL>\n");
	
	printf("<LI><INPUT TYPE=\"radio\" NAME=\"anon\" VALUE=\"no\" ");
	if ( ((er_flags & QR_ANONONLY)==0)
	   && ((er_flags & QR_ANON2)==0)) printf("CHECKED ");
	printf("> No anonymous messages\n");

	printf("<LI><INPUT TYPE=\"radio\" NAME=\"anon\" VALUE=\"anononly\" ");
	if (er_flags & QR_ANONONLY) printf("CHECKED ");
	printf("> All messages are anonymous\n");

	printf("<LI><INPUT TYPE=\"radio\" NAME=\"anon\" VALUE=\"anon2\" ");
	if (er_flags & QR_ANON2) printf("CHECKED ");
	printf("> Prompt user when entering messages</UL>\n");

/* end of anon options */

	printf("<LI>Room aide: \n");
	serv_puts("GETA");
	serv_gets(buf);
	if (buf[0]!='2') {
		printf("<EM>%s</EM>\n",&buf[4]);
		}
	else {
		extract(er_roomaide,&buf[4],0);
		printf("<INPUT TYPE=\"text\" NAME=\"er_roomaide\" VALUE=\"%s\" MAXLENGTH=\"25\">\n",er_roomaide);
		}
		
	printf("</UL><CENTER>\n");
	printf("<INPUT TYPE=\"submit\" NAME=\"sc\" VALUE=\"OK\">");
	printf("<INPUT TYPE=\"submit\" NAME=\"sc\" VALUE=\"Cancel\">");
	printf("</CENTER>\n");

	printf("</FORM>\n");
	return(1);
	}


/*
 * save new parameters for a room
 */
int editroom() {
	char buf[256];
	char er_name[20];
	char er_password[10];
	char er_dirname[15];
	char er_roomaide[26];
	unsigned er_flags;
	int bump;


	if (strcmp(bstr("sc"),"OK")) {
		printf("<EM>Changes have <STRONG>not</STRONG> been saved.</EM><BR>");
		return(0);
		}
	
	serv_puts("GETR");
	serv_gets(buf);

	if (buf[0]!='2') {
		printf("<EM>%s</EM><BR>\n",&buf[4]);
		return(0);
		}

	extract(er_name,&buf[4],0);
	extract(er_password,&buf[4],1);
	extract(er_dirname,&buf[4],2);
	er_flags=extract_int(&buf[4],3);

	strcpy(er_roomaide,bstr("er_roomaide"));
	if (strlen(er_roomaide)==0) {
		serv_puts("GETA");
		serv_gets(buf);
		if (buf[0]!='2') {
			strcpy(er_roomaide,"");
			}
		else {
			extract(er_roomaide,&buf[4],0);
			}
		}

	strcpy(buf,bstr("er_name"));		buf[20] = 0;
	if (strlen(buf)>0) strcpy(er_name,buf);

	strcpy(buf,bstr("er_password"));	buf[10] = 0;
	if (strlen(buf)>0) strcpy(er_password,buf);

	strcpy(buf,bstr("er_dirname"));		buf[15] = 0;
	if (strlen(buf)>0) strcpy(er_dirname,buf);

	strcpy(buf,bstr("type"));
	er_flags &= !(QR_PRIVATE|QR_PASSWORDED|QR_GUESSNAME);

	if (!strcmp(buf,"invonly")) {
		er_flags |= (QR_PRIVATE);
		}
	if (!strcmp(buf,"guessname")) {
		er_flags |= (QR_PRIVATE | QR_GUESSNAME);
		}
	if (!strcmp(buf,"passworded")) {
		er_flags |= (QR_PRIVATE | QR_PASSWORDED);
		}

	if (!strcmp(bstr("prefonly"),"yes")) {
		er_flags |= QR_PREFONLY;
		}
	else {
		er_flags &= ~QR_PREFONLY;
		}

	if (!strcmp(bstr("readonly"),"yes")) {
		er_flags |= QR_READONLY;
		}
	else {
		er_flags &= ~QR_READONLY;
		}

	if (!strcmp(bstr("network"),"yes")) {
		er_flags |= QR_NETWORK;
		}
	else {
		er_flags &= ~QR_NETWORK;
		}

	if (!strcmp(bstr("directory"),"yes")) {
		er_flags |= QR_DIRECTORY;
		}
	else {
		er_flags &= ~QR_DIRECTORY;
		}

	if (!strcmp(bstr("ulallowed"),"yes")) {
		er_flags |= QR_UPLOAD;
		}
	else {
		er_flags &= ~QR_UPLOAD;
		}

	if (!strcmp(bstr("dlallowed"),"yes")) {
		er_flags |= QR_DOWNLOAD;
		}
	else {
		er_flags &= ~QR_DOWNLOAD;
		}

	if (!strcmp(bstr("visdir"),"yes")) {
		er_flags |= QR_VISDIR;
		}
	else {
		er_flags &= ~QR_VISDIR;
		}

	strcpy(buf,bstr("anon"));

	er_flags &= ~(QR_ANONONLY | QR_ANON2);
	if (!strcmp(buf,"anononly")) er_flags |= QR_ANONONLY;
	if (!strcmp(buf,"anon2")) er_flags |= QR_ANON2;

	bump = 0;
	if (!strcmp(bstr("bump"),"yes")) bump = 1;

	sprintf(buf,"SETR %s|%s|%s|%u|%d",
		er_name,er_password,er_dirname,er_flags,bump);
	serv_puts(buf);
	serv_gets(buf);
	if (buf[0]!='2') {
		printf("<EM>%s</EM><HR>\n",&buf[4]);
		return(display_editroom());
		}
	gotoroom(er_name,0);

	if (strlen(er_roomaide)>0) {
		sprintf(buf,"SETA %s",er_roomaide);
		serv_puts(buf);
		serv_gets(buf);
		if (buf[0]!='2') {
			printf("<EM>%s</EM><HR>\n",&buf[4]);
			return(display_editroom());
			}
		}

	printf("<EM>Changes have been saved.</EM><BR>");
	return(0);
	}



/*
 * display the form for entering a new room
 */
int display_entroom() {
	char buf[256];

	serv_puts("CRE8 0");
	serv_gets(buf);
	
	if (buf[0]!='2') {
		printf("<EM>%s</EM><HR>\n",&buf[4]);
		return(0);
		}

        printf("<TABLE WIDTH=100% BORDER=0 BGCOLOR=000077><TR><TD>");
        printf("<FONT SIZE=+1 COLOR=\"FFFFFF\"");
        printf("<B>Enter (create) a new room</B>\n");
        printf("</FONT></TD></TR></TABLE>\n");

	printf("<FORM METHOD=\"POST\" ACTION=\"session\">\n");
	output_form_reconnect();

	printf("<INPUT TYPE=\"hidden\" NAME=\"oper\" VALUE=\"entroom\">\n");

	printf("<UL><LI>Name of room: ");	
	printf("<INPUT TYPE=\"text\" NAME=\"er_name\" MAXLENGTH=\"19\">\n");

	printf("<LI>Type of room:<UL>\n");

	printf("<LI><INPUT TYPE=\"radio\" NAME=\"type\" VALUE=\"public\" ");
	printf("CHECKED > Public room\n");

	printf("<LI><INPUT TYPE=\"radio\" NAME=\"type\" VALUE=\"guessname\" ");
	printf("> Private - guess name\n");

	printf("<LI><INPUT TYPE=\"radio\" NAME=\"type\" VALUE=\"passworded\" ");
	printf("> Private - require password:\n");
	printf("<INPUT TYPE=\"text\" NAME=\"er_password\" MAXLENGTH=\"9\">\n");

	printf("<LI><INPUT TYPE=\"radio\" NAME=\"type\" VALUE=\"invonly\" ");
	printf("> Private - invitation only\n");

	printf("<CENTER>\n");
	printf("<INPUT TYPE=\"submit\" NAME=\"sc\" VALUE=\"OK\">");
	printf("<INPUT TYPE=\"submit\" NAME=\"sc\" VALUE=\"Cancel\">");
	printf("</CENTER>\n");
	printf("</FORM>\n");
	return(1);
	}



/*
 * enter a new room
 */
int entroom() {
	char buf[256];
	char er_name[20];
	char er_type[20];
	char er_password[10];
	int er_num_type;

	if (strcmp(bstr("sc"),"OK")) {
		printf("<EM>Changes have <STRONG>not</STRONG> been saved.</EM><BR>");
		return(0);
		}
	
	strcpy(er_name,bstr("er_name"));
	strcpy(er_type,bstr("type"));
	strcpy(er_password,bstr("er_password"));

	er_num_type = 0;
	if (!strcmp(er_type,"guessname")) er_num_type = 1;
	if (!strcmp(er_type,"passworded")) er_num_type = 2;
	if (!strcmp(er_type,"invonly")) er_num_type = 3;

	sprintf(buf,"CRE8 1|%s|%d|%s",er_name,er_num_type,er_password);
	serv_puts(buf);
	serv_gets(buf);
	if (buf[0]!='2') {
		printf("<EM>%s</EM><HR>\n",&buf[4]);
		return(display_editroom());
		}
	gotoroom(er_name,0);
	return(2);
	}


/*
 * display the screen to enter a private room
 */
void display_private(rname,req_pass)
char *rname;
int req_pass; {


        printf("<TABLE WIDTH=100% BORDER=0 BGCOLOR=770000><TR><TD>");
        printf("<FONT SIZE=+1 COLOR=\"FFFFFF\"");
        printf("<B>Enter a private room</B>\n");
        printf("</FONT></TD></TR></TABLE>\n");

	printf("<CENTER>\n");
	printf("If you know the name of a hidden (guess-name) or\n");
	printf("passworded room, you can enter that room by typing\n");
	printf("its name below.  Once you gain access to a private\n");
	printf("room, it will appear in your regular room listings\n");
	printf("so you don't have to keep returning here.\n");
	printf("<BR><BR>");
	
	printf("<FORM METHOD=\"POST\" ACTION=\"session\">\n");
	output_form_reconnect();

	printf("<INPUT TYPE=\"hidden\" NAME=\"oper\" VALUE=\"goto_private\">\n");

	printf("<TABLE border><TR><TD>");
	printf("Enter room name:</TD><TD>");
	printf("<INPUT TYPE=\"text\" NAME=\"gr_name\" VALUE=\"%s\" MAXLENGTH=\"19\">\n",rname);

	if (req_pass) {
		printf("</TD></TR><TR><TD>");
		printf("Enter room password:</TD><TD>");
		printf("<INPUT TYPE=\"password\" NAME=\"gr_pass\" MAXLENGTH=\"9\">\n");
		}

	printf("</TD></TR></TABLE>\n");
	
	printf("<INPUT TYPE=\"submit\" NAME=\"sc\" VALUE=\"OK\">");
	printf("<INPUT TYPE=\"submit\" NAME=\"sc\" VALUE=\"Cancel\">");
	printf("</FORM>");
	}

/* 
 * goto a private room
 */
int goto_private() {
	char hold_rm[32];
	char buf[256];
	
	if (strcmp(bstr("sc"),"OK")) {
		return(2);
		}

	strcpy(hold_rm,room_name);
	strcpy(buf,"GOTO ");
	strcat(buf,bstr("gr_name"));
	strcat(buf,"|");
	strcat(buf,bstr("gr_pass"));
	serv_puts(buf);
	serv_gets(buf);

	if (buf[0]=='2') {
		gotoroom(bstr("gr_name"),1);
		return(0);
		}

	if (!strncmp(buf,"540",3)) {
		display_private(bstr("gr_name"),1);
		return(1);
		}

	printf("<EM>%s</EM>\n",&buf[4]);
	return(2);
	}


/*
 * display the screen to zap a room
 */
void display_zap() {
	char zaproom[32];
	
	strcpy(zaproom, bstr("room"));
	
        printf("<TABLE WIDTH=100% BORDER=0 BGCOLOR=770000><TR><TD>");
        printf("<FONT SIZE=+1 COLOR=\"FFFFFF\"");
        printf("<B>Zap (forget) the current room</B>\n");
        printf("</FONT></TD></TR></TABLE>\n");

	printf("If you select this option, <em>%s</em> will ", zaproom);
	printf("disappear from your room list.  Is this what you wish ");
	printf("to do?<BR>\n");

	printf("<FORM METHOD=\"POST\" ACTION=\"session\">\n");
	output_form_reconnect();
	printf("<INPUT TYPE=\"hidden\" NAME=\"oper\" VALUE=\"zap\">\n");
	printf("<INPUT TYPE=\"submit\" NAME=\"sc\" VALUE=\"OK\">");
	printf("<INPUT TYPE=\"submit\" NAME=\"sc\" VALUE=\"Cancel\">");
	printf("</FORM>");
	}


/* 
 * zap a room
 */
int zap() {
	char zaproom[32];
	char buf[256];

	if (strcmp(bstr("sc"),"OK")) {
		return(2);
		}

	strcpy(zaproom, bstr("room"));
	sprintf(buf, "GOTO %s", zaproom);
	serv_puts(buf);
	serv_gets(buf);
	if (buf[0] != '2') {
		printf("<EM>%s</EM>\n",&buf[4]);
		return(2);
		}

	serv_puts("FORG");
	serv_gets(buf);
	if (buf[0] != '2') {
		printf("<EM>%s</EM>\n",&buf[4]);
		return(2);
		}

	gotoroom(bstr("_BASEROOM_"),1);
	return(0);
	}



/*
 * Confirm deletion of the current room
 */
int confirm_delete_room() {
	char buf[256];
	
	serv_puts("KILL 0");
	serv_gets(buf);
	if (buf[0] != '2') {
		printf("<EM>%s</EM>\n",&buf[4]);
		return(2);
		}


	printf("<TABLE WIDTH=100% BORDER=0 BGCOLOR=770000><TR><TD>");
	printf("<FONT SIZE=+1 COLOR=\"FFFFFF\"");
	printf("<B>Confirm deletion of room</B>\n");
	printf("</FONT></TD></TR></TABLE>\n");

	printf("<CENTER>");
	printf("<FORM METHOD=\"POST\" ACTION=\"session\">\n");
	output_form_reconnect();

	printf("<INPUT TYPE=\"hidden\" NAME=\"oper\" VALUE=\"delete_room\">\n");

	printf("Are you sure you want to delete <FONT SIZE=+1>");
	escputs(room_name);
	printf("</FONT>?<BR>\n");

	printf("<INPUT TYPE=\"submit\" NAME=\"sc\" VALUE=\"Delete\">");
	printf("<INPUT TYPE=\"submit\" NAME=\"sc\" VALUE=\"Cancel\">");

	printf("</FORM></CENTER>\n");

	return(1);
	}


/*
 * Delete the current room
 */
int delete_room() {
	char buf[256];
	char sc[256];

	strcpy(sc, bstr("sc"));
	
	if (strcmp(sc, "Delete")) {
		return(2);
		}

	serv_puts("KILL 1");
	serv_gets(buf);
	printf("<EM>%s</EM>\n",&buf[4]);
	if (buf[4] == '2') {
		strcpy(room_name, "_BASEROOM_");
		}
	return(2);
	}
