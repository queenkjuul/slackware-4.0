The program in this directory comprises a Java-based chat client to be used
with the WebCit client for Citadel/UX.  Most of the code was lifted from an
all-Java client I'm currently writing, but since we expect this one to work
from the most popular browsers, everything has been tweaked in such a way as
to make it run happily in a JDK 1.0.2 environment.
 
 Since not everyone has a Java compiler on hand, I've supplied the binaries
as a courtesy.  Since Java bytecode is universal, there should be no need to
recompile.
