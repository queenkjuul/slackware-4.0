                       WebCit for Citadel/UX documentation
                       -----------------------------------
 
 This is the WebCit user interface for Citadel/UX.  It allows users to connect
to Citadel/UX based BBS's using their favourite Web browser.  The design goal
is for WebCit to do for web-based BBSing what Citadel in general did for text
based BBSing: keep the user interface simple, clean, and consistent, while
emphasizing the message content as the important part.  To this end, the
system has been streamlined as much as possible (unlike the 1.0x releases,
people seem to -like- the new versions of WebCit).

 Here's how it works: WebCit is a middleware program that acts like a cgi-bin
to the browser/webserver, while simultaneously acting as a client to a
Citadel/UX server somewhere.  WebCit and Citadel/UX do _not_ necessarily have
to be running on the same computer.  This makes it advantageous, if your
Citadel/UX server has a low-bandwidth Internet connection, to place WebCit
on a host that has a high-bandwidth connection.  This not only keeps the
excessive HTTP traffic off your system, but also takes the web service load
off it as well.  HOWEVER, in order for real time multiuser chat to work, you
must have WebCit on the same host as the Citadel server.  This is because the
chat program is implemented as a Java applet, and due to Java's security model
will only be able to connect to the applet host.
 
 All of the real work is done in the "webcit" program.  There will be one
copy of webcit running for each session that is currently active.  There is
also a program called "session" which is a little 'glue' program that connects
http transactions to the correct copy of webcit each time the user performs
any operation.  This is a bit kludgey, but can be blamed on the rather stupid
design of Web technology.
 
                    ----------------------------------
 
 Expect more functionality in the future, of course.  WebCit will
continue to be maintained as a clean, simple way for casual Web users to access
Citadel/UX BBS's.  The addition of administrative (Aide) commands to WebCit is
not planned; instead, a Java-based client is being developed for more 'serious'
use of the system.  In any case, please send any comments or suggestions to:
 
  Art Cancro  <ajc@uncnsrd.mt-kisco.ny.us>
 
 ...and please do visit UNCENSORED! BBS often.
