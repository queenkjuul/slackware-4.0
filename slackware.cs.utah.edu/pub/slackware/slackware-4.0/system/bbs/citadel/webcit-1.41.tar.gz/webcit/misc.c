#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <signal.h>
#include <sys/types.h>
#include <time.h>
#include "ipcdef.h"

#define strucmp(lstr,rstr) struncmp(lstr,rstr,32767)

extern struct serv_info serv_info;
extern long P;
extern char S[];
extern char user_name[];
extern char room_name[];
extern char curr_pass[];
extern char curr_host[];
extern char curr_port[];
extern char axlevel;
extern int timescalled;
extern int posted;
extern unsigned userflags;
extern long eternal;
extern char *bstr();

struct namelist {
	struct namelist *next;
	char name[32];
	};

/*
 * display the userlist
 */
userlist() { 
	char buf[256];
	char fl[256];
	struct tm *tmbuf;
	long lc;
	struct namelist *bio = NULL;
	struct namelist *bptr;
	int has_bio;

	serv_puts("LBIO");
	serv_gets(buf);
	if (buf[0]=='1') while (serv_gets(buf), strcmp(buf,"000")) {
		bptr = (struct namelist *) malloc(sizeof(struct namelist));
		bptr->next = bio;
		strcpy(bptr->name, buf);
		bio = bptr;
		}

	serv_puts("LIST");
	serv_gets(buf);
	if (buf[0]!='1') {
		printf("<EM>%s</EM><BR>\n",&buf[4]);
		return;
		}


        printf("<TABLE WIDTH=100% BORDER=0 BGCOLOR=007700><TR><TD>");
        printf("<FONT SIZE=+1 COLOR=\"FFFFFF\"");
        printf("<B>User list for ");
	escputs(serv_info.serv_humannode);
        printf("</B></FONT></TD></TR></TABLE>\n");

	printf("<CENTER><TABLE border>");
	printf("<TR><TH>User Name</TH><TH>Number</TH><TH>Access Level</TH>");
	printf("<TH>Last Call</TH><TH>Total Calls</TH><TH>Total Posts</TH></TR>\n");

	while (serv_gets(buf), strcmp(buf,"000")) {
		extract(fl,buf,0);
		has_bio = 0;
		for (bptr=bio; bptr!=NULL; bptr=bptr->next) {
			if (!strucmp(fl,bptr->name)) has_bio = 1;
			}
		printf("<TR><TD>");
		if (has_bio) {
			printf("<A HREF=\"session?%s&oper=showuser&who=",S);
			urlescputs(fl);
			printf("\">");
			escputs(fl);
			printf("</A>");
			}
		else {
			escputs(fl);
			}
		printf("</TD><TD>%ld</TD><TD>%d</TD><TD>",
			extract_long(buf,2),
			extract_int(buf,1));
		lc = extract_long(buf,3);
		tmbuf = (struct tm *)localtime(&lc);
		printf("%02d/%02d/%04d ",
			(tmbuf->tm_mon+1),
			tmbuf->tm_mday,
			(tmbuf->tm_year + 1900));
		

		printf("</TD><TD>%ld</TD><TD>%5ld</TD></TR>\n",
			extract_long(buf,4),extract_long(buf,5));

		}
	printf("</TABLE></CENTER>\n");
	}


/*
 * Display (non confidential) information about a particular user
 */
void showuser() {
	char who[256];
	char buf[256];
	char pic[256];
	int have_pic;

	strcpy(who,bstr("who"));
	sprintf(buf, "_userpic_|%s", who);
	have_pic = fetch_image(pic, buf);

	printf("<CENTER><TABLE><TR><TD>");
	if (have_pic == 0) {
		printf("<IMG SRC=\"%s\">", pic);
		}
	printf("</TD><TD><H1>%s</H1></TD></TR></TABLE></CENTER>\n",who);
	sprintf(buf,"RBIO %s",who);
	serv_puts(buf);
	serv_gets(buf);
	if (buf[0]=='1') fmout(NULL);
	printf("<HR>\n");
	}
