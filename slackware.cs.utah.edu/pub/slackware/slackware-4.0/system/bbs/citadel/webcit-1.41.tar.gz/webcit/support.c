#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>
#include <stdio.h>
#include "webcit.h"

long atol();
char *bstr();

/* 
 * check for the presence of a character within a string (returns count)
 */
int haschar(st,ch)
char st[];
int ch; {
	int a,b;
	b=0;
	for (a=0; a<strlen(st); ++a) if (st[a]==ch) ++b;
	return(b);
	}



/*
 * num_parms()  -  discover number of parameters...
 */
int num_parms(source)
char source[]; {
	int a;
	int count = 1;

	for (a=0; a<strlen(source); ++a) 
		if (source[a]=='|') ++count;
	return(count);
	}

/*
 * extract()  -  extract a parameter from a series of "?" separated...
 */
void extract(dest,source,parmnum)
char dest[];
char source[];
int parmnum; {
	char buf[256];
	int count = 0;
	int n;

	if (strlen(source)==0) {
		strcpy(dest,"");
		return;
		}

	n = num_parms(source);

	if (parmnum >= n) {
		strcpy(dest,"");
		return;
		}
	strcpy(buf,source);
	if ( (parmnum == 0) && (n == 1) ) {
		strcpy(dest,buf);
		for (n=0; n<strlen(dest); ++n)
			if (dest[n]=='|') dest[n] = 0;
		return;
		}

	while (count++ < parmnum) do {
		strcpy(buf,&buf[1]);
		} while( (strlen(buf)>0) && (buf[0]!='|') );
	if (buf[0]=='|') strcpy(buf,&buf[1]);
	for (count = 0; count<strlen(buf); ++count)
		if (buf[count] == '|') buf[count] = 0;
	strcpy(dest,buf);
	}

/*
 * extract_int()  -  extract an int parm w/o supplying a buffer
 */
int extract_int(source,parmnum)
char *source;
int parmnum; {
	char buf[256];
	
	extract(buf,source,parmnum);
	return(atoi(buf));
	}

/*
 * extract_long()  -  extract an long parm w/o supplying a buffer
 */
long extract_long(source,parmnum)
char *source;
long parmnum; {
	char buf[256];
	
	extract(buf,source,parmnum);
	return(atol(buf));
	}


/*
 * case insensitive string comparison
 */
int struncmp(lstr,rstr,len)
char lstr[],rstr[];
int len; {
	int pos = 0;
	char lc,rc;
	while (pos<len) {
		lc=tolower(lstr[pos]);
		rc=tolower(rstr[pos]);
		if ((lc==0)&&(rc==0)) return(0);
		if (lc<rc) return(-1);
		if (lc>rc) return(1);
		pos=pos+1;
		}
	return(0);
	}



void escputs1(strbuf,nbsp)
char strbuf[];
int nbsp; {
	int a;

	for (a=0; a<strlen(strbuf); ++a) {
		if (strbuf[a]=='<') printf("&lt;");
		if (strbuf[a]=='>') printf("&gt;");
		if (strbuf[a]=='&') printf("&amp;");
		if (strbuf[a]==34) printf("&quot;");
		if (strbuf[a]==LB) printf("<");
		if (strbuf[a]==RB) printf(">");
		if (strbuf[a]==QU) printf("\"");
		if ((strbuf[a]!='<')&&(strbuf[a]!='>')&&(strbuf[a]!='&')
		   &&(strbuf[a]!=34)&&(strbuf[a]!=LB)&&(strbuf[a]!=RB)
		   &&(strbuf[a]!=QU)) {
			if ((strbuf[a]==32)&&(nbsp==1)) {
				printf("&nbsp;");
				}
			else {
				putc(strbuf[a],stdout);
				}
			}
		}
	}

void escputs(strbuf)
char *strbuf; {
	escputs1(strbuf,0);
	}


char *urlesc(strbuf)
char strbuf[]; {
	int a,b,c;
        char *ec = " #&;`'|*?-~<>^()[]{}$\\";
	static char outbuf[512];
	
	strcpy(outbuf,"");

	for (a=0; a<strlen(strbuf); ++a) {
		c = 0;
		for (b=0; b<strlen(ec); ++b) {
			if (strbuf[a]==ec[b]) c=1;
			}
		b = strlen(outbuf);
		if (c==1) sprintf(&outbuf[b],"%%%02x",strbuf[a]);
		else sprintf(&outbuf[b],"%c",strbuf[a]);
		}
	return(outbuf);
	}

void urlescputs(strbuf)
char strbuf[]; {
	printf("%s",urlesc(strbuf));
	}

/*
 * transmit message text (in memory) to the server
 */
void text_to_server(ptr)
char ptr[]; {
	char buf[256];
	int ch,a,pos;

	pos = 0;
	
	strcpy(buf,"");
	while (ptr[pos]!=0) {
		ch = ptr[pos++];
		if (ch==10) {
			while (isspace(buf[strlen(buf)-1]))
				buf[strlen(buf)-1]=0;
			serv_puts(buf);
			strcpy(buf,"");
			}
		else {
			a = strlen(buf);
			buf[a+1] = 0;
			buf[a] = ch;
			if ((ch==32)&&(strlen(buf)>200)) {
				buf[a]=0;
				serv_puts(buf);
				strcpy(buf,"");
				}
			if (strlen(buf)>250) {
				serv_puts(buf);
				strcpy(buf,"");
				}
			}
		}
	serv_puts(buf);
	}

/*
 * translate server message output to text
 * (used for editing room info files and such)
 */
void server_to_text() {
	char buf[256]; 

	int count = 0;

	while (serv_gets(buf), strcmp(buf, "000") ) {
		if ( (buf[0] == 32) && (count > 0) ) {
			printf("\n");
			}
		printf("%s", buf);
		++count;
		}
	}

/*
 * display the form for editing something (room info, bio, etc)
 */
int display_edit(description, check_cmd, read_cmd, save_cmd)
char *description;
char *check_cmd;
char *read_cmd;
char *save_cmd; {
	char buf[256];
	long now;
	struct tm *tm;

	if (!strcmp(bstr("sc"),"Cancel")) {
		printf("Cancelled.  %s was not saved..<BR>\n", description);
		return(0);
		}

	serv_puts(check_cmd);
	serv_gets(buf);

	if (buf[0]!='2') {
		printf("<EM>%s</EM><BR>\n",&buf[4]);
		return(0);
		}


        printf("<TABLE WIDTH=100% BORDER=0 BGCOLOR=007700><TR><TD>");
        printf("<FONT SIZE=+1 COLOR=\"FFFFFF\"");
        printf("<B>Edit ");
	escputs(description);
        printf("</B></FONT></TD></TR></TABLE>\n");

	printf("<CENTER>Enter %s below.  Text is formatted to\n", description);
	printf("the <EM>reader's</EM> screen width.  To defeat the\n");
	printf("formatting, indent a line at least one space.  \n");
	printf("<BR>");

	printf("<FORM METHOD=\"POST\" ACTION=\"session\">\n");
	output_form_reconnect();

	printf("<INPUT TYPE=\"hidden\" NAME=\"oper\" VALUE=\"%s\">\n", save_cmd);

	printf("<INPUT TYPE=\"submit\" NAME=\"sc\" VALUE=\"Save\">");
	printf("<INPUT TYPE=\"submit\" NAME=\"sc\" VALUE=\"Cancel\"><BR>\n");

	printf("<TEXTAREA NAME=\"msgtext\" wrap=soft ROWS=30 COLS=80 WIDTH=80>");
	serv_puts(read_cmd);
	serv_gets(buf);
	if (buf[0] == '1') server_to_text();
	printf("</TEXTAREA><P>\n");

	printf("</FORM></CENTER>\n");

	return(1);
	}


/*
 * save a screen which was displayed with display_edit()
 */
void save_edit(description, enter_cmd)
char *description;
char *enter_cmd; {
	char buf[256];

	if (strcmp(bstr("sc"),"Save")) {
		printf("Cancelled.  %s was not saved.<BR>\n", description);
		return;
		}

	serv_puts(enter_cmd);
	serv_gets(buf);
	if (buf[0]!='4') {
		printf("<EM>%s</EM><BR>\n",&buf[4]);
		return;
		}

	text_to_server(bstr("msgtext"));
	serv_puts("000");

	printf("%s has been saved.<BR>\n", description);
	}	


