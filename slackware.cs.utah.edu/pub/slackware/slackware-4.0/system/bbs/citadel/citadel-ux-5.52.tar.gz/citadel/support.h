/* $Id: support.h,v 1.4 1998/11/22 17:08:57 ajc Exp $ */
void strproc (char *string);
int getstring (FILE *fp, char *string);
int pattern2 (char *search, char *patn);
void mesg_locate (char *targ, char *searchfor, int numdirs, char **dirs);
