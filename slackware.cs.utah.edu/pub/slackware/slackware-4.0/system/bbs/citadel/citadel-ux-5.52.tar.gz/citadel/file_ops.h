/* $Id: file_ops.h,v 1.2 1998/11/04 20:05:04 nbryant Exp $ */
void cmd_delf (char *filename);
void cmd_movf (char *cmdbuf);
void cmd_netf (char *cmdbuf);
void OpenCmdResult (void);
void cmd_open (char *cmdbuf);
void cmd_oimg (char *cmdbuf);
void cmd_uopn (char *cmdbuf);
void cmd_uimg (char *cmdbuf);
void cmd_clos (void);
void abort_upl (struct CitContext *who);
void cmd_ucls (char *cmd);
void cmd_read (char *cmdbuf);
void cmd_writ (char *cmdbuf);
void cmd_netp (char *cmdbuf);
void cmd_ndop (char *cmdbuf);
void cmd_nuop (char *cmdbuf);
