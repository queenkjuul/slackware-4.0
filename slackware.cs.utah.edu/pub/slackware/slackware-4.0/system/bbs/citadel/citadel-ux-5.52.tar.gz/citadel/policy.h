/* $Id: policy.h,v 1.3 1998/11/04 20:05:04 nbryant Exp $ */
void GetExpirePolicy(struct ExpirePolicy *epbuf, struct quickroom *qrbuf);
void cmd_gpex(char *argbuf);
void cmd_spex(char *argbuf);
