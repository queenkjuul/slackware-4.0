/* $Id: serv_chat.h,v 1.4 1998/11/04 20:05:05 nbryant Exp $ */
void ChatUnloadingTest(void);
void allwrite (char *cmdbuf, int flag, char *roomname, char *username);
t_context *find_context (char **unstr);
void do_chat_listing (int allflag);
void cmd_chat (char *argbuf);
void cmd_pexp (char *argbuf); /* arg unused */
char check_express (void);
void cmd_sexp (char *argbuf);
