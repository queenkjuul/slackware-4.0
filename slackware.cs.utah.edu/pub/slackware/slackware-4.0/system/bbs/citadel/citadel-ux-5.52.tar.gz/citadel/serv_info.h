/* $Id: serv_info.h,v 1.2 1998/11/04 20:05:05 nbryant Exp $ */
void CtdlInternalGetServInfo(struct CtdlServInfo *infobuf);
