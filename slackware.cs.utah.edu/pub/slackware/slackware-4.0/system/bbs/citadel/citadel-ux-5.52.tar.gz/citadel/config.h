/* $Id: config.h,v 1.3 1998/11/04 20:05:03 nbryant Exp $ */
void get_config(void);
void put_config(void);
extern struct config config;
extern char bbs_home_directory[PATH_MAX];
extern int home_specified;
