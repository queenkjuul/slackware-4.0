/* $Id: housekeeping.h,v 1.2 1998/11/04 20:05:04 nbryant Exp $ */
void terminate_idle_sessions (void);
void do_housekeeping (void);
void check_ref_counts (void);
