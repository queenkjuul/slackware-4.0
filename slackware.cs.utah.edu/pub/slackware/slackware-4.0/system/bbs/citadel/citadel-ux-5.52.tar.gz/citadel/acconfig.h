/* define this to the bbs home directory */
#undef BBSDIR

/* define this to enable the autologin feature */
#undef ENABLE_AUTOLOGIN
