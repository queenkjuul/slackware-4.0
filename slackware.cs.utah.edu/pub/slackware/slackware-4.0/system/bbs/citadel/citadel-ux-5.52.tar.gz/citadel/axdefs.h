/* $Id: axdefs.h,v 1.2 1998/11/04 20:05:03 nbryant Exp $ */
#ifndef AXDEFS

char *axdefs[]={
	"Deleted",
	"New User",
	"Problem User",
	"Local User",
	"Network User",
	"Preferred User",
	"Aide",
	"Sysop"
	};

#define AXDEFS 1

#else

extern char *axdefs[];

#endif
