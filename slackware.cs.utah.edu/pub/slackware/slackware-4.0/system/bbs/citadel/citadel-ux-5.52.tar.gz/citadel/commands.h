/* $Id: commands.h,v 1.6 1998/11/10 04:52:56 nbryant Exp $ */
void load_command_set(void);
void sttybbs(int cmd);
void newprompt(char *prompt, char *str, int len);
void strprompt(char *prompt, char *str, int len);
int boolprompt(char *prompt, int prev_val);
int intprompt(char *prompt, int ival, int imin, int imax);
int fmout(int width, FILE *fp, char pagin, int height, int starting_lp,
	  char subst);
int getcmd(char *argbuf);
void display_help(char *name);
void color(int colornum);
void cls(int colornum);
void send_ansi_detect(void);
void look_for_ansi(void);
int inkey(void);
void set_keepalives(int s);
extern int enable_color;
int yesno(void);
int yesno_d(int d);
