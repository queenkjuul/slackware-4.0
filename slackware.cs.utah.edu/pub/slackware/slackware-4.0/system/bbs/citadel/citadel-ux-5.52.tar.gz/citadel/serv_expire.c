/*
 * serv_expire.c
 *
 * This module handles the expiry of old messages and the purging of old users.
 *
 */
/* $Id: serv_expire.c,v 1.13 1999/01/15 02:22:10 ajc Exp $ */


/*
 * A brief technical discussion:
 *
 * Several of the purge operations found in this module operate in two
 * stages: the first stage generates a linked list of objects to be deleted,
 * then the second stage deletes all listed objects from the database.
 *
 * At first glance this may seem cumbersome and unnecessary.  The reason it is
 * implemented in this way is because GDBM (and perhaps some other backends we
 * may hook into in the future) explicitly do _not_ support the deletion of
 * records from a file while the file is being traversed.  The delete operation
 * will succeed, but the traversal is not guaranteed to visit every object if
 * this is done.  Therefore we utilize the two-stage purge.
 */


#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <signal.h>
#include <pwd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <string.h>
#include <limits.h>
#include <pthread.h>
#include "citadel.h"
#include "server.h"
#include <syslog.h>
#include <time.h>
#include "sysdep_decls.h"
#include "citserver.h"
#include "support.h"
#include "config.h"
#include "dynloader.h"
#include "room_ops.h"
#include "policy.h"
#include "database.h"
#include "msgbase.h"
#include "user_ops.h"
#include "control.h"
#include "tools.h"


struct oldvisit {
	char v_roomname[ROOMNAMELEN];
	long v_generation;
	long v_lastseen;
	unsigned int v_flags;
	};

struct PurgeList {
	struct PurgeList *next;
	char name[ROOMNAMELEN];	/* use the larger of username or roomname */
	};

struct VPurgeList {
	struct VPurgeList *next;
	long vp_roomnum;
	long vp_roomgen;
	long vp_usernum;
	};

struct ValidRoom {
	struct ValidRoom *next;
	long vr_roomnum;
	long vr_roomgen;
	};

struct ValidUser {
	struct ValidUser *next;
	long vu_usernum;
	};

struct PurgeList *UserPurgeList = NULL;
struct PurgeList *RoomPurgeList = NULL;
struct ValidRoom *ValidRoomList = NULL;
struct ValidUser *ValidUserList = NULL;
int messages_purged;

extern struct CitContext *ContextList;

#define MODULE_NAME 	"Expire old messages, users, rooms"
#define MODULE_AUTHOR	"Art Cancro"
#define MODULE_EMAIL	"ajc@uncnsrd.mt-kisco.ny.us"
#define MAJOR_VERSION	1
#define MINOR_VERSION	0

static struct DLModule_Info info = {
	MODULE_NAME,
	MODULE_AUTHOR,
	MODULE_EMAIL,
	MAJOR_VERSION,
	MINOR_VERSION
	};

void DoPurgeMessages(struct quickroom *qrbuf) {
	struct ExpirePolicy epbuf;
	long delnum;
	time_t xtime, now;
	char msgid[64];
	int a;

	time(&now);
	GetExpirePolicy(&epbuf, qrbuf);
	
	/*
	lprintf(9, "ExpirePolicy for <%s> is <%d> <%d>\n",
		qrbuf->QRname, epbuf.expire_mode, epbuf.expire_value);
	*/

	/* If the room is set to never expire messages ... do nothing */
	if (epbuf.expire_mode == EXPIRE_NEXTLEVEL) return;
	if (epbuf.expire_mode == EXPIRE_MANUAL) return;

	begin_critical_section(S_QUICKROOM);
	get_msglist(qrbuf);
	
	/* Nothing to do if there aren't any messages */
	if (CC->num_msgs == 0) {
		end_critical_section(S_QUICKROOM);
		return;
		}

	/* If the room is set to expire by count, do that */
	if (epbuf.expire_mode == EXPIRE_NUMMSGS) {
		while (CC->num_msgs > epbuf.expire_value) {
			delnum = MessageFromList(0);
			lprintf(5, "Expiring message %ld\n", delnum);
			cdb_delete(CDB_MSGMAIN, &delnum, sizeof(long));
			memcpy(&CC->msglist[0], &CC->msglist[1],
				(sizeof(long)*(CC->num_msgs - 1)));
			CC->num_msgs = CC->num_msgs - 1;
			++messages_purged;
			}
		}

	/* If the room is set to expire by age... */
	if (epbuf.expire_mode == EXPIRE_AGE) {
		for (a=0; a<(CC->num_msgs); ++a) {
			delnum = MessageFromList(a);
			sprintf(msgid, "%ld", delnum);
			xtime = output_message(msgid, MT_DATE, 0);

			if ((xtime > 0L)
			   && (now - xtime > (time_t)(epbuf.expire_value * 86400L))) {
				lprintf(5, "Expiring message %ld\n", delnum);
				cdb_delete(CDB_MSGMAIN, &delnum, sizeof(long));
				SetMessageInList(a, 0L);
				++messages_purged;
				}
			}
		}
	CC->num_msgs = sort_msglist(CC->msglist, CC->num_msgs);
	put_msglist(qrbuf);
	end_critical_section(S_QUICKROOM);
	}

void PurgeMessages(void) {
	lprintf(5, "PurgeMessages() called\n");
	messages_purged = 0;
	ForEachRoom(DoPurgeMessages);
	}


void DoPurgeRooms(struct quickroom *qrbuf) {
	time_t age, purge_secs;
	struct PurgeList *pptr;

	/* Any of these attributes render a room non-purgable */
	if (qrbuf->QRflags & QR_PERMANENT) return;
	if (qrbuf->QRflags & QR_DIRECTORY) return;
	if (qrbuf->QRflags & QR_NETWORK) return;
	if (qrbuf->QRflags & QR_MAILBOX) return;
	if (is_noneditable(qrbuf)) return;

	/* If we don't know the modification date, be safe and don't purge */
	if (qrbuf->QRmtime <= (time_t)0) return;

	/* Otherwise, check the date of last modification */
	age = time(NULL) - (qrbuf->QRmtime);
	purge_secs = (time_t)config.c_roompurge * (time_t)86400;
	if (purge_secs <= (time_t)0) return;
	lprintf(9, "<%s> is <%ld> seconds old\n", qrbuf->QRname, age);

	if (age > purge_secs) {
		
		pptr = (struct PurgeList *) mallok(sizeof(struct PurgeList));
		pptr->next = RoomPurgeList;
		strcpy(pptr->name, qrbuf->QRname);
		RoomPurgeList = pptr;

		}
	}


int PurgeRooms(void) {
	struct PurgeList *pptr;
	int num_rooms_purged = 0;
	struct quickroom qrbuf;

	lprintf(5, "PurgeRooms() called\n");
	if (config.c_roompurge > 0) {
		ForEachRoom(DoPurgeRooms);
		}

	while (RoomPurgeList != NULL) {
		if (getroom(&qrbuf, RoomPurgeList->name) == 0) {
			delete_room(&qrbuf);
			}
		pptr = RoomPurgeList->next;
		phree(RoomPurgeList);
		RoomPurgeList = pptr;
		++num_rooms_purged;
		}

	lprintf(5, "Purged %d rooms.\n", num_rooms_purged);
	return(num_rooms_purged);
	}


void do_user_purge(struct usersupp *us) {
	int purge;
	time_t now;
	time_t purge_time;
	struct PurgeList *pptr;

	/* Set purge time; if the user overrides the system default, use it */
	if (us->USuserpurge > 0) {
		purge_time = ((time_t)us->USuserpurge) * 86400L;
		}
	else {
		purge_time = ((time_t)config.c_userpurge) * 86400L;
		}

	/* The default rule is to not purge. */
	purge = 0;

	/* If the user hasn't called in two months, his/her account
	 * has expired, so purge the record.
	 */
	now = time(NULL);
	if ((now - us->lastcall) > purge_time) purge = 1;

	/* If the user set his/her password to 'deleteme', he/she
	 * wishes to be deleted, so purge the record.
	 */
	if (!strcasecmp(us->password, "deleteme")) purge = 1;

	/* If the record is marked as permanent, don't purge it.
	 */
	if (us->flags & US_PERM) purge = 0;

	/* If the access level is 0, the record should already have been
	 * deleted, but maybe the user was logged in at the time or something.
	 * Delete the record now.
	 */
	if (us->axlevel == 0) purge = 1;

	/* 0 calls is impossible.  If there are 0 calls, it must
	 * be a corrupted record, so purge it.
	 */
	if (us->timescalled == 0) purge = 1;

	if (purge == 1) {
		pptr = (struct PurgeList *) mallok(sizeof(struct PurgeList));
		pptr->next = UserPurgeList;
		strcpy(pptr->name, us->fullname);
		UserPurgeList = pptr;
		}

	}



int PurgeUsers(void) {
	struct PurgeList *pptr;
	int num_users_purged = 0;

	lprintf(5, "PurgeUsers() called\n");
	if (config.c_userpurge > 0) {
		ForEachUser(do_user_purge);
		}

	while (UserPurgeList != NULL) {
		purge_user(UserPurgeList->name);
		pptr = UserPurgeList->next;
		phree(UserPurgeList);
		UserPurgeList = pptr;
		++num_users_purged;
		}

	lprintf(5, "Purged %d users.\n", num_users_purged);
	return(num_users_purged);
	}

void AddValidUser(struct usersupp *usbuf) {
	struct ValidUser *vuptr;

	vuptr = (struct ValidUser *)mallok(sizeof(struct ValidUser));
	vuptr->next = ValidUserList;
	vuptr->vu_usernum = usbuf->usernum;
	ValidUserList = vuptr;
	}

void AddValidRoom(struct quickroom *qrbuf) {
	struct ValidRoom *vrptr;

	vrptr = (struct ValidRoom *)mallok(sizeof(struct ValidRoom));
	vrptr->next = ValidRoomList;
	vrptr->vr_roomnum = qrbuf->QRnumber;
	vrptr->vr_roomgen = qrbuf->QRgen;
	ValidRoomList = vrptr;
	}


/*
 * Purge visits
 *
 * This is a really cumbersome "garbage collection" function.  We have to
 * delete visits which refer to rooms and/or users which no longer exist.  In
 * order to prevent endless traversals of the room and user files, we first
 * build linked lists of rooms and users which _do_ exist on the system, then
 * traverse the visit file, checking each record against those two lists and
 * purging the ones that do not have a match on _both_ lists.  (Remember, if
 * either the room or user being referred to is no longer on the system, the
 * record is completely useless.)
 */
int PurgeVisits(void) {
	struct cdbdata *cdbvisit;
	struct visit vbuf;
	struct VPurgeList *VisitPurgeList = NULL;
	struct VPurgeList *vptr;
	int purged = 0;
	char IndexBuf[32];
	int IndexLen;
	struct ValidRoom *vrptr;
	struct ValidUser *vuptr;
	int RoomIsValid, UserIsValid;

	/* First, load up a table full of valid room/gen combinations */
	ForEachRoom(AddValidRoom);

	/* Then load up a table full of valid user numbers */
	ForEachUser(AddValidUser);

	/* Now traverse through the visits, purging irrelevant records... */
	cdb_rewind(CDB_VISIT);
	while(cdbvisit = cdb_next_item(CDB_VISIT), cdbvisit != NULL) {
		memset(&vbuf, 0, sizeof(struct visit));
		memcpy(&vbuf, cdbvisit->ptr,
			( (cdbvisit->len > sizeof(struct visit)) ?
			sizeof(struct visit) : cdbvisit->len) );
		cdb_free(cdbvisit);

		RoomIsValid = 0;
		UserIsValid = 0;

		/* Check to see if the room exists */
		for (vrptr=ValidRoomList; vrptr!=NULL; vrptr=vrptr->next) {
			if ( (vrptr->vr_roomnum==vbuf.v_roomnum)
			     && (vrptr->vr_roomgen==vbuf.v_roomgen))
				RoomIsValid = 1;
			}

		/* Check to see if the user exists */
		for (vuptr=ValidUserList; vuptr!=NULL; vuptr=vuptr->next) {
			if (vuptr->vu_usernum == vbuf.v_usernum)
				UserIsValid = 1;
			}

		/* Put the record on the purge list if it's dead */
		if ((RoomIsValid==0) || (UserIsValid==0)) {
			vptr = (struct VPurgeList *)
				mallok(sizeof(struct VPurgeList));
			vptr->next = VisitPurgeList;
			vptr->vp_roomnum = vbuf.v_roomnum;
			vptr->vp_roomgen = vbuf.v_roomgen;
			vptr->vp_usernum = vbuf.v_usernum;
			VisitPurgeList = vptr;
			}

		}

	/* Free the valid room/gen combination list */
	while (ValidRoomList != NULL) {
		vrptr = ValidRoomList->next;
		phree(ValidRoomList);
		ValidRoomList = vrptr;
		}

	/* Free the valid user list */
	while (ValidUserList != NULL) {
		vuptr = ValidUserList->next;
		phree(ValidUserList);
		ValidUserList = vuptr;
		}

	/* Now delete every visit on the purged list */
	while (VisitPurgeList != NULL) {
		IndexLen = GenerateRelationshipIndex(IndexBuf,
				VisitPurgeList->vp_roomnum,
				VisitPurgeList->vp_roomgen,
				VisitPurgeList->vp_usernum);
		cdb_delete(CDB_VISIT, IndexBuf, IndexLen);
		vptr = VisitPurgeList->next;
		phree(VisitPurgeList);
		VisitPurgeList = vptr;
		++purged;
		}
	
	return(purged);
	}


void cmd_expi(char *argbuf) {
	char cmd[256];
	int retval;


	if ((!(CC->logged_in))&&(!(CC->internal_pgm))) {
		cprintf("%d Not logged in.\n",ERROR+NOT_LOGGED_IN);
		return;
		}

	if ((!is_room_aide()) && (!(CC->internal_pgm)) ) {
		cprintf("%d Higher access required.\n",
			ERROR+HIGHER_ACCESS_REQUIRED);
		return;
		}

	extract(cmd, argbuf, 0);
	if (!strcasecmp(cmd, "users")) {
		retval = PurgeUsers();
		cprintf("%d Purged %d users.\n", OK, retval);
		return;
		}
	else if (!strcasecmp(cmd, "messages")) {
		PurgeMessages();
		cprintf("%d Expired %d messages.\n", OK, messages_purged);
		return;
		}
	else if (!strcasecmp(cmd, "rooms")) {
		retval = PurgeRooms();
		cprintf("%d Expired %d rooms.\n", OK, retval);
		return;
		}
	else if (!strcasecmp(cmd, "visits")) {
		retval = PurgeVisits();
		cprintf("%d Purged %d visits.\n", OK, retval);
		}
	else if (!strcasecmp(cmd, "defrag")) {
		defrag_databases();
		cprintf("%d Defragmented the databases.\n", OK);
		}
	else {
		cprintf("%d Invalid command.\n", ERROR+ILLEGAL_VALUE);
		return;
		}
	}



struct DLModule_Info *Dynamic_Module_Init(void)
{
   CtdlRegisterProtoHook(cmd_expi, "EXPI", "Expire old system objects");
   return &info;
}
