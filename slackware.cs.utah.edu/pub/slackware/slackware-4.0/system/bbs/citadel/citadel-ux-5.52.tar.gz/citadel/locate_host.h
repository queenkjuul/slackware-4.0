/* $Id: locate_host.h,v 1.2 1998/11/04 20:05:04 nbryant Exp $ */
void locate_host(char *tbuf);
