/* $Id: messages.h,v 1.3 1998/11/04 20:05:04 nbryant Exp $ */
int ka_system(char *shc);
int entmsg(int is_reply, int c);
void readmsgs(int c, int rdir, int q);
void edit_system_message(char *which_message);
extern int lines_printed;
