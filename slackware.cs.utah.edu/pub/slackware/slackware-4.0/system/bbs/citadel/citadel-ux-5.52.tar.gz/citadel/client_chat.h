/* $Id: client_chat.h,v 1.3 1999/01/10 01:38:40 ajc Exp $ */
void chatmode(void);
void page_user(void);
