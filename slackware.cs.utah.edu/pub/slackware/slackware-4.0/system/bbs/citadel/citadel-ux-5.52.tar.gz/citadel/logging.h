/* $Id: logging.h,v 1.2 1998/11/04 20:05:04 nbryant Exp $ */
void rec_log (unsigned int lrtype, char *name);
