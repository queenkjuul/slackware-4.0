/* $Id: snprintf.h,v 1.2 1998/11/04 20:05:05 nbryant Exp $ */
int snprintf (char *buf, size_t max, const char *fmt, ...);
int vsnprintf (char *buf, size_t max, const char *fmt, va_list argp);
