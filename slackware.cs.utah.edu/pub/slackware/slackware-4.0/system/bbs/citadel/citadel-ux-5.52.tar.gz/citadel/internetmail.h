/* $Id: internetmail.h,v 1.2 1998/11/04 20:05:04 nbryant Exp $ */
void LoadInternetConfig(void);
int IsHostLocal(char *WhichHost);
