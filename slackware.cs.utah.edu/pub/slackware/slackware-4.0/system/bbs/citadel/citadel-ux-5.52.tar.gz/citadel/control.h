/* $Id: control.h,v 1.4 1998/11/18 03:38:30 ajc Exp $ */
void get_control (void);
void put_control (void);
long int get_new_message_number (void);
long int get_new_user_number (void);
long int get_new_room_number (void);
void cmd_conf(char *argbuf);
