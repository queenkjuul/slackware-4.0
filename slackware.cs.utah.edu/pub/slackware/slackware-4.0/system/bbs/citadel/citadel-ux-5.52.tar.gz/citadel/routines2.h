/* $Id: routines2.h,v 1.3 1998/11/04 20:05:05 nbryant Exp $ */
void updatels(void);
void updatelsa(void);
void movefile(void);
void deletefile(void);
void netsendfile(void);
void entregis(void);
void subshell(void);
void upload(int c);
void cli_upload(void);
void validate(void);
void read_bio(void);
void cli_image_upload(char *keyname);
int room_prompt(int qrflags);
