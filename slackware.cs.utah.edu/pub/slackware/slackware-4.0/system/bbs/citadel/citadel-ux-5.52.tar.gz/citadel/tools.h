/* $Id: tools.h,v 1.3 1998/11/22 17:08:58 ajc Exp $ */
char *safestrncpy(char *dest, const char *src, size_t n);
int num_parms (char *source);
void extract (char *dest, char *source, int parmnum);
int extract_int (char *source, int parmnum);
long int extract_long (char *source, long int parmnum);
