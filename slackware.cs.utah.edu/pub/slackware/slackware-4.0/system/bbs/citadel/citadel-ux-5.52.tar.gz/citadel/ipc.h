/* $Id: ipc.h,v 1.2 1998/11/04 20:05:04 nbryant Exp $ */
void attach_to_server(int argc, char **argv);
extern char server_is_local;
int getsockfd(void);
char serv_getc(void);
