void print_mail_message(char *usersdir, char *user, int msgno);
