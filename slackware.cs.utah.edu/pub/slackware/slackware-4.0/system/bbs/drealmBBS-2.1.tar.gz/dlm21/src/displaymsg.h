void print_area_message(const char *areasdir, const char *area, int msgno);
