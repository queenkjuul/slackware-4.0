#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "doorutil.h"

void get_question(void);
void get_answer(void);
void send_answers(void);
int send_email_cd(struct email_record *new_letter, char *new_letter_text);

char message[20480];

char question[10240];
char answer[512];

int main(int argc, char *argv[])
{
	FILE *f;
	char fname[128];

	init();
	if (myacct->totlogons != 1)
		exit(0);
	qprintf("Falken New User Questionairre\r\rPlease Answer these questions for our records\r\r");
	message[0] = 0;
	sprintf(fname, "%s/nuq.txt", cfg->data_path);
	if ( (f = fopen(fname, "r")) == 0)
	{
		send_lprintf("NUQ: Couldn't open %s", fname);
		exit(0);
	} else {
		while (1)
		{
			if (fgets(question, 10239, f) == NULL)
				break;
			question[10239] = 0;
			if ((question[0] == '#') || (question[0] == '\n'))
				continue;
			qprintf("%s\r: ", question);
			get_answer();
		}
		fclose(f);
	}
	send_answers();
}

void get_answer(void)
{
	qgets(answer, 511);
	sprintf(message, "%s\rQ: %s\rA: %s\r", message, question, answer);
}

void send_answers(void)
{
	struct email_record email;
	
	memset(&email, 0, sizeof(email));
	email.status = 1;
	strcpy(email.to, cfg->sysop);
	strcpy(email.from, myacct->acctname);
	strcpy(email.subject, "New User Questionairre");
	send_email_cd(&email, message);
}

// This is Car Doctor's code.  He says it works, and i accepted that.
// If it don't work.. yell at him
int send_email_cd(struct email_record *new_letter, char *new_letter_text)
{ 
  FILE *infile, *outfile;
  char string[100], string1[100];
  int file_lock, file_lock_two, loop1, total_records;
  long pos;
  
  for(loop1 = 0; loop1 < strlen(new_letter_text); loop1++)
  { if(new_letter_text[loop1] == '\n')
       new_letter_text[loop1] = '\r';  
  }
  sprintf(string, "%semail.idx", cfg->data_path);
  sprintf(string1, "%semail.dat", cfg->data_path);
  if((infile = f_open(string, "ab", 1, &file_lock)) == NULL)
    return(0);
  else if((outfile = f_open(string1, "ab", 1, &file_lock_two)) == NULL)
  { f_close(infile, file_lock);
    return(0);
  }
  new_letter->location = ftell(infile);
  new_letter->offset = ftell(outfile);
  new_letter->length = strlen(new_letter_text);
  new_letter->timesent = time(NULL);
  fwrite(new_letter, sizeof(struct email_record), 1, infile);
  fprintf(outfile, "%s", new_letter_text);
  f_close(infile, file_lock);
  f_close(outfile, file_lock_two);
  return(1);
}
