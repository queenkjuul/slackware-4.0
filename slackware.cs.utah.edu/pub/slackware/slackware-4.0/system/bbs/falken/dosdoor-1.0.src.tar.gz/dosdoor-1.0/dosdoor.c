#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "doorutil.h"

#define DOORID "dosdoor"

void make_chaintxt(void);
int check_max_doors(void);


void main(int argc, char *argv[])
{ 
  char cmd[81],logentry[50];
  int maxdosdoors;
  
  init();
  if(argc < 2){
    send_bbslog("The door script must be setup in bbscfg");
    exit(0);
  }
  if(argc > 3) {
    send_bbslog("Only TWO parameters may be passed to dosdoor");
    exit(0);
  }
  cmd[0] = '\0';
  strcat(cmd, argv[1]);
  if (argc == 3) 
    maxdosdoors = atoi(argv[2]);
  else
    maxdosdoors = numlines;
  if (num_dosdoors() < maxdosdoors)
  {
    sprintf(logentry, "Starting DOS Door: %s", cmd);
    send_bbslog(logentry);
    sprintf(cmd, "%s %i",cmd, who);
    make_chaintxt();
    setbinarymode(who);
    bbs_start_a_door(cmd);
    settextmode(who);
  } else {
    qprintf("Sorry.  Only %i users can be in DOS doors at one time.\rThere are currently %i users in DOS doors.", maxdosdoors, num_dosdoors());
  }
  exit(0);
}

void make_chaintxt(void)
{
  char timestr[20],lbaudrate[7];
  char gender;
  FILE *fp;
  char filename[40];
  
  sprintf(filename, "temp/chain%i.txt", who);
/******* CREATE CHAIN.TXT *********/
  if (fp = fopen(filename, "w")) {
    fprintf(fp,"%s\r\n",myacct->acctnum);
    fprintf(fp,"%s\r\n",myacct->acctname);
    fprintf(fp,"%s\r\n",myacct->realname);
    fprintf(fp,"\r\n");
    fprintf(fp,"21\r\n");
    if (myacct->sex == 1)
      gender = 'M';
    else 
      gender = 'F';
    fprintf(fp,"%c\r\n",gender);
    fprintf(fp,"    100.00\r\n");
    strftime(timestr, sizeof timestr, "%m/%d/%y", 
  	localtime((time_t *)&myacct->prev_logtime));
    fprintf(fp,"%s\r\n",timestr);                //Last logon
    fprintf(fp,"%i\r\n",myacct->linlen);        //Chars per line
    fprintf(fp,"%i\r\n",myacct->lines_per_page); //Lines per page
    fprintf(fp,"10\r\n");
    fprintf(fp,"0\r\n");                      // co-Sysop?
    fprintf(fp,"0\r\n");                      // Sysop?
    fprintf(fp,"%i\r\n",myuser->u_ansi);      // ANSI Enabled?
    fprintf(fp,"1\r\n");                      
    fprintf(fp,"    14400.00\r\n");                  // Time left online
    fprintf(fp,"C:\\BBS\\\r\n");
    fprintf(fp,"C:\\BBS\\\r\n");
    fprintf(fp,"C:\\BBS\\LOGFILE.LOG\r\n");
    if (myuser->baudrate == 0)
      strcpy(lbaudrate, "57600");
    else
      sprintf(lbaudrate, "%i", myuser->baudrate);
    fprintf(fp,"%s\r\n",lbaudrate);
    fprintf(fp,"2\r\n");
    fprintf(fp,"Unknown\r\n");               //BBS Name
    fprintf(fp,"%s\r\n",cfg->sysop);                 //Sysop Name
    fprintf(fp,"0\r\n");
    fprintf(fp,"0\r\n");
    fprintf(fp,"0\r\n");
    fprintf(fp,"0\r\n");
    fprintf(fp,"0\r\n");
    fprintf(fp,"0\r\n");
    fprintf(fp,"N81\r\n");
    fprintf(fp,"%s\r\n",lbaudrate);
    fprintf(fp,"0\r\n");
    fclose(fp);
    return;
  }
}

int num_dosdoors(void)
{
  int ctr, numdoors=0;

  for (ctr = 0; ctr < numlines + 1; ctr++)
  {
    if (strcasecmp(user[ctr].doors_id, user[who].doors_id) == 0)
      numdoors++;
  }
  return(numdoors-1);
}

