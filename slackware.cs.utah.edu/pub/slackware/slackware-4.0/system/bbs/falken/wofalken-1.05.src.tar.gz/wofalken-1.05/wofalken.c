/**************************************************************************
Copyright (C) 1998  Eric Kilfoil (kewjhoe) eric@ipass.net

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

The author can be reached at eric@ipass.net

****************************************************************************/


// WARNING!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// This code is horrible.  Look at it at your own risk.
// I don't take any responsibility if you look at this code
// and fall into a deep coma or some sort of depression.
//
// And in case you were wonder, it really is that bad.
// I'm still suprised that this thing works.

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "doorutil.h"

#define maxlines MAXLINES + 1
#define userhere 1
#define usergone 0
#define UIDLEN	32

char command_string[10240];

int linesingame[maxlines];

void add_user(int line);
void remove_user(int line);
void init_program();
int get_message();

// Foreground Colors
#define BLACK 	[30m
#define RED 	[31m
#define GREEN 	[32m
#define YELLOW	[33m
#define BLUE	[34m
#define PURPLE	[35m
#define CYAN	[36m
#define WHITE	[37m

// Foreground
#define BGBLACK 	[40m
#define BGRED 		[41m
#define BGGREEN 	[42m
#define BGYELLOW	[43m
#define BGBLUE		[44m
#define BGPURPLE	[45m
#define BGCYAN		[46m
#define BGWHITE		[47m

// State set
#define BRIGHT  	[1m
#define BLINK   	[4m
#define RESET   	[0m

// Current Location in Game
#define LEAVINGGAME	0
#define PRINTMAINMENU	1
#define MAINMENUCMD	2
#define STARTNEWGAME	3
#define JOINOLDGAME	4
#define VIEWSCORES	5
#define INGAME		6
#define INGAMECMD	7
#define GETLETTER	8
#define GETVOWEL	9
#define AREYOUSURE	10
#define GETGUESS	11
#define LEAVING	12

// DOOR_ID
#define DOORID "Wheel of Falken"
#define RANDOMIZE
//#define UNREGD
//#define DEBUG1
//#define DEBUG2
//#define DEBUG3

#define pqnprintf	xpos += qnprintf
#define CURGAME		playerinfo[line].curgame
#define CURSPIN		playerinfo[line].currentspin

int xpos = 0, ypos = 0, oldxpos = 0, oldypos = 0;
char gamedata[64];
char highscore[64];
char puzzles[64];
char wofgames[64];
char cons[27];
char igmessage[256][4][161];
char *makeletters(int line);
char *getcurpuzzle(int line, char *puzzle);
int ingame=0, outtahere=0;
int spinamounts[25] = { 150, 
												150,
												150,
												150,
												250, 
												250, 
												250, 
												250, 
												350, 
												350, 
												350, 
												350, 
												450, 
												450, 
												450, 
												450, 
												500,
												500,
												500,
												500,
												750,
												1000,
												5000,
												-1,
												-2,
};

struct _gameinfo {
  char gamestatus[256];
} gameinfo;

struct _playerinfo {
  int curgame;
  int currentspin;
  int redraw;
} playerinfo[64];

struct _sgameinfo {
  char chopped[4][21];
  char puzzle[81];
  char lettersap[22];
  char lastmessage[78];
	char vowelap[6];
  int whosturn;
  int round;
  char players[3][UIDLEN];
  int score[3];
  int totalscore[3];
  int spin;
  int gamehasstarted;
} sgameinfo[256];

struct _winner {
	char playername[UIDLEN];
	int score;
	int single;
};


// It is what it says it is
// The big kahuna, the mother loop, the loop of all loops (as far as this game
// goes anyway).  It checks the current "state" of the user and acts
// accordingly when a user presses enter.
// It also saves the current game information after EACH loop.  Since this
// is the first time i've messed with fwrite, it's probably not that good of
// code... maybe i should seek through the wofgames file and only write the
// the current game instead of rewriting the structure for ALL 256 possible
// games?
void main_game_loop(void)
{
  int line = -1;
  int ctr, combo, flag;
  FILE *f;

  if ((f = f_open(wofgames, "r", 1, &combo)) != 0)
	{
    fread(&sgameinfo, sizeof(sgameinfo), 1,  f);
  	f_close(f, combo);
	} else {  
		send_lprintf("Can't open file %s for read", wofgames); 
		exit(0); 
	}
  if ((f = fopen(gamedata, "r")) != 0)
	{
    fread(&gameinfo, sizeof(gameinfo), 1,  f);
  	fclose(f);
	} else {  
		send_lprintf("Can't open file %s for read", wofgames); 
		exit(0); 
	}
	srand(time(NULL));
  for (;; relinq())
  { 
    outtahere=0;
    ingame=0;
    
    if ((f = fopen(wofgames, "w")) != 0)
		{
      fwrite(&sgameinfo, sizeof(sgameinfo), 1,  f);
    	fclose(f);
		} else { 
			send_lprintf("Can't open file %s for write", wofgames); exit(0); 
		}
		if ((f = fopen(gamedata, "w")) != 0)
		{
			fwrite(&gameinfo, sizeof(gameinfo), 1, f);
    	fclose(f);
		} else { 
			send_lprintf("Can't open file %s for write", gamedata); exit(0); 
		}  
    line = get_message();
    if ((strcmp(command_string, "EXITNOW") == 0) && (strcasecmp(acnt[line].acctname, "kewjhoe") == 0))
      exit(0);
    if (!user[line].u_ansi)
		{
			if (strcasecmp(command_string, "q") == 0)
				remove_user(line);
			else {
				qnprintf(line, "You must have ANSI enabled to use Wheel of Falken\r");
				qnprintf(line, "Type .ansi to enable ansi, or Q to quit.\r");
			}
			continue;
		}
    switch (linesingame[line])
    {
      case PRINTMAINMENU:
        do_menu(line,1);
        break;
      case MAINMENUCMD:
        if (!(strlen(command_string) == 0))
        {
					switch(toupper(command_string[0]))
					{
						case 'Q':
							if (strlen(command_string) == 1)
							{
								remove_user(line);
								linesingame[line] = LEAVING;
								break;
							}
						case 'S':
							if (strlen(command_string) == 1)
							{
								CURGAME = start_new_game(line, 1);
								break;
							}
						case 'L':
							if (strlen(command_string) == 1)
							{
								list_all_games(line);
								break;
							}
						case 'J':
							if (strlen(command_string) == 1)
							{
								CURGAME = join_old_game(line);
								break;
							}
						case 'V':
							if (strlen(command_string) == 1)
							{
								view_high_scores(line);
								break;
							}
						default:
							if (linesingame[line] != LEAVING)
							{
								int tmp;

								tmp = ingame_globals(line);
								if (tmp) 
								{
									if (tmp != 5)
										linesingame[line] = MAINMENUCMD;
									break;
								} else
									qnprintf(line, "Invalid Command - Press [ENTER] to continue");
							}
							break;
					}
        } else {
          do_menu(line, 1);
        }
        break;
      case INGAME:
        if (playerinfo[line].redraw) redraw(line);
				qnprintf(line, "> ");
        // do_menu(line, 2);
        break;
      case INGAMECMD:
        if (playerinfo[line].redraw) redraw(line);
        if (command_string[0] == '.')
        {
          send_to_everyone(command_string+1, line);
        }
				ingame=0;
        for (ctr=0; ctr < 3; ctr++)
 					if (sgameinfo[CURGAME].players[ctr][0] != 0)
	 					if (strcasecmp(sgameinfo[CURGAME].players[ctr], acnt[line].acctname) == 0)
           	 ingame=1;
#ifdef DEBUG3
        qnprintf(line, "%d", line);
#endif
        if (ingame)
        {
          if (sgameinfo[CURGAME].gamehasstarted)
          {
            if (strcmp(sgameinfo[CURGAME].players[sgameinfo[CURGAME].whosturn], acnt[line].acctname) == 0)
            {
              // Woo hoo!  it's MY turn!
              if (toupper(command_string[0]) == 'S')
							{
								spinthewheel(line);
								continue;
							}
              if (toupper(command_string[0]) == 'B')
							{
								buyavowel(line);
								continue;
							}
              if (toupper(command_string[0]) == 'G')
							{
								qnprintf(line, "Are you sure you want to try to solve (y/N): ");
								linesingame[line]=AREYOUSURE;
								continue;
							}
							ingame_globals(line);
            } else {
							// Someone Else's Turn
						  ingame_globals(line);
            }
          } else {
						// This game hasn't started
            if(toupper(command_string[0]) == 'S')
            {
              sgameinfo[CURGAME].gamehasstarted = 1;
              redraw_all(line);
              // do_menu_all(line,2);
              // relinq();
              //remove_blocks_all(line);
              linesingame[line] = INGAMECMD;
            }
						ingame_globals(line);
          }
        } else { 
					  // I'm not even playing the game
            if(toupper(command_string[0]) == 'J')
            { 
              if (!(sgameinfo[CURGAME].gamehasstarted)) {
                if (!(strlen(sgameinfo[CURGAME].players[0]))) {
                  strcpy(sgameinfo[CURGAME].players[0], acnt[line].acctname);
									start_new_game(line, 0);
                  redraw(line);
                  // do_menu(line, 2);
								} else if (!(strlen(sgameinfo[CURGAME].players[1]))) {
                  strcpy(sgameinfo[CURGAME].players[1], acnt[line].acctname);
                  redraw(line);
                  // do_menu(line, 2);
                } else if (!(strlen(sgameinfo[CURGAME].players[2]))) {
                  strcpy(sgameinfo[CURGAME].players[2], acnt[line].acctname);
                  redraw(line);
                  // do_menu(line, 2);
                } else {
                  qnprintf(line, "This game is already full! You can't join!\r");
                }
              } else { 
                qnprintf(line, "You can't join a game that has already started!\r");
              }
              linesingame[line] = INGAMECMD;
            }
						ingame_globals(line);
        } 
        if ((outtahere != 1) && (linesingame[line] == INGAMECMD)) {
					// Not leaving the game
					// OLD PROMPT - qnprintf(line, "[1;37m> ");
					do_prompt(line);
          linesingame[line] = INGAMECMD;
        } else { 
					notify_pig(line, 0); 
					CURGAME = -1; 
				}
        break;
      case JOINOLDGAME:
				if ((atoi(command_string) > 255) || (atoi(command_string) < 0))
				{
					qnprintf(line, "That is an invalid game number.\rSelect a Game number between 0 and 255: ");
				} else {
					playerinfo[line].curgame = atoi(command_string);
					notify_pig(line, 1);
					redraw(line);
					relinq();
					qnprintf(line, "> ");
					ingame=0;
					for (ctr=0; ctr < 3; ctr++)
						if (strcasecmp(sgameinfo[CURGAME].players[ctr],
													 acnt[line].acctname) == 0)
							ingame=1;
					linesingame[line] = INGAMECMD;
				}
        break;
			case GETLETTER:
				flag = getletter(line);
				if (flag) qnprintf(line, "> ");
				break;
			case GETVOWEL:
				flag = getvowel(line);
				if (flag) qnprintf(line, "> ");
				break;
      case AREYOUSURE:
				if (toupper(command_string[0]) == 'Y')
				{
					guessthepuzzle(line);
				}
				else
					linesingame[line]=INGAMECMD;
				break;
			case GETGUESS:
				guess_the_puzzle(line);
				linesingame[line] = INGAMECMD;
				qnprintf(line, "> ");
				break;
      default:
        break;
    }
  }
}

//  Checks to see if there are any games available
//  Gets a puzzle for the new game
//  calls the chop function and sets the chopped var
//  starts the game
start_new_game(int line, int mm)
{ 
  FILE *f;
  int combo, newgamenum=0,i, randnum;
  char firstgame;

  linesingame[line] = STARTNEWGAME;
  //qnprintf(line, "Starting a new game...\r");
	//qnprintf(line, "If this is that LAST thing you see, (ie the game halts), please email\reric@ipass.net immediately. Damned Bugs\r");
	if (firstgame = strchr(gameinfo.gamestatus,1) == 0)
	{
		pqnprintf(line, "There are no games available right now. Sorry.");
		sleep(3);
		linesingame[line] = PRINTMAINMENU;
	} else {
		if (mm)
		{
			newgamenum = set_first_active(&gameinfo.gamestatus);
			CURGAME = newgamenum;
		} else {
			newgamenum = set_spec_active(CURGAME);
		}
		if ((f = f_open(puzzles, "r", 1, &combo)) != 0)
		{
#ifdef RANDOMIZE
			randnum = (1+(int) (1086.0*rand()/(RAND_MAX+1.0)));
#else
			randnum = (1+(int) (1.0*rand()/(RAND_MAX+1.0)));
			qnprintf(line, "%d", randnum);
#endif
			for (i = 0; i < randnum; i++)
			{
				fgets(sgameinfo[newgamenum].puzzle, 127, f);  
			}
			f_close(f, combo);
		} else qnprintf(line, "Couldn't open %s", puzzles);
		strupr(&sgameinfo[newgamenum].puzzle);
		playerinfo[line].redraw = 1;
		strcpy(sgameinfo[newgamenum].players[0], acnt[line].acctname);
		chop_puzzle(line, sgameinfo[newgamenum].puzzle);
		sgameinfo[CURGAME].round = 0;
		qnprintf(line, "\rYou have just started Game #%d.  You can play this game\rby yourself or let others join.\r", newgamenum);
		qnprintf(line, "\rOnce you are in the game, press 'S' to start the first round.\r", newgamenum);
		bbs_sendmsg(line, 15);
		sleep(3);
		linesingame[line] = INGAME;
#ifdef DEBUG1
		print_puzzle_debug(line);
#endif
		return(newgamenum);
	}
  linesingame[line] = PRINTMAINMENU;
  do_menu(line, 1);
  return(newgamenum);
}

// Join a game
join_old_game(int line)
{
  linesingame[line] = JOINOLDGAME;
  qnprintf(line, "Which Game Do you want to join: ");
  return(1);
}

// Draw some menu stuff (main menu, and ingame menus)
do_menu(int line,int menunum)
{
  int ctr,ingame=0;

  switch (menunum)
  {
    case 1:
      cls(line);
			redraw(line);
			do_menu(line, 2);
      linesingame[line] = MAINMENUCMD;
#ifdef DEBUG1
      goxy(line, 1,1);
      qnprintf(line, "%d", linesingame[line]);
      goxy(line, -1, -1);
#endif
      break;
    case 2:
			if (CURGAME != -1)
			{
				for (ctr=0; ctr < 3; ctr++)
					if (strcasecmp(sgameinfo[CURGAME].players[ctr], 
												 acnt[line].acctname) == 0) 
						ingame=1;
				if (ingame)
				{
					if (sgameinfo[CURGAME].gamehasstarted)
					{
						if (strcmp(sgameinfo[CURGAME].players[sgameinfo[CURGAME].whosturn], 
											 acnt[line].acctname) == 0)
						{
							qnprintf(line, "[10;1HYOUR turn: [S]pin  [B]uy a Vowel  [G]uess the puzzle  [Q]uit[15;1H");
						} else {
							qnprintf(line, "[10;1HIt is not your turn:  [Q]uit  [#] Switch to Game #[15;1H");
						}
					} else {
						qnprintf(line, "[10;1HGame hasn't started:  [S]tart Game   [R]emove yourself from this game  [Q]uit[15;1H");
					}
				} else {
					qnprintf(line, "[10;1HYou are not playing in this game - [J]oin Game  [Q]uit[15;1H");
				}
			} else {
				qnprintf(line, "[1;33m[2;5H[[1;37mS[1;33m]tart a new game                   [1;33m[ [1;37mGlobal Commands [1;33m]");
				qnprintf(line, "[3;5H[1;33m[[1;37mJ[1;33m]oin a game                        [[1;37mhelp[1;33m] Online help");
				qnprintf(line, "[4;5H[1;33m[[1;37mL[1;33m]ist all games                     [[1;37mdraw[1;33m] Redraw the screen");
				qnprintf(line, "[5;5H[1;33m[[1;37mV[1;33m]iew high scores                   [[1;37m###[1;33m] Change to game number (0-255)\r");
				qnprintf(line, "                                         [[1;37mlist[1;33m] List current players");
				qnprintf(line, "[7;5H[[1;37mQ[1;33m]uit Wheel of Falken[15;1H");
				qnprintf(line, "[9;5H[1;34m[ [1;37m(c) Eric Kilfoil (kEwjhOe) - 1998 [1;34m]");
#ifdef UNREGD
				qnprintf(line, "[9;50H[1;34m[ [5;31mUNREGISTERED[0m [1;34m]");
#endif
				qnprintf(line, "[12;10H[1;37mWheel[13;39Hof[12;63HFalken");
				// OLD PROMPT - qnprintf(line, "[15;1H[1;37m> ");
				qnprintf(line, "[15;1H");
				do_prompt(line);
			}
      qnprintf(line, "[1;37m");
      linesingame[line] = INGAMECMD;
      break;
    default:
      qnprintf(line, "There is a problem");
      exit(1);
  }
}
      

// Centers text on the screen
centerprint(int line, char *ltp)
{
  int x;
  
  x = ((myacct->linlen/2) - (strlen(ltp)/ 2));
  goxy(line, x-1, -1);
  pqnprintf(line, ltp);
}

// Clear the screen and home the cursor
cls(int line)
{
  xpos = 1; ypos = 1;
  qnprintf(line, "[2J[1;1H");
#ifdef DEBUG1
  goxy(line,1,1);
  qnprintf(line, "%d", linesingame[line]);
#endif
}

// does what it says.  Also updates globals x and y to reflect the new
// cursor position.  This is just altogether bad code.  The only real way
// to do this is to do some sort of ansi parser.  Ugh...
goxy(int line, int x, int y)
{
  if ((x == -1) && (y == -1))
  {
    x = oldxpos; y = oldypos;
    oldxpos = xpos; oldypos = ypos;
    xpos = x; ypos = y;
    goxy(line, x, y); 
    return;
  }
  oldxpos = xpos; oldypos = ypos;
  xpos = x; ypos = y;
  if (y == -1)
  {
    qnprintf(line, "[G[M[%dC", x);
    ypos = oldypos;
  }
  else
    qnprintf(line, "[%d;%dH",y,x);
}

// Silly code to move the cursor left.  May wanna get rid of this...
go_left(int x,int line)
{
  xpos -= x;
  oldxpos = x+1;
  qnprintf(line, "[%dD",x);
}

// Silly code to move the cursor right.  May wanna get rid of this...
go_right(int x,int line)
{
  xpos += x;
  oldxpos = x-1;
  qnprintf(line, "[%dC",x);
}

// Find the first inactive game, and set it active in MEMORY.  NOT on disk.
// Maybe I should write this to disk right here too?  Nah, it's done after
// every loop of the game anyway :)
set_first_active(char *gamestatus)
{
  int i;

  for (i = 0; i <= strlen(gamestatus); i ++)
  {
    if (gamestatus[i] == 1)
    {
      gamestatus[i]=2;
      return(i);
    }
  }
}
set_spec_active(int tmp)
{
	gameinfo.gamestatus[tmp]=2;
  return(tmp);
}

// This redraws most of the stuff on the screen.  Maybe i should integrate
// the remove_blocks code with this code.  I'll leave that for the next
// version.  I'm too lazy :)
redraw(int line)
{
  int i,i2, curcolor=0, ctr;
	char buffer[10240];

  qnprintf(line, "[2J[1;1H");
	ingame=0;
	for (ctr=0; ctr < 3; ctr++)
		if (strcasecmp(sgameinfo[CURGAME].players[ctr], acnt[line].acctname) == 0)
			ingame=1;
	if (strcasecmp(acnt[line].acctname, "kewjhoe") == 0)
		ingame=1;

#ifdef DEBUG1
  goxy(line,1,25);
  qnprintf(line, "%d", linesingame[line]);
  goxy(line, 1, 1);
#endif
	if (ingame)
	{
  	sprintf(buffer, "[47m[1;33m");
		for (i2 = 0; i2 < 4; i2++) 
		{
			for (i = 0; i < 20; i++) 
			{
				if ((sgameinfo[CURGAME].chopped[i2][i] == ' '))
						// || (sgameinfo[CURGAME].chopped[i2][i] == 0))
				{
					if (!curcolor)
					{
						sprintf(buffer, "%s[40m    ", buffer);
						curcolor++;
					} else {
						sprintf(buffer, "%s    ", buffer);
					}
				} else if ((strchr(sgameinfo[CURGAME].lettersap, sgameinfo[CURGAME].chopped[i2][i]) > 0) || (strchr(sgameinfo[CURGAME].vowelap, sgameinfo[CURGAME].chopped[i2][i]) > 0)) {
					if (!curcolor)
					{
						sprintf(buffer, "%s[40m %c  ", buffer, sgameinfo[CURGAME].chopped[i2][i]);
						curcolor++;
					} else {
						sprintf(buffer, "%s %c  ", buffer, sgameinfo[CURGAME].chopped[i2][i]);
					}
				} else if (ispunct(sgameinfo[CURGAME].chopped[i2][i])) {
					if (!curcolor)
					{
						sprintf(buffer, "%s[40m %c  ", buffer, sgameinfo[CURGAME].chopped[i2][i]);
						curcolor++;
					} else {
						sprintf(buffer, "%s %c  ", buffer, sgameinfo[CURGAME].chopped[i2][i]);
					}
				} else {
					if (curcolor)
					{
						sprintf(buffer, "%s[47m   [C", buffer);
						curcolor--;
					} else {
						sprintf(buffer, "%s   [C", buffer);
					}
				}
			}
			sprintf(buffer, "%s\r\r", buffer);
		}
		sendtoline(line, buffer);
		relinq();
	} else {
		qnprintf(line, "[9;0H");
	}
		sprintf(buffer, "[40m[1;34m");
		for (i = 1; i <= 79; i++) sprintf(buffer, "%s�", buffer);
		sprintf(buffer, "%s\r\r", buffer);
		for (i = 1; i <= 79; i++) sprintf(buffer, "%s�", buffer);
		sprintf(buffer, "%s\r\r\r", buffer);
		for (i = 1; i <= 79; i++) sprintf(buffer, "%s�", buffer);
		sprintf(buffer, "%s\r", buffer);
		sprintf(buffer, "%s[1;34m[11;26H�[11;52H�", buffer );
		sprintf(buffer, "%s\r", buffer);
		sprintf(buffer, "%s[12;26H�[12;52H�", buffer);
		sprintf(buffer, "%s\r", buffer);
		sprintf(buffer, "%s[13;26H�[13;52H�", buffer);
		sprintf(buffer, "%s\r", buffer);
		sprintf(buffer, "%s[14;26H�[14;52H�", buffer);
		sprintf(buffer, "%s\r", buffer);
	if (CURGAME != -1)
	{
		sprintf(buffer, "%s[1;36m[9;7H[ Game: %d ]", buffer, CURGAME);
		sprintf(buffer, "%s\r", buffer);
		sprintf(buffer, "%s[9;25H[ Letters: %s ]", buffer, makeletters(line));
		sprintf(buffer, "%s\r", buffer);
		sprintf(buffer, "%s[1;36m[9;65H[ Round: %d ]", buffer, sgameinfo[CURGAME].round+1);
		sprintf(buffer, "%s\r", buffer);
		sprintf(buffer, "%s[1;36m[14;7H[ %s ]", buffer, sgameinfo[CURGAME].lastmessage);
		sprintf(buffer, "%s\r", buffer);
		sprintf(buffer, "%s[1;36m[12;1HName : [1;%sm%s", buffer, ((sgameinfo[CURGAME].whosturn == 0) ? "37" : "33"), sgameinfo[CURGAME].players[0]);
		sprintf(buffer, "%s\r", buffer);
		sprintf(buffer, "%s[1;36m[13;1HScore: [1;%sm%d", buffer, ((sgameinfo[CURGAME].whosturn == 0) ? "37" : "33"), sgameinfo[CURGAME].score[0]);
		sprintf(buffer, "%s\r", buffer);
		sprintf(buffer, "%s[1;36m[12;27HName : [1;%sm%s", buffer, ((sgameinfo[CURGAME].whosturn == 1) ? "37" : "33"), sgameinfo[CURGAME].players[1]);
		sprintf(buffer, "%s\r", buffer);
		sprintf(buffer, "%s[1;36m[13;27HScore: [1;%sm%d", buffer, ((sgameinfo[CURGAME].whosturn == 1) ? "37" : "33"), sgameinfo[CURGAME].score[1]);
		sprintf(buffer, "%s\r", buffer);
		sprintf(buffer, "%s[1;36m[12;53HName : [1;%sm%s", buffer, ((sgameinfo[CURGAME].whosturn == 2) ? "37" : "33"), sgameinfo[CURGAME].players[2]);
		sprintf(buffer, "%s\r", buffer);
		sprintf(buffer, "%s[1;36m[13;53HScore: [1;%sm%d[15;1H[1;37m", buffer, ((sgameinfo[CURGAME].whosturn == 2) ? "37" : "33"), sgameinfo[CURGAME].score[2]);
	} 
	sendtoline(line, buffer);
	if (CURGAME != -1)
	{
		do_menu(line, 2);
	}
	buffer[0] = 0;
	for (ctr = 0; ctr < 4; ctr++)
	{
		if (igmessage[CURGAME][ctr][0] != '\0')
			sprintf(buffer, "%s%s\r", buffer, igmessage[CURGAME][ctr]);
	}
	sendtoline(line, buffer);
	playerinfo[line].redraw = 0;
}

// This chops the puzzle into pieces that can fit on the game screen
// Kinda like word wrap.  Thanks CD, You're a cupcake.
chop_puzzle(int line, char *puzzle)
{
  char *str, string[128]; 
  int ctr = 0, loop1, loop2, i, i2;
  
	for (loop1 = 0; loop1 < 4; loop1++)
		for (loop2 = 0; loop2 < 20; loop2++)
			sgameinfo[CURGAME].chopped[loop1][loop2] = '\0';
  puzzle[strlen(puzzle)-1] = 0;
  strcpy(string, puzzle);
  str = strtok(string, " ");	/* There is the first space	*/
  strcpy(sgameinfo[CURGAME].chopped[ctr], str);
  while(1)
  { if((str = strtok(NULL, " ")) == NULL)
      break;
    if(strlen(sgameinfo[CURGAME].chopped[ctr]) + (strlen(str) + 1) > 20)
		{
      ctr++; 
		} else strcat(sgameinfo[CURGAME].chopped[ctr], " ");
    strcat(sgameinfo[CURGAME].chopped[ctr], str);
  }
  relinq();
}

// This will remove the blocks from the screen that are blanks.
// It also will print out any letters that have already been played.
// And it will print out any punctuation in the puzzle
remove_blocks(int line)
{
  int ctr, ctr2, ctr3;

	qnprintf(line, "[1;33m");
  for (ctr=0; ctr < 4; ctr++)
  {
    for (ctr2=0; ctr2 < 20; ctr2++)
    {
      if (sgameinfo[CURGAME].chopped[ctr][ctr2] == ' ')
      {
          goxy(line, ctr2*4, ctr*2+1);
          qnprintf(line, "    ");
      } else if (sgameinfo[CURGAME].chopped[ctr][ctr2] == 0) {
        goxy(line, ctr2*4, ctr*2+1);
        for (ctr3=ctr2*4; ctr3 <= 80; ctr3++)
        {
          qnprintf(line, " ");
        }
        ctr2=20;
      } else if ((strchr(sgameinfo[CURGAME].lettersap, sgameinfo[CURGAME].chopped[ctr][ctr2]) > 0) || (strchr(sgameinfo[CURGAME].vowelap, sgameinfo[CURGAME].chopped[ctr][ctr2]) > 0))
			{
        goxy(line, ctr2*4, ctr*2+1);
				if (ctr2 == 0) {
					qnprintf(line, " %c ", sgameinfo[CURGAME].chopped[ctr][ctr2]);
				} else {
					qnprintf(line, "  %c ", sgameinfo[CURGAME].chopped[ctr][ctr2]);
				}
			} else if (ispunct(sgameinfo[CURGAME].chopped[ctr][ctr2])) {
          goxy(line, ctr2*4, ctr*2+1);
					qnprintf(line, "  %c ", sgameinfo[CURGAME].chopped[ctr][ctr2]);
			}
#ifdef DEBUG2
      else 
      { 
        goxy(line, ctr2*4+2, ctr*2+1);
        qnprintf(line, "%c", sgameinfo[CURGAME].chopped[ctr][ctr2]);
      }
#endif
    }
  }
	strupr(command_string);
  if ((strcmp(command_string, "DRAW") != 0) && (strcmp(command_string, "REDRAW") != 0)) 
	{
		// OLD PROMPT - qnprintf(line, "[15;0H[1;37m> ");
		if (igmessage[CURGAME][0] == 0)
		{
			qnprintf(line, "[15;1H");
		} else if (igmessage[CURGAME][0] == 0) {
			qnprintf(line, "[16;1H");
		} else if (igmessage[CURGAME][0] == 0) {
			qnprintf(line, "[17;1H");
		} else if (igmessage[CURGAME][0] == 0) {
			qnprintf(line, "[18;1H");
		}
		do_prompt(line);
	}
	else
		qnprintf(line, "[15;0H");
}

// Debug stuff to see what the puzzle is
#ifdef DEBUG1
print_puzzle_debug(line)
{
  int loop1;

  for (loop1=0; loop1 < 4; loop1++)
    qnprintf(line, "\r%s - %d", sgameinfo[CURGAME].chopped[loop1], CURGAME);
  sleep(1);
  qnprintf(line, "Slept");
}
#endif

//  Send a public message to everyone in the game.  May need some work
send_to_everyone(char *message, int line)
{
  int loop1;
	char tmp[strlen(message)+30];
  
  sprintf(tmp, "[2DFrom %s: %s", acnt[line].acctname, message);
	strcpy(message, tmp);
  for (loop1=0; loop1 < MAXLINES; loop1++)
  {
    if (playerinfo[loop1].curgame == playerinfo[line].curgame)
    {
      if (loop1 != line) 
      {
        if((user[loop1].u_stat == 6) && (strcasecmp(user[loop1].doors_id, DOORID) == 0))
        {
          qnprintf(loop1, "[G[M%s\r", message);
					do_prompt(loop1);
        }
      } else {
        qnprintf(line, "Message Sent\r");
				if (igmessage[CURGAME][0][0] == 0) {
					strncpy(igmessage[CURGAME][0], message, 159);
				} else if (igmessage[CURGAME][1][0] == 0) {
					strncpy(igmessage[CURGAME][1], message, 159);
				} else if (igmessage[CURGAME][2][0] == 0) {
					strncpy(igmessage[CURGAME][2], message, 159);
				} else if (igmessage[CURGAME][3][0] == 0) {
					strncpy(igmessage[CURGAME][3], message, 159);
				} else {
					strcpy(igmessage[CURGAME][0], igmessage[CURGAME][1]);
					strcpy(igmessage[CURGAME][1], igmessage[CURGAME][2]);
					strcpy(igmessage[CURGAME][2], igmessage[CURGAME][3]);
					strcpy(igmessage[CURGAME][3], message);
				}
      }
    }
  }
}


// Notify Players in the game of joins/parts
//   enter = if true, line is entering else, it's leaving
notify_pig(int line, int enter)
{
  int loop1;
  
  for (loop1=0; loop1 < 64; loop1++)
  {
    if (playerinfo[loop1].curgame == playerinfo[line].curgame)
    {
      if (loop1 != line) 
      {
        if((user[loop1].u_stat == 6) && (strcasecmp(user[loop1].doors_id, DOORID) == 0))
        {
          if (enter) {
            qnprintf(loop1, "[G[M%s has just joined this game\r", acnt[line].acctname);
						do_prompt(loop1);
          } else { 
						qnprintf(loop1, "[G[M%s has just left this game\r", acnt[line].acctname); 
						do_prompt(loop1);
					}
        }
      } 
    }
  }
}

// Checks to see if s is an integer. ALL of s must be an integer for this
// test to pass.
isinteger(char *s)
{
  int loop;
  
  for (loop=0; loop < strlen(s); loop++)
  {
		if (!isdigit(s[loop]))
      return(0);
  }
  return(1);
}

//  Spins the wheel, assigns the SPIN to the player's curspin variable
//  checks to see if they spun bankrupt or something.
spinthewheel(int line)
{
  int loop1;
  
	if (consleft(line))
	{
		//if (strcasecmp(sgameinfo[CURGAME].players[sgameinfo[CURGAME].whosturn], "kevin") == 0)
		//	CURSPIN = -1;
		//else
	  	CURSPIN = spinamounts[((int) (25.0*rand()/(RAND_MAX+1.0)))];
		for (loop1=0; loop1 < 64; loop1++)
		{
			if (playerinfo[loop1].curgame == playerinfo[line].curgame)
			{
				if (loop1 != line) 
				{
					if((user[loop1].u_stat == 6) && (strcasecmp(user[loop1].doors_id, DOORID) == 0))
					{
						if (CURSPIN > 0) {
							qnprintf(loop1, "[2D%s spins and the wheel stops at %d!\r", acnt[line].acctname, CURSPIN);
							do_prompt(loop1);
						} else if (CURSPIN == -1) {
							qnprintf(loop1, "[2D%s has gone Bankrupt!\r", acnt[line].acctname);
							do_prompt(loop1);
						} else if (CURSPIN != -2) {
							qnprintf(loop1, "[2D%s has lost a turn!\r", acnt[line].acctname);
							do_prompt(loop1);
						}
					}
				} else {
					if (CURSPIN > 0) {
						qnprintf(line, "The wheel spins at stops at %d\rPick a Letter: ", CURSPIN);
						linesingame[line] = GETLETTER;
					} else if (CURSPIN == -1) {
						sprintf(sgameinfo[CURGAME].lastmessage, "%s has spun and the wheel stopped at Bankrupt!", acnt[line].acctname);
						sgameinfo[CURGAME].score[sgameinfo[CURGAME].whosturn] = 0; 
						inc_turn(line);
						linesingame[line] = INGAMECMD;
						redraw_all(line);
						relinq();
						do_prompt(line);
						// do_menu_all(line);
						// relinq();
						// remove_blocks_all(line);
					} else if (CURSPIN == -2) {
						sprintf(sgameinfo[CURGAME].lastmessage, "%s has spun and the wheel stopped at Lose a Turn!", acnt[line].acctname);
						inc_turn(line);
						linesingame[line] = INGAMECMD;
						redraw_all(line);
						relinq();
						do_prompt(line);
						// do_menu_all(line);
						// relinq();
						// remove_blocks_all(line);
					}
				}
			}
		}
	} else {
		qnprintf(line, "There are no consonants left, you must solve or buy a vowel\r");
		do_prompt(line);
	}
  return(0);
}

// This check for global ingame commands like redraw and quit which are
// available regardless of who's turn it is, etc...
ingame_globals(int line)
{
	int ctr, loop1;

  if(toupper(command_string[0]) == 'Q')
	{
		if (linesingame[line] != MAINMENUCMD)
		{
			linesingame[line] = MAINMENUCMD;
			CURGAME = -1;
			redraw(line);
			do_menu(line,1);
			outtahere=1; 
			return(1);
		}
		return(0);
  }
  if ((strcasecmp(command_string, "help") == 0) || (strcasecmp(command_string, "?") == 0))
	{
		char buffer[512];
		
		sprintf(buffer, "To say something to everyone in the game, type:\r");
		sprintf(buffer, "%s  .message  -  Anything after the '.' will be sent\r\r", buffer);
		sprintf(buffer, "%sTo list everyone in Wheel of Falken and the game number they are in, type:\r", buffer);
		sprintf(buffer, "%s  list\r\r", buffer);
		sprintf(buffer, "%sTo redraw the screen, type:\r", buffer);
		sprintf(buffer, "%s  redraw\r\r", buffer);
		sprintf(buffer, "%sTo change to a different game, type the number of the game to change to\r\r", buffer);
		qnprintf(line, "%s", buffer);
		return(2);
	}
  if (strcasecmp(command_string, "list") == 0)
	{
		char buffer[4];

  	for (loop1=0; loop1 < 64; loop1++)
		{
			if((user[loop1].u_stat == 6) && (strcasecmp(user[loop1].doors_id, DOORID) == 0))
			{
				char buffer2[20] = "Game ";
				sprintf(buffer, "%d", playerinfo[loop1].curgame);
				qnprintf(line, "[1;33m%-22s: [1;37m%s\r", acnt[loop1].acctname, (playerinfo[loop1].curgame == -1) ? "Main Menu" : strcat(buffer2, buffer));
			}
		}
		return(3);
	}
  if ((strcasecmp(command_string, "draw") == 0) || (strcasecmp(command_string, "redraw") == 0))
  { redraw(line);
    // do_menu(line, 2);
    linesingame[line] = INGAMECMD;
    relinq();
    //remove_blocks(line);
		return(4);
  }
  if (strlen(command_string) < 4)
  {
    if ((isinteger(command_string)) && (command_string[0] != 0))
    {
			if (atoi(command_string) != CURGAME) 
			{
				if ((atoi(command_string) < 256) && (atoi(command_string) >= 0))
				{
					int prevgame = CURGAME;
					//changing games now!
					notify_pig(line, 0); 
					CURGAME = atoi(command_string);
					notify_pig(line, 1); 
					redraw(line);
					// do_menu(line, 2);
					if (prevgame == -1)
						qnprintf(line, "> ");
					ingame=0;
					for (ctr=0; ctr < 3; ctr++)
						if (strcasecmp(sgameinfo[CURGAME].players[ctr],
									acnt[line].acctname) == 0)
							ingame=1;
					linesingame[line] = INGAMECMD;
					return(5);
				} else {
					qnprintf(line, "That is not a valid game number\r");
				}
			} else {
			  qnprintf(line, "You are already in that game\r");
			}
		}
	}
}

// Increments the who's turn variable
inc_turn(int line)
{
	sgameinfo[CURGAME].whosturn++;
	if (sgameinfo[CURGAME].whosturn == 3) sgameinfo[CURGAME].whosturn = 0;
	if (sgameinfo[CURGAME].players[sgameinfo[CURGAME].whosturn][0] == 0)
		inc_turn(line);

}

// This function will process a letter input from the user.  There are
// a few main tests.  
//  1.  Make sure it's a letter
//  2.  Make sure it's a consonant
//  3.  Make sure it hasn't already been played
//  4.  See if it's in the puzzle
getletter(int line)
{
	char letter, *mypuzzle, therealpuzzle[81];
	int loop1=0, foundletter=0;
	
	strcpy(therealpuzzle, sgameinfo[CURGAME].puzzle);
	letter = toupper(command_string[0]);
	if (isalpha(letter))
	{
		if (!(isvowel(letter)))
		{
#ifdef DEBUG1
			qnprintf(line, "Alpha Test Passed\r");
#endif
			if (index(sgameinfo[CURGAME].lettersap, letter) == 0)
			{
#ifdef DEBUG1
			  qnprintf(line, "Not played test passed\r");
#endif
				// the letter hasn't been played yet
				mypuzzle = strchr(therealpuzzle, letter);
				while (mypuzzle != NULL)
				{
				  mypuzzle = strchr(mypuzzle, letter);
					if (mypuzzle != NULL) mypuzzle++; else continue;
					foundletter++;
#ifdef DEBUG1
					qnprintf(line, "mypuzzle: %d - FL: %d\r", mypuzzle, foundletter);
					sleep(2);
#endif
				}
				while (loop1 != 21) {
					if (isalpha(sgameinfo[CURGAME].lettersap[loop1]))	
						loop1++;
					else {
						sgameinfo[CURGAME].lettersap[loop1] = letter;
						break;
					}
				}
				if (foundletter)
				{
					sgameinfo[CURGAME].score[sgameinfo[CURGAME].whosturn] = (sgameinfo[CURGAME].score[sgameinfo[CURGAME].whosturn] + CURSPIN * foundletter);
				  sprintf(sgameinfo[CURGAME].lastmessage, "There were %d %c's in the puzzle.", foundletter, letter);
					redraw_all(line);
					relinq();
					// do_menu_all(line);
					// relinq();
					//remove_blocks_all(line);
				} else {
				  sprintf(sgameinfo[CURGAME].lastmessage, "There were no %c's in the puzzle.", letter);
					inc_turn(line);
					linesingame[line] = INGAMECMD;
					redraw_all(line);
					relinq();
					// do_menu_all(line);
					// relinq();
					//remove_blocks_all(line);
				}
				return(1);
			} else {
				// that letter has already been played
				qnprintf(line, "That letter has already been played\rPick a letter: ");
			}
		} else {
			qnprintf(line, "You cannot select a vowel.\rPick a letter: ");
		}
	} else {
		// that letter isn't a letter at all!
		qnprintf(line, "You must enter a letter A through Z\rPick a letter: ");
	}
	return(0);
}


// Redraw all the lines in the current game.  Normally called after something
// is updated that everyone should see.  LOTS OF RELINQ()'s since there's a 
// lot of output.
redraw_all(int line)
{
  int loop1;
  
  for (loop1=0; loop1 < 64; loop1++)
  {
    if (playerinfo[loop1].curgame == playerinfo[line].curgame)
    {
      if((user[loop1].u_stat == 6) && (strcasecmp(user[loop1].doors_id, DOORID) == 0))
      {
				relinq();
				redraw(loop1);
      }
    }
  }
}

// Redraw all the lines in the current game.  Normally called after something
// is updated that everyone should see.  LOTS OF RELINQ()'s since there's a 
// lot of output.
do_menu_all(int line)
{
  int loop1;
  
  for (loop1=0; loop1 < 64; loop1++)
  {
    if (playerinfo[loop1].curgame == playerinfo[line].curgame)
    {
      if((user[loop1].u_stat == 6) && (strcasecmp(user[loop1].doors_id, DOORID) == 0))
      {
				relinq();
				do_menu(loop1, 2);
      }
    }
  }
}

// Remove the blocks for all the lines in the current game.  Normally called 
// after something is updated that everyone should see.  LOTS OF RELINQ()'s 
// since there's a  lot of output.
remove_blocks_all(int line)
{
  int loop1;
  
  for (loop1=0; loop1 < 64; loop1++)
  {
    if (playerinfo[loop1].curgame == playerinfo[line].curgame)
    {
      if((user[loop1].u_stat == 6) && (strcasecmp(user[loop1].doors_id, DOORID) == 0))
      {
				relinq();
				//remove_blocks(loop1);
      }
    }
  }
}

isvowel(int letter)
{
	if (strchr("AEIOU", toupper(letter)) != NULL)
		return(1);
	else
		return(0);
}

//  This function just prints out info when the player starts to buy a vowel
buyavowel(line)
{
  int loop1;
  
	if (strlen(sgameinfo[CURGAME].vowelap) < 5)
	{
		if (sgameinfo[CURGAME].score[sgameinfo[CURGAME].whosturn] > 250)
		{
			for (loop1=0; loop1 < 64; loop1++)
			{
				if (playerinfo[loop1].curgame == playerinfo[line].curgame)
				{
					if (loop1 != line) 
					{
						if((user[loop1].u_stat == 6) && (strcasecmp(user[loop1].doors_id, DOORID) == 0))
						{
							qnprintf(loop1, "[2D%s is buying a vowel.\r", acnt[line].acctname, CURSPIN);
							do_prompt(loop1);
						}
					} else {
						qnprintf(line, "Pick a Vowel: ");
						linesingame[line] = GETVOWEL;
					}
				}
			}
		} else {
	 		qnprintf(line, "You can not afford to buy a vowel\r");
			do_prompt(line);
	 	}
	} else {
		qnprintf(line, "There are no vowels left to buy, you must solve or spin\r");
		do_prompt(line);
	}
  return(0);
}


// This function will process a letter input from the user.  There are
// a few main tests.  
//  1.   Make sure it's a letter
//  1.5. Make sure the letter is a vowel
//  2.   Make sure they can afford a vowel
//  3.   Make sure it hasn't already been played
//  4.   See if it's in the puzzle
getvowel(line)
{
	char letter, *mypuzzle, therealpuzzle[81];
	int loop1=0, foundletter=0;
	
	strcpy(therealpuzzle, sgameinfo[CURGAME].puzzle);
	letter = toupper(command_string[0]);
	if (isalpha(letter))
	{
#ifdef DEBUG1
		qnprintf(line, "Alpha Test Passed\r");
#endif
		if (isvowel(letter))
		{
				if (index(sgameinfo[CURGAME].vowelap, letter) == 0)
				{
#ifdef DEBUG1
					qnprintf(line, "Not played test passed\r");
#endif
					// the letter hasn't been played yet
					mypuzzle = strchr(therealpuzzle, letter);
					while (mypuzzle != NULL)
					{
						mypuzzle = strchr(mypuzzle, letter);
						if (mypuzzle != NULL) mypuzzle++; else continue;
						foundletter++;
#ifdef DEBUG1
						qnprintf(line, "mypuzzle: %d - FL: %d\r", mypuzzle, foundletter);
						sleep(2);
#endif
					}
					while (loop1 != 5) {
						if (isalpha(sgameinfo[CURGAME].vowelap[loop1]))	
							loop1++;
						else {
							sgameinfo[CURGAME].vowelap[loop1] = letter;
							break;
						}
					}
					if (foundletter)
					{
						sgameinfo[CURGAME].score[sgameinfo[CURGAME].whosturn] = sgameinfo[CURGAME].score[sgameinfo[CURGAME].whosturn] - 250;
						sprintf(sgameinfo[CURGAME].lastmessage, "There were %d %c's in the puzzle", foundletter, toupper(letter));
						redraw_all(line);
						relinq();
						// do_menu_all(line);
						// relinq();
						//remove_blocks_all(line);
					} else {
						sprintf(sgameinfo[CURGAME].lastmessage, "There are no %c's in the puzzle.", toupper(letter));
						inc_turn(line);
						linesingame[line] = INGAMECMD;
						redraw_all(line);
						relinq();
						// do_menu_all(line);
						// relinq();
						//remove_blocks_all(line);
					}
					return(1);
				} else {
					// that letter has already been played
					qnprintf(line, "That letter has already been played\rPick a letter: ");
				}
		} else {
			qnprintf(line, "You cannot buy a consonant.\rPick a letter: ");
		}
	} else {
		// that letter isn't a letter at all!
		qnprintf(line, "You must enter a vowel (A, E, I, O, or U).\rPick a letter: ");
	}
	return(0);
}

consleft(int line)
{
	char *ptl, mypuzzle[81];
	int loop1;
	
	strcpy(mypuzzle, sgameinfo[CURGAME].puzzle);
	for (loop1 = 0; loop1 < strlen(sgameinfo[CURGAME].lettersap); loop1++)
	{
		ptl=NULL;
		do
		{
			if ((ptl = strchr(mypuzzle, sgameinfo[CURGAME].lettersap[loop1])) != NULL)
				*ptl = '*';
		} while (ptl != NULL);
	}
#ifdef DEBUG1
	qnprintf(line, "Puzzle: %s", mypuzzle);
#endif
	for (loop1 = 0; loop1 < strlen(mypuzzle); loop1++)
		if (mypuzzle[loop1] != '*') 
			if ((!isvowel(mypuzzle[loop1])) && (!ispunct(mypuzzle[loop1])) && (!isspace(mypuzzle[loop1]))) 
			{
#ifdef DEBUG1
				qnprintf(line, "iv: %d - ip %d - loop1: %d - letter: %c\r", isvowel(mypuzzle[loop1]), ispunct(mypuzzle[loop1]), loop1, mypuzzle[loop1]);
#endif
				return(1);
			}
	return(0);
}

char *makeletters(int line)
{
	int loop1;
	char *ptl;
	
	strcpy(cons, "ABCDEFGHIJKLMNOPQRSTUVWXYZ");
	
	for (loop1 = 0; loop1 < strlen(sgameinfo[CURGAME].lettersap); loop1++)
	{
		ptl=NULL;
		do
		{
			if ((ptl = strchr(cons, sgameinfo[CURGAME].lettersap[loop1])) != NULL)
				*ptl = ' ';
		} while (ptl != NULL);
	}
	for (loop1 = 0; loop1 < strlen(sgameinfo[CURGAME].vowelap); loop1++)
	{
		ptl=NULL;
		do
		{
			if ((ptl = strchr(cons, sgameinfo[CURGAME].vowelap[loop1])) != NULL)
				*ptl = ' ';
		} while (ptl != NULL);
	}
	return(cons);
}

guessthepuzzle(int line)
{
  int loop1;
	char puzzle[81];
  
	strcpy(puzzle, sgameinfo[CURGAME].puzzle);
	for (loop1=0; loop1 < 64; loop1++)
	{
		if (playerinfo[loop1].curgame == playerinfo[line].curgame)
		{
			if (loop1 != line) 
			{
				if((user[loop1].u_stat == 6) && (strcasecmp(user[loop1].doors_id, DOORID) == 0))
				{
					qnprintf(loop1, "[2D%s is going to try to solve the puzzle.\r", acnt[line].acctname, CURSPIN);
					do_prompt(loop1);
				}
			} else {
				qnprintf(line, "\rCurrent Letters Showing: %s\r", getcurpuzzle(line, puzzle));
				qnprintf(line, "       Enter Your Guess: ");
				linesingame[line] = GETGUESS;
			}
		}
	}
  return(0);
}

char *getcurpuzzle(int line, char *puzzle)
{
	int loop1;
	char mypuzzle[81];
	
	for (loop1 = 0; loop1 < strlen(puzzle); loop1++)
	{
		if ((strchr(sgameinfo[CURGAME].lettersap, puzzle[loop1])) || (strchr(sgameinfo[CURGAME].vowelap, puzzle[loop1])) || (ispunct(puzzle[loop1])) || (isspace(puzzle[loop1]))) 
			mypuzzle[loop1] = puzzle[loop1];
		else
			mypuzzle[loop1] = '.';
	}
	mypuzzle[loop1] = '\0';
	strcpy(puzzle, mypuzzle);
	return(puzzle);
}

guess_the_puzzle(int line)
{
  int loop1, combo, flag=0;
	FILE *f;
  
	for (loop1=0; loop1 < 64; loop1++)
	{
		if (playerinfo[loop1].curgame == playerinfo[line].curgame)
		{
			if (loop1 != line) 
			{
				if((user[loop1].u_stat == 6) && (strcasecmp(user[loop1].doors_id, DOORID) == 0))
				{
					if (strcasecmp(command_string, sgameinfo[CURGAME].puzzle) == 0)
					{
						qnprintf(loop1, "[2D%s has guessed the puzzle.\rThe puzzle was:\r%s\r\r ", acnt[line].acctname, sgameinfo[CURGAME].puzzle);
						if (sgameinfo[CURGAME].round < 2)
						{
							qnprintf(loop1, "Type 'draw' to see the next puzzle\r");
						}
					}
				}
			} else {
				if (strcasecmp(command_string, sgameinfo[CURGAME].puzzle) == 0)
				{
					qnprintf(line, "Congratulations, you have guessed the puzzle.\r%d %shas been added to your total score\r\r ", (sgameinfo[CURGAME].score[sgameinfo[CURGAME].whosturn] > 500) ? sgameinfo[CURGAME].score[sgameinfo[CURGAME].whosturn] : 500, (sgameinfo[CURGAME].score[sgameinfo[CURGAME].whosturn] < 500) ? "(the house minimum) " : "" );
					if (sgameinfo[CURGAME].score[sgameinfo[CURGAME].whosturn] < 500) sgameinfo[CURGAME].score[sgameinfo[CURGAME].whosturn] += 500;
					if (sgameinfo[CURGAME].round < 2)
					{
						qnprintf(line, "Type 'draw' to see the next puzzle\r");
					}
				}
			}
		}
	}
	if (strcasecmp(command_string, sgameinfo[CURGAME].puzzle) != 0)
	{
		sprintf(sgameinfo[CURGAME].lastmessage, "%s guessed the puzzle incorrectly", acnt[line].acctname);
		inc_turn(line);
		linesingame[line] = INGAMECMD;
		redraw_all(line);
		relinq();
		// do_menu_all(line);
		// relinq();
		//remove_blocks_all(line);
	} else {
		if (sgameinfo[CURGAME].round < 2)
		{
			sprintf(sgameinfo[CURGAME].lastmessage, "%s guessed the last puzzle", acnt[line].acctname);
			start_new_round(line);
			linesingame[line] = INGAMECMD;
		} else {  // GAME OVER MAN!
			int winner;
			
			sgameinfo[CURGAME].totalscore[sgameinfo[CURGAME].whosturn] = sgameinfo[CURGAME].totalscore[sgameinfo[CURGAME].whosturn] + sgameinfo[CURGAME].score[sgameinfo[CURGAME].whosturn];
			if (sgameinfo[CURGAME].totalscore[0] > sgameinfo[CURGAME].totalscore[1])
				winner = 0;
			else
				winner = 1;
			if (sgameinfo[CURGAME].totalscore[winner] < sgameinfo[CURGAME].totalscore[2])
				winner = 2;
			sgameinfo[CURGAME].gamehasstarted=0;
			for (loop1=0; loop1 < 64; loop1++)
			{
				if((user[loop1].u_stat == 6) && (strcasecmp(user[loop1].doors_id, DOORID) == 0))
				{
					if (playerinfo[loop1].curgame == playerinfo[line].curgame)
					{
						int i;
						qnprintf(loop1, "[1;33mThe final scores were:\r");
						qnprintf(loop1, "[1;37m%-22.22s[1;33m:  [1;37m%d\r", sgameinfo[playerinfo[loop1].curgame].players[0], sgameinfo[playerinfo[loop1].curgame].totalscore[0]);
						if (sgameinfo[CURGAME].players[1][0]) qnprintf(loop1, "[1;37m%-22.22s[1;33m:  [1;37m%d\r", sgameinfo[playerinfo[loop1].curgame].players[1], sgameinfo[playerinfo[loop1].curgame].totalscore[1]);
						if (sgameinfo[CURGAME].players[2][0]) qnprintf(loop1, "[1;37m%-22.22s[1;33m:  [1;37m%d\r", sgameinfo[playerinfo[loop1].curgame].players[2], sgameinfo[playerinfo[loop1].curgame].totalscore[2]);
						qnprintf(loop1, "[1;33m[[1;37m%s[1;33m] is the winner!\r", sgameinfo[CURGAME].players[winner]);
					}
				}
			}
			
			if ((f = fopen(highscore, "r+")) == 0)
			{
				qnprintf(line, "Error opening highscore file for write");
			} else {
				int looporama=0;
				int single = 0;
				struct _winner wininfo;
				
				if (sgameinfo[CURGAME].players[1][0] == '\0')
					single=1;

				while(fread(&wininfo, sizeof(wininfo), 1, f))
				{
					//qnprintf(line, "test1");
					if ((strcmp(wininfo.playername, sgameinfo[CURGAME].players[winner]) == 0) && (single == wininfo.single))
					{
						fseek(f, (sizeof(struct _winner) * -1), SEEK_CUR);
						strcpy(wininfo.playername, sgameinfo[CURGAME].players[winner]);
						wininfo.score = wininfo.score + sgameinfo[CURGAME].totalscore[winner];
						qnprintf(line, "Your new High Score: %d\r", wininfo.score);
						if (sgameinfo[CURGAME].players[1][0] == 0)
							wininfo.single = 1;
						else
							wininfo.single = 0;
						fwrite(&wininfo, sizeof(struct _winner), 1, f);
						fclose(f);
						flag = 1;
						looporama++;
						break;
					}
				}
			}
			if (!flag)
			{
				//qnprintf(line, "test2");
				if ((f = fopen(highscore, "a")) == 0)
				{
					qnprintf(line, "Error opening the highscore file");
				} else {
					struct _winner wininfo;

					strcpy(wininfo.playername, sgameinfo[CURGAME].players[winner]);
					wininfo.score = sgameinfo[CURGAME].totalscore[winner];
					if (sgameinfo[CURGAME].players[1][0] == 0)
						wininfo.single = 1;
					else
						wininfo.single = 0;
					fwrite(&wininfo, sizeof(struct _winner), 1, f);
					fclose(f);
				}
			}
			gameinfo.gamestatus[CURGAME] = 1;
			memset(&sgameinfo[CURGAME], 0, sizeof(sgameinfo[CURGAME]));
			if ((f = fopen(wofgames, "w")) != 0)
				fwrite(&sgameinfo, sizeof(sgameinfo), 1,  f);
			else { send_lprintf("Can't open file %s for write", wofgames); exit(0); }  
		}
	}
  return(0);
}

start_new_round(int line)
{ 
  FILE *f;
  int combo, newgamenum=0,i,i2, randnum;

  linesingame[line] = STARTNEWGAME;
	if ((f = f_open(puzzles, "r", 1, &combo)) != 0)
	{
#ifdef RANDOMIZE
		randnum = (1+(int) (1086.0*rand()/(RAND_MAX+1.0)));
#else
		randnum = (1+(int) (1.0*rand()/(RAND_MAX+1.0)));
#endif
		for (i = 0; i <= randnum; i++)
		{
			fgets(sgameinfo[CURGAME].puzzle, 127, f);  }
		f_close(f, combo);
	} else qnprintf(line, "Couldn't open %s", puzzles);
	strupr(&sgameinfo[CURGAME].puzzle);
	chop_puzzle(line, sgameinfo[CURGAME].puzzle);
	sgameinfo[CURGAME].totalscore[sgameinfo[CURGAME].whosturn] = sgameinfo[CURGAME].totalscore[sgameinfo[CURGAME].whosturn] + sgameinfo[CURGAME].score[sgameinfo[CURGAME].whosturn];
	for (i = 0; i < 3; i++)
		sgameinfo[CURGAME].score[i] = 0;
	sgameinfo[CURGAME].whosturn = ++sgameinfo[CURGAME].round;
	if (sgameinfo[CURGAME].players[sgameinfo[CURGAME].whosturn][0] == 0)
		inc_turn(line);
	for (i = 0; i < 22; i++)
		sgameinfo[CURGAME].lettersap[i] = '\0';
	for (i = 0; i < 6; i++)
		sgameinfo[CURGAME].vowelap[i] = '\0';
	linesingame[line] = INGAME;
	return(0);
}

list_all_games(int line)
{
	int loop1;
	FILE *f;
	
	qnprintf(line, "[1;33mGame # : [[1;37m%-20.20s[1;33m] [[1;37m%-20.20s[1;33m] [[1;37m%-20.20s[1;33m]\r", "Player 1", "Player 2", "Player 3");
	for (loop1 = 0; loop1 < 256; loop1++)
	{
		if (gameinfo.gamestatus[loop1] == 2)
		{
			char p1[26], p2[26], p3[26];
			
			qnprintf(line, "[1;33mGame #[1;37m%d[1;33m: [[1;37m%-1s%-19.19s[1;33m] [[1;37m%-1s%-19.19s[1;33m] [[1;37m%-1s%-19.19s[1;33m]\r", 
					loop1, 
					((sgameinfo[loop1].whosturn == 0) ? "*" : ""),
					sgameinfo[loop1].players[0], 
					((sgameinfo[loop1].whosturn == 1) ? "*" : ""),
					sgameinfo[loop1].players[1], 
					((sgameinfo[loop1].whosturn == 2) ? "*" : ""),
					sgameinfo[loop1].players[2]);
		}
	}
	bbs_sendmsg(line, 15);
}

do_prompt(int line)
{
	char puzzle[81];

	switch (linesingame[line])
	{
		case GETLETTER:
			qnprintf(line, "Pick a Letter: ");
			break;
		case GETVOWEL:
			qnprintf(line, "Pick a Vowel: ");
			break;
		case AREYOUSURE:
			qnprintf(line, "Are you sure you want to try to solve (y/N): ");
			break;
		case GETGUESS:
				strcpy(puzzle, sgameinfo[CURGAME].puzzle);
				qnprintf(line, "\rCurrent Letters Showing: %s\r", getcurpuzzle(line, puzzle));
				qnprintf(line, "       Enter Your Guess: ");
		case LEAVING:
		case INGAME:
		case INGAMECMD:
		case STARTNEWGAME:
		case JOINOLDGAME:
		case LEAVINGGAME:
		case PRINTMAINMENU:
		case MAINMENUCMD:
		case VIEWSCORES:
		default:
				qnprintf(line, "[1;37m> ");
				break;
	}
}

/*
** A high score displaying example for wofalken
*/


view_high_scores(int line)
{
  int loop1, loop2, loop3, total_records, file_lock, total_high_scores = 0;
  char string[200];
	char buffer[2048];
	//char test[80];
	char score[20];
	char score2[20];
  FILE *infile;
  struct _winner topscores[20], tmp;
	struct _winner stopscores[20];
 
  
  total_high_scores = 0;
  total_records = file_size2(highscore) / sizeof(struct _winner);
  if((infile = f_open(highscore, "rb", 1, &file_lock)) == NULL)
  { 
		qnprintf(line, "\rError opening highscore.dat file.\r");
    return(1);
  }
  memset(&topscores[0], 0, sizeof(struct _winner) * 20);
  //qnprintf(line, "\rFilesize (%d)\r", total_records);
  for(loop1 = 0; loop1 < total_records; loop1++)
  { 
		if(fread(&tmp, sizeof(struct _winner), 1, infile) != 1)
		  qnprintf(line, "\rError reading in record %d (%s).\r", loop1, strerror(errno));
		//qnprintf(line, "\r%s -TEST- %d -TEST- %d", tmp.playername, tmp.score, tmp.single);
    if(tmp.single)
    { 
			for(loop2 = 0; loop2 < 20; loop2++)
      { 
				if((tmp.score > topscores[loop2].score)) 
        { 
          if(total_high_scores)
          { for(loop3 = total_high_scores; loop3 > loop2; loop3--)
              memcpy(&topscores[loop3], &topscores[loop3 - 1], sizeof(struct _winner));
		  	  }
			 		memcpy(&topscores[loop2], &tmp, sizeof(struct _winner));
					total_high_scores++;
					break;
        }     
      }
    }
  }
	memcpy(&stopscores[0], &topscores[0], sizeof(struct _winner) * 20);
	total_high_scores = 0;
  fseek(infile, 0L, SEEK_SET);
  memset(&topscores[0], 0, sizeof(struct _winner) * 20);
  for(loop1 = 0; loop1 < total_records; loop1++)
  { 
		fread(&tmp, sizeof(struct _winner), 1, infile);
    if(!tmp.single)
    { 
			for(loop2 = 0; loop2 < 20; loop2++)
      { 
				if(tmp.score > topscores[loop2].score)
        { if(total_high_scores)
          {	for(loop3 = total_high_scores; loop3 > loop2; loop3--)
              memcpy(&topscores[loop3], &topscores[loop3 - 1], sizeof(struct _winner));
          }
          memcpy(&topscores[loop2], &tmp, sizeof(struct _winner));
          total_high_scores++;
					break;
        }
      }
    }
  }
	qnprintf(line, " [1;34m���[ [1;33mSingle Player Highscores [1;34m]��         ��[ [1;33mMulti-Player High Scores [1;34m]�Ŀ\r");
	qnprintf(line, " [1;34m��[ [1;33mName            [1;34m]�[ [1;33mScore [1;34m]�������������[ [1;33mName            [1;34m]�[ [1;33mScore [1;34m]��\r");
  for(loop1 = 0; loop1 < 20; loop1++)
	{
		char num[3];
		sprintf(num, "%d", loop1+1);
		sprintf(score,  "%d", stopscores[loop1].score);
		if (score[0] == '0')
			strcpy(stopscores[loop1].playername, "-----------------");
		sprintf(score2, "%d", topscores[loop1].score);
		if (score2[0] == '0')
			strcpy(topscores[loop1].playername, "-----------------");
    sprintf(buffer, "[1;34m%2.2s[1;33m) [1;37m%-17.17s   %-7.7s[11C[1;34m%2.2s[1;33m) [1;37m%-17.17s   %-7.7s\r", num, stopscores[loop1].playername, score, num, topscores[loop1].playername, score2);
		sendtoline(line, buffer);
	}
	bbs_sendmsg(line, 15);
  f_close(infile, file_lock);
}      

file_size2(char *path)
{
	FILE *f;
	long a;
	
	if ((f = fopen(path, "r")) != 0)
	{
		fseek(f, 0, SEEK_END);
		a = ftell(f);
		fclose(f);
		return(a);
	}
	return(-1);
}

void main(int argc, char *argv[])
{    
  int int1,i;  
  FILE *f;
  
  if (strcmp(argv[1],"init") == 0)
  {
    f = fopen("games.dat", "w");
    for (i=1; i <= 255; i++)
      fputc(1, f);
    fputc('\n',f);
    fclose(f);
    f = fopen("wofgames.dat", "w");
    fwrite(&sgameinfo, sizeof(sgameinfo), 1, f);
    fclose(f);
		f = fopen("highscore.dat", "w");
		fclose(f);
    exit(0);
  }
  if (argc == 1) {
    sprintf(gamedata, "%sgames.dat", "./");
    sprintf(puzzles, "%spuzzles.dat", "./");
    sprintf(wofgames, "%swofgames.dat", "./");
    sprintf(highscore, "%shighscore.dat", "./");
  } else {
    if (argv[1][strlen(argv[1])-1] == '/')
    { sprintf(gamedata, "%sgames.dat", argv[1]);
      sprintf(puzzles, "%spuzzles.dat", argv[1]);
      sprintf(wofgames, "%swofgames.dat", argv[1]);
      sprintf(highscore, "%shighscore.dat", argv[1]);
    }
    else
    {
      sprintf(gamedata, "%s/games.dat", argv[1]);
      sprintf(puzzles, "%s/puzzles.dat", argv[1]);
      sprintf(wofgames, "%s/wofgames.dat", argv[1]);
      sprintf(highscore, "%s/highscore.dat", argv[1]);
    }
  }
  int1 = make_daemon();
  init();
  if(int1 < 0)
  { wakeup(myuser->u_doortcb);
    exit(0);
  }  
  init_program();
  while(1)
  { 
    main_game_loop();

  }
}

void init_program()
{ 
  int loop1;
  
  for(loop1 = 0; loop1 < numlines; loop1++)
    linesingame[loop1] = 0;
}

int get_message()
{
  int ploop, count, int1;
  extern struct mdbrec *dequeue_mdb(int);
  struct mdbrec *msgqbuf;
  char string[81];
  
  for(;; relinq())
  { count = 0;
    for(ploop = 0; ploop < numlines; ploop++)
    { 
      if((user[ploop].u_stat == st_extern) && (strcasecmp(user[ploop].doors_id, DOORID) == 0))
      { 
        if(linesingame[ploop] == usergone)	/* New Entry	*/
          add_user(ploop);
	else if((msgqbuf = dequeue_mdb(user[ploop].door_inq)) != NULL)
	{ 
          if(msgqbuf->command == F_CMD_KILLTASK)
	  { release_mdb(msgqbuf);
	    remove_user(ploop);
	  } 
          else if(msgqbuf->command == F_CMD_TEXTIN) 
          { 
            int1 = copy_from_buffers(command_string, ibufsz - 1, msgqbuf);
	    command_string[int1] = '\0';
	    release_mdb(msgqbuf);
	    return(ploop);
	  }
	  else release_mdb(msgqbuf);
        }
        count++;	  
      }
      else if(linesingame[ploop] > usergone && strcasecmp(user[ploop].doors_id, DOORID) != 0)
        remove_user(ploop);
    }
    if(count == 0)
      exit(0);
  }
}      

void remove_user(int line)
{ 

  wakeup(user[line].u_doortcb);
  relinq();
  playerinfo[line].curgame = -1;
  linesingame[line] = usergone;
  pid_monitor_off(line);
}  
  
void add_user(int line)
{ 
  linesingame[line] = userhere;
	CURGAME = -1;
  pid_monitor(line);
	linesingame[line] = 1;
	do_menu(line, 1);
  relinq();
}  
    
