#include <stdio.h>
#include "doorutil.h"
#include "defs.h"

void main(int argc, char *argv[])
{
	FILE *f;
	char buffer[1000];
  int j, k, age = 0, age2 = 0, loop1, int1;
  char password[21], string[22], datapath[64],fname[76];
  
  password[0] = 0;  
  strcpy(datapath, argv[1]);
	
	if (argc == 1) 
		sprintf(datapath, "%s", "./");
	else
		if (argv[1][strlen(argv[1])-1] == '/')
		 sprintf(datapath, "%s", argv[1]);
		else 
			sprintf(datapath, "%s/", argv[1]);

  for(loop1 = 2; loop1 < argc; loop1++)
  { if(argv[loop1][0] == '/')
    { switch(toupper(argv[loop1][1]))
      { case 'P':
          strncpy(password, &argv[loop1][3], 20);
          break;
        case 'A':
          age = atoi(&argv[loop1][3]);
          break;
      }
    }
  }
  init();
  if(age)
  { age2 = compute_age(myacct->birthday.month, myacct->birthday.day, myacct->birthday.year);
    if(age2 < age)
    { qprintf("\r\x1b[0;32mYou are to young for this program.\x1b[0m\r\r");
      return;
    }
  }
  if(strlen(password))
  { qprintf("\r\x1b[0;32mThis program is password protected, please enter a valid password.\r: \x1b[0;1m");
    qgets(string, 21);
    if(strcasecmp(string, password) != 0)
    { qprintf("\r\x1b[0;32mInvalid password, returning you to the main menu.\x1b[0m\r");
      return;
    }
  }    
	if (!(myacct->accessflags & tlcf_access))
	{
		qprintf("You do not have access to the Teleconference yet.\rPlease wait until you are validated.\r");
		exit(0);
	}
  hog();
  for(loop1 = 0; loop1 < numlines; loop1++)
  { if(strcasecmp(user[loop1].doors_id, DOORID) == 0)
      break;
  }
  if(loop1 == numlines)
  { 
    sprintf(fname, "%sqtc %s", datapath, datapath);
    if((int1 = load_a_door(fname)) < 0)
    { 
			qprintf("\r\x1b[0;32mError loading main engine, returning you to the bbs.\x1b[0m\r");
      exit(0);
    }
  }
  nohog();
  sprintf(fname, "%s/welcome.ans", datapath, datapath);
	if ((f = fopen(fname, "r")) != 0)
	{
		while (!feof(f))
		{
			fgets(buffer, 999, f);
			qprintf("%s\r", buffer);
		}
		fclose(f);
	}
  strcpy(myuser->doors_id, DOORID);
  suspend();
  exit(0);
}

compute_age(int month, int day, int year)
{
  struct tm *t;
  int j, k;
  time_t t1;
  
  t1 = time(NULL);
  t = localtime(&t1);
  j = (t->tm_year + 1900) - year;
  k = month - t->tm_mon;
  if(k == 0)
    k = day - t->tm_mday;
  if(k > 0)
    j--;
  return (j);
}

