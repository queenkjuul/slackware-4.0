
/***************************************************************************
Copyright (C) 1998  Eric Kilfoil (kewjhoe) eric@ipass.net

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

The author can be reached at eric@ipass.net

****************************************************************************/

// If you make any changes, please send them to me.  I will place all
// changes on my FTP Site and will make a web database of modifcations as
// well.  (eventually)
// All softare derived from this code *MUST BE LICENSED UNDER THE GNU GPL*
//
// Here is fair warning.. set your tab stops to 2 :)
//
// I'm bad about commenting code, if you have a question about something,
// feel free to send it to me.
//
// Turn on -Wall if you wish.  But there's about a billion warnings.

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "doorutil.h"

#define MAXLINES 64
#define maxlines MAXLINES + 1
#define userhere 1
#define usergone 0
#define MAINNUM -1


char command_string[10240];

int linesintc[maxlines];

int logging;

void add_user(int line);
void remove_user(int line);
void init_program();
char *parse_ui(char *input, char *ewwietext);
char *parse_color_codes(char *input);
void get_config(void);
int get_message();
void log_line(char *logentry);
char *make_recip_string(int line, char *format);
char *get_topic(int line);
int numactions;

char df[64];

//this would be prettier in a struct
char beep[maxlines];
char echo[maxlines];
char gagged[maxlines];
char banned[maxlines];
char username[maxlines][uidlen];
long timein[maxlines];

struct _action {
	char actionname[21];
	char returntext[81];
	char reciptext[81];
	char regtext[81];
} action;

char **actionlist;


#include "defs.h"


char *make_string(int line, char *format, int recip);
char userdata[64];
char badwords[64][30];

struct _tcuser {
	char acctnum[12];
	char acctname[uidlen];
	char entmessage[80];
	char extmessage[80];
	char beep;
	char gagged;
	char banned;
	char echo;
	char topic[30];
	char extra[66];
} tcuser, usereditor;

struct _channellist {
	char name[uidlen];
	char open;
	char invited[maxlines];
} channellist[maxlines];

struct _action newaction;

int channel[maxlines];

char actionstring[1024];

#define IN_TC						1
#define EDIT_PREFS			2
#define GET_ENT					3
#define GET_EXT					4
#define GET_TOPIC				5
#define SYS_EDIT_PREFS	90
#define SYS_GET_ENT			91
#define SYS_GET_EXT			92
#define SYS_GET_TOPIC		93
#define EDIT_ACTION			100
#define ADD_ACT1				101
#define ADD_ACT2				102
#define SET_REGTEXT			106
#define SET_RETTEXT			107
#define SET_RECIPTEXT		108
#define CONFIRM_SAVE		109
#define ED_ACT1					110
#define ED_ACT2					111
#define CONFIRM_SAVE_ED	112
#define DEL_ACT					113


void main_game_loop(void)
{
  int line = -1, outtahere=0;
  int ctr, combo, flag, loop1;
	char temp[80];
	char fname[64];
	int whatchadoin;
  FILE *f;

	srand(time(NULL));
	read_bad_words();
  for (;; relinq())
  { 

		if ((line != -1) && (outtahere != 1)) 
			do_prompt(line);
    line = get_message();
		outtahere=0;
    if ((strcmp(command_string, "EXITNOW") == 0) && (priv_user(line)))
		{
			send_to_all(line, "%s is restarting the teleconference\r\r", acnt[line].acctname);
			exit(0);
		}
		if (((strcasecmp(command_string, "x") == 0) || 
				(strcasecmp(command_string, "q") == 0) || 
				(strcasecmp(command_string, ".exit") == 0) || 
				(strcasecmp(command_string, "/exit") == 0) || 
				(strcasecmp(command_string, "exit") == 0) || 
				(strcasecmp(command_string, "quit") == 0) || 
				(strcasecmp(command_string, ".quit") == 0) || 
				(strcasecmp(command_string, "/quit") == 0)) &&
					(linesintc[line] == IN_TC))
		{
			remove_user(line);
			outtahere=1;
		} else {
			switch(linesintc[line])
			{
				case IN_TC:
					if (strlen(command_string)) {
						if (!command_test(line))
							if ((!gagged[line]) && (!user[line].gag))
							{
								if (!wirty_dord(command_string))
								{
									send_to_everyone(command_string, line);
								} else
									qnprintf(line, "Your last message contained a word which is not allowed to be used in\rthe teleconference.  The message was not sent.\r");
							} else
								qnprintf(line, "You are gagged.  You cannot send anything to the teleconference.\r");
					} else {
						print_who_list(line);
					}
					break;
				case SYS_EDIT_PREFS:
					if (toupper(command_string[0]) == '1')
					{
						qnprintf(line, "Enter Entrance Message Now (max 79 chars)\r:");
						linesintc[line] = SYS_GET_ENT;
					}
					if (toupper(command_string[0]) == '2')
					{
						qnprintf(line, "Enter Exit Message Now (max 79 chars)\r:");
						linesintc[line] = SYS_GET_EXT;
					}
					if (toupper(command_string[0]) == '3')
					{
						qnprintf(line, "Enter Channel Topic\r:");
						linesintc[line] = SYS_GET_TOPIC;
					}
					if (toupper(command_string[0]) == 'G')
					{
						gag_user(line);
						print_sysop_acct_editor(line);
					}
					if (toupper(command_string[0]) == 'B')
					{
						ban_user(line);
						print_sysop_acct_editor(line);
					}
					if (toupper(command_string[0]) == 'Q')
					{
						linesintc[line] = IN_TC;
						sprintf(temp, "[2D[1;33m%s has returned.\r", acnt[line].acctname);
						send_to_all(line, temp);
					}
					break;
				case EDIT_PREFS:
					if (toupper(command_string[0]) == '1')
					{
						qnprintf(line, "Enter your Entrance Message Now (max 79 chars)\r:");
						linesintc[line] = GET_ENT;
					}
					if (toupper(command_string[0]) == '2')
					{
						qnprintf(line, "Enter your Exit Message Now (max 79 chars)\r:");
						linesintc[line] = GET_EXT;
					}
					if (toupper(command_string[0]) == '3')
					{
						qnprintf(line, "Enter your Channel Topic\r:");
						linesintc[line] = GET_TOPIC;
					}
					if (toupper(command_string[0]) == 'B')
					{
						if (beep[line])
							beep[line] = 0;
						else
							beep[line] = 1;
						print_pref_menu(line);
					}
					if (toupper(command_string[0]) == 'E')
					{
						if (echo[line])
							echo[line] = 0;
						else
							echo[line] = 1;
						print_pref_menu(line);
					}
					if (toupper(command_string[0]) == 'S')
					{
						save_settings(line);
					}
					if (toupper(command_string[0]) == 'Q')
					{
						linesintc[line] = IN_TC;
						sprintf(temp, "[2D[1;33m%s has returned.\r", acnt[line].acctname);
						send_to_all(line, temp);
						//do_prompt(line);
					}
					break;
				case EDIT_ACTION:
					if (toupper(command_string[0]) == 'A')
					{
						qnprintf(line, "Enter the name of the new action: ");
						linesintc[line] = ADD_ACT1;
					}
					if (toupper(command_string[0]) == 'Q')
					{
						sprintf(temp, "[2D[1;33m%s has returned from the OAE.\r", acnt[line].acctname);
						send_to_all(line, temp);
						linesintc[line] = IN_TC;
					}
					if (toupper(command_string[0]) == 'E') {
						qnprintf(line, "Enter the name of the action to edit: ");
						linesintc[line] = ED_ACT1;
					}
					if (toupper(command_string[0]) == 'D') {
						qnprintf(line, "Enter the name of the action to delete: ");
						linesintc[line] = DEL_ACT;
					}
					break;
				case ED_ACT1:
					if (strlen(command_string))
					{
						whatchadoin = 1;
						memset(&newaction, 0, sizeof(struct _action));
						sprintf(fname, "%sactions.dat", df);
						if ((f = fopen(fname, "r")) == 0)
						{
							qnprintf(line, "Couldn't open file for read\r");
							sleep(1);
							print_edit_action_menu(line);
						} else {
							for (ctr=0; ctr < numactions; ctr++)
								if (strcasecmp(command_string, actionlist[ctr]) == 0)
									break;
							if (ctr == numactions)
							{
								qnprintf(line, "Action not found.\r");
								sleep(1);
								print_edit_action_menu(line);
							} else {
								fseek(f, sizeof(struct _action) * ctr, SEEK_SET);
								fread(&newaction, sizeof(struct _action), 1, f);
								print_action_edit_screen(line);
							}
						}
					} else {
						print_edit_action_menu(line);
						linesintc[line] = EDIT_ACTION;
					}
					break;
				case DEL_ACT:
					if (strlen(command_string))
					{
						char fname2[64];
						FILE *f2;

						memset(&newaction, 0, sizeof(struct _action));
						sprintf(fname, "%sactions.dat", df);
						sprintf(fname2, "%stmpact.dat", df);
						if ((f = fopen(fname, "r")) == 0)
						{
							qnprintf(line, "Couldn't open file for read\r");
							sleep(1);
							print_edit_action_menu(line);
							break;
						} else {
							if ((f2 = fopen(fname2, "w")) == 0)
							{
								qnprintf(line, "Couldn't open file for write\r");
								sleep(1);
								print_edit_action_menu(line);
								fclose(f);
								break;
							} else {
								for (ctr=0; ctr < numactions; ctr++)
									if (strcasecmp(command_string, actionlist[ctr]) == 0)
										break;
								if (ctr == numactions)
								{
									qnprintf(line, "Action not found.\r");
									sleep(1);
									print_edit_action_menu(line);
								} else {
									loop1=0;
									while (fread(&newaction, sizeof(struct _action), 1, f))
									{
										if (ctr != loop1)
											fwrite(&newaction, sizeof(struct _action), 1, f2);
										loop1++;
									}
									fclose(f);
									fclose(f2);
									rename(fname2, fname);
									for (ctr = 0; ctr < numactions; ctr++)
										free(actionlist[ctr]);
									init_actions();
									print_edit_action_menu(line);
								}
							}
						}
					} else {
						print_edit_action_menu(line);
						linesintc[line] = EDIT_ACTION;
					}
					break;
				case ADD_ACT1:
					if (strlen(command_string))
					{
						memset(&newaction, 0, sizeof(struct _action));
						strncpy(newaction.actionname, command_string, 20);
						for (ctr=0; ctr < numactions; ctr++)
							if (strcasecmp(command_string, actionlist[ctr]) == 0)
								break;
						if (ctr == numactions)
							print_action_screen(line);
						else {
							qnprintf(line, "This action already exists.  You can only edit it.\r");
							linesintc[line] = EDIT_ACTION;
						}
					} else {
						print_edit_action_menu(line);
						linesintc[line] = EDIT_ACTION;
					}
					break;
				case ADD_ACT2:
					whatchadoin = 0;
					if (toupper(command_string[0]) == '1')
						linesintc[line] = SET_RETTEXT;
					if (toupper(command_string[0]) == '2')
						linesintc[line] = SET_REGTEXT;
					if (toupper(command_string[0]) == '3')
						linesintc[line] = SET_RECIPTEXT;
					if (toupper(command_string[0]) == 'Q')
					{
						linesintc[line] = CONFIRM_SAVE;
					}
					break;
				case ED_ACT2:
					whatchadoin = 1;
					if (toupper(command_string[0]) == '1')
						linesintc[line] = SET_RETTEXT;
					if (toupper(command_string[0]) == '2')
						linesintc[line] = SET_REGTEXT;
					if (toupper(command_string[0]) == '3')
						linesintc[line] = SET_RECIPTEXT;
					if (toupper(command_string[0]) == 'Q')
					{
						linesintc[line] = CONFIRM_SAVE_ED;
					}
					break;
				case CONFIRM_SAVE_ED:
					if (toupper(command_string[0]) == 'Y')
					{
						sprintf(fname, "%sactions.dat", df);
						if ((f = fopen(fname, "r+")) == 0)
						{
							qnprintf(line, "ACTION NOT SAVED! Couldn't open file for append\r");
							sleep(1);
							print_edit_action_menu(line);
						} else {
							for (ctr=0; ctr < numactions; ctr++)
								if (strcasecmp(newaction.actionname, actionlist[ctr]) == 0)
									break;
							if (ctr == numactions)
							{
								qnprintf(line, "Action not found - Couldn't write.\r");
								sleep(1);
								print_edit_action_menu(line);
							} else {
								fseek(f, sizeof(struct _action) * ctr, SEEK_SET);
								if (!fwrite(&newaction, sizeof(struct _action), 1, f))
								{
									qnprintf(line, "Action File Rewrite FAILED!!!");
									sleep(2);
								}
								fclose(f);
								for (ctr = 0; ctr < numactions; ctr++)
									free(actionlist[ctr]);
								init_actions();
								print_edit_action_menu(line);
							}
						}
					} else {
						qnprintf(line, "Modifications discarded\r");
						print_edit_action_menu(line);
						linesintc[line] = EDIT_ACTION;
					}
					break;
				case CONFIRM_SAVE:
					if (toupper(command_string[0]) == 'Y')
					{
						sprintf(fname, "%sactions.dat", df);
						if ((f = fopen(fname, "a")) == 0)
						{
							qnprintf(line, "ACTION NOT SAVED! Couldn't open file for append\r");
							sleep(1);
							print_edit_action_menu(line);
						} else {
							fwrite(&newaction, sizeof(struct _action), 1, f);
							fclose(f);
							for (ctr = 0; ctr < numactions; ctr++)
								free(actionlist[ctr]);
							init_actions();
							sort_actions(line);
							init_actions();
							qnprintf(line, "Actions sorted\r");
							print_edit_action_menu(line);
						}
					} else {
						qnprintf(line, "Modifications discarded\r");
						linesintc[line] = EDIT_ACTION;
					}
					break;
				case SET_RETTEXT:
					strncpy(newaction.returntext, command_string, 80);
					print_action_screen(line);
					if (whatchadoin)
						linesintc[line] = ED_ACT2;
					else
						linesintc[line] = ADD_ACT2;
					break;
				case SET_REGTEXT:
					strncpy(newaction.regtext, command_string, 80);
					print_action_screen(line);
					if (whatchadoin)
						linesintc[line] = ED_ACT2;
					else
						linesintc[line] = ADD_ACT2;
					break;
				case SET_RECIPTEXT:
					strncpy(newaction.reciptext, command_string, 80);
					print_action_screen(line);
					if (whatchadoin)
						linesintc[line] = ED_ACT2;
					else
						linesintc[line] = ADD_ACT2;
					break;
				case SYS_GET_ENT:
					sys_set_message(line, 0);
					break;
				case SYS_GET_EXT:
					sys_set_message(line, 1);
					break;
				case SYS_GET_TOPIC:
					sys_set_message(line, 2);
					break;
				case GET_ENT:
					set_message(line, 0);
					break;
				case GET_EXT:
					set_message(line, 1);
					break;
				case GET_TOPIC:
					set_message(line, 2);
					break;
				default:
					break;
			}
		}
  }
}

send_to_everyone(char *message, int line)
{
  int loop1;
	int loop2;
	char tmp[20480];
	char notes[uidlen+30];
	char notes2[uidlen+40] = "";
	int linematch=(-1);
  
	message = parse_color_codes(message);
	if (message[0] == '/')
	{
    message = message + 1;
		linematch = find_matching_user(line, message, 0);
		if (linematch == (-1))
		{
			qnprintf(line, "[2DThere is no one in here that matches that name\rThe user must be in the teleconference to use whispers. To send a message\rto someone that is not in the teleconference, use:  .send username message\r");
			return(0);
		} else if (linematch == (-100)) {
			qnprintf(line, "[2DThat could be more than one person.  Please be more specific.\r");
			return(0);
		} else {
			if (!strlen(message))
			{
				qnprintf(line, "You need to type a message to send\r");
				return(0);
			}
			qnprintf(linematch, "[2D%sWhisper From %s%s%s: %s%s\r", WHISPER, WHISPERNAME, acnt[line].acctname, PARENS, MESSAGETEXT, message);
			do_prompt(linematch);
			qnprintf(line, "[2D%sWhisper Sent\r", WHISPER);
			return(0);
		}
	}
	if (message[0] == '>')
	{
    message++;
		linematch = find_matching_user(line, message, 1);
		if (linematch == (-1)) {
	    qnprintf(line, "There is no one in here that matches that name\r");
			return(0);
		} else if (linematch == (-100)) {
			qnprintf(line, "[2DThat could be more than one person.  Please be more specific.\r");
			return(0);
		} else {
			if (linematch == line)
				sprintf(notes, " %s(%sto %sself?%s): %s", PARENS, DIRECTMSG, (acnt[line].sex ? "him" : "her"), PARENS, MESSAGETEXT);
			else 
				sprintf(notes, " %s(%sto %s%s): %s", PARENS, DIRECTMSG, acnt[linematch].acctname, PARENS, MESSAGETEXT);
			sprintf(notes2, " to %s", acnt[linematch].acctname);
			if (!strlen(message))
			{
				qnprintf(line, "You need to type a message to send\r");
				return(0);
			}
		}
	} else 
		sprintf(notes, "%s: %s", PARENS, MESSAGETEXT);
  sprintf(tmp, "[2D%sFrom %s%s%s%s", FROM, NAME, acnt[line].acctname, notes, message);
	if (logging)
		log_line(tmp);
  for (loop1=0; loop1 < numlines; loop1++)
  {
		if (linesintc[loop1] == IN_TC)
		{
			if (channel[line] == channel[loop1])
			{
				if ((loop1 != line) || (echo[line]))
				{
					if((user[loop1].u_stat == 6) && (strcasecmp(user[loop1].doors_id, DOORID) == 0))
					{
						if ((linematch == loop1))
						{
							qnprintf(loop1, "[2D%s%sFrom %s%s %s(%sto [1;31mYOU%s): %s%s\r", (beep[loop1] == 1) ? "" : "", FROM, NAME, acnt[line].acctname, PARENS, DIRECTMSG, PARENS, MESSAGETEXT, message);
							do_prompt(loop1);
						} else {
							qnprintf(loop1, "%s\r", tmp);
							do_prompt(loop1);
						}
					}
				} else {
					qnprintf(line, "[2D%s%s%s\r", MESGSENT, MSGSENTTEXT, notes2);

					if (linematch == line)
						qnprintf(line, "[2D%sFrom %s%s %s(%sto yourself?%s): %s%s\r", FROM, NAME, acnt[line].acctname, PARENS, DIRECTMSG, PARENS, MESSAGETEXT, message);
				}
			}
		}
  }
}

do_prompt(int line)
{
	switch(linesintc[line])
	{
		case EDIT_PREFS:
			qnprintf(line, "Teleconf Preferences Menu: ");
			break;
		case ED_ACT1:
		case DEL_ACT:
		case ADD_ACT1:
			break;
		case SET_REGTEXT:
			qnprintf(line, "Enter a new NON-RECIPIENT text string (80 chars max):\r");
			break;
		case CONFIRM_SAVE:
		case CONFIRM_SAVE_ED:
			qnprintf(line, "Do you wish to save this action and re-init the database [Y/n]: ");
			break;
		case SET_RETTEXT:
			qnprintf(line, "Enter a new RETURN text string (80 chars max):\r");
			break;
		case SET_RECIPTEXT:
			qnprintf(line, "Enter a new RECIPIENT text string (80 chars max):\r");
			break;
		case EDIT_ACTION:
		case ED_ACT2:
		case ADD_ACT2:
			qnprintf(line, "Action Editor: ");
			break;
		default:
			qnprintf(line, "[2D%s%s %s", PROMPT, PROMPTTEXT, INPUTTEXT);
			break;
	}
}

command_test(int line)
{
	FILE *f;
	int loop1 = 0, ctr=0;
	int total_records;
	int action_num=0;
	char fname[64];
	char entmessage[80];
	char extmessage[80];
	char temp[255];
	char message[strlen(command_string+1)];
	char buffer[10240];
	
	loop1=0;
	strcpy(buffer, "");
	while(command_string[loop1])
	{
		if (command_string[loop1] != 32)
			break;
		loop1++;
	}
	if (strlen(command_string) == loop1)
	{
		print_who_list(line);
		return(1);
	}
	strcpy(message, command_string);
	if ((strcasecmp(command_string, "/join") == 0) || 
			(strcasecmp(command_string, "join") == 0) ||
			(strcasecmp(command_string, "join ") == 0) ||
			(strcasecmp(command_string, "/join ") == 0) ||
			(strcasecmp(command_string, "/join main") == 0) ||
			(strcasecmp(command_string, "/j") == 0) ||
			(strcasecmp(command_string, "/j ") == 0) ||
			(strcasecmp(command_string, "/j main") == 0))
	{
		if (channel[line] != -1)
		{
			sprintf(buffer, "[2D%s has left this channel.\r", acnt[line].acctname);
			send_to_all(line, buffer);
			channel[line] = -1;
			sprintf(buffer, "[2D%s has joined this channel.\r", acnt[line].acctname);
			send_to_all(line, buffer);
			print_who_list(line);
		}
		return(1);
	} else if ((strncasecmp(command_string, "join ", 5) == 0) ||
						(strncasecmp(command_string, "/j ", 3) == 0)) {
		if (strncasecmp(command_string, "/j ", 3) == 0)
			strncpy(temp, command_string+3, 79);
		else
			strncpy(temp, command_string+5, 79);
		temp[79] = 0;
		for (loop1 = 0; loop1 < numlines; loop1++)
		{
			if (strcasecmp(acnt[loop1].acctname, temp) == 0)
			{
				if ((strlen(channellist[loop1].name)) || (line == loop1))
				{
					if ((invited(line, loop1)) || (line == loop1))
					{
						if (!strlen(channellist[loop1].name))
						{
							memset(&channellist, 0, sizeof(struct _channellist));
							strcpy(channellist[line].name, acnt[line].acctname);
							channellist[line].open = 0;
						}
						if (channel[line] != loop1)
						{
							sprintf(buffer, "[2D%s has left this channel.\r", acnt[line].acctname);
							send_to_all(line, buffer);
							channel[line] = loop1;
							sprintf(buffer, "[2D%s has joined this channel.\r", acnt[line].acctname);
							send_to_all(line, buffer);
							print_who_list(line);
						}
					} else {
						qnprintf(line, "You have not been invited to that channel\r");
					}
				} else {
					qnprintf(line, "That channel is not currently active\r");
				}
				break;
			}
		}
		if (loop1 == numlines)
			qnprintf(line, "That channel does not exist\r");
		return(1);
	} else if ((strcasecmp(command_string, "scan") == 0) ||
						(strcasecmp(command_string, "/s") == 0)) {
		qnprintf(line, "���������������������������������������������������������������������������Ŀ\r");
		qnprintf(line, "�  Username                         Channel                                 �\r");
		qnprintf(line, "�����������������������������������������������������������������������������\r");
		for (loop1 = 0; loop1 < numlines; loop1++)
		{
			if ((user[loop1].u_stat == 6) && (strcasecmp(user[loop1].doors_id, DOORID) == 0))
			{
				if (linesintc[loop1] == IN_TC)
				{
					qnprintf(line, "  %-32.32s %s%s\r", acnt[loop1].acctname, (channel[loop1] == -1) ? "Main" : acnt[channel[loop1]].acctname, (channel[loop1] == -1) ? "" : "'s");
					if (loop1 == channel[loop1])
						qnprintf(line, "                             Topic: (%s)\r", get_topic(loop1));
				} else {
					qnprintf(line, "  %-32.32s ", acnt[loop1].acctname);
					// Print other locations
					switch(linesintc[loop1])
					{
						case 2:
						case 3:
						case 4:
						case 5:
							qnprintf(line, "Editing Preferences\r");
							break;
						case 90:
						case 91:
						case 92:
						case 93:
							qnprintf(line, "Sysop User Editor\r");
							break;
						default:
							qnprintf(line, "Online Action Editor\r");
							break;
					}
				}
			}
		}
		return(1);
	} else if ((strcasecmp(command_string, "close") == 0) ||
						(strcasecmp(command_string, "/c") == 0)) {
		if (channel[line] == line)
		{
			if (channellist[line].open == 1)
			{
				channellist[line].open = 0;
				qnprintf(line, "Your channel is now closed.  You must invite people before they can enter.\r");
			} else
				qnprintf(line, "Your channel is already closed\r");
		} else
			qnprintf(line, "You must be in your channel to set it open or closed\r");
		return(1);
	} else if ((strcasecmp(command_string, "open") == 0) ||
						(strcasecmp(command_string, "/o") == 0)) {
		if (channel[line] == line)
		{
			if (channellist[line].open == 0)
			{
				qnprintf(line, "Your channel is now open to everyone.\r");
				channellist[line].open = 1;
			} else
				qnprintf(line, "Your channel is already open\r");
		} else
			qnprintf(line, "You must be in your channel to set it open or closed\r");
		return(1);
	} else if ((strncasecmp(command_string, "uninvite ", 9) == 0) ||
						(strncasecmp(command_string, "/u ", 3) == 0)) {
		if (strncasecmp(command_string, "/u ", 3) == 0)
			strncpy(temp, command_string+3, 79);
		else
			strncpy(temp, command_string+9, 79);
		temp[79] = 0;
		for (loop1 = 0; loop1 < numlines; loop1++)
		{
			if (strcasecmp(acnt[loop1].acctname, temp) == 0)
			{
				if (loop1 != line)
				{
					if (invited(loop1, line))
					{
						channellist[line].invited[loop1] = 0;
						qnprintf(loop1, "\r[2D%s has uninvited you from %s channel.\r\r", acnt[line].acctname, acnt[line].sex ? "his" : "her");
						qnprintf(line, "You have uninvited %s from your channel.\r", acnt[loop1].acctname);
						if (channel[loop1] == line)
						{
							channel[loop1] = -1;
							sprintf(buffer, "%s has been uninvited and kicked from the channel.\r", acnt[loop1].acctname);
							qnprintf(line, "%s has been kicked from the channel.\r", acnt[loop1].acctname);
							send_to_all(line, buffer);
							print_who_list(loop1);
						}
						do_prompt(loop1);
					} else {
						qnprintf(line, "That user is not currently invited to your channel\r");
					}
					break;
				} else
					qnprintf(line, "You can't uninvite yourself from your own channel.\r");
			}
		}
		return(1);
	} else if ((strncasecmp(command_string, "invite ", 7) == 0) || 
						(strncasecmp(command_string, "/i ", 3) == 0)) {
		if (strncasecmp(command_string, "/i ", 3) == 0)
			strncpy(temp, command_string+3, 79);
		else
			strncpy(temp, command_string+7, 79);
		temp[79] = 0;
		if (channel[line] == line)
		{
			for (loop1 = 0; loop1 < numlines; loop1++)
			{
				if (strcasecmp(acnt[loop1].acctname, temp) == 0)
				{
					if (line != loop1)
					{
						if (!invited(loop1, line))
						{
							channellist[line].invited[loop1] = 1;
							qnprintf(loop1, "[2D%s has invited you to %s channel.\rType 'join %s' to join the channel.\r", acnt[line].acctname, acnt[line].sex ? "his" : "her", acnt[line].acctname);
							do_prompt(loop1);
							qnprintf(line, "You have invited %s to your channel.\r", acnt[loop1].acctname);
						} else {
							qnprintf(line, "That user has already been invited to your channel\r");
						}
						break;
					} else
						qnprintf(line, "You can't invite yourself to your own channel.\r");
				}
			}
		} else {
			qnprintf(line, "You must be in your channel to invite people.\r");
		}
		return(1);
	} else if (strcasecmp(command_string, "edit") == 0) {
		sprintf(temp, "[2D[1;33m%s has left to edit %s preferences\r", acnt[line].acctname, (acnt[line].sex) ? "his" : "her");
		send_to_all(line, temp);
		sprintf(fname, "%stcuser.dat", df);
		total_records = file_size(fname) / sizeof(struct _tcuser);
		sprintf(fname, "%stcuser.dat", df);
		if ((f = fopen(fname, "r+")) == 0)
		{
			send_lprintf("QTC: Couldn't open %stcuser.dat", df);
			return(1);
		} else {
			while(fread(&tcuser, sizeof(struct _tcuser), 1, f))
			{
				if (strcmp(acnt[line].acctnum, tcuser.acctnum) == 0) {
					break;
				}
				loop1++;
			}
			fclose(f);
		}
		if (loop1 == total_records)
		{
			strcpy(tcuser.acctname, acnt[line].acctname);
			strcpy(tcuser.acctnum, acnt[line].acctnum);
			tcuser.entmessage[0] = 0;
			tcuser.extmessage[0] = 0;
			qnprintf(line, "\rWrote your (new) Information at byte position %d", ftell(f));
			if ((f = fopen(fname, "a")) == 0)
			{
				send_lprintf("QTC: Couldn't open %stcuser.dat", df);
				return(1);
			} else {
				fwrite(&tcuser, sizeof(struct _tcuser), 1, f);
				fclose(f);
			}
		}
		print_pref_menu(line);
		return(1);
	} else if (strncasecmp(command_string, "edit ", 5) == 0) {
		int total_records;

		if (priv_user(line))
		{
			for (loop1 = 0; loop1 < numlines; loop1++)
			{
				if ((linesintc[loop1] >= 90) && (linesintc[loop1] < 100))
				{
					qnprintf(line, "Another user is currently in the account editor\r");
					return(1);
				}
			}
			sprintf(temp, "[2D[1;33m%s has left to edit a user.\r", acnt[line].acctname);
			send_to_all(line, temp);
			strncpy(temp, command_string+5, 79);
			temp[79] = 0;
			sprintf(fname, "%stcuser.dat", df);
			total_records = file_size(fname) / sizeof(struct _tcuser);
			if ((f = fopen(fname, "r+")) == 0)
			{
				qnprintf(line, "Can't open Userfile for update\r");
				return(1);
			} else {
				loop1=0;
				while (fread(&usereditor, sizeof(struct _tcuser), 1, f))
				{
					if (strcasecmp(usereditor.acctname, temp) == 0)
						break;
					loop1++;
				}
				fclose(f);
				if (loop1 == total_records)
					qnprintf(line, "User %s does not have an entry in the userfile\r", temp);
				else
					print_sysop_acct_editor(line);
			}
		}
		return(1);
	} else if (strcasecmp(command_string, "clear") == 0) {
		qnprintf(line, "[2J[1;1H%s%s %s", PROMPT, PROMPTTEXT, INPUTTEXT);
		return(1);
	} else if ((action_num = action_check(line, strtok(message, " "))) != (-1)) {
		if ((!gagged[line]) && (!user[line].gag))
			do_action(line, action_num, message);
		else
			qnprintf(line, "You are gagged.  You cannot send anything to the teleconference.\r");
		return(1);
	} else if (strcasecmp(command_string, "action list") == 0) {
		for (loop1 = 0; loop1 < numactions; loop1+=3)
			qnprintf(line, " %-20s %-20s %-20s\r", actionlist[loop1], (loop1+1 < numactions) ? actionlist[loop1+1] : "", (loop1+2 < numactions) ? actionlist[loop1+2] : "");
		qnprintf(line, "Total Number of Actions: %d\r", numactions);
		qnprintf(line, "%s%s %s", PROMPT, PROMPTTEXT, INPUTTEXT);
		return(1);
	} else if (strcasecmp(command_string, "action search") == 0) {
		qnprintf(line, "[2DYou must specify a word to search for\r");
		qnprintf(line, "  Type:  action search searchspec\r");
		qnprintf(line, "  'searchspec' is the name (or part of a name) to search for.\r");
		qnprintf(line, "  (ie 'action search foo' will show you all the actions with the\r  word 'foo' in the name)\r");
		return(1);
	} else if (strcasecmp(command_string, "action help") == 0) {
		qnprintf(line, "[2DYou must specify an action to get help on\r");
		qnprintf(line, "  Type:  action help actionname\r");
		qnprintf(line, "  'actionname' is the name of the action you want help on\r");
		qnprintf(line, "  (ie 'action help foo' will show you what the 'foo' action does)\r");
		return(1);
	} else if (strcasecmp(command_string, "toggle log") == 0) {
		if (priv_user(line))
		{
			if (logging)
				logging = 0;
			else
				logging = 1;
			qnprintf(line, "Logging is now %s\r", (logging) ? "ON" : "OFF");
			return(1);
		} else {
			return(0);
		}
	} else if (strncasecmp(command_string, "remove ", 7) == 0) {
		if (priv_user(line))
		{
			strncpy(temp, command_string+7, 79);
			temp[79] = 0;
			for (loop1 = 0; loop1 < numlines; loop1++)
				if (strcasecmp(temp, acnt[loop1].acctname) == 0)
					break;
			if (loop1 == numlines)
			{
				qnprintf(line, "User %s Not Found\r", temp);
				return(1);
			}
			if((user[loop1].u_stat == 6) && (strcasecmp(user[loop1].doors_id, DOORID) == 0))
			{
				qnprintf(loop1, "You have been forcibly removed from the Teleconference\r");
				remove_user(loop1);
			} else qnprintf(line, "That user is not in the teleconference\r");
			return(1);
		} else {
			qnprintf(line, "You do not have access to remove people\r");
		}
	} else if (strncasecmp(command_string, "action search ", 14) == 0) {
		strncpy(temp, command_string+14, 79);
		temp[79] = 0;
		qnprintf(line, "The following actions contain the word '%s'\r", temp);
		for (loop1 = 0; loop1 < numactions; loop1++)
			if (strstr(actionlist[loop1], temp))
				qnprintf(line, "%s\r", actionlist[loop1]);
		return(1);
	} else if (strncasecmp(command_string, "action help ", 12) == 0) {
		strncpy(temp, command_string+12, 79);
		temp[79] = 0;
		action_help(line, temp);
		return(1);
	} else if (strcasecmp(command_string, "action edit") == 0) {
		for (loop1 = 0; loop1 < numlines; loop1++)
			if (linesintc[loop1] > 99)
			{
				qnprintf(line, "Someone else is currently in the action editor\r");
				qnprintf(line, "Only one person may edit actions at a time\r");
				return(1);
			}
		if (priv_user(line))
		{
			sprintf(temp, "[2D[1;33m%s has gone into the action editor\r", acnt[line].acctname);
			send_to_all(line, temp);
			print_edit_action_menu(line);
		} else {
			qnprintf(line, "You don't have the priveledge\r");
		}
		return(1);
	} else if ((strcasecmp(command_string, "help") == 0) || 
						(strcasecmp(command_string, "/help") == 0) || 
						(strcasecmp(command_string, ".help") == 0)) {
		qnprintf(line, "[1;33mHelp\r");
		qnprintf(line, "[1;34m-----------------------------------------------------------------------\r");
		qnprintf(line, " [1;33mDirected Messages:\r");
		qnprintf(line, "   [0;36mYou can use the '[1m>[0;36m' character to direct messages to a\r");
		qnprintf(line, "   specific user.  ie if you typed:");
		qnprintf(line, "  [1;36m>chr\r");
		qnprintf(line, "   [0;36mand there was a person named 'Chris,' your message will\r");
		qnprintf(line, "   be directed to Chris.\r");
		qnprintf(line, "\r [1;33mWhispers:\r");
		qnprintf(line, "   [0;36mYou can use the '[1m/[0;36m' character the same as you would for directed\r");
		qnprintf(line, "   messages to \"whisper\" to another user.  ONLY the user you\r");
		qnprintf(line, "   whisper too will see the message\r");
		qnprintf(line, "\r [1;33mEditing Preferences:\r");
		qnprintf(line, "   [0;36mTyping '[1medit[0;36m' will bring you to the preferences editor.\r");
		qnprintf(line, "   You can set an entrance and exit message as well as set\r");
		qnprintf(line, "   your toggles.\r");
		qnprintf(line, "[1;34m-----------------------------------------------------------------------\r");
		qnprintf(line, "  [1;33mhelp channels  [0;36mShows the channel help screen\r");
		qnprintf(line, "  [1;33mhelp colors    [0;36mShows the color help screen\r");
		qnprintf(line, "  [1;33maction list    [0;36mShows a list of actions\r");
		qnprintf(line, "  [1;33maction help    [0;36mWill display what an action does\r");
		qnprintf(line, "  [1;33maction search  [0;36mWill display actions contaning a certain word\r");
		qnprintf(line, "  [1;33mclear          [0;36mClear the screen\r");
		qnprintf(line, "  [1;33mexit (x or q)  [0;36mexit, x, and q all exit the teleconference\r");
		qnprintf(line, "[1;34m-----------------------------------------------------------------------\r");
		if (priv_user(line))
		{
			qnprintf(line, " [1;33mPriveledged User Commands:\r");
			qnprintf(line, "  [1;33mremove         [0;36mRemoves a user from the teleconference\r");
			qnprintf(line, "  [1;33maction edit    [0;36mLets you add, edit, and delete actions\r");
			qnprintf(line, "  [1;33medit <user>    [0;36mEdit a user's TC preferences (strings, gag, ban)\r");
			qnprintf(line, "[1;34m---------------------------------------------------------------------\r");
		}
		return(1);
	} else if ((strcasecmp(command_string, "help channels") == 0) || 
						(strcasecmp(command_string, "/help channels") == 0) || 
						(strcasecmp(command_string, ".help channels") == 0)) {
		qnprintf(line, "[1;33mChannel Help\r");
		qnprintf(line, "[1;34m-----------------------------------------------------------------------\r");
		qnprintf(line, " [1;33mChannels:\r");
		qnprintf(line, "   [0;36mEach user can make their own private channel.  Private channels can\r");
		qnprintf(line, "   be 'open' or 'closed.'  If a channel is open, then anyone can join.\r");
		qnprintf(line, "   If it is closed, then each user must be invited before he/she can join\r");
		qnprintf(line, "   the channel.  When you first create a channel, it will be closed by.\r");
		qnprintf(line, "   default.\r");
		qnprintf(line, "[1;34m-----------------------------------------------------------------------\r");
		qnprintf(line, "  [1;33mscan (or /s)     [0;36mType 'scan' to view everyone in the teleconf\r");
		qnprintf(line, "  [1;33mjoin (or /j)     [0;36mType 'join username' to join a users channel\r");
		qnprintf(line, "  [1;33mjoin main        [0;36mType 'join main' to go back to the main channel\r");
		qnprintf(line, "  [1;33minvite (or /i)   [0;36mType 'invite username' to invite a user\r");
		qnprintf(line, "  [1;33muninvite (or /u) [0;36mType 'uninvite username' to uninvite a user\r");
		qnprintf(line, "                   If the user is in the channel, he/she will be kicked\r");
		qnprintf(line, "  [1;33mopen (or /o)     [0;36mType 'open' to make the channel open\r");
		qnprintf(line, "  [1;33mclose (or /c)    [0;36mType 'close' to close the channel\r");
		qnprintf(line, "[1;34m-----------------------------------------------------------------------\r");
		return(1);
	} else if (strcasecmp(command_string, "help colors") == 0) {
		qnprintf(line, "[1;33mColor Help\r");
		qnprintf(line, "[1;34m-----------------------------------------------------------------------\r");
		qnprintf(line, " [1;33mColors:\r");
		qnprintf(line, "   [0;36mYou can put colors in the text that you write by using the\r");
		qnprintf(line, "   \\ code for the color.  For example:\r");
		qnprintf(line, "          \\05This is purple\r");
		qnprintf(line, "   would print:\r");
		qnprintf(line, "          [0;35mThis is purple\r");
		qnprintf(line, "   [1;33m\r");
		qnprintf(line, "   Color codes are as follows\r");
		qnprintf(line, "[1;33m        \\01 = [0;31mRed            [1;33m\\08 = [1;30mDark Grey\r");
		qnprintf(line, "[1;33m        \\02 = [0;32mGreen          [1;33m\\09 = [1;31mBright Red\r");
		qnprintf(line, "[1;33m        \\03 = [0;33mYellow         [1;33m\\10 = [1;32mBright Green\r");
		qnprintf(line, "[1;33m        \\04 = [0;34mBlue           [1;33m\\11 = [1;33mBright Yellow\r");
		qnprintf(line, "[1;33m        \\05 = [0;35mPurple         [1;33m\\12 = [1;34mBright Blue\r");
		qnprintf(line, "[1;33m        \\06 = [0;36mCyan           [1;33m\\13 = [1;35mBright Purple\r");
		qnprintf(line, "[1;33m        \\07 = [0;37mGrey           [1;33m\\14 = [1;36mBright Cyan\r");
		qnprintf(line, "[1;33m                             [1;33m\\15 = [1;37mWhite\r");
		return(1);
	}
	return(0);
}

sys_set_message(int line, int which)
{
	FILE *f;
	char fname[64];
	int loop1=0;

	sprintf(fname, "%stcuser.dat", df);
	if ((f = fopen(fname, "r+")) == 0)
	{
		send_lprintf("QTC: Couldn't open %stcuser.dat", df);
	} else {
		while(fread(&tcuser, sizeof(struct _tcuser), 1, f))
		{
			if (strcasecmp(tcuser.acctnum, usereditor.acctnum) == 0) {
				fseek(f, sizeof(struct _tcuser) * -1, SEEK_CUR);
				break;
			}
		}
	}
	switch (which)
	{
		case 0:
			strncpy(usereditor.entmessage, command_string, 79);
			break;
		case 1:
			strncpy(usereditor.extmessage, command_string, 79);
			break;
		case 2:
			strncpy(usereditor.topic, command_string, 79);
			break;
	}
	if (!fwrite(&usereditor, sizeof(struct _tcuser), 1, f))
	{
		qnprintf(line, "\rUpdate FAILED!");
		sleep(1);
	}
	fclose(f);
	print_sysop_acct_editor(line);
	return(0);
}


set_message(int line, int which)
{
	FILE *f;
	char fname[64];
	int loop1=0;

	sprintf(fname, "%stcuser.dat", df);
	if ((f = fopen(fname, "r+")) == 0)
	{
		send_lprintf("QTC: Couldn't open %stcuser.dat", df);
	} else {
		while(fread(&tcuser, sizeof(struct _tcuser), 1, f))
		{
			if (strcasecmp(acnt[line].acctnum, tcuser.acctnum) == 0) {
				fseek(f, sizeof(struct _tcuser) * -1, SEEK_CUR);
				break;
			}
		}
	}
	switch (which)
	{
		case 0:
			strncpy(tcuser.entmessage, command_string, 79);
			break;
		case 1:
			strncpy(tcuser.extmessage, command_string, 79);
			break;
		case 2:
			strncpy(tcuser.topic, command_string, 30);
			break;
	}
	fwrite(&tcuser, sizeof(struct _tcuser), 1, f);
	fclose(f);
	print_pref_menu(line);
	return(0);
}

print_who_list(int line)
{
	int loop1=0;
	int numInTC=0;
	int numInList=0;
	char userlist[numlines*40+10];
	
	memset(&userlist, 0, sizeof(userlist));
	qnprintf(line, "[2D%sYou are in %s%s%s%s %schannel\r", LISTHEAD, (channel[line] == -1) ? "the " : "", CHANNAME, (channel[line] == -1) ? "main" : acnt[channel[line]].acctname, (channel[line] == -1) ? "" : "'s", LISTHEAD);
  for (loop1=0; loop1 < numlines; loop1++)
  {
		if((user[loop1].u_stat == 6) && (strcasecmp(user[loop1].doors_id, DOORID) == 0))
		{
			if ((!user[loop1].stealth) || (acnt[line].accessflags & sysopaccess))
			{
				if (linesintc[loop1] == IN_TC)
				{
					if (channel[line] == channel[loop1])
					{
						if ((line != loop1))
						{
							numInTC++;
						}
					}
				}
			}
		}
	}
	if (numInTC > 1)
	{
		for (loop1=0; loop1 < numlines; loop1++)
		{
			if((user[loop1].u_stat == 6) && (strcasecmp(user[loop1].doors_id, DOORID) == 0))
			{
				if ((!user[loop1].stealth) || (acnt[line].accessflags & sysopaccess))
				{
					if (channel[loop1] == channel[line])
					{
						if ((line != loop1))
						{
							if (linesintc[loop1] == IN_TC)
							{
								if (numInList == numInTC-1)
								{
									sprintf(userlist, "%s%sand %s%s %sare here with you.\r", userlist, LISTTEXT, LISTNAME, acnt[loop1].acctname, LISTTEXT);
								} else if (numInList == numInTC-2) {
									sprintf(userlist, "%s%s%s ", userlist, LISTNAME, acnt[loop1].acctname);
									numInList++;
								} else {
									sprintf(userlist, "%s%s%s, ", userlist, LISTNAME, acnt[loop1].acctname, LISTCOMMA);
									numInList++;
								} 
							}
						}
					}
				}
			}
		}
	} else if (numInTC == 0) {
		sprintf(userlist, "%sYou are all alone.\r", LISTTEXT);

	} else {
		for (loop1=0; loop1 < numlines; loop1++)
		{
			if((user[loop1].u_stat == 6) && (strcasecmp(user[loop1].doors_id, DOORID) == 0))
			{
				if ((!user[loop1].stealth) || (acnt[line].accessflags & sysopaccess))
				{
					if (channel[loop1] == channel[line])
					{
						if (linesintc[loop1] == IN_TC)
						{
							if ((line != loop1))
							{
									sprintf(userlist, "%s%s %sis here with you.\r", LISTNAME, acnt[loop1].acctname, LISTTEXT);
							}
						}
					}
				}
			}
		}
	}
	sendtoline(line, userlist);
}


save_settings(int line)
{
	FILE *f;
	char fname[64];
	int loop1=0;

	sprintf(fname, "%stcuser.dat", df);
	if ((f = fopen(fname, "r+")) == 0)
	{
		send_lprintf("QTC: Couldn't open %stcuser.dat", df);
	} else {
		while(fread(&tcuser, sizeof(struct _tcuser), 1, f))
		{
			if (strcmp(acnt[line].acctnum, tcuser.acctnum) == 0) {
				fseek(f, sizeof(struct _tcuser) * -1, SEEK_CUR);
				break;
			}
		}
	}
	tcuser.beep = beep[line];
	tcuser.echo = echo[line];
	qnprintf(line, "\rRewrote your Information at byte position %d", ftell(f));
	fwrite(&tcuser, sizeof(struct _tcuser), 1, f);
	fclose(f);
	print_pref_menu(line);
	return(0);
}

print_action_screen(int line)
{
	qnprintf(line, "[2J[1;1H[1;35mAciton Editor              Editing Action: %s\r\r", newaction.actionname);
	qnprintf(line, "[1;34m[[36m1[34m] [0;36mReturn string - This string is sent back to the user who typed the action\r");
	qnprintf(line, "[0m%s\r\r", newaction.returntext);
	qnprintf(line, "[1;34m[[36m2[34m] [0;36mText sent to everyone when there is NO recipient\r");
	qnprintf(line, "[0m%s\r\r", newaction.regtext);
	qnprintf(line, "[1;34m[[36m3[34m] [0;36mText sent to everyone when there IS a recipient\r");
	qnprintf(line, "[0m%s\r\r", newaction.reciptext);
	qnprintf(line, "\r[1;36m@ code listing:\r");
	qnprintf(line, "From User Codes:\r");
	qnprintf(line, "[1;36m@FU [0;36m= Username  [1;36m@FP [0;36m= his/her  [1;36m@FS [0;36m= himself/herself  [1;36m@FR [0;36m= him/her\r");
	qnprintf(line, "[1;36m@FE [0;36m= he/she\r\r"); 
	qnprintf(line, "To User Codes:\r");
	qnprintf(line, "[1;36m@TU [0;36m= Username  [1;36m@TP [0;36m= his/her  [1;36m@TS [0;36m= himself/herself  [1;36m@TR [0;36m= him/her\r");
	qnprintf(line, "[1;36m@TE [0;36m= he/she\r\r"); 
	qnprintf(line, "[1;36m@UI [0;36m= User Input\r");
	linesintc[line] = ADD_ACT2;
}

print_action_edit_screen(int line)
{
	qnprintf(line, "[2J[1;1H[1;35mAction Editor                       Editing Action: %s\r\r", newaction.actionname);
	qnprintf(line, "[1;34m[[36m1[34m] [0;36mReturn string - This string is sent back to the user who typed the action\r");
	qnprintf(line, "[0m%s\r\r", newaction.returntext);
	qnprintf(line, "[1;34m[[36m2[34m] [0;36mText sent to everyone when there is NO recipient\r");
	qnprintf(line, "[0m%s\r\r", newaction.regtext);
	qnprintf(line, "[1;34m[[36m3[34m] [0;36mText sent to everyone when there IS a recipient\r");
	qnprintf(line, "[0m%s\r\r", newaction.reciptext);
	qnprintf(line, "\r[1;36m@ code listing:\r");
	qnprintf(line, "From User Codes:\r");
	qnprintf(line, "[1;36m@FU [0;36m= Username  [1;36m@FP [0;36m= his/her  [1;36m@FS [0;36m= himself/herself  [1;36m@FR [0;36m= him/her\r");
	qnprintf(line, "[1;36m@FE [0;36m= he/she\r\r"); 
	qnprintf(line, "[1;36mTo User Codes:\r");
	qnprintf(line, "[1;36m@TU [0;36m= Username  [1;36m@TP [0;36m= his/her  [1;36m@TS [0;36m= himself/herself  [1;36m@TR [0;36m= him/her\r");
	qnprintf(line, "[1;36m@TE [0;36m= he/she\r\r"); 
	qnprintf(line, "[1;36m@UI [0;36m= User Input\r");
	linesintc[line] = ED_ACT2;
}

print_edit_action_menu(int line)
{
	qnprintf(line, "[2J[1;1H[1;35mAction Editor:\r\r");
	qnprintf(line, "  [1;34m[[36mE[34m][0;36mdit an action\r");
	qnprintf(line, "  [1;34m[[36mA[34m][0;36mdd an action\r");
	qnprintf(line, "  [1;34m[[36mD[34m][0;36melete an action\r\r");
	qnprintf(line, "  [1;34m[[36mQ[34m][0;36muit\r\r");
	linesintc[line] = EDIT_ACTION;
	return(0);
}

print_sysop_acct_editor(int line)
{
	char buffer[512];

	qnprintf(line, "[2J[1;1H[1;36m%s's [0;36mCurrent Teleconference Settings are:\r", usereditor.acctname);
	sprintf(buffer, "%s", usereditor.entmessage);
	qnprintf(line, "[1;34m[[36m1[1;34m] [0;36mEntrance Message:\r");
	qnprintf(line, "[0m%s\r\r", parse_color_codes(buffer));
	qnprintf(line, "[1;34m[[36m2[1;34m] [0;36mExit Message:\r");
	sprintf(buffer, "%s", usereditor.extmessage);
	qnprintf(line, "[0m%s\r\r", parse_color_codes(buffer));
	qnprintf(line, "[1;34m�������������������������������������������������������������������������������\r");
	qnprintf(line, "[1;34m�������������������������������������������������������������������������������\r");
	qnprintf(line, " [1;36mSysop Toggles:\r\r");
	qnprintf(line, " [1;34m[[36mG[1;34m][0;36mag this user [1;37m%s\r", (usereditor.gagged) ? "- GAGGED" : "");
	qnprintf(line, " [1;34m[[36mB[1;34m][0;36man this user [1;37m%s\r\r", (usereditor.banned) ? "- BANNED" : "");
	qnprintf(line, " [1;34m[[36mS[1;34m][0;36mave Toggle Settings\r");
	qnprintf(line, " [1;34m[[36mQ[1;34m][0;36muit\r");
	linesintc[line] = SYS_EDIT_PREFS;
	return(0);
}


print_pref_menu(int line)
{
	char buffer[512];

	qnprintf(line, "[2J[1;1H[0;36mYour Current Teleconference Settings are:\r");
	qnprintf(line, "[1;34m[[36m1[34m] [0;36mEntrance Message:\r");
	sprintf(buffer, "%s", tcuser.entmessage);
	qnprintf(line, "[0m%s\r\r", parse_color_codes(buffer));
	qnprintf(line, "[1;34m[[36m2[34m] [0;36mExit Message:\r");
	sprintf(buffer, "%s", tcuser.extmessage);
	qnprintf(line, "[0m%s\r\r", parse_color_codes(buffer));
	qnprintf(line, "[1;34m[[36m3[34m] [0;36mChannel Topic:\r");
	sprintf(buffer, "%s", tcuser.topic);
	qnprintf(line, "[0m%s\r\r", parse_color_codes(buffer));
	qnprintf(line, "�������������������������������������������������������������������������������\r");
	qnprintf(line, " [1;36mToggles:\r\r");
	qnprintf(line, " [1;34m[[36mB[34m][0;36meep on Directed Message - [1;37m%s\r", (beep[line]) ? "ON" : "OFF");
	qnprintf(line, " [1;34m[[36mE[34m][0;36mcho your own Messages   - [1;37m%s\r\r", (echo[line]) ? "ON" : "OFF");
	qnprintf(line, " [1;34m[[36mS[34m][0;36mave Toggle Settings\r");
	qnprintf(line, " [1;34m[[36mQ[34m][0;36muit\r");
	linesintc[line] = EDIT_PREFS;
	return(0);
}

send_to_all(int line, char *text)
{
	int loop1;
	char buffer[sizeof(text)];

	for (loop1=0; loop1 < numlines; loop1++)
	{
		if (linesintc[loop1] == IN_TC)
		{
			if (channel[line] == channel[loop1])
			{
				if((user[loop1].u_stat == 6) && (strcasecmp(user[loop1].doors_id, DOORID) == 0))
				{
					if ((line != loop1))
					{
							text = parse_color_codes(text);
							qnprintf(loop1, "%s", text);
							do_prompt(loop1);
					}
				}
			}
		}
	}
}

action_check(int line, char *checkme)
{
	int loop1;

	for (loop1 = 0; loop1 < numactions; loop1++)
	{
		if (strcasecmp(actionlist[loop1], checkme)==0)
			return(loop1);
	}
	return(-1);
}

do_action(int line, int actionnum, char *message)
{
	int loop1;
	FILE *actionfile;
	int recip;
	char fname[64];
	char temp[200];
	char *temp2;
	char *temp3;
	
	sprintf(fname, "%sactions.dat", df);
	if ((actionfile = fopen(fname, "r+")) == 0)
	{
		send_lprintf("QTC: Couldn't open %sactions.dat", df);
	} else {
		fseek(actionfile, (actionnum) * sizeof(struct _action), SEEK_SET);
		if (fread(&action, sizeof(struct _action), 1, actionfile))
		{
			if (strstr(action.reciptext, "@UI") == 0)
			{
				strtok(command_string, " ");
				if ((temp2 = strtok(NULL, " ")) != 0)
				{ 
					if (strlen(action.reciptext))
					{
						if (strcasecmp(temp2, "all") == 0)
							recip = -2;
						else if (strcasecmp(temp2, "?") == 0) {
							action_help(line, action.actionname);
							return(0);
						} else
							recip = find_matching_user(line, temp2, 1);
						if (recip != (-1))
						{
							char buffer[10240];

							if (recip == (-100)) {
								qnprintf(line, "[2D%s could be more than one person.  Please be more specific.\r", temp2);
								return(0);
							}
							if (recip == -2)
							{
								sprintf(buffer, "%s%s", ACTION, make_string(line, action.reciptext, recip));
								send_to_all(line, buffer);
							} else {
								sprintf(buffer, "%s%s", ACTION, make_recip_string(line, action.reciptext));
								send_to_recip(line, buffer, recip); 
								sprintf(buffer, "%s%s", ACTION, make_string(line, action.reciptext, recip));
								send_to_nonrecip(line, buffer, recip);
							}
							sprintf(buffer, "%s%s", ACTION, make_string(line, action.returntext, recip));
							temp3 = parse_color_codes(buffer);
							qnprintf(line, "%s", temp3);
						} else
							qnprintf(line, "Couldn't find anyone by that name around here\r");
					}
					else
						qnprintf(line, "[2DThis action cannot have a recipient\r");
				} else {
					if (strlen(action.regtext))
					{
						char buffer[10240];
						sprintf(buffer, "%s%s", ACTION, make_string(line, action.regtext, -5));
						send_to_all(line, buffer);
						qnprintf(line, "%s%s", ACTION, parse_color_codes(make_string(line, action.returntext, -5)));
					} else
						qnprintf(line, "[2DThis action must have a recipient\r");
				}
			} else {
				char buffer[10240];

				if ((strtok(command_string, " ") != NULL) && ((temp2 = strtok(NULL, "\0")) != NULL))
				{
					sprintf(buffer, "%s%s", ACTION, parse_color_codes(parse_ui(make_string(line, action.reciptext, -4), temp2)));
					send_to_all(line, buffer);
					qnprintf(line, "%s%s", ACTION, parse_color_codes(parse_ui(make_string(line, action.returntext, -4), temp2)));
				} else {
					if (strlen(action.regtext))
					{
						sprintf(buffer, "%s%s", ACTION, make_string(line, action.regtext, -5));
						send_to_all(line, buffer);
						qnprintf(line, "%s%s", ACTION, parse_color_codes(make_string(line, action.returntext, -5)));
					} else {
						qnprintf(line, "This action requires additional text\r");
					}
				}
			}
		} else {
			qnprintf(line, "Action Failed\r");
		}
		fclose(actionfile);
	}
}


find_matching_user(int line, char *ntm, int chanmatter)
{ 
  int loop1, loop2, matched[numlines], length[numlines], matches, line_match;
  char string[uidlen], *str;
  
  strncpy(string, ntm, uidlen);								/* Copy 32 chars			*/
  str = strtok(string, " ");  								/* Find a space 			*/
  for(loop1 = 0; loop1 < numlines; loop1++)
  { matched[loop1] = length[loop1] = 0;
    if(linesintc[loop1] == IN_TC)
    { 
			if((channel[line] == channel[loop1]) || (!chanmatter))
      { 
				if((user[loop1].u_stat == 6) && (strcasecmp(user[loop1].doors_id, DOORID)) == 0)
        { 
					if(strncasecmp(acnt[loop1].acctname, str, strlen(str)) == 0)
          { 
						matched[loop1] = 1;						/* Mark as a candidate	*/
            length[loop1] = strlen(str);	/* Default size					*/
            for(loop2 = 0; loop2 < uidlen; loop2++)
            { 
							if(strncasecmp(acnt[loop1].acctname, ntm, loop2) != 0)  /* This will tell us the lenght of the name entered against the name of the account	*/
              { 
								length[loop1] = loop2;		/* This is the length of the name entered	*/
								if(acnt[loop1].acctname[loop2 - 1] != ' ')
								  length[loop1]--;
                break;
              }
            }
          }
        }
      }
    }
  }
  for(loop1 = 0, matches = 0, line_match = -1; loop1 < numlines; loop1++)
  { if(matched[loop1] == 1)
    { matches++;
      line_match = loop1;
    }
  }  
  if(matches == 1)												/* The only possible choice					*/
    strcpy(ntm, &ntm[length[line_match]]);	/* Then get rid of the name + space	*/
  else if(matches > 1)										/* To MANY Matches									*/
    line_match = -100;										/* Return -100 per Kewjhoe					*/
  else line_match = -1;										/* Matches out of range, return -1	*/
  if(ntm[0] == ' ')
    strcpy(ntm, &ntm[1]);
  return(line_match);
}

char *make_string(int line, char *format, int recip)
{
	int temp;
	char *iamhere;
	char replacewith[10240];
	int numtomove;
	char *origformat;
	char code[10];

	origformat = format;
	//qnprintf(line, "DEBUG: ms_format: %s\r", format);
	strcpy(actionstring, "[2D");
	iamhere = strchr(format, '@');
	if (!iamhere)
	{
		strcat(actionstring, format);
		strcat(actionstring, "\r");
		return(actionstring);
	}
	while (1)
	{
		if ((iamhere = strchr(format, '@')) != NULL)
		{
			strncat(actionstring, format, (iamhere - format));
			format = iamhere+1;
			strncpy(code, format, 2);
			code[2] = 0;
			numtomove = make_code(line, replacewith, code, recip);
			format = format + numtomove;
			strcat(actionstring, replacewith);
		} else {
			strcat(actionstring, format);
			break;
		}
	}
	strcat(actionstring, "\r");
	format = origformat;
	parse_color_codes(actionstring);
	return(actionstring);
}

make_code(int line, char *replacewith, char *code, int recip)
{
	if (recip >= -3)
	{
		if (strcasecmp(code, "TU") == 0) {
			if (recip == -2)
				strcpy(replacewith, "everyone");
			else if (recip == -3)
				strcpy(replacewith, "Sysop");
			else
				strcpy(replacewith, acnt[recip].acctname);
			return(2);
		} else if (strcasecmp(code, "TP") == 0) {
			if (recip == -2)
				strcpy(replacewith, "them");
			else if (recip == -3)
				strcpy(replacewith, "his");
			else
				strcpy(replacewith, (acnt[recip].sex) ? "his" : "her");
			return(2);
		} else if (strcasecmp(code, "TS") == 0) {
			if (recip == -2)
				strcpy(replacewith, "themself");
			else if (recip == -3)
				strcpy(replacewith, "himself");
			else
				strcpy(replacewith, (acnt[recip].sex) ? "himself" : "herself");
			return(2);
		} else if (strcasecmp(code, "TR") == 0) {
			if (recip == -2)
				strcpy(replacewith, "them");
			else if (recip == -3)
				strcpy(replacewith, "him");
			else
				strcpy(replacewith, (acnt[recip].sex) ? "him" : "her");
			return(2);
		} else if (strcasecmp(code, "TE") == 0) {
			if (recip == -2)
				strcpy(replacewith, "they");
			else if (recip == -3)
				strcpy(replacewith, "he");
			else
				strcpy(replacewith, (acnt[recip].sex) ? "he" : "she");
			return(2);
		} else if (strcasecmp(code, "UI") == 0) {
			if (recip == -3)
				strcpy(replacewith, "<user input>");
			return(2);
		}
	}
	if (strcasecmp(code, "FU") == 0) {
		strcpy(replacewith, acnt[line].acctname);
		return(2);
	} else if (strcasecmp(code, "FP") == 0) {
		strcpy(replacewith, (acnt[line].sex) ? "his" : "her");
		return(2);
	} else if (strcasecmp(code, "FS") == 0) {
		strcpy(replacewith, (acnt[line].sex) ? "himself" : "herself");
		return(2);
	} else if (strcasecmp(code, "FR") == 0) {
		strcpy(replacewith, (acnt[line].sex) ? "him" : "her");
		return(2);
	} else if (strcasecmp(code, "FE") == 0) {
		strcpy(replacewith, (acnt[line].sex) ? "he" : "she");
		return(2);
	} else {
		strcpy(replacewith, "@");
		strcat(replacewith, code);
		return(2);
	}
	return(1);
}

priv_user(int line)
{
	FILE *privfile;
	char nif[80];
	char fname[64];
	
	if (acnt[line].accessflags & sysopaccess)
		return(1);
	sprintf(fname, "%sprivuser.txt", df);
	if ((privfile = fopen(fname, "r")) == 0)
	{
		send_lprintf("QTC: Can't open file: %s\r", fname);
		return(0);
	} else {
		while(fgets(nif, 79, privfile))
		{
			nif[strlen(nif)-1] = 0;
			if (strcasecmp(acnt[line].acctname, nif) == 0)
				return(1);
		}
		return(0);
	}
}

ban_user(int line)
{
	int ctr;
	FILE *f;
	char fname[64];
	
	sprintf(fname, "%stcuser.dat", df);
	if ((f = fopen(fname, "r+")) == 0)
	{
		send_lprintf("QTC: Could not open user data file");
		return(1);
	} else {
		while (fread(&tcuser, sizeof(struct _tcuser), 1, f))
		{
			if (strcasecmp(tcuser.acctname, usereditor.acctname) == 0)
			{
				if (usereditor.banned)
					usereditor.banned = 0;
				else
					usereditor.banned = 1;
				fseek(f, sizeof(struct _tcuser) * (-1), SEEK_CUR);
				fwrite(&usereditor, sizeof(struct _tcuser), 1, f);
				fclose(f);
				for (ctr = 0; ctr < numlines; ctr++)
				{
					if (strcasecmp(usereditor.acctname, acnt[ctr].acctname) == 0)
						banned[ctr] = 1;
				}
				return(0);
			}
		}
	}
}

gag_user(int line)
{
	int ctr;
	FILE *f;
	char fname[64];
	
	sprintf(fname, "%stcuser.dat", df);
	if ((f = fopen(fname, "r+")) == 0)
	{
		send_lprintf("QTC: Could not open user data file");
		return(1);
	} else {
		while (fread(&tcuser, sizeof(struct _tcuser), 1, f))
		{
			if (strcasecmp(tcuser.acctname, usereditor.acctname) == 0)
			{
				if (usereditor.gagged)
					usereditor.gagged = 0;
				else
					usereditor.gagged = 1;
				fseek(f, sizeof(struct _tcuser) * (-1), SEEK_CUR);
				fwrite(&usereditor, sizeof(struct _tcuser), 1, f);
				fclose(f);
				for (ctr = 0; ctr < numlines; ctr++)
				{
					if (strcasecmp(usereditor.acctname, acnt[ctr].acctname) == 0)
						if (gagged[ctr])
							gagged[ctr] = 0;
						else
							gagged[ctr] = 1;
				}
				return(0);
			}
		}
	}
}

notify_uit(line)
{
	int loop1;
	int total_records;
	int amihere=0;
	char entmesg[1024];
	char fname[64];
	FILE *f;
	
	if (!user[line].stealth)
	{
		sprintf(fname, "%stcuser.dat", df);
		if ((f = fopen(fname, "r+")) == 0)
		{
			send_lprintf("QTC: Couldn't open %stcuser.dat", df);
			sprintf(entmesg, "%s has entered the Teleconference\r", acnt[line].acctname);
		} else {
			total_records = file_size(fname) / sizeof(struct _tcuser);
			while(fread(&tcuser, sizeof(struct _tcuser), 1, f))
			{
				if ((strcmp(acnt[line].acctnum, tcuser.acctnum) == 0) || (strcasecmp(acnt[line].acctname, tcuser.acctname) == 0)) 
				{
					if (((strcmp(acnt[line].acctnum, tcuser.acctnum) == 0) && (strcasecmp(acnt[line].acctname, tcuser.acctname) != 0)) 
							|| ((strcasecmp(acnt[line].acctname, tcuser.acctname) != 0) && (strcmp(acnt[line].acctnum, tcuser.acctnum) == 0)))
					{
						memset(&tcuser, 0, sizeof(struct _tcuser));
						strcpy(tcuser.acctnum, acnt[line].acctnum);
						strcpy(tcuser.acctname, acnt[line].acctname);
						strcpy(tcuser.entmessage, "");
						strcpy(tcuser.extmessage, "");
						fseek(f, (sizeof(struct _tcuser) * -1), SEEK_CUR);
						fwrite(&tcuser, (sizeof(struct _tcuser)), 1, f);
						qnprintf(line, "This is your first time joining the teleconference\rYour Teleconference account has been created\rType 'help' for help\r\r");
						sprintf(entmesg, "%s has entered the Teleconference\r", acnt[line].acctname);
					} else if (strcmp(acnt[line].acctnum, tcuser.acctnum) == 0) {
						if (tcuser.banned)
						{
							qnprintf(line, "You are banned from the teleconference.  If you feel this is in error,\rplease contact the sysop");
							remove_user(line);
						} else
							sprintf(entmesg, "%s has entered the Teleconference\r%s\r", acnt[line].acctname, parse_color_codes(tcuser.entmessage));
						break;
					} else {
						sprintf(entmesg, "%s has entered the Teleconference\r", acnt[line].acctname);
					}
				}
				amihere++;
			}
			fclose(f);
		}
		if (total_records == 0)
			sprintf(entmesg, "%s has entered the Teleconference\r", acnt[line].acctname);
		if (amihere == total_records)
		{
			if ((f = fopen(fname, "a")) == 0)
			{
				send_lprintf("QTC: Couldn't open %stcuser.dat", df);
				sprintf(entmesg, "%s has entered the Teleconference\r", acnt[line].acctname);
			} else {
				memset(&tcuser, 0, sizeof(struct _tcuser));
				strcpy(tcuser.acctnum, acnt[line].acctnum);
				strcpy(tcuser.acctname, acnt[line].acctname);
				strcpy(tcuser.entmessage, "");
				strcpy(tcuser.extmessage, "");
				fwrite(&tcuser, (sizeof(struct _tcuser)), 1, f);
				qnprintf(line, "This is your first time joining the teleconference\rYour Teleconference account has been created\rType 'help' for help\r\r");
				fclose(f);
			}
			sprintf(entmesg, "%s has entered the Teleconference\r", acnt[line].acctname);
		}
		for (loop1=0; loop1 < numlines; loop1++)
		{
			if (loop1 != line)
			{
				if ((user[loop1].u_stat == 6) && (strcasecmp(user[loop1].doors_id, DOORID) == 0))
				{
					if (channel[line] == channel[loop1])
					{
						if (linesintc[loop1] == IN_TC)
						{
							qnprintf(loop1, "[2D%s", entmesg);
							do_prompt(loop1);
						}
					}
				}
			}
		}
	}
}

invited(int line, int channelnum)
{
	if ((channellist[channelnum].open) || (channellist[channelnum].invited[line])) 
	{
		return(1);
	} else {
		return(0);
	}
}

read_bad_words()
{
	FILE *f;
	char fname[64];
	int loop1 = 0;

	sprintf(fname, "%s/tlcf.bad", cfg->bbs_path);
	if ((f = fopen(fname, "r")) == 0)
	{
		send_lprintf("Error Reading Dirty Words File - %s", fname);
	} else {
		while (fgets(badwords[loop1], 39, f))
		{
			strupr(badwords[loop1]);
			badwords[loop1][strlen(badwords[loop1])-2] = 0;
			loop1++;
		}
	}
}

wirty_dord(char *message)
{
	char upmessage[10240];
	int ctr;
	char *blah;
	
	strcpy(upmessage, message);
	strupr(upmessage);
	
	for (ctr = 0; strlen(badwords[ctr]); ctr++)
	{
		//qnprintf(0, "%s - %s", upmessage, badwords[ctr]);
		if ((blah = strstr(upmessage, badwords[ctr])) != NULL)
			return(1);
		//qnprintf(0, "%d", blah);
	}
	return(0);
}





void main(int argc, char *argv[])
{    
  int int1,i;  
  FILE *f;
  
  if (argc == 1) {
    sprintf(df, "%s", "./");
  } else {
    if (argv[1][strlen(argv[1])-1] == '/')
			sprintf(df, "%s", argv[1]);
    else
      sprintf(df, "%s/", argv[1]);
	}
  init();
	init_actions();
  int1 = make_daemon();
  if(int1 < 0)
  { 
		wakeup(myuser->u_doortcb);
    exit(0);
  }  
  init_program();
  while(1)
  { 
    main_game_loop();
  }
}

void init_program()
{ 
  int loop1;
  
  for(loop1 = 0; loop1 < numlines; loop1++)
    linesintc[loop1] = 0;
	get_config();
}

int get_message()
{
  int ploop, count, int1;
  extern struct mdbrec *dequeue_mdb(int);
  struct mdbrec *msgqbuf;
  char string[81];
  
	memset(command_string, 0, sizeof(command_string));
  for(;; relinq())
  { count = 0;
    for(ploop = 0; ploop < numlines; ploop++)
    { 
      if((user[ploop].u_stat == st_extern) && (strcasecmp(user[ploop].doors_id, DOORID) == 0))
      { 
        if(linesintc[ploop] == usergone)	/* New Entry	*/
          add_user(ploop);
				else if((msgqbuf = dequeue_mdb(user[ploop].door_inq)) != NULL)
				{ 
          if(msgqbuf->command == F_CMD_KILLTASK)
				  { 
						release_mdb(msgqbuf);
				    remove_user(ploop);
			  	} else if(msgqbuf->command == F_CMD_TEXTIN) { 
            int1 = copy_from_buffers(command_string, ibufsz - 1, msgqbuf);
				    command_string[int1] = '\0';
				    release_mdb(msgqbuf);
				    return(ploop);
				  } else release_mdb(msgqbuf);
        }
        count++;	  
      }
      else if(linesintc[ploop] > usergone && strcasecmp(user[ploop].doors_id, DOORID) != 0)
        remove_user(ploop);
    }
    if(count == 0)
		{
			free(actionlist);
      exit(0);
		}
  }
}      

void remove_user(int line)
{ 
	FILE *f;
	int total_records;
	char extmesg[uidlen+115];
	char fname[64];
	int loop1;
	
	acnt[line].tlcf_time += ((time(NULL) - timein[line]) / 60);
	if (!user[line].stealth)
	{
		sprintf(fname, "%stcuser.dat", df);
		if ((f = fopen(fname, "r")) == 0)
		{
			send_lprintf("QTC: Couldn't open %stcuser.dat", df);
			sprintf(extmesg, "%s has left the Teleconference\r", username[line]);
		} else {
			total_records = file_size(fname) / sizeof(struct _tcuser);
			while(fread(&tcuser, sizeof(struct _tcuser), 1, f))
			{
				if (strcasecmp(username[line], tcuser.acctname) == 0) {
					sprintf(extmesg, "%s\r%s has left the Teleconference\r", parse_color_codes(tcuser.extmessage), username[line]);
					break;
				} else {
					sprintf(extmesg, "%s has just left the Teleconference\r", username[line]);
				}
			}
		}
		if (total_records == 0)
			sprintf(extmesg, "%s has left the Teleconference\r", username[line]);
		for (loop1=0; loop1 < numlines; loop1++)
		{
			if (loop1 != line)
			{
				if (channel[line] == channel[loop1])
				{
					if ((user[loop1].u_stat == 6) && (strcasecmp(user[loop1].doors_id, DOORID) == 0))
					{
						if (linesintc[loop1] == IN_TC)
						{
							qnprintf(loop1, "[2D%s", extmesg);
							do_prompt(loop1);
						}
					}
				}
			}
		}
	}
	for (loop1 = 0; loop1 <= maxlines; loop1++)
		channellist[loop1].invited[line] = 0;
  wakeup(user[line].u_doortcb);
  relinq();
  linesintc[line] = usergone;
  pid_monitor_off(line);
}  
  
void add_user(int line)
{ 
	FILE *f;
	int total_records;
	char extmesg[uidlen+115];
	char fname[64];
	int loop1;
	
	timein[line] = time(NULL);
  sprintf(fname, "%stcuser.dat", df);
	if ((f = fopen(fname, "r")) == 0)
	{
		send_lprintf("QTC: Couldn't open %stcuser.dat", df);
		sprintf(extmesg, "%s has joined the Teleconference\r", acnt[line].acctname);
	} else {
		total_records = file_size(fname) / sizeof(struct _tcuser);
		while(fread(&tcuser, sizeof(struct _tcuser), 1, f))
		{
			if (strcmp(acnt[line].acctnum, tcuser.acctnum) == 0) {
				beep[line] = tcuser.beep;
				echo[line] = tcuser.echo;
				gagged[line] = tcuser.gagged;
				break;
			}
		}
		fclose(f);
	}
	qnprintf(line, "Quickie Teleconf version %s\r\r", VERSION);
	channel[line] = MAINNUM;
	strcpy(username[line], acnt[line].acctname);
	notify_uit(line);
	print_who_list(line);
	do_prompt(line);
  linesintc[line] = userhere;
  pid_monitor(line);
  relinq();
}  
    
init_actions(void)
{
	FILE *actionfile;
	char fname[64];
	int loop1;
	int error;
	
  sprintf(fname, "%sactions.dat", df);
	numactions = file_size(fname) / sizeof(struct _action);
	if ((actionfile = fopen(fname, "r")) == 0)
	{
		send_lprintf("QTC: Couldn't open %sactions.dat", df);
	} else {
		actionlist = malloc(numactions * sizeof(int));
		for (loop1 = 0; loop1 < numactions; loop1++)
			actionlist[loop1] = malloc(21);
		rewind(actionfile);
		loop1 = 0;
		while(error = fread(&action, sizeof(struct _action), 1, actionfile))
		{
			strcpy(actionlist[loop1], action.actionname);
			loop1++;
		}
		fclose(actionfile);
	}
}

sort_actions(int line)
{
	FILE *actionfile;
	char fname[64];
	int loop1, loop2, error;
	struct _action *tmp_action = NULL, temp_action;
	
  sprintf(fname, "%sactions.dat", df);
	numactions = file_size(fname) / sizeof(struct _action);
	if((actionfile = fopen(fname, "r")) == 0)
	 	send_lprintf("QTC: Couldn't open %sactions.dat", df);
	else 
	{	if((tmp_action = (struct _action *)realloc(tmp_action, sizeof(struct _action) * numactions)) == NULL)
	  { qnprintf(line, "\rError allocating memory for actions. File not sorted\r");
 	    fclose(actionfile);
	    return;
	  }
		rewind(actionfile);
		loop1 = 0;
		while(error = fread(&action, sizeof(struct _action), 1, actionfile))
		{ memcpy(&tmp_action[loop1], &action, sizeof(struct _action));
			loop1++;
		}
		fclose(actionfile);
		for(loop1 = 0; loop1 < numactions; loop1++)
		{ for(loop2 = 0; loop2 < numactions - 1; loop2++)
		  { if(strcasecmp(tmp_action[loop2].actionname, tmp_action[loop2 + 1].actionname) > 0)
		    { memcpy(&temp_action, &tmp_action[loop2], sizeof(struct _action));
		      memcpy(&tmp_action[loop2], &tmp_action[loop2 + 1], sizeof(struct _action));
		      memcpy(&tmp_action[loop2 + 1], &temp_action, sizeof(struct _action));
		    }
		  }
		}
    if((actionfile = fopen(fname, "wb")) == NULL)
	  { qnprintf(line, "QTC: Couldn't open %s", fname);
	    free(tmp_action);
	    return;
	  }
	  for(loop1 = 0; loop1 < numactions; loop1++)
	  { fwrite(&tmp_action[loop1], sizeof(struct _action), 1, actionfile);
	    free(actionlist[loop1]);
	  }
	  fclose(actionfile);
	}
  free(tmp_action); 
}

char *parse_color_codes(char *input)
{
	char buffer[204800];
	char codebuf[3];
	int acode, bufctr=0, ctr;
	
	for (ctr=0; ctr < strlen(input); ctr++)
	{
		if (input[ctr] != '\\')
		{
			//qnprintf(line, "%c", input[ctr]);
			buffer[bufctr++] = input[ctr];
		} else {
			//qnprintf(line, "Woo hoo! Found a \\ - Let's do some color!\r");
			if (isdigit(input[ctr+1]) && isdigit(input[ctr+2]))
			{
				strncpy(codebuf, input+ctr+1, 2);
				codebuf[2] = 0;
				acode = atoi(codebuf);
				if ((acode > 0) && (acode < 16))
				{
					//qnprintf(line, "%d is a valid code!\r", acode);
					buffer[bufctr++] = 27;
					buffer[bufctr++] = '[';
					if (acode > 7)
					{
						buffer[bufctr++] = '1';
						buffer[bufctr++] = ';';
						acode-=8;
					} else {
						buffer[bufctr++] = '0';
						buffer[bufctr++] = ';';
					}
					buffer[bufctr++] = '3';
					buffer[bufctr++] = acode+48;
					buffer[bufctr++] = 'm';
					ctr+=2;
				} else {
					//qnprintf(line, "%d isn't a valid code!\r", acode);
					buffer[bufctr++] = input[ctr];
				}
			} else {
				//qnprintf(line, "codebuf: %c%c\r", input[ctr]+1, input[ctr]+2);
				buffer[bufctr++] = '\\';
			}
		}
	}
	buffer[bufctr++] = 27;
	buffer[bufctr++] = '[';
	buffer[bufctr++] = '0';
	buffer[bufctr++] = 'm';
	buffer[bufctr] = 0;
	strcpy(input, buffer);
	return(input);
}

// Parse Color codes without the ansi reset at the end
char *parse_color_codes_nr(char *input)
{
	char buffer[204800];
	char codebuf[3];
	int acode, bufctr=0, ctr;
	
	for (ctr=0; ctr < strlen(input); ctr++)
	{
		if (input[ctr] != '\\')
		{
			//qnprintf(line, "%c", input[ctr]);
			buffer[bufctr++] = input[ctr];
		} else {
			//qnprintf(line, "Woo hoo! Found a \\ - Let's do some color!\r");
			if (isdigit(input[ctr+1]) && isdigit(input[ctr+2]))
			{
				strncpy(codebuf, input+ctr+1, 2);
				codebuf[2] = 0;
				acode = atoi(codebuf);
				if ((acode > 0) && (acode < 16))
				{
					//qnprintf(line, "%d is a valid code!\r", acode);
					buffer[bufctr++] = 27;
					buffer[bufctr++] = '[';
					if (acode > 7)
					{
						buffer[bufctr++] = '1';
						buffer[bufctr++] = ';';
						acode-=8;
					} else {
						buffer[bufctr++] = '0';
						buffer[bufctr++] = ';';
					}
					buffer[bufctr++] = '3';
					buffer[bufctr++] = acode+48;
					buffer[bufctr++] = 'm';
					ctr+=2;
				} else {
					//qnprintf(line, "%d isn't a valid code!\r", acode);
					buffer[bufctr++] = input[ctr];
				}
			} else {
				//qnprintf(line, "codebuf: %c%c\r", input[ctr]+1, input[ctr]+2);
				buffer[bufctr++] = '\\';
			}
		}
	}
	buffer[bufctr] = 0;
	strcpy(input, buffer);
	return(input);
}

char *parse_ui(char *input, char *ewwietext)
{
	char buffer[204800];
	int acode, bufctr=0, ctr;
	
	for (ctr=0; ctr < strlen(input); ctr++)
	{
		if (input[ctr] != '@')
		{
			buffer[bufctr++] = input[ctr];
		} else {
			if ((input[ctr+1] == 'U') && (input[ctr+2] == 'I'))
			{
				buffer[ctr]=0;
				strcat(buffer, ewwietext);
				bufctr+=strlen(ewwietext);
				ctr+=2;
			} else {
				// Don't know what it is, but it's not an eww-ie
				buffer[bufctr++] = input[ctr];
			}
		}
	}
	buffer[bufctr] = 0;
	strcpy(input, buffer);
	return(input);
}

void get_config(void)
{
	FILE *f;
	char buffer[512];
	char fname[64];
	int ctr=0;
	
	sprintf(fname, "%s/qtc.cfg", df);
	if ((f = fopen(fname, "r")) == 0)
	{
		send_lprintf("Couldn't open Color Configuration - Exiting");
		exit(0);
	} else {
		while (!feof(f))
		{
			fgets(buffer, 511, f);
			if (buffer[0] != '#')
			{
				buffer[strlen(buffer)-1] = 0;
				if ((strlen(buffer) > 0) && (!blank_line(buffer)))
				{
					switch(ctr)
					{
						case 0:
							strncpy(PARENS, parse_color_codes_nr(buffer), 7);
							PARENS[7] = 0;
							break;
						case 1:
							strncpy(DIRECTMSG, parse_color_codes_nr(buffer), 7);
							DIRECTMSG[7] = 0;
							break;
						case 2:
							strncpy(MESSAGETEXT, parse_color_codes_nr(buffer), 7);
							MESSAGETEXT[7] = 0;
							break;
						case 3:
							strncpy(FROM, parse_color_codes_nr(buffer), 7);
							FROM[7] = 0;
							break;
						case 4:
							strncpy(NAME, parse_color_codes_nr(buffer), 7);
							NAME[7] = 0;
							break;
						case 5:
							strncpy(MESGSENT, parse_color_codes_nr(buffer), 7);
							MESGSENT[7] = 0;
							break;
						case 6:
							strncpy(LISTHEAD, parse_color_codes_nr(buffer), 7);
							LISTHEAD[7] = 0;
							break;
						case 7:
							strncpy(LISTTEXT, parse_color_codes_nr(buffer), 7);
							LISTTEXT[7] = 0;
							break;
						case 8:
							strncpy(LISTNAME, parse_color_codes_nr(buffer), 7);
							LISTNAME[7] = 0;
							break;
						case 9:
							strncpy(LISTCOMMA, parse_color_codes_nr(buffer), 7);
							LISTCOMMA[7] = 0;
							break;
						case 10:
							strncpy(CHANNAME, parse_color_codes_nr(buffer), 7);
							CHANNAME[7] = 0;
							break;
						case 11:
							strncpy(INPUTTEXT, parse_color_codes_nr(buffer), 7);
							INPUTTEXT[7] = 0;
							break;
						case 12:
							strncpy(PROMPT, parse_color_codes_nr(buffer), 7);
							PROMPT[7] = 0;
							break;
						case 13:
							strncpy(WHISPER, parse_color_codes_nr(buffer), 7);
							WHISPER[7] = 0;
							break;
						case 14:
							strncpy(WHISPERNAME, parse_color_codes_nr(buffer), 7);
							WHISPERNAME[7] = 0;
							break;
						case 15:
							strncpy(ACTION, parse_color_codes_nr(buffer), 7);
							ACTION[7] = 0;
							break;
						case 16:
							strncpy(MSGSENTTEXT, parse_color_codes_nr(buffer), 511);
							MSGSENTTEXT[strlen(MSGSENTTEXT)] = 0;
							MSGSENTTEXT[511] = 0;
							break;
						case 17:
							strncpy(PROMPTTEXT, parse_color_codes_nr(buffer), 1);
							PROMPTTEXT[2] = 0;
							break;
						case 18:
							if (strcasecmp("LOGGING ON", buffer) == 0)
								logging = 1;
							else
								logging = 0;
							break;
					}
					ctr++;
				}
			}
		}
		fclose(f);
	}
}

int blank_line(char *string)
{
	int ctr;

	for (ctr=0; ctr < strlen(string); ctr++)
	{
		if (!isspace(string[ctr]))
			return(0);
	}
	return(1);
}

// For those paranoid/nosey sysops
// Maybe add a strip_ansi() routine?
void log_line(char *logentry)
{
	FILE *f;
	char buffer[strlen(logentry) + 80];
	char fname[128];
	
	strcpy(buffer, logentry);
	buffer[strlen(buffer)-1] = '\n';
	sprintf(fname, "%s/qtc.log", df);
	if ( (f = fopen(fname, "a")) != 0)
	{
		fputs(buffer+4, f);
		fclose(f);
	}
}


send_to_recip(int line, char *text, int recip) {

	int loop1;

	for (loop1=0; loop1 < numlines; loop1++)
	{
		if (linesintc[loop1] == IN_TC)
		{
			if (channel[line] == channel[loop1])
			{
				if((user[loop1].u_stat == 6) && (strcasecmp(user[loop1].doors_id, DOORID) == 0))
				{
					if ((loop1 == recip)) {
							qnprintf(loop1, "%s", text);
							do_prompt(loop1);

					}
				}
			}
		}
	}
}

send_to_nonrecip (int line, char *text, int recip) {

	int loop1;

	for (loop1=0; loop1 < numlines; loop1++)
	{
		if (linesintc[loop1] == IN_TC)
		{
			if (channel[line] == channel[loop1])
			{
				if((user[loop1].u_stat == 6) && (strcasecmp(user[loop1].doors_id, DOORID) == 0))
				{
					if ((line != loop1) && (recip != loop1)) {
							qnprintf(loop1, "%s", text);
							do_prompt(loop1);
					} 
				}
			}
		}
	}
}

char *make_recip_string(int line, char *format)
{
	int temp;
	char *iamhere;
	char replacewith[10240];
	int numtomove;
	char *origformat;
	char code[10];

	origformat = format;

	strcpy(actionstring, "[2D");

	iamhere = strchr(format, '@');
	if (!iamhere)
	{
		strcat(actionstring, format);
		strcat(actionstring, "\r");
		return(actionstring);
	}
	while (1)
	{
		if ((iamhere = strchr(format, '@')) != NULL)
		{
			strncat(actionstring, format, (iamhere - format));
			format = iamhere+1;
			strncpy(code, format, 2);
			code[2] = 0;
			numtomove = make_recip_code(line, replacewith, code);
			format = format + numtomove;
			strcat(actionstring, replacewith);
		} else {
			strcat(actionstring, format);
			break;
		}
	}
	strcat(actionstring, "\r");
	format = origformat;
	parse_color_codes(actionstring);
	return(actionstring);
}

make_recip_code(int line, char *replacewith, char *code)
{
	if (strcasecmp(code, "TU") == 0) {
		strcpy(replacewith, "you");
		return(2);
	} else if (strcasecmp(code, "TP") == 0) {
		strcpy(replacewith, "your");
		return(2);
	} else if (strcasecmp(code, "TS") == 0) {
		strcpy(replacewith, "yourself");
		return(2);
	} else if (strcasecmp(code, "TR") == 0) {
		strcpy(replacewith, "you");
		return(2);
	} else if (strcasecmp(code, "TE") == 0) {
		strcpy(replacewith, "you");
		return(2);
	} else if (strcasecmp(code, "FU") == 0) {
		strcpy(replacewith, acnt[line].acctname);
		return(2);
	} else if (strcasecmp(code, "FP") == 0) {
		strcpy(replacewith, (acnt[line].sex) ? "his" : "her");
		return(2);
	} else if (strcasecmp(code, "FS") == 0) {
		strcpy(replacewith, (acnt[line].sex) ? "himself" : "herself");
		return(2);
	} else if (strcasecmp(code, "FR") == 0) {
		strcpy(replacewith, (acnt[line].sex) ? "him" : "her");
		return(2);
	} else if (strcasecmp(code, "FE") == 0) {
		strcpy(replacewith, (acnt[line].sex) ? "he" : "she");
		return(2);
	} else {
		strcpy(replacewith, "@");
		strcat(replacewith, code);
		return(2);
	}
	return(1);
}

int action_help(int line, char *temp)
{
	int loop1;
	char fname[128];
	FILE *f;

	for (loop1 = 0; loop1 < numactions; loop1++)
		if (strcasecmp(actionlist[loop1], temp) == 0)
			break;
	if (loop1 == numactions)
	{
		qnprintf(line, "[2DAction not found: %s\r", temp);
		return(1);
	}
	sprintf(fname, "%sactions.dat", df);
	if ((f = fopen(fname, "r")) == 0)
	{
		qnprintf(line, "Couldn't open action file for read\r");
		return(1);
	} else {
		fseek(f, sizeof(struct _action) * loop1, SEEK_SET);
		fread(&action, sizeof(struct _action), 1, f);
		fclose(f);
		qnprintf(line, "Action Name:  %s\r\r", action.actionname);
		if (strlen(action.regtext))
		{
			qnprintf(line, "Without a recipient, this action will print:\r");
			qnprintf(line, "%s\r", make_string(line, action.regtext, -3));
		}
		if (strlen(action.reciptext))
		{
			qnprintf(line, "With a recipient, this action will print:\r");
			qnprintf(line, "%s", make_string(line, action.reciptext, -3));
		}
	}
}

char *get_topic(int line)
{
	FILE *f;
	char fname[128];

	sprintf(fname, "%stcuser.dat", df);
	if ((f = fopen(fname, "r")) == 0)
	{
		send_lprintf("QTC: Couldn't open %stcuser.dat", df);
	} else {
		while(fread(&tcuser, sizeof(struct _tcuser), 1, f))
		{
			if (strcmp(tcuser.acctnum, acnt[line].acctnum) == 0)
			{
				if (strlen(tcuser.topic))
					return(tcuser.topic);
				else {
					strcpy(tcuser.topic, "No Topic");
					return(tcuser.topic);
				}
			}
		}
	}
	strcpy(tcuser.topic, "No Topic");
	return(tcuser.topic);
}
