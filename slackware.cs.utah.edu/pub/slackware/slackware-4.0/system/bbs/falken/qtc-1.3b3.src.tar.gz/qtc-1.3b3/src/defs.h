// Foreground Colors
#define BLACK 	"[30m"
#define RED 		"[31m"
#define GREEN 	"[32m"
#define YELLOW	"[33m"
#define BLUE		"[34m"
#define PURPLE	"[35m"
#define CYAN		"[36m"
#define WHITE		"[37m"


// Foreground
#define BGBLACK 	"[40m"
#define BGRED 		"[41m"
#define BGGREEN 	"[42m"
#define BGYELLOW	"[43m"
#define BGBLUE		"[44m"
#define BGPURPLE	"[45m"
#define BGCYAN		"[46m"
#define BGWHITE		"[47m"

// State set
#define BRIGHT  	"[1m"
#define BLINK   	"[4m"
#define RESET   	"[0m"

// DOOR_ID
#define DOORID "Quickie Teleconf"

char PARENS[8], DIRECTMSG[8], MESSAGETEXT[8], FROM[8], NAME[8], MESGSENT[8],
		HEADER[8], WELCOME[8], LISTHEAD[8], LISTTEXT[8], LISTNAME[8], LISTCOMMA[8],
		CHANNAME[8], INPUTTEXT[8], PROMPT[8], WHISPER[8], WHISPERNAME[8], ACTION[8],
		MSGSENTTEXT[512], PROMPTTEXT[2];

#define VERSION				"1.3beta3"
