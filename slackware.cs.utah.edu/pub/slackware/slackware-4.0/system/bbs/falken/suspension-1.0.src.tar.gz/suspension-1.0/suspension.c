#include <stdio.h>
#include <time.h>
#include "doorutil.h"

struct _su {
	char acctname[uidlen];
	time_t timestamp;
	int days;
	char reason[160];
} su;

#define DAY 60 * 60 * 24

void unsuspend_user(char *name);
void suspend_user(char *name, int days, char *reason);
void press_enter(void);

int main(int argc, char *argv[])
{
	char command[80];
	char reason[160];
	time_t over;
	int usernum;
	struct acct_rec account;
	
	init();

	if (argc == 1)
	{
		while (toupper(command[0]) != 'Q')
		{
			qprintf("[1;1H[2JSuspendor Door by RDS\r\r");
			qprintf(" [S]uspend a User\r");
			qprintf(" [R]emove Suspension\r\r");
			qprintf(" [Q]uit\r");
			qprintf("\r `-> ");
			qgets(command, 79);
			if (toupper(command[0]) == 'S')
			{
				qprintf("Name of user to suspend: ");
				qgets(command, 79);
				if ( (usernum = find_user_name(command)) != -1)
				{
					if (load_user_account(&account, usernum))
					{
						qprintf("Suspend for how many days: ");
						qgets(command, 3);
						qprintf("Reason (2 lines max) - Make it descriptive\rThe user will see this, don't be too harsh\r: ");
						qgets(reason, 159);
						qprintf("Suspending %s for %d days\r", account.acctname, atoi(command));
						suspend_user(account.acctname, atoi(command), reason);
						press_enter();
						continue;
					} else {
						qprintf("Couldn't load user record\r");
						press_enter();
					}
				} else {
					qprintf("Couldn't find any user named %s\r", command);
					press_enter();
				}
			}
			if (toupper(command[0]) == 'R')
			{
				qprintf("Which user to reinstate: ");
				qgets(command, 79);
				if (is_user_suspended(command))
				{
					unsuspend_user(command);
					press_enter();
				} else {
					qprintf("That user is not suspended\r");
					press_enter();
				}
			}
		}
	} else {
		if (is_user_suspended(myacct->acctname))
		{
			if (still_suspended())
			{
				qprintf("Your account has been suspended.  During the time your account is suspended\r");
				qprintf("you will not be able to log in.\r\r");
				qprintf("The reason for your suspension is:\r%s\r\r", su.reason);
				over = su.timestamp + (su.days * DAY);
				qprintf("You will be able to login at %s\r\r", ctime(&over));
				press_enter();
				bbs_logoff(who);
			} else {
				unsuspend_user(myacct->acctname);
				qprintf("Your account was suspended.  It is now reactivated.  Your account\r");
				qprintf("was suspended for the given reason:\r%s\r", su.reason);
				qprintf("Please refrain from annoying and inconsiderate behavior and heed\rSysop warnings in the future.\r\r");
				press_enter();
				return(0);
			}
		} else {
			return(0);
		}
	}
}

void press_enter(void)
{
	char temp[3];

	qprintf("Press Enter to continue");
	qgets(temp, 2);
}

void suspend_user(char *name, int days, char *reason)
{
	FILE *f;
	char fname[128];
	int rec;
	
	sprintf(fname, "%s/suspended.dat", cfg->data_path);
	qprintf("Opening %s\r", fname);
	if ( (f = fopen(fname, "a+")) == 0)
	{
		send_lprintf("Suspendor:  Couldn't open suspension file: %s", fname);
		return;
	} else {
		if (!is_user_suspended(name))
		{
			if ( (rec = find_empty_record()) != -1)
			{
				fseek(f, rec * sizeof(su), SEEK_SET);
			} else {
				fseek(f, 0, SEEK_END);
			}
			strcpy(su.acctname, name);
			strcpy(su.reason, reason);
			su.timestamp = time(NULL);
			su.days = days;
			if (fwrite(&su, sizeof(su), 1, f))
				qprintf("\rUser suspended\r");
			else
				qprintf("\rError Suspending user\r");
			fclose(f);
			return;
		} else {
			qprintf("That user is already suspended!\r");
			fclose(f);
		}
	}
}

void unsuspend_user(char *name)
{
	FILE *f;
	char fname[128];
	
	sprintf(fname, "%s/suspended.dat", cfg->data_path);
	if ( (f = fopen(fname, "r+")) == 0)
	{
		return;
	} else {
		fseek(f, 0, SEEK_SET);
		while (fread(&su, sizeof(su), 1, f))
		{
			if (strcmp(name, su.acctname) == 0)
			{
				fseek(f, sizeof(su) * -1, SEEK_CUR);
				memset(&su, 0, sizeof(su));
				if (!(fwrite(&su, sizeof(su), 1, f)))
					qprintf("There was an error removing your suspension record.\rPlease contact the sysop about this immediately\r");
				fclose(f);
				return;
			}
		}
		fclose(f);
		return;
	}
}

int is_user_suspended(char *name)
{
	FILE *f;
	char fname[128];
	
	sprintf(fname, "%s/suspended.dat", cfg->data_path);
	if ( (f = fopen(fname, "r")) == 0)
	{
		return(0);
	} else {
		fseek(f, 0, SEEK_SET);
		while (fread(&su, sizeof(su), 1, f))
		{
			if (strcmp(name, su.acctname) == 0)
			{
				fclose(f);
				return(1);
			}
		}
		fclose(f);
		return(0);
	}
}

int find_empty_record(void)
{
	FILE *f;
	char fname[128];
	int ctr=0;
	
	sprintf(fname, "%s/suspended.dat", cfg->data_path);
	if ( (f = fopen(fname, "r")) == 0)
	{
		return(0);
	} else {
		fseek(f, 0, SEEK_SET);
		while (fread(&su, sizeof(su), 1, f))
		{
			if (su.acctname[0] == 0)
			{
				fclose(f);
				return(ctr);
			}
			ctr++;
		}
		fclose(f);
		return(-1);
	}
}

int still_suspended()
{
	if (time(NULL) > (su.timestamp + (su.days * DAY)))
		return(0);
	else
		return(1);
}
