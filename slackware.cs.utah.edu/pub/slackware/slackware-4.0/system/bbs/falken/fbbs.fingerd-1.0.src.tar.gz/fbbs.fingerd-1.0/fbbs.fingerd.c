#include <stdio.h>
#include "doorutil.h"

int main()
{
	int ctr;
	char line[1024];

	util_init();
	fgets(line, sizeof(line), stdin);
	for (ctr = 0; ctr < numlines; ctr++)
		if (strlen(acnt[ctr].acctname))
			break;
	if (ctr != numlines)
	{
		printf("+----+----------------------+----------------------+-------------------------+\r\n");
		printf("|Line| Username             | Location             | Comment                 |\r\n");
		printf("+----+----------------------+----------------------+-------------------------+\r\n");
		for (ctr=0; ctr < numlines; ctr++)
		{
			if ((strlen(acnt[ctr].acctname)) && (!user[ctr].stealth))
			{
				printf("| %-2.2d | %-20.20s | %-20.20s | %-23.23s |\r\n", ctr, acnt[ctr].acctname, user[ctr].doors_id, acnt[ctr].comment);
			}
		}
		printf("+----+----------------------+----------------------+-------------------------+\r\n");
	} else {
		printf("There is currently no one logged into the BBS.\r\n");
	}
}
