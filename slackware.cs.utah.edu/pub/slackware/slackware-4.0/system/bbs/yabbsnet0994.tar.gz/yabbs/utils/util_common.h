/*
 * this file is a part of yabbs - yet another bulletin board system.
 * Copyright (C) 1993, 1994 Alex Wetmore.  
 * email: alex@phred.org
 * address: 6 rech ave
 *          oreland pa 19075
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#ifndef TRUE
#define TRUE 1
#define FALSE 0
#endif

unsigned long power(int base, int n);
#define killconnection(x) exit(1);
char opton(int option, int u);
char lower(char i);
char upper(char i);
void inttosubs(char *subs, unsigned long int *subsi);
int fexist(char *fname);
char readc(void);
void writec(char c);
char waitfor(char *okaych);
void sputs(char *st);
int readl(char *ptr, register int maxlen, register int echo);
void sgets(char *st, int max);
void sgetpw(char *st);
void dump(char *filename);
unsigned long power(int base, int n);
int ynprompt(char *st, int def);
void strmid(char *dup, char *src, int beg, int n);
void writebases(brec *base);
void readbases(brec **basep);
void readusers(void);
void waitkey(void);
void writeusers(void);
void drawuser(int u);
void noecho(void);
void echo(void);

#ifndef UTIL_COMMON_C
extern urec user[MAXUSERS];
extern int usernum;
#endif
