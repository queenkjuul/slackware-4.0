/*
 * this file is a part of yabbs - yet another bulletin board system.
 * Copyright (C) 1993, 1994 Alex Wetmore.  
 * email: alex@phred.org
 * address: 6 rech ave
 *          oreland pa 19075
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#define MNU_CONFIG "\
<Bold>p</Bold>)assword           <Bold>l</Bold>)ines per screen   <Bold>s</Bold>)ubscriptions<nl>\
<Bold>x</Bold>)pert toggle       <Bold>i</Bold>)nfo edit          <Bold>q</Bold>)uit<nl>\
<Bold>g</Bold>)oodbye<nl>"

#define MNU_MAIN "\
<Bold>m</Bold>)essage menu     <Bold>s</Bold>)etup menu       <Bold>t</Bold>)alk             <Bold>f</Bold>) g-files<nl>\
<Bold>c</Bold>)hannels (talk)  <Bold>w</Bold>)ho is online    <Bold>i</Bold>)nfo on a user   <Bold>g</Bold>)oodbye<nl>"

#define MNU_MSG "\
<Bold>n</Bold>)ext               <Bold>p</Bold>)revious           <Bold>c</Bold>)urrent            <Bold>j</Bold>)ump to message<nl>\
<Bold>f</Bold>)ind message       <Bold>e</Bold>)nter message      <Bold>r</Bold>)eply to message   <Bold>d</Bold>)elete message<nl>\
<Bold>b</Bold>)ase selection     <Bold>s</Bold>)ubscription setup <Bold>u</Bold>)ser list          <Bold>l</Bold>)ist titles<nl>\
<Bold>i</Bold>)nfo on a user     <Bold>g</Bold>)oodbye (logout)   <Bold>q</Bold>)uit<nl>"

#define MNU_GFILES "<nl>gfile: <Bold>#</Bold> to select, \
scroll (<Bold>u</Bold>)p, scroll (<Bold>d</Bold>)own, go (<Bold>b</Bold>)ack, \
or (<Bold>q</Bold>)uit : "

#define H_TALK "<Bold>:<lt>action></Bold> - Do an action.<nl>\
<nl>\
You can run one command many times with a different first argument by <nl>\
putting a list of arguments in parantheses.  For example \"/msg (user1 <nl>\
user2) hi there\" would send the message \"hi there\" to user1 and user2.<nl>"

#define H_MSG "\
<nl>\
----- basic stuff -----<nl>\
<Bold>/s</Bold> = save<nl>\
<Bold>/q</Bold> = quit (no save)<nl>\
<Bold>/?</Bold> = help<nl>\
<nl>\
---- editing stuff ----<nl>\
<Bold>/dx</Bold> = delete line number x.<nl>\
<Bold>/rx</Bold> = replace line x with new text.<nl>\
<Bold>/l</Bold> = list the message<nl>\
<Bold>/c</Bold> = clear message and start over<nl>\
-----------------------<nl>"
