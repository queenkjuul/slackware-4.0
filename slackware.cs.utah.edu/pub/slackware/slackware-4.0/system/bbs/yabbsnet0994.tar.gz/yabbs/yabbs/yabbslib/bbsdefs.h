/*
 * this file is a part of yabbs - yet another bulletin board system.
 * Copyright (C) 1993, 1994 Alex Wetmore.  
 * email: alex@phred.org
 * address: 6 rech ave
 *          oreland pa 19075
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/*
 * bbsdefs.h - part of the yabbs bulletin board package by alex wetmore
 *             see bbs.c for information on the system and copying.
 */

#include <stdio.h>                          /* standard i/o stuff       */
#include <unistd.h>                         /* for linux, has read()    */
#include <sys/file.h>                       /* low-level i/o stuff      */
#include <stdlib.h>                         /* standard library         */
#include <strings.h>                        /* string utils             */
#include <time.h>                           /* time stuff               */
#if TERMIO
#include <termio.h>                         /* termio terminal control  */
#else
#include <sgtty.h>                          /* sgtty terminal control   */
#endif
#include <sys/ioctl.h>                      /* i/o control              */
#include <sys/socket.h>                     /* sockets                  */
#include <netinet/in.h>                     /* tcp/ip stuff             */
#include <netdb.h>                          /* more net stuff           */
#include <errno.h>                          /* for perror               */
#include <signal.h>                         /* signal stuff             */
#include "yabbslib.h"                       /* bbs header file          */

#define YABBS
#ifndef TRUE
#define TRUE 1                              /* you might have these     */
#define FALSE 0
#endif

extern  int     s;                          /* socket for server        */
