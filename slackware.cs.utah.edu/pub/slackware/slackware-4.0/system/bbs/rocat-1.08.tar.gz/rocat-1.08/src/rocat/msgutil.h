// Filename:	msgutil.h
// Contents:	the object definition for the messages utility object
// Author:	Greg Shaw
// Created:	4/14/96

#ifndef _MSGUTIL_H_
#define _MSGUTIL_H_

#include "bbshdr.h"

#ifdef USE_DATABASE

#define MAX_IMPORT_MESSAGE	512*1024	// 512k max message


// Object:	msgutil
// Purpose:	encapsulate some of the methods for message utility that 
//		don't belong in the message object properly
// Attribute:	none
// Methods;	pimport - import private email (as a filter) to the BBS.
// Author:	Greg Shaw
// Created:	4/14/96

class msgutil:public Message
{
public:
	int pimport(void);	// import messages into BBS
};

#endif 

#endif // _MSGUTIL_H_
