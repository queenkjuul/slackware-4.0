#ifndef _ALLIANCE_H_
#define _ALLIANCE_H_

#include "bf.h" 

typedef struct alliancerec {
  stringtype name;	// name of alliance
  long num;		// ordinal number of alliance
  char password[9];	// password to join alliance
  struct alliancerec *next;	// next alliance in list
} alliancerec;

#endif // _ALLIANCE_H_
