#!/usr/bin/perl

# Program: checkpw.pl
# Purpose: check the passwd file against the userlog.  Delete those users
# found in the passwd file but not in the userlog that have /bbs/bbs as 
# their shell.
# Author:  Greg Shaw
# Created: 5/15/95

# open the passwd file

	open(USERLOG,'/bbs/admin/userlog') || die "Can't open userlog.";

	while (<USERLOG>) {
		if (/\[A (\w+)/)		# got 1st line?
		{
			$array{$1} = 1;
		}
	}
	close(USERLOG);

	open(PASSWD,'/etc/passwd') || die "Can't open passwd file.";
	open(RFILE,'>remove.dirs') || die "Can't open remove.dirs output file.";
	open(NPWFILE,'>passwd.new') || die "Can't open passwd.new output file.";

	while (<PASSWD>) {
		if (/\/bbs\/bbs$/)	# look for shell
		{
			@pw = split(/:/);
			$name = @pw[0];
			$home = @pw[5];
			if (!$array{$name})	# not in userlog?
			{	# nuke
				# generate output file
				print (RFILE "rm -rf $home\n");
			}
			else	# in passwd file
			{
				print (NPWFILE);
			}
		}
		else	# non-bbs user passwd file
		{
			print (NPWFILE);
		}
	}
	close(PASSWD);
	close(NPWFILE);
	close(RFILE);

