#ifndef _LOAD_H_
#define _LOAD_H_

#include "bf.h"


typedef struct optionrecord {
  int timelimit;		// timelimit for players
  int entries; 			// number of entries
  int messagelimit; 		// # of days until a message is deleted
  int daystorun; 		// # of days until game automatically resets
  int daysingame;		// days in current cycle
  int firstime;			// is this the first time into the program?
  int difficulty;		// game difficulty (1=easy 10=very hard)
  int scores;			// generate a scores file?
  char scorespath[MAXPATHLEN];	// path to scores file
  int sysopacl;			// access level for sysop
  time_t  date;			// date of options write
} optionrecord;   /* of the options record */

typedef struct telerec {
  long sector;			// sector of teleporter
  struct telerec *next;		// next teleporter in list
} telerec;

#endif //_LOAD_H

