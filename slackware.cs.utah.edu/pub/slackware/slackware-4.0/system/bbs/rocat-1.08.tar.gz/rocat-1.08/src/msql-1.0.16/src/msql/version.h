/*
** Mini SQL version details
*/

#define PROTOCOL_VERSION 	6
#define SERVER_VERSION  	"1.0.16"

