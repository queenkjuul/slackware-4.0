#!/usr/bin/perl
# get the next unused UID from the passwd file

open(PWFILE,"</etc/passwd") || die "Can't open passwd file";

# read the entire passwd file, recording UIDs
while (<PWFILE>)
{
	@pwline=split(/:/);
	$uid = @pwline[2];
	$array{$uid} = 1;
}

close(PWFILE);

$new = 1000;	# don't asssign ID less than 1000

while ($new < 50000)
{
	if (!$array{$new})	# not set?  Then we're done.
	{
		printf("%d",$new);
		exit 0;
	}
	else
	{
		$new += 1;
	}
}
