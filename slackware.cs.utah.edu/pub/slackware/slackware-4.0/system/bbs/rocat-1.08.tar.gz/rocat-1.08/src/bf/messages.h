#ifndef _MESSAGES_H_
#define _MESSAGES_H_


#include "bf.h"


typedef struct bfMessage {
  stringtype message;		// message
  nametype fromwho; 		// from 
  nametype towho;		// to 
  time_t day;			// date of sending
  long mesnum;			// ordinal message number
  long alliance;		// alliance of recipient
  boolean broadcast; 		// broadcast message? (e.g. for all)
  boolean deleted;		// deleted message?
  struct bfMessage *next;	// next message in list
} bfMessage;


#endif // _MESSAGES_H_

