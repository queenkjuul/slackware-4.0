#include <stdio.h>
#include <sys/types.h>

main()
{
	u_int	foo;

	foo = 1;
}
