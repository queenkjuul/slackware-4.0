#include <stdio.h>

main()
{
	FILE *f;

	f = fopen("file","a+");
	fprintf(f,"wow, it works!\n");
	fclose(f);
}
