#ifndef _ARMY_H_
#define _ARMY_H_

#include "bf.h"

// Structure:   Army
// Purpose:     encapsulate the army (for stationed armies)
// Author:      Greg Shaw
// Created:     6/26/95

typedef struct Army {
        long sector;            // where
        nametype owner;         // who
        long men;               // how big
        long region;            // what region
        long region_sub;        // sub-part of region
        long purpose;           // what purpose
        struct Army *next;   // next guy in the list
} Army;


#endif // _ARMY_H_
