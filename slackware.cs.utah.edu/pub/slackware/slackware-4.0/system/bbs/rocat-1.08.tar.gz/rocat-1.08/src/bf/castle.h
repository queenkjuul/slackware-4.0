#ifndef _CASTLE_H_
#define _CASTLE_H_

#include "bf.h"

typedef struct Castle {
  boolean attacked;	// has the castle been attacked while player was away?
  nametype name;	// name of castle
  nametype oldowner; 	// previous owner of castle 
  nametype alias;	// owner's alias
  nametype attackedby;	// last attacked by
  long sector;		// resident sector
  long region; 		// region
  long region_sub;	// sub-region
  long castype; 	// castle type
  long armor;		// armor of defenders
  long weapon;		// weapons of defenders
  long defend; 		// number of defenders
  long alliance;	// alliance of castle
  long oil;		// amount of burning oil
  long wall; 		// height of wall
  long moat; 		// width of moat
  long towers; 		// number of (wizard) towers
  long newgold;		// new gold obtained during failed takeover attempt
  struct Castle *next;	// next castle in list
} Castle;

#endif //  _CASTLE_H_
