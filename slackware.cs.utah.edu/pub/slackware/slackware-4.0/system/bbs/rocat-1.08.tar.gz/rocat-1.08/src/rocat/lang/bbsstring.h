// Filename:	bbsstring.h
// Contents:	Those strings that couldn't be changed within the language
//		object.
// Author:	Greg Shaw
// Created:	12/8/94

#ifndef _BBSSTRING_H_
#define _BBSSTRING_H_

// the sysexec object is situated below the language object, which means 
// it can't take advantage of the language object.

#define EXPIRE3MINUTES  "\n\nYour time expires in 3 minutes.\n"
#define	PREPARETOLOGOFF	"Please prepare to log off.\n"
#define	YOUWILLBEOFF	"\n\nYou will be logged off in less than one minute.\n\n"
#define	PLEASELOGOFF	"Please log off.\n"

// bbsint lies below the language object 

#define CONTINUE 	"       <\\f4continue\\n>\\n"
#define QTOQUIT         "Press '\\f7q\\n' to quit, space bar to page\\n"

// rochatd:

#define CHATDHEADER "User         Alias         Messages        On since\n"

// NOTE: the below is *NOT* a typo.  To put a colorized message at the 
// exit of a user from the chat room, the below '10' is necessary.
// Subtract 1 from the colors in the BBS to get the colors used by
// the curses package.  e.g.: in the BBS, red on black is 21  
//            In the chat module, it is 10
// A two digit number is MANDATORY for normal operation.  If it is not
// there, a core dump could result.
#define HASLEFTROOM  "%s has left the room.10"

#endif // _BBSSTRING_H_
