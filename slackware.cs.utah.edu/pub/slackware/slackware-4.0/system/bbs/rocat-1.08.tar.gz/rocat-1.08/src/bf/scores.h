
#ifndef _SCORES_H_
#define _SCORES_H_

#include "bf.h"


typedef struct scorerec {
  long score;			// score
  char name[32]; 		// name of player
  char killedby[32];		// last killed by
  long alliance; 		// alliance of player
  long members;			// number of members in alliance
} scorerec;

#endif // _SCORES_H_
