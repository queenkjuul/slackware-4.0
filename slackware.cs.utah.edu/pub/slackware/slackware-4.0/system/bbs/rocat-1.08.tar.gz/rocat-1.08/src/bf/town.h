#ifndef _TOWN_H_
#define _TOWN_H_

#include "bf.h"

typedef struct Village {
  long sector;			// location of town
  nametype name;		// name of town
  long price; 			// price basis
  long men; 			// # of men available for purchase
  long regeneration;		// regeneration time
  struct Village *next;	// next village in list
} Village;

#endif // _TOWN_H_
