/*
version: $Id: login.c,v 5.123 1995/01/18 01:24:58 hitman Exp $
purpose: Get a login from the user.
updates: All updates are handled by RCS
warnings: Warning on HP's with the declariation of getlogin.
*/

#include <stdio.h>

#ifndef __MSDOS__
#	include <unistd.h>
#	include "hsh_glob.h"
#	include "hshgen_s.h"
#else				/* not_MSDOS */
#	include "..\src\hsh_glob.h"
#	include "..\src\hshgen_s.h"
#endif				/* MSDOS */


/* Define functions and procedures.                                 */
int             login(_character * Character);

int 
login(_character * Character)
{
#ifdef DEBUG
	fprintf(stderr, "** %s: **\n", __FILE__);
#endif

#ifdef __MSDOS__
	printf("Login: ");
	gets(Character->CharacterName);
#else
	/* Get the username from the operating system and assign it This is
	   going to set the user name for the entire program */
	strcpy(Character->CharacterName, (char *) getlogin());
/* I don't understand why I have to typedef the above, probally because it is not getting read from the 'unistd.h' header.  If the extern was read, this program may know that getlogin is defined 'extern char *getlogin (void)' and this error would clean up.  Until then I typecasted this one in that way. */
#endif

/* somewhere we need to decide if the username is equal to BBS  and if it
is we need to get the users realname and set up the rest for them. */

#ifdef DEBUG
	fprintf(stderr, "** %s: Username =  %s, Program = %s **\n", __FILE__, Character->CharacterName, PROGRAM);
#endif

	return (RET_NORMAL);
}				/* login */
