/********************************************************************/
/*	file: redraw_screen.c */
/*	version: $Id: redraw_s.c,v 5.120 1995/01/04 12:25:19 hitman Exp $
 	purpose: Clears and redraws the screen for users.
	updates: All updates are handled by RCS
																	*/
/* The Hitman 1993													*/
/********************************************************************/

#include <stdio.h>

#ifndef __MSDOS__
#	include "hsh_glob.h"
#	include "hsh_sub.h"
#	include "hshgen_s.h"
#	include "hshgen_h.h"
#else  /* NOT_msdos */
#	include "..\src\bbs_fn-s\hsh_glob.h"
#	include "..\src\bbs_fn-s\hsh_sub.h"
#	include "..\src\bbs_fn-s\hshgen_s.h"
#	include "..\src\bbs_fn-s\hshgen_h.h"
#endif /* msdos */
/********************************************************************/
/* Define functions and procedures.                                 */
int redraw_screen(_character *Character);

/********************************************************************/
int redraw_screen(_character *Character)
{
#ifdef DEBUG
	fprintf(stderr, "** %s: **\n", __FILE__);
#endif

	/** Clear the screen and redisplay the prompt **/
#ifdef _MSDOS_
	clrscr();
#else
	system("clear");
#endif

	return(RET_NORMAL); /* show_prompt */
}
