/* file: version.h */
/* purpose: MSDOS Only -inform user of version */
#define CCVER           "Turbo C++ Version 1.01, (c)1990 by Borland International, Inc."
#define PROGRAM         "bbs_scri"
#define OSVER           "MSDOS 6.2"
#define COPYRIGHT       "1993-94 GNU General Software License"
#define VER                     "??.???.???.??a, b5.88.2.0"
#define COMPBY          "hit379"
#define KPROGRAM                 "Genaric Multiple User Kernel"
#define KPROG_ABRV               "K7"
#define KCOPYRIGHT               "1993 GNU General Software License"
#define KVER                     "0.1.1a"
/* End-Of-version.h */

/* Special options */
#define ENGLISH
#define FINITE
