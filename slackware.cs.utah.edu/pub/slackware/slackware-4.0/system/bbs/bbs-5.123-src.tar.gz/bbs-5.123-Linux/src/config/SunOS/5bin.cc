# [$Id$]
# compiler:	Sun Release 4.1 System V - C Compiler (very K&R)
# DONOT: CC=/usr/5bin/cc
DEFINES =$(G_DEFINE) -I"/usr/5include"
#DEFINES =$(G_DEFINE) -DDEBUG -I"/usr/5include"
UPDAT_OPT=$(DEFINES) -E -M
CFLAGS = -g3 $(DEFINES) -Wall -fmemoize-lookups -target sun4
CCVER = echo "Sun Release 4.1 System V - C Compiler \($(CC)\)"
#
