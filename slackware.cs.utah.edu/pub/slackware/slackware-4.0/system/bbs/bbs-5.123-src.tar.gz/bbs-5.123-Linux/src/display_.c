/*
file: display_charbuff.c
version: $Id: display_.c,v 5.123 1995/01/18 01:24:58 hitman Exp $
purpose: I am not really sure.
updates: All updates are handled by RCS
*/

#include <stdio.h>

#ifndef __MSDOS__
#	include "hsh_glob.h"
#	include "hsh_sub.h"
#	include "hshgen_s.h"
#	include "hshgen_h.h"
#else				/* not_MSDOS */
#	include "..\src\bbs_fn-s\hsh_glob.h"
#	include "..\src\bbs_fn-s\hsh_sub.h"
#	include "..\src\bbs_fn-s\hshgen_s.h"
#	include "..\src\bbs_fn-s\hshgen_h.h"
#endif				/* MSDOS */


/****************************************************************/
/* Define functions and procedures.                             */
int             display_charbuff(_character * Character);

/****************************************************************/
int 
display_charbuff(_character * Character)
{
#ifdef DEBUG
	fprintf(stdout, "** %s: **\n", __FILE__);
#endif
	return (RET_NORMAL);
}
