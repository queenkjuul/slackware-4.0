/*
version: [$Id: statetbl.h,v 5.123 1995/01/18 01:24:58 hitman Exp $]
purpose: Define something 
*/

#ifndef __STATETBL_H
#define __STATETBL_H

/* Structure for process table.                                 */
typedef struct {
	int state;              /* State of entry in the table. */
	int (*func)(_character *Character);     /* Function to call.            */
	int nextstate[3];       /* Next state to call.          */
} _statetbl; /* _statetbl */

#endif /* __STATETBL_H */
