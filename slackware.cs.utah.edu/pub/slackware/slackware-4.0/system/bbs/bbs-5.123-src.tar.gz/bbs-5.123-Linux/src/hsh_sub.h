/*
version: [$Id: hsh_sub.h,v 5.123 1995/01/18 01:24:58 hitman Exp $]
purpose: Lists out variables that are passed from subfunction (object) to main program.
updates: All updates are handled by RCS
*/
#include "hsh_glob.h"

#ifndef __HSH_SUB_H
#define __HSH_SUB_H

/* define external variables that this program uses.                */
extern char *com_ln[MAX_ARG];   /* The input from the user  */
										/* from the command line.   */

#endif /* __HSH_SUB_H */
