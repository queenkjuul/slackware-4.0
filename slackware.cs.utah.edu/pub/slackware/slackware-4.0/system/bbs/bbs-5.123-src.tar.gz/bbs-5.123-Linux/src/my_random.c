/*
version: [$Id: my_random.c,v 5.123 1995/01/18 01:24:58 hitman Exp $]
purpose: produce a random number.
updates: All updates are handled by RCS
Author: The Hitman 1994
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "version.h"

#ifndef __MSDOS__
#	include "bbs_director.h"
#else				/* not_MSDOS */
#	include "..\src\bbs_dire.h"
#endif				/* MSDOS */

int
my_random(void)
{
	int             chance;
	int             utime;
	long            ltime;

#if DEBUG
	fprintf(stderr, "** %s: **\n", __FILE__);
#endif
	/** time items **/
	ltime = time(NULL);
	utime = (unsigned int) ltime / 2;

	srand(utime);
	srand(rand());

	chance = rand();
	chance %= 10;

#if DEBUG
	fprintf(stderr, "** %s: utime = %d, chance = %d **\n", __FILE__, utime, chance);
#endif

	return (chance);
}				/* my_random */
