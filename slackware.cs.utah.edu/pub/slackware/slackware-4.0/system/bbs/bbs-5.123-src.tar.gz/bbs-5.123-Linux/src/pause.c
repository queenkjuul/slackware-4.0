/*
version: [$Id: pause.c,v 5.123 1995/01/18 01:24:58 hitman Exp $]
purpose: Pause the screen and wait for the user to hit a key.
updates: All updates are handled by RCS
Author: The Hitman 1994
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "version.h"

#ifndef __MSDOS__
#	include "bbs_director.h"
#else				/* not_MSDOS */
#	include "..\src\bbs_dire.h"
#endif				/* MSDOS */

/* Screen Pause */
int
pause(void)
{
	int             temp;

#if DEBUG
	fprintf(stderr, "** %s: **\n", __FILE__);
#endif
	/* display a little message and wait for the user to hit return or
	   something. */
	puts("\n-- Hit ENTER Please --");
#ifndef __MSDOS__
	temp = getchar();
#else				/* not_MSDOS */
	getche();
#endif				/* MSDOS */

	return (0);
}				/* pause */
