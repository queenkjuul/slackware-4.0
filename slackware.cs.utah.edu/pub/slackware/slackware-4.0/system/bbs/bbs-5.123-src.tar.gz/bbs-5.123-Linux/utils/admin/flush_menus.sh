#!/bin/sh
#
# [$Id: flush_menus.sh,v 5.123 1995/01/18 01:27:07 hitman Exp $]
# purpose: Wipe out all the menus in the root of the bbs system.
#
MENUS="../../*.dat"


if [ -f $MENUS ]; then 
#	Make the menus writeable
	chmod 644 $MENUS

#	Destroy the menus
	rm -f $MENUS
else # if_menus_remove #
	echo "Nothing to remove..."
fi # no_menus #
