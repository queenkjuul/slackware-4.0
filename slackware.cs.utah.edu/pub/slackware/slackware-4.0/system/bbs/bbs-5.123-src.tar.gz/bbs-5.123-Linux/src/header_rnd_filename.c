/*
version: [$Id: header_rnd_filename.c,v 5.123 1995/01/18 01:24:58 hitman Exp $]
purpose: get the filepath of the random header text file.
updates: All updates are handled by RCS
Author: The Hitman 1994
*/

#include <stdio.h>
#include <stdlib.h>
#include "version.h"

#ifndef __MSDOS__
#	include <strings.h>
#	include "bbs_director.h"
#else				/* not_MSDOS */
#	include <string.h>
#	include "..\src\bbs_dire.h"
#endif				/* MSDOS */

char           *
header_rnd_filename(const char *filename)
{
	char            tex_filename[PATH_LENGTH];	/* I am the filename for
							   the binary file */
	char           *text_filename;	/* I am the pointer to the binary */

	extern int      my_random(void);

#if DEBUG
	fprintf(stderr, "** %s: filename = %s **\n", __FILE__, filename);
#endif
	/** Do the same for the input file. **/
	strcpy(tex_filename, SCREENS);	/* Set down the directory location */
	strcat(tex_filename, filename);	/* Add the filename */
	text_filename = tex_filename;	/* Point to it */
	/** This is my fix for the random number, could be better **/
	switch (my_random())
	{
	case 0:
		strcat(text_filename, ".0");
		break;
	case 1:
		strcat(text_filename, ".1");
		break;
	case 2:
		strcat(text_filename, ".2");
		break;
	case 3:
		strcat(text_filename, ".3");
		break;
	case 4:
		strcat(text_filename, ".4");
		break;
	case 5:
		strcat(text_filename, ".5");
		break;
	case 6:
		strcat(text_filename, ".6");
		break;
	case 7:
		strcat(text_filename, ".7");
		break;
	case 8:
		strcat(text_filename, ".8");
		break;
	case 9:
		strcat(text_filename, ".9");
		break;
	}			/* add_random_extention */

/* Due to the limitations of the ''8 dot 3'' file nameing convention under MSDOS I can't add the following extention. */
#ifndef __MSDOS__
	/* add the last part */
	strcat(text_filename, SCREENS_EXT);	/* add the extention */
#endif				/* not_MSDOS */

#if DEBUG
	fprintf(stderr, "** %s: text_filename = %s **\n", __FILE__, text_filename);
#endif
	return (text_filename);
}				/* header_rnd_filename */
