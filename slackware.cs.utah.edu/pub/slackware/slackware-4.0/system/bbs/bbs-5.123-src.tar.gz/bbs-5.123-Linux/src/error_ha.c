/*
version: $Id: error_ha.c,v 5.120 1995/01/04 12:25:19 hitman Exp $
purpose:
updates: All updates are handled by RCS
*/

#include <stdio.h>

#ifndef __MSDOS__
#	include "hsh_glob.h"
#	include "hsh_sub.h"
#	include "hshgen_s.h"
#	include "hshgen_h.h"
#else /* not_MSDOS */
#	include "..\src\bbs_fn-s\hsh_glob.h"
#	include "..\src\bbs_fn-s\hsh_sub.h"
#	include "..\src\bbs_fn-s\hshgen_s.h"
#	include "..\src\bbs_fn-s\hshgen_h.h"
#endif /* MSDOS */

/********************************************************************/
/* Define functions and procedures.                                 */
int error_handle(_character *Character);

/********************************************************************/
int error_handle(_character *Character)
{
#ifdef DEBUG
	fprintf(stderr, "** %s: **\n", __FILE__);
#endif
	fprintf(stderr, "ERROR!");

	return(RET_NORMAL);
}

