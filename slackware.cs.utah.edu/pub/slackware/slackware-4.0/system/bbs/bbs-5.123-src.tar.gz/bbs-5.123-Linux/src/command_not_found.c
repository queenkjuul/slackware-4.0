/*
version: [$Id: command_not_found.c,v 5.123 1995/01/18 01:24:58 hitman Exp $]
purpose: Tell the user that the command is not found.
updates: Handled by RCS
*/

#include <stdio.h>

#ifndef __MSDOS__
#	include "hshgen_s.h"
#else				/* not_MSDOS */
#	include "..\src\bbs_fn-s\hshgen_s.h"
#endif				/* MSDOS */

int             command_not_found(_character * Character);

int
command_not_found(_character * Character)
{
	/* print out a message to the user letting them know that a command
	   is not found */
	printf("%s: Command not found.\n", Character->input_string);

	return (RET_NORMAL);
}				/* command_not_found.c */
