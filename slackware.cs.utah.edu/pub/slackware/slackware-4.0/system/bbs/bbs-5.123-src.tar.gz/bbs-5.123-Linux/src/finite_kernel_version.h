/* DO NOT EDIT, USE: MAKE VERSION */
/* file: version.h */
/* purpose: inform user of version */
#define KPROGRAM                 "Genaric Multiple User Kernel"
#define KPROG_ABRV               "K7"
#define KCOPYRIGHT               "1993 GNU General Software License"
#define KVER                     "0.1.1a"
/* End of file */
