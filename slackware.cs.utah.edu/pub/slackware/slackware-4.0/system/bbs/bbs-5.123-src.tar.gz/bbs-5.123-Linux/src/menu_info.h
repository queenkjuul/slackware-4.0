/*
version: [$Id: menu_info.h,v 5.123 1995/01/18 01:24:58 hitman Exp $]
purpose:  This file defines the information the works with the menu files.  This file defines most of the menu information
updates: All updates are handled by RCS
Author: The Hitman 1994	
*/

#include <stdio.h>

#ifndef __MENU_INFO_H
#define __MENU_INFO_H

/* These are the definitions of the sizes for the structure
"MENU_struct".  They are used throughout the program for
comparisions etc... */
#define MAXKEY	5
#define MAXLENGTH	50
#define MAXLINES	10

 /* The follow are pretty generic, but I would like to make sure they work the first time. */
#ifndef TRUE
#	define TRUE 0
#endif /* TRUE */

#ifndef FALSE
#	define FALSE 1
#endif /* FALSE */


/* This structure controls the menus and the format of both the text and binary menu inforamation */
typedef struct 
  {
    int index;
    char keyword[MAXKEY];
    char description[MAXLENGTH];
    char information[MAXLENGTH];
    char other[MAXLENGTH];
  } MENU_struct;

#endif /*  __MENU_INFO_H */
