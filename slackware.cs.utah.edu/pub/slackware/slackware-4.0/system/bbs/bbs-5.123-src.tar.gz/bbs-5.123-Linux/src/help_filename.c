/*
version: [$Id: help_filename.c,v 5.123 1995/01/18 01:24:58 hitman Exp $]
purpose: get the filepath of the menu_text_file.
updates: All updates are handled by RCS
Author: The Hitman 1994
*/

#include <stdio.h>
#include <stdlib.h>
#include "version.h"

#ifndef __MSDOS__
#	include <strings.h>
#	include "bbs_director.h"
#else				/* not_MSDOS */
#	include <string.h>
#	include "..\src\bbs_dire.h"
#endif				/* MSDOS */
char           *
help_filename(const char *filename)
{
	char            tex_filename[PATH_LENGTH];	/* I am the filename for
							   the binary file */
	char           *text_filename;	/* I am the pointer to the binary */

#if DEBUG
	fprintf(stderr, "** %s: filename = %s **\n", __FILE__, filename);
#endif
	/** Do the same for the input file. **/
	strcpy(tex_filename, HELP);	/* Set down the directory location */
	strcat(tex_filename, filename);	/* Add the filename */
	text_filename = tex_filename;	/* Point to it */

#if DEBUG
	fprintf(stderr, "** %s: text_filename = %s **\n", __FILE__, text_filename);
#endif
	return (text_filename);
}				/* help_filename */
