/*
version:  [$Id: bbs_script.c,v 5.120 1995/01/04 12:26:00 hitman Exp $]
purpose:  This is the main bbs program that reads and interpretes the menus for the users.
updates:  All updates are handled by RCS
Author:  The Hitman 1994
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#ifndef __MSDOS__
#	include <strings.h>
#	include <time.h>
#endif /* not_MSDOS */

#ifndef __MSDOS__
#	include "bbs_director.h"
#	include "menu_info.h"
#	include "bbs_fn-src/hsh_glob.h"
#	include "bbs_fn-src/hsh_sub.h"
#	include "bbs_fn-src/hshgen_s.h"
#	include "bbs_fn-src/hshgen_h.h"
#else /* not_MSDOS */
#	include "..\src\bbs_dire.h"
#	include "..\src\menu_inf.h"
#	include "..\src\bbs_fn-src/hsh_glob.h"
#	include "..\src\bbs_fn-src/hsh_sub.h"
#	include "..\src\bbs_fn-src/hshgen_s.h"
#	include "..\src\bbs_fn-src/hshgen_h.h"
#endif /* MSDOS */
#include "version.h"

/* Finite state headers */

int
outpost_bbs (_character * Character)
{
  /* SUPER LOOP FOR MENUS */
  for (;;)
    {
	/* Display the menu choice for the user */
	display_menu( Character);

	/* Show a prompt to the user and get some information */
	show_prompt ( Character);

	/* Interperate the users commands and do work accordingly */
	interp_user_commands ( Character);

      /** END THE SUPER LOOP **/
    }				/* for_the_super_loop */
}				/* main */
