/*
version: [$Id: redraw_screen.c,v 5.123 1995/01/18 01:24:58 hitman Exp $]
purpose: Clears and redraws the screen for users.
updates: All updates are handled by RCS
*/

#include <stdio.h>
#include <stdlib.h>

#ifndef __MSDOS__
#	include "hshgen_s.h"
#else				/* NOT_msdos */
#	include "..\src\bbs_fn-s\hshgen_s.h"
#endif				/* msdos */

/* Define functions and procedures. */
int             redraw_screen(_character * Character);

int 
redraw_screen(_character * Character)
{
#ifdef DEBUG
	fprintf(stderr, "** %s: **\n", __FILE__);
#endif

	/* Clear the screen and redisplay the prompt */
#ifdef __MSDOS__
	clrscr();
#else
	printf("[2J");		/* this will only work on a vt type terminal */
#endif

	return (RET_NORMAL);
}				/* redraw_screen */
