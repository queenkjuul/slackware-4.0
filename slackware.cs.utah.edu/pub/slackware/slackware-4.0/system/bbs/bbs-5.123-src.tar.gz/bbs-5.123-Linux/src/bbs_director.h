/*
version: $Id: bbs_director.h,v 5.123 1995/01/18 01:24:58 hitman Exp $
purpose: this header keeps track of all the directories for the bbs this needs to be as specific as possible.
updates: All updates are handled by RCS
Author: The Hitman 1994
*/

/** Most things don't need to be changed here, but if you do */
/*	be careful, because this file defines the location for everything **/

/** NOTE: For directorys please include thier slash so the program knows */
/*	how to reference them.  This program should work on more operating */
/*	systems than unix. **/

#ifndef __BBS_DIRECTOR_H
#define __BBS_DIRECTOR_H

#define PATH_LENGTH	100

/* The following is very important, this will allow users to compile under unix and MSDOS. */
#ifndef __MSDOS__
#	define SLASH "/"
#else	/* not_MSDOS */
#	define SLASH "\\"
#endif /* MSDOS */

/** Things that have to do with executables paths **/
#define MAILER	"/bin/mail"

/** The directory structure for basic program **/
#define WELCOMES	"welcome"SLASH
#define UTILS		"utils"SLASH

/** These are for use with the help **/
#define HELP	"help"SLASH
#define HELP_FILE	"help.help"

/** These things have to do with the menus **/
#define MENUS		"menu"SLASH
#define MENU_EXT	".menu"
#define	FIRST_MENU	"main"

/** These things have to do with the screens **/
#define SCREENS		"screen"SLASH
#define SCREENS_EXT		".header"

/** things that have to do with the menu structure **/
#define COLUMN_LIM	50

#endif /* __BBS_DIRECTOR_H */
