/*
version: $Id: hsh_glob.h,v 5.123 1995/01/18 01:24:58 hitman Exp $
purpose: Header file that controls all global varaiables for this program.  This header is not to contain any variables, only pre-compiler definitions.
updates: All updates are handled by RCS
*/

#include "version.h"
/* Information about each functions title for calls back and forth */
#ifndef __MSDOS__
#	include "functbl.h"
#else /* NOT_msdos */
#	include "..\src\bbs_fn-s\functbl.h"
#endif /* msdos */

#ifndef __HSH_GLOB_H
#define __HSH_GLOB_H

/********************************************************************/
/* define some variable that have to do with the commands inputed   */
#define MAX_ARG 20
#define ARG_LEN 30
/********************************************************************/
/* later change this to take its mark from the command line         */
#if __MSDOS__
	#define SHELL "DOS Operating System"
#endif /* __MSDOS__ */

#endif /* __HSH_GLOB_H */
