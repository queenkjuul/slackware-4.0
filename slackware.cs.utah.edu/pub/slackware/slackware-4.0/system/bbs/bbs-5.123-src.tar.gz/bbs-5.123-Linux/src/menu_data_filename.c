/*
version: [$Id: menu_data_filename.c,v 5.123 1995/01/18 01:24:58 hitman Exp $]
purpose: get the filepath of the menu_data_file.
updates: All updates are handled by RCS
Author: The Hitman 1994
*/

#include <stdio.h>
#include <stdlib.h>
#include "version.h"

#ifndef __MSDOS__
#	include <strings.h>
#	include "bbs_director.h"
#else				/* not_MSDOS */
#	include <string.h>
#	include "..\src\bbs_dire.h"
#endif				/* MSDOS */


char           *
menu_data_filename(const char *filename)
{
	char            dat_filename[50];	/* I am the filename for the
						   binary file */
	char           *data_filename;	/* I am the pointer to the binary */

#if DEBUG
	fprintf(stderr, "** %s: filename = %s **\n", __FILE__, filename);
#endif
	/** Get the argument and give it to a variable, point to it */
	/* then add the rest of the items needed. * */
	strcpy(dat_filename, filename);	/* Set down the filename */
	data_filename = dat_filename;	/* point to it */
	strcat(data_filename, ".dat");	/* Add the extention */

#if DEBUG
	fprintf(stderr, "** %s: data_filename = %s **\n", __FILE__, data_filename);
#endif
	return (data_filename);
}				/* menu_data_filename */
