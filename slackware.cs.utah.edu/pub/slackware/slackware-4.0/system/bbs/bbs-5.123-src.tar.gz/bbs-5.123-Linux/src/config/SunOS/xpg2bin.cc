# [$Id$]
# compiler:	Sun Release 4.1 Xpg2 C Compiler (very K&R)
#DONOT: CC = /usr/xpg2bin/cc
DEFINES =$(G_DEFINE) -I"/usr/xpg2include"
#DEFINES =$(G_DEFINE) -DDEBUG -I"/usr/xpg2include"
UPDAT_OPT = $(DEFINES) -E -M
CFLAGS = -g3 $(DEFINES) -Wall -fmemoize-lookups -target sun4
CCVER = echo "Sun Release 4.1 Xpg2 C Compiler \($(CC)\)"
#
