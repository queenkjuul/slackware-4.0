/*
version: [$Id: dis_version.c,v 5.123 1995/01/18 01:24:58 hitman Exp $]
purpose: display version information for various parts of this program.
updates: All updates are handled by RCS
Author: The Hitman 1994
*/

#include <stdio.h>
#include "version.h"

#ifndef __MSDOS__
#	include "bbs_director.h"
#else				/* not_MSDOS */
#	include "..\src\bbs_dire.h"
#endif				/* MSDOS */

/**	Display the current version. **/
int
display_bbs_version()
{
#if DEBUG
	fprintf(stderr, "** %s: **\n", __FILE__);
#endif
	/** the version information **/
	fprintf(stdout, "\nProgram: %s, v%s\n", PROGRAM, VER);
	fprintf(stdout, "Copyright: %s, %s\n", COPYRIGHT, __DATE__);
	fprintf(stdout, "Compiled: %s, %s, %s\n\n", OSVER, CCVER, COMPBY);

	return (0);
}				/* display_bbs_version */
