/*
version:  [$Id: show_prompt.c,v 5.123 1995/01/18 01:24:58 hitman Exp $]
purpose:  Show a prompt on the screen for a user, and get command.  This
	may be replaced by the hsh shell show_prompt, and get_command.  Keep on the
	lookout for these code changes, the programs may be useful.
updates:  All updates are handled by RCS
Author:  The Hitman 1994
*/

#include <stdio.h>
#ifndef __MSDOS__
#	include <strings.h>
#endif				/* not_MSDOS */

#ifndef __MSDOS__
#	include "hsh_glob.h"
#	include "hshgen_s.h"
#else				/* not_MSDOS */
#	include "..\src\hsh_glob.h"
#	include "..\src\hshgen_s.h"
#endif				/* MSDOS */
#include "version.h"

int             show_prompt(_character * Character);

int 
show_prompt(_character * Character)
{
	/* set up the users prompt */
	fprintf(stdout, "%s's Choice: ", Character->CharacterName);
	/* Maybe if this program runs under novell I can get the novell user
	   name and userid from the system itself. After the anonomous user
	   login gets coded, I can use the users name from the login prompt
	   and write my own get login function for the msdos platform. */

	return (RET_NORMAL);
}				/* show_prompt */
