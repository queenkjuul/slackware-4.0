/*
version: $Id: hshgen_s.h,v 5.123 1995/01/18 01:24:58 hitman Exp $
purpose: Structure information for game .
updates: All updates are handled by RCS
*/

#ifndef __MSDOS__
#	include "hshgen_h.h"
#	include "hsh_glob.h"
#	include "menu_info.h"
#else /* NOT_msdos */
#	include "..\src\hshgen_h.h"
#	include "..\src\hsh_glob.h"
#	include "..\src\menu_info.h"
#endif /* msdos */


#ifndef __HSHGEN_S_H
#define __HSHGEN_S_H
/****************************************************************/
/* Channels and characters structure. */
/*  Remember to be safe I must initialize all integer variables because I am going to use some of these as pointers.  It is safer to initialize now than clean up a core
dump.*/
    typedef struct
    {
      /************************************************************/
      /* Channel datafile defined. */
      char
        CharacterName[MAXCHANNELNAME];
      /* Characters Name in the system        */

      /************************************************************/
      /* System control variables. */ 
      int nextstate,		/* Reference for the next function      */
        bypass,			/* Has the next state been bypassed.  Uses the same results as below. */
        ControlledBy,		/* Who controls this player? (COMPUTER, HUMAN). */
        Control,		/* Temp. variable for swapping.  The System Master uses this to keep track of the current players turn.  */
        Activity,		/* What is the character doing at the current time.   */
        QuestionStatus;
      /* Has the user been prompted for an   */
      /*      answer. 0 = NEUTRAL,              */
      /*              1 = YES,                  */
      /*              2 = NO                    */
      /*              3 = YES BUT NO ANSWER,    */
      /*              4 = FORFEIT THE QUESTION. */

      char Currmenu[MAXLINES]; /* the name of the current menu */

      char input_string[100];	/* Input buffer for the users strings.  */
      char output_string[100];	/* Output buffer for the users strings.     */

      int input_integer;		/* Input buffer for the users integers. */
      int output_integer;		/* Output buffer for the users integers.*/

    } _character;			/* _character */

#endif /* __HSHGEN_S_H */
