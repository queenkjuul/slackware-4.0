void dprintf(char *, ...);
void fatal_error(char *, ...);
void init_error(char *, ...);

#define OPTIONS 8

#define NODE     0
#define MODEM    1
#define REMOTE   2
#define DEBUG    3
#define SPY      4
#define USER     5 
#define NODETECT 6
#define NOGETTY  7
