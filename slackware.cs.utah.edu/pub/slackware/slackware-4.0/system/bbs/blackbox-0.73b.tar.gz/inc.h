#define INC_GET      1
#define INC_SETS     2
#define INC_SETN     3
#define INC_SHUTDOWN 4
#define INC_REPLY    5
#define INC_SEND     6

void handle_inc(int);
void init_inc();
void kill_inc();
int inc(int, int, char *);

