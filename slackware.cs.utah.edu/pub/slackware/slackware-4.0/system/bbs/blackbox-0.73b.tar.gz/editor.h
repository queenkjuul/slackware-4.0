#define CURSOR_LEFT  -1
#define CURSOR_RIGHT -2
#define CURSOR_UP    -3
#define CURSOR_DOWN  -4
#define CURSOR_END   -5
#define CURSOR_HOME  -6
#define UNKNOWN      -7

struct line_t {
  struct line_t *last, *next;
  char *text;
  int length;
};

void edit();
void edit_cleanup();
void insert_line();
void strip(struct line_t *);
