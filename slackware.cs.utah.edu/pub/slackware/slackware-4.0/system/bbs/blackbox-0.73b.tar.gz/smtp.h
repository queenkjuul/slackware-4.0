int smtp_connect(char *);
int smtp_command(char *);
void smtp_write(char *);
