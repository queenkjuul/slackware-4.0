int bb_lock(char *);
void bb_unlock();
void kill_locks();

extern int locked;

