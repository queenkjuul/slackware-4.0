#include "varlist.h" // ugly but functional

int output_raw(char *);
void output_raw(char);
int output_cooked(char *);
int voutput_raw(char *, ...);
int input_alpha(char *, int, char = 0);
int input_num(int);
int yesno();
int noyes();
int read_char();
void init_log();
void close_log();
void log(char *, ...);
int cook(char *, varlist *vlist = NULL);
int ansi_length(char *);
void flush();
void kill_line(int);
void ansi_clip(char *, int);
