int load_user(char *, varlist *);
void save_user();
int check_name(char *);
void make_email();
