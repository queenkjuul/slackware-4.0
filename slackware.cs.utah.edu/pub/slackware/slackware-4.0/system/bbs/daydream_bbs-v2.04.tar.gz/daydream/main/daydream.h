#include "dd.h"
#include <sys/types.h>
#include "config.h"
#include <stdio.h>
#include <time.h>
#include "global.h"
#include "md5.h"
#include "strf.h"
#include <signal.h>
#ifdef _WINDOWS
#include <io.h>
#include <stdlib.h>
#include <direct.h>
#endif


#define ReapChildren() while ((waitpid(�1, NULL, WNOHANG)) > 0);

struct olm {
	struct Node olm_head;
	char olm_msg[200];
	int olm_user;
	int olm_number;
};

/*
Routine definitions
*/

#ifdef _WINDOWS
char *ttyname(int);
void wintext(char *);
#define DIR long
struct dirent {
	char d_name[256];
};

DIR *opendir(char *);
struct dirent *readdir(DIR *);
int closedir (DIR *);

#define mkdir(x,y) mkdir(x)
#define sleep(x) Sleep(x*1000)
#define runstdio(x,y,z) system(x)
#define rundoor(x,y) system(x)
#endif

void freefstr(char *);
void freebstr(char *);
int newcopy(char *, char *);
int strlwr (char *);
int getfreeulp(char *, char *, int);
int initbgchecker(void);
int getreplyid(int, char *);
int askqlines();
int ispid(pid_t pid);
int dumpfilestofile(char *);
int isfiletagged(char *);
int findfilestolist(char *, char *);
int unflagfile(char *);
void makemainprompt(char *);
int checkforftp(int, char *, char *);
int writetomodem(char *);
int createflaglist();
int dropcarrier(void);
int ispw();
int checkcarrier(void);
int getin(void);
int clearlist(struct List *);
int visitbbs(int);
int waitforcall(int mode);
void dpause(void);
struct DayDream_Conference *findconf(int);
char *filepart(char *);
#ifdef UNIX
int rundoor(char *, char *);
#endif
unsigned char HotKey(int);
void smallstatus(void);
#ifdef UNIX
int runstdio(char *, char *, int);
#endif
int checkfilename(char *);
int getarchiver(char *);
int newrename(char *, char *);
unsigned long long getfreesp(char *);
char *currt(void);
int getsec(void);
#ifdef UNIX
void strupr(char *);
#endif
int handlectrl(int);
int changemsgbase(int, int);
void writelog(char *);
void changenodestatus(char *);
void DDPut(char *);
void LineChat(void);
int TypeFile(char *, int);
int Prompt(char *, int, int);
void StripAnsi(unsigned char *);
int CreateNewAccount (void);
int wildcmp(char *, char *);
int iswilds(char *);
int findusername(char *, int);
int checklogon(char *);
int cmppasswds(char *, unsigned char *);
void carrieroff(int);
void clear(void);
void enterbbs(void);
int domenu(int);
void userstats(void);
void questionnaire(void);
void stripansi(char *);
void versioninfo(void);
void edituser(int);
void testscreenl(void);
void saveuserbase(void);
void userlist(char *);
char *nextword(char *);
int getnodeinfo(void);
void usered(void);
int joinconf(int, int);
int nextconf(void);
int joinconfmenu(char *);
int entermsg(struct DayDream_Message *, int, char *);
int checkconfaccess(int, struct userbase *);
void getmsgptrs(void);
int setmsgptrs(void);
int readmessages (int, int);
int getfizesize(char *);
int replymessage(struct DayDream_Message *);
int lineed(char *, int, struct DayDream_Message *);
int cmbmenu(char *);
int nextbase(void);
int prevbase(void);
int pagesysop(char *);
int globalread(void);
int isbasetagged(int, int);
char *strspa(char *, char *);
int isanybasestagged(int);
int upload(int);
int freespace(void);
int localupload(void);
int filelist(int, char *);
char *mystrc(char *, char *);
void multibackspace(int bscnt);
int scanfornewmail(void);
char *mystrcn(char *, char *, int);
void strcupr(char *, char *);
int taged(char *, int);
int listtags(void);
void recountfiles(void);
void killflood(void);
int mktempdir(void);
int getdisplaymode(char *, int);
int syspw(void);
void removespaces(char *);
int runlogoffbatch(void);
void recfiles(char *, char *);
int docmd(char *, int);
int processmsg(struct dd_nodemessage *);
int makeflist(char *, char *);
int sendfiles(char *, char *);
void Remove(struct Node *);
int getfreetnode(void);
int getfreelnode(void);
int isnode(int, struct DayDream_NodeInfo *);
int nuaskh(void);
int nuaskr(void);
int setprotocol(void);
int rundoorbatch(char *batch, char *fn);
int globalnewscan(void);
int checkforlcfiles(void);
int checkforpartialuploads(int);
int copypartial(void);
int isaccess(int , int );
int logoff(char *);
int download(char *);
int sysopdownload(char *);
int bulletins(char *);
int comment(void);
int viewfile(char *);
int tagmessageareas(void);
int tagconfs(void);
int prevconf(void);
void who(void);
int olmsg(char *);
int movefile(char *, int);
int isconftagged(int);
int seceditor(struct DD_Seclevel *);
int strtoconfs(char *);
int genstdiocmdline(char *, char *, char *, char *);
int flagsingle(char *, int );
int isfreedl(char *);
int flagfile(char *, int );
int fileattach(void);
int edfile(char *, int , struct DayDream_Message *);
void cleantemp(void);
int getfidounique(void);
void deldir(char *);
int getfilesize(char *);
int editmsg(int);
int editmsghdr(int);
int strlena(char *);
int editfile (char *);
int fsed(char *, int, struct DayDream_Message *);
int analyzedszlog(char *, char *);
int maketmplist(void);
int autodisconnect(void);
int makelc(char *);
int dupecheck(char *);
int getpath(struct DayDream_Conference *, char *, int);
int runexamine(char *);
int findfile(char *, char *, struct DayDream_Conference *);
int addtag(char *, char *, int , int , int);
int estimsecs(int);
int sflagfile(char *);
int flagres(int , char *, int);
int makepartial(char *);
int who_show(struct DayDream_Multinode *, int);
int changemode(int);
int largestmode(void);
int loadstrings(int);
int lscpy(char *, char *);
int olmall(int, char *);
int lineolm(int, char *);
int sendtosock(int, struct dd_nodemessage *);
int bigolm(int, int, char *);
int mf(char *, int);
int mff(char *, char *, char *, int);
int ltosdesc(char *, char *);
int stoldesc(char *, char *);
int getdp(struct DayDream_Conference *, char *, int);
int initterm(void);
char hangupstring[512];
extern int hupmode;




struct List *NewList(void);
void AddTail(struct List *, struct Node *);
void AddHead(struct List *, struct Node *);

char *fgetsnolf(char *, int, FILE *);
void MD5Init (MD5_CTX *);                                        /* context */
void MD5Update (MD5_CTX *, unsigned char *,unsigned int);
void MD5Final (unsigned char[16],MD5_CTX *);

/*
Global Variables
*/

extern int   bgmode;
extern int   dsockfd;
extern int   conin;
extern int   conout;
extern int   serhandle;
extern char  serup;
extern int   node;
extern char  keysrc;
extern int   ansi;
extern int   carrier;
extern int   conon;
extern int   timeleft;
extern time_t endtime;
extern int   bpsrate;
extern int   lrp;
extern int   oldlrp;
extern int   lsp;
extern int   oldlsp;
extern int   highest;
extern int   lowest;
extern struct DayDream_MainConfig maincfg;
extern struct DayDream_Conference *confs;
extern struct DayDream_Conference *conf;
extern struct DayDream_MsgBase *base;
extern struct DayDream_AccessPreset *presets;
extern struct DayDream_DisplayMode *displays;
extern struct DayDream_DisplayMode *display;
extern struct DD_Seclevel *secs;
extern struct DD_Seclevel sec;
extern struct DayDream_Archiver *arcs;
extern struct DayDream_Multinode *nodes;
extern struct DayDream_Multinode *currnode;
extern struct DayDream_Protocol *protocols;
extern struct DayDream_Protocol *protocol;
extern struct callerslog clog;
extern char reason[100];
extern int pages;
extern int access1;
extern int access2;
extern int onlinestat;
extern int userinput;
extern struct DD_ExternalCommand *exts;
extern char lrpdatname[80];
extern int delayt;
extern struct userbase user;
extern int pageflag;
extern UBYTE selcfg[2056];
extern time_t last;
extern struct List *flaggedfiles;
extern int bytestagged, fbytestagged;
extern UWORD filestagged, ffilestagged;
extern char origdir[1024];
extern char wrapbuf[80];
extern unsigned char inconvtab[256];
extern unsigned char outconvtab[256];
extern char *sd[MAXSTRS];
extern struct List *olms;
extern int fnode;

#define MD_CTX MD5_CTX
#define MDInit MD5Init
#define MDUpdate MD5Update
#define MDFinal MD5Final
#define strcmpi strcasecmp


int setpreset(int, struct userbase *);
