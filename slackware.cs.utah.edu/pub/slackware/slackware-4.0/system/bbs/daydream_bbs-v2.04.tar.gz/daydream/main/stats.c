#include "daydream.h"






void userstats(void)
{
	char buf[10000];
	char extrabuf[100];
	
	sprintf(buf,sd[stats1str],user.user_realname,user.user_screenlength);
	DDPut(buf);
	sprintf(buf,sd[stats2str],user.user_handle,user.user_securitylevel);
	DDPut(buf);

	sprintf(buf,sd[stats3str],user.user_zipcity,timeleft/60,pages);
	DDPut(buf);
	sprintf(buf,sd[stats4str],user.user_organization);
	DDPut(buf);
	sprintf(buf,sd[stats5str],user.user_pubmessages,user.user_pvtmessages);
	DDPut(buf);
	
	if (user.user_fileratio) {
		sprintf(extrabuf,"%d",user.user_fileratio);
	} else {
		strcpy(extrabuf,sd[disastr]);
	}
	sprintf(buf,sd[stats6str],user.user_ulbytes,user.user_ulfiles,extrabuf);
	DDPut(buf);

	if (user.user_byteratio) {
		sprintf(extrabuf,"%d",user.user_byteratio);
	} else {
		strcpy(extrabuf,sd[disastr]);
	}

	sprintf(buf,sd[stats7str],user.user_dlbytes,user.user_dlfiles,extrabuf);
	DDPut(buf);
	
	sprintf(extrabuf,"%-24.24s",ctime(&user.user_firstcall));
	sprintf(&extrabuf[30],"%-24.24s",ctime(&user.user_lastcall));
	
	sprintf(buf,sd[stats8str],&extrabuf[4],&extrabuf[34],user.user_connections);
	DDPut(buf);

	sprintf(buf,sd[stats9str],user.user_voicephone,protocol->PROTOCOL_NAME);
	DDPut(buf);
	
	sprintf(buf,sd[stats10str],user.user_computermodel);
	DDPut(buf);
	sprintf(buf,sd[stats11str],user.user_signature);
	DDPut(buf);
}
