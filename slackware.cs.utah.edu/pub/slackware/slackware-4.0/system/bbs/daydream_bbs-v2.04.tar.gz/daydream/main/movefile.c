#include "daydream.h"
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

char *fnd(char *, char *);
char *getfe(char *);

extern char monthlist[];

static char lastmove[1024];

int movefile(char *params, int mode)
{
	char parbuf[1024];
	char vbuf[1024];
	char *srcstrh;
	
	srcstrh=params;

	*lastmove=0;
	
	if (!params || !*params) {
		struct FFlag *myf;
	
		myf=(struct FFlag *)flaggedfiles->lh_Head;
		if (myf->fhead.ln_Succ) {
			DDPut(sd[move1str]);
			if (HotKey(HOT_YESNO)==1) {
				while(myf->fhead.ln_Succ)
				{
					if (myf->f_conf==conf->CONF_NUMBER) {
						mf(myf->f_filename,mode);
					}
					myf=(struct FFlag *)myf->fhead.ln_Succ;		
				}

			}
		}
		DDPut(sd[move2str]);
		*vbuf=0;
		if (!(Prompt(vbuf,80,PROMPT_FILE))) return 0;
		if (!*vbuf) return 0;
		srcstrh=vbuf;
	}
	while((srcstrh=strspa(srcstrh,parbuf)))
	{
		mf(parbuf,mode);
	}
	return 1;
}

int mf(char *file, int mode)
{
	int dirsleft, currdir;
	
	char fpath[1024];
	char fb[1024];
	if (!findfile(file,fpath,0)) {
		sprintf(fb,sd[moveerrstr],file);
		DDPut(fb);
		return 0;
	}

	dirsleft=conf->CONF_FILEAREAS;
	currdir=dirsleft;
	sprintf(fb,"%sdata/directory.%3.3d",conf->CONF_PATH,conf->CONF_UPLOADAREA);
	
	if (mff(fb,filepart(fpath),fpath,mode)) return 1;

	while(dirsleft)
	{
		if (currdir==conf->CONF_UPLOADAREA) {
			currdir--; dirsleft--;
		} else {
			sprintf(fb,"%sdata/directory.%3.3d",conf->CONF_PATH,currdir);
			if (mff(fb,filepart(fpath),fpath,mode)) return 1;
			currdir--; dirsleft--;
		}						
	}
	return 0;
}

int mff(char *dr, char *file, char *fpath, int mode)
{
	int dirhandle;
	char fndbuf[40];
	struct stat st;
	char *DirMem;
	char *fptr, *feptr;
	char descbuffer[80*40];
	char mfb[1024];
	int dconf;
	struct DayDream_Conference *dc;
	int darea;
	char dpath[1024];
	int fd;
	
		
	if (stat(dr,&st)==-1) return 0;

	if (!(DirMem=malloc(st.st_size+2))) return 0;

	dirhandle=open(dr,O_RDONLY);
	read(dirhandle,&DirMem[1],st.st_size);
	close(dirhandle);
	DirMem[0]=10;
	DirMem[st.st_size+1]=0;
	
	sprintf(fndbuf,"\n%s ",file);
	if ((fptr=fnd(fndbuf,DirMem))) {
		fptr++;
		feptr=getfe(fptr);

		strcpy(descbuffer,fptr);

		DDPut("[0m\n");
		DDPut(fptr);
		DDPut("\n");
		free(DirMem);

		while(1) {
			DDPut(sd[movedstr]);
			*mfb=0;
			if (!(Prompt(mfb,2,0))) return 0;
			if (*mfb==0) return 0;
			if (toupper(*mfb)=='L') {
				TypeFile("joinconference",TYPE_MAKE|TYPE_WARN);
				continue;
			}
			dconf=atoi(mfb);
			dc=findconf(dconf);
			if (!dc) {
				DDPut(sd[movenodstr]);
				continue;
			}
			if (dc->CONF_FILEAREAS==0) {
				DDPut(sd[movenodcstr]);
				continue;
			}
			break;
		}
		if (dc->CONF_FILEAREAS==1) {
			darea=1;
		} else {
			while(1) {
				sprintf(mfb,sd[movedfstr],dc->CONF_FILEAREAS);
				DDPut(mfb);
				*mfb=0;
				if (!(Prompt(mfb,2,0))) return 0;
				if (*mfb==0) return 0;
				if (toupper(*mfb)=='L') {
					int old;
					old=conf->CONF_NUMBER;
					joinconf(dconf,JC_SHUTUP|JC_QUICK);
					TypeFile("filecatalogs",TYPE_MAKE|TYPE_CONF|TYPE_WARN);
 					joinconf(old,JC_SHUTUP|JC_QUICK);
					continue;
				} else if (toupper(*mfb)=='U') {
					darea=dc->CONF_UPLOADAREA;
					break;
				}
				darea=atoi(mfb);
				if (darea < 1 || darea > dc->CONF_FILEAREAS) continue;
				break;
			}
		}
		if (dc->CONF_ATTRIBUTES & (1L<<3) && (!(conf->CONF_ATTRIBUTES & (1L<<3)))) {
			char newdesc[40*80];
			stoldesc(newdesc,descbuffer);
			strcpy(descbuffer,newdesc);
		} else if ( (!(dc->CONF_ATTRIBUTES & (1L<<3))) && (conf->CONF_ATTRIBUTES & (1L<<3))) {
			char newdesc[40*80];
			ltosdesc(newdesc,descbuffer);
			strcpy(descbuffer,newdesc);
		}
		sprintf(mfb,"%sdata/directory.%3.3d",dc->CONF_PATH,darea);
		getdp(dc,dpath,darea);
		strcat(dpath,file);
		if (!mode) {
			newrename(fpath,dpath);
		} else if (mode==1) {
			symlink(fpath,dpath);
		} else {
			newcopy(fpath,dpath);
		}
		fd=open(mfb,O_WRONLY|O_CREAT,0664);
		if (fd<0) return 1;
		lseek(fd,0,SEEK_END);
		write(fd,descbuffer,strlen(descbuffer));
		write(fd,"\n",1);
		close(fd);

		if (stat(dr,&st)==-1) return 0;

		if (!(DirMem=malloc(st.st_size+2))) return 0;
		DirMem[st.st_size+1]=0;
		
		dirhandle=open(dr,O_RDONLY);
		if (dirhandle!=-1) {
			read(dirhandle,&DirMem[1],st.st_size);
			DirMem[0]=10;
			close(dirhandle);

			sprintf(fndbuf,"\n%s ",file);
			if ((fptr=fnd(fndbuf,DirMem))) {
				fptr++;
				feptr=getfe(fptr);

				if (!mode) {
					dirhandle=open(dr,O_WRONLY|O_TRUNC|O_CREAT,0644);
			
					write(dirhandle,&DirMem[1],fptr-DirMem-1);
					write(dirhandle,feptr+1,strlen(feptr+1));
					close(dirhandle);
				}
			}
		}
		free(DirMem);
		return 1;
	}
	return 0;
	
}

int ltosdesc(char *n, char *o)
{
	int i;
	struct tm teemh;
	char numb[4];
	char *s;

	s=monthlist;
	for(teemh.tm_mon=0;teemh.tm_mon < 13; teemh.tm_mon++)
	{
		if (!strncmp(s,&o[52],3)) break;
		s=&s[3];
	}
	numb[0]=o[56];
	numb[1]=o[57];
	numb[2]=0;
	teemh.tm_mday=atoi(numb);
	numb[0]=o[70];
	numb[1]=o[71];
	teemh.tm_year=atoi(numb);

	for (i=0;i<13;i++) *n++=o[i];
	o=&o[35];
	for (i=0;i<13;i++) *n++=*o++;
	sprintf(n,"%2.2d.%2.2d.%2.2d ",teemh.tm_mday,teemh.tm_mon+1,teemh.tm_year);
	while(*n) n++;
	while(*o!=10) o++;
	o++;
	while(*o==' ') o++;
	strcpy(n,o);
	return 1;
}

int stoldesc(char *n, char *o)
{
	int i;
	struct tm teemh;
	char numb[4];
	char *s;
	numb[0]=o[26];
	numb[1]=o[27];
	numb[2]=0;
	teemh.tm_sec=0;
	teemh.tm_min=0;
	teemh.tm_hour=0;
	teemh.tm_mday=atoi(numb);
	numb[0]=o[29];
	numb[1]=o[30];
	teemh.tm_mon=atoi(numb)-1;
	numb[0]=o[32];
	numb[1]=o[33];
	teemh.tm_year=atoi(numb);
	teemh.tm_wday=0;
	teemh.tm_yday=0;
	teemh.tm_isdst=-1;
	
	for (i=0;i<13;i++) n[i]=*o++;
	for (i=13;i<35;i++) n[i]=' ';
	n=&n[i];
	for (i=0;i<13;i++) *n++=*o++;
	while(*o!=' ') o++;
	o++;
	s=asctime(&teemh);	
	while (*s) *n++=*s++;
	for (i=0;i<35;i++) *n++=' ';
	while(*o) *n++=*o++;
	*n=0;
	return 1;
}

int getdp(struct DayDream_Conference *dc, char *s, int ar)
{
	char mb[1024];
	FILE *dp;
	
	if (dc->CONF_ULPATH[0]=='@') {
		getfreeulp(&dc->CONF_ULPATH[1],s,0);
	} else {
		strcpy(s,dc->CONF_ULPATH);
	}
	sprintf(mb,"%sdata/paths.dat",dc->CONF_PATH);
	dp=fopen(mb,"r");
	if (!dp) {
		return 1;
	}
	while(ar)
	{
		if (!fgetsnolf(s,1024,dp)) {
			fclose(dp);
			return 1;
		}
		ar--;
	}
	fclose(dp);
	return 1;
}

char * getfe(char *entry)
{
	for (;;)
	{
		while (*entry!=10) entry++;
		entry++;
		switch (*entry)
		{
			case ' ':
				break;
			default:
				entry--;
				*entry=0;
				return entry;
				break;
		}
	}
}

char * filepart(char *s)
{
	char *t;
	t=&s[strlen(s)];

	while(s!=t) {
		if (*t=='/') return t+1;
		t--;
	}
	return t;
}

char * fnd(char *needle, char *haystack)
{
	return strstr(haystack, needle);
}
