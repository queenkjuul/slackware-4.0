#include "daydream.h"
#include <fcntl.h>
#include <stdlib.h>

/*
char *sd[bunobullsstr] = "\e[35m\nNo bulletins found!\n\n";
char *sd[bumenustr] = "\n\e[36mSelect bulletin: \e[33m?\e[34m=\e[36mList :\e[0m ";
*/

int bulletins(char *params)
{
	char bdir[200];
	char menunam[240];
	char bullb[500];
	char tbuf[400];
	char nbu[240];
	int first=0;
			
	int menfd;
	char *srcstrh;
	
	changenodestatus("Viewing bulletins");
	
	sprintf(bdir,"%sbulletins/",conf->CONF_PATH);
	sprintf(menunam,"%sbulletinmenu.%s",bdir,ansi ? "gfx" : "txt" );
	
	menfd=open(menunam,O_RDONLY);
	if (menfd==-1) {
		sprintf(bdir,"bulletins/");
		sprintf(menunam,"bulletins/bulletinmenu.%s", ansi ? "gfx" : "txt");
		menfd=open(menunam,O_RDONLY);
		if (menfd==-1) {
			DDPut(sd[bunobullsstr]);
			return 0;
		}
	}
	close(menfd);
	srcstrh=params;
	
	while(1)
	{
		int bulnum;
		if (!(srcstrh=strspa(srcstrh,bullb))) {
			if (!first) TypeFile(menunam,TYPE_WARN);
			DDPut(sd[bumenustr]);
			*tbuf=0;
			if (!(Prompt(tbuf,60,0))) return 0;
			srcstrh=tbuf;
			srcstrh=strspa(srcstrh,bullb);
			if (!srcstrh) return 0;
		}
		first=1;
		if (*bullb=='q' || *bullb=='Q') return 0;
		if (*bullb=='l' || *bullb=='L' || *bullb=='?') {
			TypeFile(menunam,TYPE_WARN);
		} else if ((bulnum=atoi(bullb))) {
			sprintf(nbu,"%sbulletin.%d.%s",bdir,bulnum,ansi ? "gfx" : "txt");
			if (TypeFile(nbu,TYPE_WARN)) {
				if (!(user.user_toggles & (1L<<4))) {
					DDPut(sd[pause2str]);
					HotKey(0);
				}
			}
		}
	}
}
