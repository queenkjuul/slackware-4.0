#include <fcntl.h>
#include "daydream.h"
#include <stdio.h>


void userlist(char *cmppat)
{
	struct userbase luser;
	int lcount;

	int userfd;
	char userbuf[500];
	int usercnt=0, frozcnt=0, sysopcnt=0, cosysopcnt=0;
	int disp;
		
	changenodestatus("Listing users");
	
	lcount=user.user_screenlength-3;
	
	userfd=open("data/userbase.dat",O_RDONLY);
	
	if (userfd==-1) return;

	DDPut(sd[userlheadstr]);
	while(read(userfd,&luser,sizeof(struct userbase)))
	{
		disp=0;
		sprintf(userbuf,sd[userllinestr],luser.user_realname,luser.user_handle,luser.user_organization,luser.user_securitylevel,luser.user_connections);
		if (cmppat!=0)
		{
			if (wildcmp(luser.user_realname,cmppat) || wildcmp(luser.user_handle,cmppat)) {
				disp=1;
			}
		
		} else {
			disp=1;
		}

		if ( (luser.user_toggles & (1L<<30)) && ( (luser.user_toggles & (1L<<31)) == 0) ) disp=0;
		
		if (disp)
		{
			usercnt++;
			if ( ( luser.user_toggles & (1L<<31)) && ( (luser.user_toggles & (1L<<31))==0) ) {
				DDPut("[34m");
				frozcnt++;
			} else if (luser.user_securitylevel==255) {
				DDPut("[32m");
				sysopcnt++;
			} else if (luser.user_securitylevel==maincfg.CFG_COSYSOPLEVEL) {
				DDPut("[33m");
				cosysopcnt++;
			} else {
				DDPut("[0m");
			}                       
			DDPut(userbuf);
			lcount--;

			if (lcount==0) {
				int hot;
				
				DDPut(sd[morepromptstr]); 
				hot=HotKey(0);
				DDPut("\r                                                         \r");
				if (hot=='N'||hot=='n') break;
				if (hot=='C'||hot=='c') {
					lcount=-1;
				} else {
					lcount=user.user_screenlength;
				}
			}
		}
	}
	sprintf(userbuf,sd[userltailstr],sysopcnt,usercnt,cosysopcnt,frozcnt);
	DDPut(userbuf);
	
	close(userfd);
}
