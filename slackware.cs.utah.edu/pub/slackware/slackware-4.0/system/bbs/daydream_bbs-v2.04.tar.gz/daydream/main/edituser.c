#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "daydream.h"
#include <stdlib.h>
#ifdef UNIX
#include <unistd.h>
#endif
#include <string.h>
#include <stdlib.h>
#include <ctype.h>






void switches(void);

void edituser(int mode)
{
	char askbuf[20];
	char lesbabuf[30];
	struct userbase muser;
	int leps;
			
	changenodestatus("Editing personal data");
	muser=user;
		
viewag:
	TypeFile("edituser",TYPE_MAKE|TYPE_WARN);
	
menu:
	DDPut(sd[eupromptstr]);
	askbuf[0]=0;
	if (!(Prompt(askbuf,3,0))) return;

askreal:
	if (!(strcasecmp(askbuf,"1"))) {
		if (!isaccess(SECB_REALNAME,access2)) goto menu;
		DDPut(sd[eu1str]);
		strcpy(lesbabuf,user.user_realname);
		if (!(Prompt(lesbabuf,25,0))) return;
		removespaces(lesbabuf);
		if (strcmp(lesbabuf,user.user_realname)) {
			leps=findusername(lesbabuf,1);
			if (leps==user.user_account_id || leps==-1) {                   
				if (lesbabuf[0]) strcpy(user.user_realname,lesbabuf);                                           
			} else {
				DDPut(sd[newalreadystr]);
				goto askreal;
			}
		}
		goto menu;
	}               

askhan:
	if (!(strcasecmp(askbuf,"2"))) {
		if (!isaccess(SECB_HANDLE,access2)) goto menu;
		DDPut(sd[eu2str]);
		strcpy(lesbabuf,user.user_handle);
		if (!(Prompt(lesbabuf,25,0))) return;
		removespaces(lesbabuf);
		if (strcmp(lesbabuf,user.user_handle)) {
			leps=findusername(lesbabuf,1);
			if (leps==user.user_account_id || leps==-1) {                   
				if (lesbabuf[0]) strcpy(user.user_handle,lesbabuf);                                             
			} else {
				DDPut(sd[newalreadystr]);
				goto askhan;
			}
		}
		goto menu;
	}               

	if (!(strcasecmp(askbuf,"3"))) {
		DDPut(sd[eu3str]);
		if (!(Prompt(user.user_organization,25,0))) return;
		goto menu;
	}

	if (!(strcasecmp(askbuf,"4"))) {
		DDPut(sd[eu4str]);
		if (!(Prompt(user.user_zipcity,20,0))) return;
		goto menu;
	}

	if (!(strcasecmp(askbuf,"5"))) {
		DDPut(sd[eu5str]);
		if (!(Prompt(user.user_voicephone,20,0))) return;
		goto menu;
	}

	if (!(strcasecmp(askbuf,"6"))) {
		MD_CTX context;

		DDPut(sd[eu6str]);
		lesbabuf[0]=0;
		if (!(Prompt(lesbabuf,15,0))) return;
		if (lesbabuf[0]==0) goto menu;
		strupr(lesbabuf);
		MDInit(&context);
		MDUpdate(&context,lesbabuf,strlen(lesbabuf));
		MDFinal(user.user_password,&context);
		
		goto menu;
	}

asksl:
	if (!(strcasecmp(askbuf,"7"))) {
		int fallos;
		
		DDPut(sd[eu7str]);
		lesbabuf[0]=0;
		if (!(Prompt(lesbabuf,3,0))) return;
		if (lesbabuf[0]=='t' || lesbabuf[0]=='T') {
			testscreenl();
			goto asksl;
		}
		fallos=atoi(lesbabuf);
		if (fallos < 10) {
			DDPut(sd[newminslstr]);
			goto asksl;
		}
		user.user_screenlength=fallos;
		goto menu;
	}

	if (!(strcasecmp(askbuf,"8"))) {
		struct DayDream_Protocol *tp;
		
		TypeFile("protocols",TYPE_MAKE|TYPE_WARN);
		DDPut(sd[eu8str]);
		*lesbabuf=0;
		if (user.user_protocol) {
			*lesbabuf=user.user_protocol;
			lesbabuf[1]=0;
		}
		if (!(Prompt(lesbabuf,3,0))) return;
		*lesbabuf=toupper(*lesbabuf);
		if (!*lesbabuf) goto menu;
		tp=protocols;
		while (1)
		{
			if (tp->PROTOCOL_ID==0) goto menu;
			if (tp->PROTOCOL_ID==*lesbabuf) {
				protocol=tp;
				user.user_protocol=*lesbabuf;
				goto menu;
			}
			tp++;
		}
	}
	if (!(strcasecmp(askbuf,"9"))) {
		DDPut(sd[eu9str]);
		if (!(Prompt(user.user_signature,44,0))) return;
		goto menu;
	}

	if (!(strcasecmp(askbuf,"10"))) {
		DDPut(sd[eu10str]);
		if (!(Prompt(user.user_computermodel,20,0))) return;
		goto menu;
	}
	
	if (!(strcasecmp(askbuf,"11"))) {
		DDPut(sd[eu11str]);
		sprintf(lesbabuf,"%d",user.user_flines);
		if (!(Prompt(lesbabuf,3,0))) return;
		user.user_flines=atoi(lesbabuf);
		goto menu;
	}

	if (!(strcasecmp(askbuf,"a"))) {
		DDPut(sd[euabortedstr]);
		user=muser;
		return;
	}

	if (!(strcasecmp(askbuf,"v"))) {
		goto viewag;
	}

	if (!(strcasecmp(askbuf,"s"))) {
		switches();
		goto menu;
	}

	if ((!(strcasecmp(askbuf,"c")) || (askbuf[0]==0))) {
		DDPut(sd[eusavedstr]);
		saveuserbase();
	} else goto menu;
}

void switches(void)
{
	char inp[82];
	char *s;
	char tok[82];
	ULONG togbak;
	int poro;
	togbak=user.user_toggles;
	
	for(;;)
	{
		char buffa[200];
		char *togf;

		DDPut("\n");            
		if (user.user_toggles & (1L<<12)) togf=sd[tsaskstr];
			else if (user.user_toggles & (1L<<5)) togf=sd[tsnostr];
			else togf=sd[tsyesstr];
		sprintf(buffa,sd[togglinestr],1,sd[ts1str],togf);
		DDPut(buffa);

		if (user.user_toggles & (1L<<13)) togf=sd[tsaskstr];
			else if (user.user_toggles & (1L<<6)) togf=sd[tsyesstr];
			else togf=sd[tsnostr];
		sprintf(buffa,sd[togglinestr],2,sd[ts2str],togf);
		DDPut(buffa);

		DDPut("\n");
		
		if (user.user_toggles & (1L<<11)) togf=sd[tsaskstr];
			else if (user.user_toggles & (1L<<0)) togf=sd[tsyesstr];
			else togf=sd[tsnostr];
		sprintf(buffa,sd[togglinestr],3,sd[ts3str],togf);
		DDPut(buffa);

		if (user.user_toggles & (1L<<9)) togf=sd[tsnostr]; else togf=sd[tsyesstr];
		sprintf(buffa,sd[togglinestr],4,sd[ts4str],togf);
		DDPut(buffa);

		DDPut("\n");

		if (user.user_toggles & (1L<<14)) togf=sd[tsyesstr]; else togf=sd[tsnostr];
		sprintf(buffa,sd[togglinestr],5,sd[ts5str],togf);
		DDPut(buffa);

		if (user.user_toggles & (1L<<15)) togf=sd[tsnostr]; else togf=sd[tsyesstr];
		sprintf(buffa,sd[togglinestr],6,sd[ts6str],togf);
		DDPut(buffa);

		DDPut("\n");
	
		poro=1;
		while (poro)
		{
			DDPut(sd[tspromptstr]);
			inp[0]=0;
			if (!(Prompt(inp,80,0))) return;
			s=inp;
			if (!*inp) {
				strcpy(inp,"s");
			}
			while( (s=strspa(s,tok)) )
			{
				int numb;
				if (!strcasecmp("s",tok)) {
					return;
				} else if (!strcasecmp("a",tok)) {
					user.user_toggles=togbak;
					return;
				} else if (!strcasecmp("v",tok)) {
					poro=0;
					break;
				} else {
					numb=atoi(tok);
					switch(numb)
					{
						case 1:
							if (user.user_toggles & (1L<<5)) {
								user.user_toggles |= (1L<<12);
								user.user_toggles &= ~(1L<<5);
								sprintf(buffa,sd[asktlinestr],sd[ts1str]);
							} else if (user.user_toggles & (1L<<12)) {
								user.user_toggles &= ~(1L<<12);
								user.user_toggles &= ~(1L<<5);
								sprintf(buffa,sd[ontlinestr],sd[ts1str]);
							} else {
								user.user_toggles &= ~(1L<<12);
								user.user_toggles |= (1L<<5);
								sprintf(buffa,sd[offtlinestr],sd[ts1str]);
							}
							DDPut(buffa);
						break;
						case 2:
							if (user.user_toggles & (1L<<6)) {
								user.user_toggles |= (1L<<13);
								user.user_toggles &= ~(1L<<6);
								sprintf(buffa,sd[asktlinestr],sd[ts2str]);
							} else if (user.user_toggles & (1L<<13)) {
								user.user_toggles &= ~(1L<<13);
								user.user_toggles &= ~(1L<<6);
								sprintf(buffa,sd[offtlinestr],sd[ts2str]);
							} else {
								user.user_toggles &= ~(1L<<13);
								user.user_toggles |= (1L<<6);
								sprintf(buffa,sd[ontlinestr],sd[ts2str]);
							}
							DDPut(buffa);
						break;
						case 3:                                 
							if (user.user_toggles & (1L<<0)) {
								user.user_toggles |= (1L<<11);
								user.user_toggles &= ~(1L<<0);
								sprintf(buffa,sd[asktlinestr],sd[ts3str]);
							} else if (user.user_toggles & (1L<<11)) {
								user.user_toggles &= ~(1L<<11);
								user.user_toggles &= ~(1L<<0);
								sprintf(buffa,sd[offtlinestr],sd[ts3str]);
							} else {
								user.user_toggles &= ~(1L<<11);
								user.user_toggles |= (1L<<0);
								sprintf(buffa,sd[ontlinestr],sd[ts3str]);
							}
							DDPut(buffa);
						break;
						case 4:                                 
							if (user.user_toggles & (1L<<9)) {
								user.user_toggles &= ~(1L<<9);
								sprintf(buffa,sd[ontlinestr],sd[ts4str]);
							} else {
								user.user_toggles |= (1L<<9);
								sprintf(buffa,sd[offtlinestr],sd[ts4str]);
							}
							DDPut(buffa);
						break;
						case 5:                                 
							if (user.user_toggles & (1L<<14)) {
								user.user_toggles &= ~(1L<<14);
								sprintf(buffa,sd[offtlinestr],sd[ts5str]);
							} else {
								user.user_toggles |= (1L<<14);
								sprintf(buffa,sd[ontlinestr],sd[ts5str]);
							}
							DDPut(buffa);
						break;
						case 6:                                 
							if (user.user_toggles & (1L<<15)) {
								user.user_toggles &= ~(1L<<15);
								sprintf(buffa,sd[ontlinestr],sd[ts6str]);
							} else {
								user.user_toggles |= (1L<<15);
								sprintf(buffa,sd[offtlinestr],sd[ts6str]);
							}
							DDPut(buffa);
						break;
					}
				}
			}
		}
	}
}

int tagmessageareas(void)
{
	UBYTE backup[32];
	char tbuf[500];
	char *sta;
	struct DayDream_MsgBase *mb;
	int bcnt;
	char inp[90];
	char *s;
	char tok[90];
		
	int i;
	
	for(i=0;i<32;i++)
	{
		backup[i]=selcfg[((conf->CONF_NUMBER-1)*32)+i];
	}
vagain:
	DDPut("[2J[H");

	bcnt=conf->CONF_MSGBASES;
	(struct DayDream_Conference *)mb=conf+1;
		
	i=0;
	while (bcnt)
	{
		i++;
		if (i==3) {
			DDPut("\n");
			i=1;
		}
		if (isbasetagged(conf->CONF_NUMBER,mb->MSGBASE_NUMBER)) {
			sta="ON";
		} else sta="OFF";
		
		sprintf(tbuf,sd[tbclinestr],mb->MSGBASE_NUMBER,mb->MSGBASE_NAME,sta);
		DDPut(tbuf);
		mb++;
		bcnt--;
	}               

	DDPut("\n");
	while (1) 
	{
		DDPut(sd[tbpromptstr]);
		inp[0]=0;
		if (!(Prompt(inp,80,0))) return 0;
		s=inp;
		if (!*inp) {
			strcpy(inp,"s");
		}
		while( (s=strspa(s,tok)) )
		{
			if (!strcasecmp(tok,"c")) {
				for(i=0;i<32;i++)
				{
					selcfg[((conf->CONF_NUMBER-1)*32)+i]=backup[i];
				}
				return 0;
			} else if (!strcasecmp(tok,"v")) {
				goto vagain;
			} else if (!strcasecmp(tok,"s")) {
				int selfd;
				sprintf(tbuf,"users/%d/selected.dat",user.user_account_id);
				selfd=open(tbuf,O_WRONLY|O_CREAT,0664);
				if (selfd!=-1) {
					write(selfd,&selcfg,2056);
					close(selfd);
				}
				return 0;
			} else if (!strcasecmp(tok,"-")) {
				for(i=0;i<32;i++)
				{
					selcfg[((conf->CONF_NUMBER-1)*32)+i]=0;
				}
				DDPut(sd[tballoffstr]);
			} else if (!strcasecmp(tok,"+")) {
				bcnt=conf->CONF_MSGBASES;
				(struct DayDream_Conference *)mb=conf+1;
		
				while (bcnt)
				{
					selcfg[((conf->CONF_NUMBER-1)*32)+(mb->MSGBASE_NUMBER-1)/8] |= (1L<<(mb->MSGBASE_NUMBER-1)%8);
					mb++;
					bcnt--;
				}               
				DDPut(sd[tballonstr]);
			} else {
				i=atoi(tok);
				if (i) {
					bcnt=conf->CONF_MSGBASES;
					(struct DayDream_Conference *)mb=conf+1;
		
					while (bcnt)
					{
						if (i==mb->MSGBASE_NUMBER) {
							if (selcfg[((conf->CONF_NUMBER-1)*32)+(mb->MSGBASE_NUMBER-1)/8] & (1L<<(mb->MSGBASE_NUMBER-1)%8)) {
								selcfg[((conf->CONF_NUMBER-1)*32)+(mb->MSGBASE_NUMBER-1)/8] &= ~(1L<<(mb->MSGBASE_NUMBER-1)%8);
							} else {
								selcfg[((conf->CONF_NUMBER-1)*32)+(mb->MSGBASE_NUMBER-1)/8] |= (1L<<(mb->MSGBASE_NUMBER-1)%8);
							}
							break;
						}
						mb++;
						bcnt--;
					}               
				
				}
			}
		}
	}
}

int tagconfs(void)
{
	UBYTE backup[8];
	char tbuf[500];
	char *sta;
	struct DayDream_Conference *mc;
	struct DayDream_Conference *tbase;
	int bcnt;
	char inp[90];
	char *s;
	char tok[90];
		
	int i;
	
	for(i=0;i<8;i++)
	{
		backup[i]=selcfg[2048+i];
	}
vagain:
	DDPut("[2J[H");

	mc=confs;
		
	i=0;
	while (mc->CONF_NUMBER!=255 && mc->CONF_NUMBER)
	{
		if (checkconfaccess(mc->CONF_NUMBER,&user)) {
			i++;
			if (i==3) {
				DDPut("\n");
				i=1;
			}
			if (isconftagged(mc->CONF_NUMBER)) {
				sta="ON";
			} else sta="OFF";
		
			sprintf(tbuf,sd[togglinestr],mc->CONF_NUMBER,mc->CONF_NAME,sta);
			DDPut(tbuf);
		}                       
		tbase=mc+1;
		bcnt=mc->CONF_MSGBASES;
		while(bcnt) {
			tbase++;
			bcnt--;
		}
		mc=tbase;
	}
	DDPut("\n");

	while (1) 
	{
		DDPut(sd[tcpromptstr]);
		inp[0]=0;
		if (!(Prompt(inp,80,0))) return 0;
		s=inp;
		if (!*inp) {
			strcpy(inp,"s");
		}
		while( (s=strspa(s,tok)) )
		{
			if (!strcasecmp(tok,"c")) {
				for(i=0;i<8;i++)
				{
					selcfg[2048+i]=backup[i];
				}
				return 0;
			} else if (!strcasecmp(tok,"v")) {
				goto vagain;
			} else if (!strcasecmp(tok,"s")) {
				int selfd;
				sprintf(tbuf,"users/%d/selected.dat",user.user_account_id);
				selfd=open(tbuf,O_WRONLY|O_CREAT,0664);
				if (selfd!=-1) {
					write(selfd,&selcfg,2056);
					close(selfd);
				}
				return 0;
			} else if (!strcasecmp(tok,"-")) {
				for(i=0;i<8;i++)
				{
					selcfg[2048+i]=0;
				}
				DDPut(sd[tcalloffstr]);
			} else if (!strcasecmp(tok,"+")) {
				for(i=0;i<8;i++)
				{
					selcfg[2048+i]=255;
				}
				DDPut(sd[tcallonstr]);
			} else {
				i=atoi(tok);
				if (i > 0 && i < 65 && checkconfaccess(i,&user)) {
					(struct DayDream_Conference *)mc=confs;
		
					while (mc->CONF_NUMBER!=255)
					{
						if (i==mc->CONF_NUMBER) {
							if (selcfg[2048+(mc->CONF_NUMBER-1)/8] & (1L<<(mc->CONF_NUMBER-1)%8)) {
								selcfg[2048+(mc->CONF_NUMBER-1)/8] &= ~(1L<<(mc->CONF_NUMBER-1)%8);
							} else {
								selcfg[2048+(mc->CONF_NUMBER-1)/8] |= (1L<<(mc->CONF_NUMBER-1)%8);
							}
							break;
						}
						tbase=mc+1;
						bcnt=mc->CONF_MSGBASES;
						while(bcnt) {
							tbase++;
							bcnt--;
						}
						mc=tbase;
					}               
				
				}
			}
		}
	}
}

char *strspa(char *src, char *dest)
{
	int go=1;

	if (src==0) return 0;
		
	while (*src==' ') src++;
	if (*src==0) return 0;
	while (go)
	{
		if (*src==' '||*src==0) go=0;
		else *dest++=*src++;
	}
	*dest=0;
	return src;
}

int isbasetagged(int tconf, int tbase)
{
	if (selcfg[((tconf-1)*32)+(tbase-1)/8] & (1L<<(tbase-1)%8)) return 1;
	return 0;
}

int isconftagged(int tconf)
{
	if (selcfg[2048+((tconf-1)/8)] & (1L<<(tconf-1)%8)) return 1;
	return 0;
}

int isanybasestagged(int tconf)
{
	int i=0;
	for (i=0;i<32;i++)
	{
		if (selcfg[((tconf-1)*32)+i]) return 1;
	}
	return 0;
}
void saveuserbase(void)
{
	int userfd;

	userfd=open("data/userbase.dat",O_CREAT|O_RDWR,0664);
	lseek(userfd,user.user_account_id*sizeof(struct userbase),SEEK_SET);
	write(userfd,&user,sizeof(struct userbase));
	close(userfd);
}
