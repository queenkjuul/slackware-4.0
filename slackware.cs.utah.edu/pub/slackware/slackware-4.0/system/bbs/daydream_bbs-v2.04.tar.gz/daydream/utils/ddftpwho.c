#include <dd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

struct DayDream_MainConfig maincfg;
char *env;

void showftp(void);
void who_show(struct DayDream_Multinode *, int);


int ispid(pid_t pid)
{
	char ibuf[1024];
	struct stat st;
	
	sprintf(ibuf,"/proc/%d",pid);

	if (stat(ibuf,&st)==-1) return 0; 
	return 1;
}

int main(int argc, char *argv[])
{
	char *env;
	char bufa[1024];
	int fd;

	env=getenv("DAYDREAM");
	
	sprintf(bufa,"%s/data/daydream.dat",env);
	fd=open(bufa,O_RDONLY);
	if (fd < 0) {
		perror("open $DAYDREAM/data/daydream.dat");
		return -1;
	}
	read(fd,&maincfg,sizeof(struct DayDream_MainConfig));
	close(fd);
	
	showftp();
	return 0;
}

void showftp()
{
	int i;
	int fd;
	char buf[1024];
	char acti[512];
	struct ftpinfo mi;
	struct userbase nuser;
	char *usern, *orgn;
	int cps;

	printf("Account Name            Org. / Location           Activity                 CPS\n------------------------------------------------------------------------------\n");

	for(i=0;i<maincfg.CFG_MAXFTPUSERS;i++) {
		sprintf(buf,"%sftpinfo%d.dat",DDTMP,i+1);
		fd=open(buf,O_RDONLY);
		if (fd<0) continue;
		read(fd,&mi,sizeof(struct ftpinfo));
		close(fd);
		if (!ispid(mi.pid)) continue;
		
		sprintf(buf,"%s/data/userbase.dat",getenv("DAYDREAM"));
		fd=open(buf,O_RDONLY);
		lseek(fd,mi.userid*sizeof(struct userbase),SEEK_SET);
		read(fd,&nuser,sizeof(struct userbase));
		close(fd);

		if (maincfg.CFG_FLAGS & (1L<<1)) usern=nuser.user_handle; else usern=nuser.user_realname;
		if (maincfg.CFG_FLAGS & (1L<<2)) orgn=nuser.user_organization; else orgn=nuser.user_zipcity;
		if (mi.mode==1) {
			cps=mi.cps;
			sprintf(acti,"UL: %s",mi.filename);
		} else if (mi.mode==2) {
			cps=mi.cps;
			sprintf(acti,"DL: %s",mi.filename);
		} else {
			cps=0;
			strcpy(acti,"Idle");
		}
		printf("%-23.23s %-25.25s %-20.20s %7d\n",
			usern,orgn,acti,cps);
		if (mi.mode) {
			if (mi.filesize==-1) {
				strcpy(acti,"????????");
			} else {
				sprintf(acti,"%d",mi.filesize);
			}
			printf("%-23.23s %-25.25s (%d/%s)\n"," "," ",mi.transferred,acti);
		}
	}
	printf("------------------------------------------------------------------------------\n");

}


/*
design:

Hydra                   HiRMU                   UL: warezelite.tgz      1234567
                                                (12345678/????????)
Marko                   Jumala.                 Idle                          0
V�in�                   The 31337 godz          DL: porno.tar.gz          54445
                                                (12345/67874324)

						*/
