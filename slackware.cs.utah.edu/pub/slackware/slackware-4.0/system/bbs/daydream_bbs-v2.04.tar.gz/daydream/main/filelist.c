#include <daydream.h>
#include <sys/stat.h>
#include <fcntl.h>
#ifdef UNIX
#include <unistd.h>
#include <sys/mman.h>
#endif
#include <string.h>
#include <stdlib.h>

int screenl;
extern int flagerror;
char monthlist[] = "JanFebMarAprMayJunJulAugSepOctNovDec";

void ShowFile(char *, char *, int);


/* Filescan

 mode : 1 = Regular, 2 = New Files, 3 = Zippy Search, 4 = Global new scan
 
 */

struct cursordat {
	int cd_line;
	char cd_file[40];
};

int fileprompt(int ,UBYTE *, struct cursordat *, struct cursordat *, int);
 
/*
char *sd[flnoareasstr] = "[35m\nNo fileareas in this conference!\n\n";
char *sd[fldatestr] = "\n[36mStart Scan From [32m([33m-X[34m = [36mX Days Ago, [32m([33mEnter[32m) [34m= [36m%2.2d%2.2d%2.2d, [32m([33mH[32m)[36melp[32m)[36m: [0m";
char *sd[flzippystr] = "\n[36mEnter string to search: [0m";
char *sd[fldirsstr] = "[36m\nDirectories [32m([33m1[32m-[33m%ld[32m)[36m, [32m([33mA[32m)[36mll, [32m([33mU[32m)[36mpload, [32m([33mL[32m)[36mist, [32m([33mH[32m)[36melp, [32m([33mEnter[32m)[34m=[36mExit: [0m";
char *sd[flscanningstr] = "[2J[H\n[33mScanning directory #%3.3ld";
char *sd[flnoentriesstr] = "[35m\rNo filecatalog entries found to be listed!\n\n";
char *sd[flmorestr] = "[0mMore? [33mY[32m)[36mes, [33mN[32m)[36mo, [33mC[32m)[36montinuous, [33mT[32m)[36mag Files, [33mE[32m)[36mdir, Cursor: ";
char *sd[flflagstr] = "\r[0;36mCursor keys to move, Q to quit or <-' to toggle.              ";
char *sd[fltagstr] = "[%ld;1H[44;36m%s[0m";
char *sd[fltagoffstr] = "[%ld;1H[36m%s[0m";
char *sd[flglobhstr] = "\n[35mScanning for new files\n[34m-----------------------------------------------------------------------------[0m\n";
char *sd[flconfstr] = "[2J[H\n[33mScanning Conference %s[0m\n";
char *sd[flcol1str] = "[36m";
char *sd[flcol2str] = "[32m";
char *sd[flcol3str] = "[33m";
char *sd[flcol4str] = "[35m";
char *sd[flcol5str] = "[0m";
char *sd[flz1str] = "[44;36m";
char *sd[flz2str] = "[0;36m";
char *sd[flz3str] = "[0;44m";
char *sd[flz4str] = "[0m";
*/






int filelist(int mode, char *params)
{
	struct tm *myt=0;
	struct tm teem;
	struct cursordat *cdat;
	char *srcstrh;
	char parbuf[500];
	char databuf[600];
	char zippystrh[500];
	char *zipmatch=0;
	int ziplen=0;
	UBYTE arealist[256];
	time_t scannewer;
	int gopr=1;
	int entries=0, entriesinarea=1;
	UBYTE *curarea;
	int contmode=0;
			
	changenodestatus("Scanning filedirs");
	if (!(conf->CONF_FILEAREAS)) {
		DDPut(sd[flnoareasstr]);
		return 0;
		
	}

	srcstrh=params;
	
	if (mode==2 || mode == 4) {
		time_t temptime;

		if (!(srcstrh=strspa(srcstrh,parbuf))) {
			
			myt=localtime(&last);
			sprintf(parbuf,sd[fldatestr],myt->tm_mday,myt->tm_mon+1,myt->tm_year);
			DDPut(parbuf);
			databuf[0]=0;
			if (!(Prompt(databuf,44,0))) return 0;
			srcstrh=databuf;
			*parbuf=0;
			srcstrh=strspa(srcstrh,parbuf);
		}
		if (parbuf[0]==0 || (!strcasecmp(parbuf,"s"))) {
			myt=localtime(&last);
			myt->tm_sec=0;
			myt->tm_min=0;
			myt->tm_hour=0;
			scannewer=mktime(myt);
		} else if (!strcasecmp(parbuf,"t")) {
			time(&temptime);
			myt=localtime(&temptime);
			myt->tm_sec=myt->tm_min=myt->tm_hour=0;
			scannewer=mktime(myt);
			myt=localtime(&scannewer);
		} else if (parbuf[0]=='-') {
			int days;
			
			days=atoi(&parbuf[1]);
			time(&temptime);
			myt=localtime(&temptime);
			myt->tm_sec=0;
			myt->tm_min=0;
			myt->tm_hour=0;
			scannewer=mktime(myt);
			scannewer=scannewer-(days*86400);
			myt=localtime(&scannewer);
		} else {
			char numb[4];
			
			if (strlen(parbuf)!=6) return 0;
			numb[0]=parbuf[0];
			numb[1]=parbuf[1];
			numb[2]=0;
			teem.tm_sec=0;
			teem.tm_min=0;
			teem.tm_hour=0;
			teem.tm_mday=atoi(numb);
			numb[0]=parbuf[2];
			numb[1]=parbuf[3];
			teem.tm_mon=atoi(numb)-1;
			numb[0]=parbuf[4];
			numb[1]=parbuf[5];
			teem.tm_year=atoi(numb);
			scannewer=mktime(&teem);
			myt=&teem;
		}
	} else if (mode==3) {
		if (!(srcstrh=strspa(srcstrh,zippystrh))) {
			DDPut(sd[flzippystr]);
			databuf[0]=0;
			if (!(Prompt(databuf,44,0))) return 0;
			srcstrh=databuf;
			if (!(srcstrh=strspa(srcstrh,zippystrh))) return 0;
		}
		strupr(zippystrh);
		ziplen=strlen(zippystrh);
	} else if (mode==1) {
		char *kelos;
		if (!(kelos=strspa(srcstrh,zippystrh))) {
			TypeFile("filecatalogs",TYPE_MAKE|TYPE_WARN|TYPE_CONF);
		}	
	}

	while (gopr)
	{
		gopr=1;
		if (!(srcstrh=strspa(srcstrh,parbuf))) {
			sprintf(databuf,sd[fldirsstr],conf->CONF_FILEAREAS); 
			DDPut(databuf);
			databuf[0]=0;
			
			if (!(Prompt(databuf,70,0))) return 0;
			srcstrh=databuf;
			if (!(srcstrh=strspa(srcstrh,parbuf))) return 0;
		}
		arealist[0]=0;

		do {
			if (!strcasecmp(parbuf,"a")) {
				UBYTE *nap;
				int num=1;
				nap=&arealist[0];
				while (num <= conf->CONF_FILEAREAS)
				{
					*nap++=num++;
				}
				*nap=0;
				gopr=0;
				break;
			} else if (!strcasecmp(parbuf,"h")) {
				TypeFile("filecataloghelp",TYPE_MAKE|TYPE_WARN|TYPE_CONF);
				gopr=2;
				break;
			} else if (!strcasecmp(parbuf,"l")) {
				TypeFile("filecatalogs",TYPE_MAKE|TYPE_WARN|TYPE_CONF);
				gopr=2;
				break;
			} else {
				int newarea;
				
				if (!strcasecmp(parbuf,"u")) {
					newarea=conf->CONF_UPLOADAREA;
				} else newarea=atoi(parbuf);
				
				if (newarea)
				{
					if (newarea > 0 && newarea <= conf->CONF_FILEAREAS) {
						UBYTE *nap;
						int ok=1;
						nap=arealist;
						while (*nap) {
							if (*nap==newarea) ok=0;
							nap++;
						}
						*nap++=newarea;
						*nap=0;
					} 
				}
			}
		} while((srcstrh=strspa(srcstrh,parbuf)));
		if (gopr==1) break;
	}

	cdat=(struct cursordat *)malloc((user.user_screenlength+2)*sizeof(struct cursordat));
	curarea=arealist;

	for(curarea=arealist;*curarea;curarea++)
	{
		char *listm;
		int listfd;
		int listsize;
		struct stat st;
		char descbuf[6000];
		char *endp;
		char *s, *t;
		int nono;
		
		nono=1;
		if (entriesinarea) {
			sprintf(parbuf,sd[flscanningstr],*curarea);
		} else {
			sprintf(parbuf,"[3D%3.3d",*curarea);
		}
		DDPut(parbuf);
		entriesinarea=0;
		
		sprintf(parbuf,"%sdata/directory.%3.3d",conf->CONF_PATH,*curarea);
		listfd=open(parbuf,O_RDONLY);
		if (listfd!=-1) {
			struct cursordat *currc;
			int ml;
			
			screenl=4;
			currc=cdat;
			currc->cd_line=0;
						
			fstat(listfd,&st);
			listsize=st.st_size;
#ifdef UNIX
			listm=mmap(0,listsize,PROT_READ,MAP_SHARED,listfd,0);
			if (listm==(char *)-1) {
				close(listfd);
				DDPut("Cannot mmap();\n");
				break;
			}
#else
			listm=malloc(st.st_size);
			read(listfd,listm,st.st_size);
#endif
			close(listfd);

			endp=listm+listsize;
			s=listm;
			
			while (s<endp)
			{
				int flins=1;
				if (!user.user_flines) 
				  ml=500;
				else {
					ml=user.user_flines;
					if (conf->CONF_ATTRIBUTES & (1L<<3)) ml++;
				}
				t=descbuf;
				for(;;)
				{
					if (s==endp) break;
					if (*s==10 && ((s+1)==endp || *(s+1)!=' ')) break;
					if (*s==10) {
						if (ml) {
							flins++;
							ml--;
						}
					}
					if (ml) {
						*t++=*s++;
					} else s++;
				} 
				s++;
				*t++=10;
				*t=0;

				if (mode==3) {
					char upbuf[8000];
					strcupr(upbuf,descbuf);
					if (!(zipmatch=strstr(upbuf,zippystrh))) continue;
					zipmatch=zipmatch-upbuf+descbuf;
				}
				if (mode==2 || mode == 4) {
					struct tm teemh;

					if (conf->CONF_ATTRIBUTES & (1L<<3)) {
						char *s;					
						char numb[4];

						s=monthlist;
						for(teemh.tm_mon=0;teemh.tm_mon < 13; teemh.tm_mon++)
						{
							if (!strncmp(s,&descbuf[52],3)) break;
							s=&s[3];
						}
						numb[0]=descbuf[56];
						numb[1]=descbuf[57];
						numb[2]=0;
						teemh.tm_sec=0;
						teemh.tm_min=0;
						teemh.tm_hour=0;
						teemh.tm_mday=atoi(numb);
						numb[0]=descbuf[70];
						numb[1]=descbuf[71];
						teemh.tm_year=atoi(numb);
					} else {
						char numb[4];
						numb[0]=descbuf[26];
						numb[1]=descbuf[27];
						numb[2]=0;
						teemh.tm_sec=0;
						teemh.tm_min=0;
						teemh.tm_hour=0;
						teemh.tm_mday=atoi(numb);
						numb[0]=descbuf[29];
						numb[1]=descbuf[30];
						teemh.tm_mon=atoi(numb)-1;
						numb[0]=descbuf[32];
						numb[1]=descbuf[33];
						teemh.tm_year=atoi(numb);
					}
					if (teemh.tm_year < myt->tm_year) continue;
					if (teemh.tm_mon < myt->tm_mon && teemh.tm_year==myt->tm_year) continue;
					if (teemh.tm_mday < myt->tm_mday && teemh.tm_mon==myt->tm_mon && teemh.tm_year == myt->tm_year) continue;
				}				
				if (entriesinarea==0) {
					DDPut("\n\n");
				}
				entries++; entriesinarea++;
				if (screenl + flins - 1 > user.user_screenlength) {
					int hotres;
					hotres=fileprompt(contmode,curarea,cdat,currc, 1);
					if (hotres==3) contmode=1;
					if (hotres==0) {
						nono=0;
						break;
					}
					currc=cdat;
					screenl=1;
					currc->cd_line=0;
				}
				if (!contmode) {
					currc->cd_line=screenl;
					strspa(descbuf,currc->cd_file);
					screenl+=flins;
					currc++;
					currc->cd_line=0;
				} else {
					if (HotKey(HOT_QUICK)==3) {
						currc=cdat;
						currc->cd_line=0;
						contmode=0;
						screenl=user.user_screenlength;
					}
				}
				if (!checkcarrier()) break;
				ShowFile(descbuf,zipmatch,ziplen);
			}
			if (entriesinarea && nono) {
				int hotres;
				hotres=fileprompt(contmode,curarea,cdat,currc,0);
				if (hotres==3) contmode=1;
			}
#ifndef UNIX
			free(listm);
#else
			munmap(listm,listsize);
#endif
		}
	}

	if (entries==0 && mode != 4) {
		DDPut(sd[flnoentriesstr]);
	} else {
		DDPut("\n");
	}
	free(cdat);
	return 1;
}

void fl_getbot()
{
	char buf[32];
	sprintf(buf,"[%d;1H",screenl);
	DDPut(buf);

}

void fl_restore(struct cursordat *cda)
{
	char buf[32];

	fl_getbot();
	DDPut("\r                                                                             \r");
	DDPut(sd[flmorestr]);
	sprintf(buf,"[%d;%dH",cda->cd_line,strlen(cda->cd_file));
	DDPut(buf);
}
int fileprompt(int contmode,UBYTE *curarea, struct cursordat *cdat, struct cursordat *currc, int clear)
{
	int hotres=1;
	char parbuf[512];
	char fbuf[512];
	char *s;
	int i;
	
	if (contmode==0) {
			DDPut(sd[flmorestr]);
	} else {
		hotres=3;
	}
	while(hotres==1)
	{
		if (!checkcarrier()) hotres=0;
		switch(HotKey(HOT_CURSOR))
		{
		 case 0:
		 case 'n':
		 case 'N':
		 case 'q':
		 case 'Q':
			*(curarea+1)=0;
			hotres=0;
			break;
			case 13:
		 case 10:
		 case 'y':
		 case 'Y':
		 case 251:
		 case ' ':
			if (clear) DDPut("[2J[H");
			hotres=2;
			break;		
		 case 250:
			if (cdat->cd_line) {
				DDPut(sd[flflagstr]);
			}
			currc--;
			while(currc->cd_line)
			{
				sprintf(parbuf,sd[fltagstr],currc->cd_line,currc->cd_file);
				DDPut(parbuf);								
				switch(HotKey(HOT_CURSOR))
				{
					int ii;
					
				 case 13:
				 case 10:
					ii=flagsingle(currc->cd_file,0);
					if (ii==0 || ii==4) {
						DDPut(sd[starstr]);
						DDPut("[D");
						sprintf(parbuf,"[%d;1H[36m%s[0m",currc->cd_line,currc->cd_file);
						DDPut(parbuf);								
						currc++;
					} else if (ii==3) {
						if (unflagfile(currc->cd_file)) {
							DDPut(" [D");
							sprintf(parbuf,"[%d;1H[36m%s[0m",currc->cd_line,currc->cd_file);
							DDPut(parbuf);								
							currc++;
						}
					} else if (ii==1) {
						fl_getbot();
						DDPut(sd[flfrater2str]);
						HotKey(0);
						fl_restore(currc);
					} else if (ii==2) {
						fl_getbot();
						DDPut(sd[flbrater2str]);
						HotKey(0);
						fl_restore(currc);
					} else if (ii==-1) {
						fl_getbot();
						DDPut(sd[flexister2str]);
						HotKey(0);
						fl_restore(currc);
					}
					break;
				 case 250:
					if (currc==cdat) break;
					sprintf(parbuf,sd[fltagoffstr],currc->cd_line,currc->cd_file);
					DDPut(parbuf);								
					currc--;
					break;										
				 case 251:
					sprintf(parbuf,sd[fltagoffstr],currc->cd_line,currc->cd_file);
					DDPut(parbuf);								
					currc++;
					break;										
				 case 'q':
				 case 'Q':
					sprintf(parbuf,sd[fltagoffstr],currc->cd_line,currc->cd_file);
					DDPut(parbuf);								
					while(currc->cd_line) currc++;
					break;
				}
				if (!checkcarrier()) break;
			}
			sprintf(parbuf,"[%d;1H",screenl);
			DDPut(parbuf);
			DDPut(sd[flmorestr]);
			break;
		 case 'c':
		 case 'C':
			contmode=1;
			hotres=3;
			break;
		 case 'f':
		 case 'F':
		 case 't':
		 case 'T':
			DDPut(sd[flflag2str]);
			*parbuf=0;
			if (!(Prompt(parbuf,512,PROMPT_FILE|PROMPT_NOCRLF))) return 0;
			s=parbuf;
			i=0;
			while((s=strspa(s,fbuf))) {
				i+=flagfile(fbuf,0);
			}
			if (i || flagerror==-1 ) {
				sprintf(fbuf,sd[flresstr],i);
				DDPut(fbuf);
			} else {
				if (flagerror==1) {
					fl_getbot();
					DDPut(sd[flfrater2str]);
				} else if (flagerror==2) {
					fl_getbot();
					DDPut(sd[flbrater2str]);
				} 
			}
			HotKey(0);
			fl_getbot();
			DDPut("\r                                                                             \r");
			DDPut(sd[flmorestr]);
			break;
			
		}	
	}
	return hotres;
}
char *mystrc(char *de, char *so)
{
	while(*so) *de++=*so++;
	*de=0;
	return de;
}

char *mystrcn(char *de, char *so, int s)
{
	int cnt=0;

	while(*so) 
	{
		*de++=*so++;
		cnt++;
		if (cnt==s) break;
	}
	*de=0;
	return de;
}

void ShowFile(char *src, char *zipmatch, int ziplen)
{
	char showb[8000];
	char *s, *t;
	int zoffset;
	char fname[256];
	
	s=src;
	t=fname;
	while(*s!=' ') *t++=*s++;
	*t=0;
	
	s=src;
	t=showb;
	
	if (ziplen==0) zoffset=344444444;
	else zoffset=zipmatch-src;
	t=mystrc(t,sd[flcol1str]);
	if (conf->CONF_ATTRIBUTES & (1L<<3)) {
		if (zoffset<34) {
			int cnt=0;
			while(s!=zipmatch) {
				*t++=*s++; cnt++;
			}
			t=mystrc(t,sd[flz1str]);
			for (;ziplen;ziplen--) {
				*t++=*s++; cnt++;
			}
			t=mystrc(t,sd[flz2str]);
			t=mystrcn(t,s,35-cnt);
			s=&s[35-cnt];
		} else {
			if (isfiletagged(fname)) {
				int cnt;
				t=mystrc(t,fname);
				t=mystrc(t,sd[starstr]);
				
				for (cnt=35-(strlen(fname)+1);cnt ; cnt--) {
					*t++=' ';
				}
				*t=0;
				s=&s[35];
			} else {
				t=mystrcn(t,s,35);
				s=&s[35];
			}
		}
		t=mystrc(t,sd[flcol2str]);
		t=mystrcn(t,s,4);
		s=&s[4];
		t=mystrc(t,sd[flcol3str]);
		t=mystrcn(t,s,9);
		s=&s[9];
		t=mystrc(t,sd[flcol4str]);
		t=mystrcn(t,s,25);
		s=&s[25];
	} else {
		if (zoffset<13) {
			int cnt=0;
			while(s!=zipmatch) {
				*t++=*s++; cnt++;
			}
			t=mystrc(t,sd[flz1str]);
			for (;ziplen;ziplen--) {
				*t++=*s++; cnt++;
			}
			t=mystrc(t,sd[flz2str]);
			t=mystrcn(t,s,13-cnt);
			s=&s[13-cnt];
		} else {
			if (isfiletagged(fname)) {
				int cnt;
				t=mystrc(t,fname);
				t=mystrc(t,sd[starstr]);
				
				for (cnt=13-(strlen(fname)+1);cnt ; cnt--) {
					*t++=' ';
				}
				*t=0;
				s=&s[13];
			} else {
				t=mystrcn(t,s,13);
				s=&s[13];
			}
		}
		t=mystrc(t,sd[flcol2str]);
		t=mystrcn(t,s,5);
		s=&s[5];
		t=mystrc(t,sd[flcol3str]);
		t=mystrcn(t,s,8);
		s=&s[8];
		t=mystrc(t,sd[flcol4str]);
		t=mystrcn(t,s,9);
		s=&s[9];
	}
	t=mystrc(t,sd[flcol5str]);

	if (!ziplen) {
		strcpy(t,s);
	} else {
		while(s!=zipmatch && *s) {
			*t++=*s++;
		}
		*t=0;
		if (*s) {
			t=mystrc(t,sd[flz3str]);
			for (;ziplen;ziplen--) {
				*t++=*s++;
			}
			t=mystrc(t,sd[flz4str]);
			strcpy(t,s);
		}
	}
	DDPut(showb);
}

int globalnewscan(void)
{
	struct DayDream_Conference *mc;
	struct DayDream_MsgBase *mb;
	int oldc;
	char gbuf[300];
	int bcnt;
	mc = confs;
		
	oldc=conf->CONF_NUMBER;
	
	DDPut(sd[flglobhstr]);

	while(mc->CONF_NUMBER!=255 && mc->CONF_NUMBER)
	{
		if (mc->CONF_FILEAREAS && *mc->CONF_NEWSCANAREAS && checkconfaccess(mc->CONF_NUMBER,&user) && isconftagged(mc->CONF_NUMBER)) {
			sprintf(gbuf,sd[flconfstr],mc->CONF_NAME);
			DDPut(gbuf);
			joinconf(mc->CONF_NUMBER,JC_SHUTUP|JC_QUICK);		
			sprintf(gbuf,"S %s",mc->CONF_NEWSCANAREAS);
			filelist(4,gbuf);
		}
		bcnt=mc->CONF_MSGBASES;
		(struct DayDream_Conference *)mb=mc+1;
		while (bcnt) {
			mb++;
			bcnt--;
		}
		mc=(struct DayDream_Conference *)mb;
	}
	joinconf(oldc,JC_SHUTUP|JC_QUICK);
	return 1;
}
