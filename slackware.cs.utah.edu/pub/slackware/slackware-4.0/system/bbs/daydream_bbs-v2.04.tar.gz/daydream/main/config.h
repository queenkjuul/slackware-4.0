/*
	small config file..

*/
 
/* Uncomment USE_SGTTY if you use *bsd */
 
/* #undef USE_SGTTY */

/* #define USE_SGTTY 1 */
 
/* Uncomment NO_VFS if your system does not have sys/vfs.h */
 
/* #define NO_VFS 1 */

 
 