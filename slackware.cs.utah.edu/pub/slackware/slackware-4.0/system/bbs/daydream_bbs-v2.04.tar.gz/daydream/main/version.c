#include "daydream.h"
#ifndef _WINDOWS
#include <sys/utsname.h>
#endif

void versioninfo(void)
{
#ifndef _WINDOWS
	struct utsname pilu;
	char verbuf[500];
	uname(&pilu);
	sprintf(verbuf,"\033[2J\033[H\033[0;33mDayDream/UNiX BBS %s, \033[32mCopyright 1996-1997 by Antti H�yrynen\n\n\033[0mRunning on %s/%s %s\n\n",versionstring,pilu.sysname,pilu.machine,pilu.release);
#else
	char verbuf[512];
	sprintf(verbuf,"\033[2J\033[H\033[0;33mDayDream/95 BBS %s, \033[32mCopyright 1996-1997 by Antti H�yrynen\n\n",versionstring);
#endif
	DDPut(verbuf);

}
