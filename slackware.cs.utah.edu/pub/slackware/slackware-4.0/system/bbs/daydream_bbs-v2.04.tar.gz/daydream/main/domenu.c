#include "daydream.h"
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

void dpause(void)
{
	DDPut(sd[pause2str]);
	HotKey(0);
	DDPut("\n");
}

int domenu(int p)
{
	char bufferi[500];
	
	if (p==1) {
		if (!(user.user_toggles & (1L<<4))) {
			dpause();
			TypeFile("commands",TYPE_SEC|TYPE_MAKE|TYPE_WARN|TYPE_CONF);
		}
	}

	changenodestatus("Main menu");  
//	sprintf(bufferi,sd[mainmenustr],conf->CONF_NUMBER,conf->CONF_NAME,base->MSGBASE_NUMBER,base->MSGBASE_NAME,lrp,highest,timeleft/60);
	makemainprompt(bufferi);
	DDPut(bufferi);
	
	bufferi[0]=0;
	
	if (!(Prompt(bufferi,400,PROMPT_MAIN))) return 0;
	
	if (bufferi[0]==0) return 2;

	return docmd(bufferi,0);
}

int docmd(char *bufferi, int skipd)
{
	char cmd[500];
	char *params;
	int i;
	struct DD_ExternalCommand *ext;
			
	i=0;
	params=0;
	while(bufferi[i]!=0) {
		if (bufferi[i]==' ') {
			params=&bufferi[i+1];
			while (*params==' ') params++;
			break;
		}
		cmd[i]=bufferi[i];
		i++;
	}
	if (bufferi[i]==0) params=0;
	
	cmd[i]=0;

	ext=exts;
	while (ext->EXT_NAME[0]!=0 && !skipd)
	{
		if (!strcasecmp(cmd,ext->EXT_NAME)) {
			if (ext->EXT_SECLEVEL > user.user_securitylevel) {
				DDPut(sd[accessdeniedstr]);
				return 1;
			}
			switch (ext->EXT_CMDTYPE)
			{
			 case 1:
				rundoor(ext->EXT_COMMAND,params);
				break;
			 case 2:
				runstdio(ext->EXT_COMMAND,0,1);
				break;
			 case 3:
				TypeFile(ext->EXT_COMMAND,TYPE_MAKE|TYPE_WARN);
				break;
			 case 4:
				return docmd(ext->EXT_COMMAND,1);
				break;
			}
			return 1;
		}
		ext++;
	}
	
	if (!strcasecmp(cmd,"cls")) {
		DDPut("[2J[H");
		return 2;
	} else if (!strcasecmp(cmd,"ver")) {
		versioninfo();
		return 1;
	} else if (!strcasecmp(cmd,"x")) {
		if (!isaccess(SECB_EXPERTMODE,access1)) return 1;
		
		if (user.user_toggles & (1L<<4)) {
			DDPut(sd[expertoffstr]);
			user.user_toggles &= ~(1L<<4);
		} else {
			DDPut(sd[expertonstr]);
			user.user_toggles |= (1L<<4);
		}
		return 1;
	} else if (!strcasecmp(cmd,"g")) {
		return logoff(params);
	} else if (!strcasecmp(cmd,"a")) {
		if (isaccess(SECB_CHANGEINFO,access1)) edituser(0);
		return 1;
	} else if (!strcasecmp(cmd,"f")) {
		if (isaccess(SECB_FILESCAN,access1)) filelist(1,params);
		return 1;
	} else if (!strcasecmp(cmd,"d")) {
		if (isaccess(SECB_DOWNLOAD,access1)) if (download(params)==2) return 0;
		return 1;
	} else if (!strcasecmp(cmd,"t")) {
		if (isaccess(SECB_TAGEDITOR,access1)) taged(params,0);
		return 1;
	} else if (!strcasecmp(cmd,"b")) {
		if (isaccess(SECB_BULLETINS,access1)) bulletins(params);
		return 1;
	} else if (!strcasecmp(cmd,"n")) {
		if (isaccess(SECB_NEWFILES,access1)) filelist(2,params);
		return 1;
	} else if (!strcasecmp(cmd,"z")) {
		if (isaccess(SECB_ZIPPYSEARCH,access1)) filelist(3,params);
		return 1;
	} else if (!strcasecmp(cmd,"l")) {
		time_t aika;
		char *aikas;
		char tmpstrh[180];
		
		if (!isaccess(SECB_VIEWTIME,access1)) return 1;
		aika=time(0);

		aikas=ctime(&aika);
		aikas[24]=0;
		sprintf(tmpstrh,sd[ltimestr],aikas);
		DDPut(tmpstrh);
		return 1;
	} else if (!strcasecmp(cmd,"s")) {
		if (isaccess(SECB_USERSTATS,access1)) userstats();
		return 1;
	} else if (!strcasecmp(cmd,"e")) {
		if (isaccess(SECB_ENTERMSG,access1)) entermsg(0,0,params);
		return 1;
	} else if (!strcasecmp(cmd,"c")) {
		if (isaccess(SECB_COMMENT,access1)) comment();
		return 1;
	} else if (!strcasecmp(cmd,"r")) {
		DDPut("\n");
		if (isaccess(SECB_READMSG,access1)) readmessages(-1,0);
		return 1;
	} else if (!strcasecmp(cmd,"gr")) {
		if (isaccess(SECB_READMSG,access1)) globalread();
		return 1;
	} else if (!strcasecmp(cmd,"j")) {
		if (isaccess(SECB_JOINCONF,access1)) joinconfmenu(params);
		return 1;
	} else if (!strcasecmp(cmd,"m")) {
		if (isaccess(SECB_CHANGEMSGAREA,access1)) cmbmenu(params);
		return 1;
	} else if (!strcasecmp(cmd,"lu")) {
		localupload();
		return 1;
	} else if (!strcasecmp(cmd,"u")) {
		if (isaccess(SECB_UPLOAD,access1)) if (upload(0)==2) return 0;
		return 1;
	} else if (!strcasecmp(cmd,"rz")) {
		if (isaccess(SECB_UPLOAD,access1)) if (upload(3)==2) return 0;
		return 1;
	} else if (!strcasecmp(cmd,"v")) {
		if (isaccess(SECB_VIEWFILE,access2)) viewfile(params);
		return 1;
	} else if (!strcasecmp(cmd,"ms")) {
		scanfornewmail();
		return 1;
	} else if (!strcasecmp(cmd,"ns")) {
		if (isaccess(SECB_NEWFILES,access1)) globalnewscan();
		return 1;
	} else if (!strcasecmp(cmd,"sm")) {
		if (isaccess(SECB_SELECTMSGBASES,access1)) tagmessageareas();
		return 1;
	} else if (!strcasecmp(cmd,"sf")) {
		if (isaccess(SECB_SELECTFILECONFS,access1)) tagconfs();
		return 1;
	} else if (!strcasecmp(cmd,">")) {
		nextconf();
		return 1;
	} else if (!strcasecmp(cmd,"<")) {
		prevconf();
		return 1;
	} else if (!strcasecmp(cmd,">>")) {
		nextbase();
		return 1;
	} else if (!strcasecmp(cmd,"<<")) {
		prevbase();
		return 1;
	} else if (!strcasecmp(cmd,"who")) {
		if (isaccess(SECB_WHO,access1)) who();
		return 1;
	} else if (!strcasecmp(cmd,"?")) {
		TypeFile("commands",TYPE_MAKE|TYPE_WARN);
		return 2;
	} else if (!strcasecmp(cmd,"userlist")) {
		if (isaccess(SECB_USERLIST,access1)) userlist(params);
		return 1;
	} else if (!strcasecmp(cmd,"mode")) {
		getdisplaymode(params,1);
		return 1;
	} else if (!strcasecmp(cmd,"o")) {
		if (isaccess(SECB_PAGE,access1)) pagesysop(params);
		return 1;
	} else if (!strcasecmp(cmd,"olm")) {
		if (isaccess(SECB_OLM,access2)) olmsg(params);
		return 1;
	} else if (!strcasecmp(cmd,"move")) {
		if (isaccess(SECB_MOVEFILE,access1)) movefile(params,0);
		return 1;
	} else if (!strcasecmp(cmd,"copy")) {
		if (isaccess(SECB_MOVEFILE,access1)) movefile(params,2);
		return 1;
	} else if (!strcasecmp(cmd,"link")) {
		if (isaccess(SECB_MOVEFILE,access1)) movefile(params,1);
		return 1;
	} else if (!strcasecmp(cmd,"sd")) {
		if (isaccess(SECB_SYSOPDL,access1)) sysopdownload(params);
		return 1;
	} else if (!strcasecmp(cmd,"usered")) {
		if (isaccess(SECB_USERED,access1)) {
			if (maincfg.CFG_OLUSEREDPW[0]) {
				char pwbuf[20];
				pwbuf[0]=0;
				DDPut(sd[uepwstr]);
				if (!(Prompt(pwbuf,15,PROMPT_SECRET))) return 0;
				if (strcasecmp(pwbuf,maincfg.CFG_OLUSEREDPW)) return 1;
			}
			usered();
		}
		return 1;
	}


	return 1;       

}

int isaccess(int flag, int accint)
{
	if (accint & (1L<<flag)) return 1;
	else {
		DDPut(sd[accden2str]);
		return 0;       
	}
}

void makemainprompt(char *buf)
{
	char *t=buf;
	char *s=sd[mainmenustr];

	while (*s) {
		if (*s=='~') {
			s++;
			switch(tolower(*s++)) {
			 case 'a':
				sprintf(t,"%d",lrp);
				while(*t) t++;
				break;
			 case 'c':
				strcpy(t,conf->CONF_NAME);
				while(*t) t++;
				break;
			 case 'e':
				sprintf(t,"%d",highest);
				while(*t) t++;
				break;
			 case 'l':
				sprintf(t,"%d",base->MSGBASE_NUMBER);
				while(*t) t++;
				break;
			 case 'm':
				strcpy(t,base->MSGBASE_NAME);
				while(*t) t++;
				break;
			 case 'n':
				sprintf(t,"%d",conf->CONF_NUMBER);
				while(*t) t++;
				break;
			 case 't':
				sprintf(t,"%d",timeleft/60);
				while(*t) t++;
				break;
			 case 'b':
				sprintf(t,"%d",node);
				while(*t) t++;
				break;
			 case 's':
				strcpy(t,maincfg.CFG_BOARDNAME);
				while(*t) t++;
				break;
			 case '~':
				*t++='~';
				break;
			}
		} else {
			*t++=*s++;
		}
	}
	*t=0;
}
	
	
/*

Control code    Meaning
========================================================================
     ~~         Print %-char
     ~A         Last read pointer
     ~C         Conference name
     ~E         Highest message
     ~L         Message base number
     ~M         Message base name
     ~N         Conference number
     ~T         Time left in minutes
     ~B         Node number
     ~S         BBS Name

 */
