// 	$Id: time.hh,v 1.4 1998/04/30 16:30:09 jvuokko Exp $	

/****************************************************************************
 * *
 * *  MODULE : time.hh
 * *
 * *  Copyright (c) 1997 Jukka Vuokko
 * *  See file COPYING for more information about copyrights.
 * *
 ****************************************************************************
 * *
 * *  Class for getting current time
 * *
 * *
 * *
 * *
 * *
 ***************************************************************************/

#ifndef __ajastukset__
#define __ajastukset__

#include <time.h>
#include "../utilib/my_types.h"
#include "../utilib/String.hh"
#include "datatypes.hh"

class Time_handler {
private:
        time_t current_time;
        struct tm *local_time;

        void update();
public:
        Time_handler(){};
        ~Time_handler(){};
        char* get_time();
        char* get_date();
};

class Date {
public:
        Date() {}
        Date( const String& d ) : _jmrdate( d ) { set_date(); }
        ~Date(){}
        void set( const String& d ) { _jmrdate = d; set_date(); }
        const Date& operator=(const String& d) { set(d); return *this; }
        const Date& operator=(const Date& d);
        const String& get_date() const { return _date; }
        const String& get_jmrdate() const { return _jmrdate; }
private:
        void set_date();
        String _jmrdate;
        String _date;
};



#endif
