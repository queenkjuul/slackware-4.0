// $Id: system.h,v 1.2 1998/05/25 20:06:12 jvuokko Exp $

#ifndef __system_h__
#define __system_h__


#if defined (__OS2__) || defined (__EMX__)
#   define DOS_PATH
#   define NEED_BINARY_FILEMODE
#   define LITTLE_ENDIAN_SYS
#   ifndef OS2
#      define OS2
#   endif
#elif defined (__DOS__) || defined (__MSDOS__)
#   define DOS_PATH
#   define NEED_BINARY_FILEMODE
#   define LITTLE_ENDIAN_SYS
#   ifndef DOS
#      define DOS
#   endif
#elif defined (__WIN32__) || defined (__NT__)
#   define DOS_PATH
#   define NEED_BINARY_FILEMODE
#   define LITTLE_ENDIAN_SYS
#   ifndef WIN32
#      define WIN32
#   endif
#endif

#endif /* __system_h__ */
