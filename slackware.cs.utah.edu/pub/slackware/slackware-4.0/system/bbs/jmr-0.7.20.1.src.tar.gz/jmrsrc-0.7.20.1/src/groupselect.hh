// $Id: groupselect.hh,v 1.3 1997/11/17 17:16:59 jvuokko Exp $

/*****************************************************************************
 * *
 * *      MODULE:     groupselect.hh
 * *                  --------------
 * ***************************************************************************
 * *
 * *
 * *      COPYRIGHT (C) 1997 JUKKA VUOKKO. ALL RIGHTS RESERVED
 * ***************************************************************************
 * *
 * *      Module containts class for interactive selection list of groups.
 * *
 *****************************************************************************/


#ifndef __grpselect__
#define __grpselect__

#include "select.hh"

struct grpnode {
        String name;
        int    number;
};


class Groupselection : public Selection<grpnode> {
public:
        Groupselection();
        ~Groupselection();
        grpnode select();
private:
        void display() {};
        void draw_item( int flag = DEFAULT_FL );
};

#endif
