// $Id: linereader.hh,v 1.3 1998/05/25 20:06:05 jvuokko Exp $
/*****************************************************************************
 * *
 * *      MODULE:     linereader.hh
 * *                  -------------
 * ***************************************************************************
 * *
 * *
 * *      COPYRIGHT (C) 1997 JUKKA VUOKKO. ALL RIGHTS RESERVED
 * ***************************************************************************
 * *
 * *      Simple class for reading line from file.
 * *
 *****************************************************************************/

#ifndef __freadlines_hh__
#define __freadlines_hh__

#include <fstream.h>
#include "../utilib/String.hh"
#include "constants.h"


class Linereader {
public:
        Linereader( const String &fname );
        ~Linereader();
        String read_line();  // read single line
        List<String> *read_all_lines(); // read all lines to linked list
private:
        ifstream fin;
        bool failed;
};





#endif
