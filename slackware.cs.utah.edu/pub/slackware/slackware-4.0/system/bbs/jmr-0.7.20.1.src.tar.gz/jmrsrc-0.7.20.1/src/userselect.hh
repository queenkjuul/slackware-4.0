// $Id: userselect.hh,v 1.2 1998/04/30 16:30:09 jvuokko Exp $

/*
 * This file is in the public domain.
 * author: krid@comnets.rwth-aachen.de
 * revised by: jvuokko
 */


#ifndef __userselect_hh__
#define __userselect_hh__

#include "../utilib/String.hh"
#include "select.hh"

class Userselection : public Selection<String> 
{
public:
    Userselection();
    ~Userselection();
    String select();

private:
    void display() {};
    void draw_item(int flag = DEFAULT_FL);
};

#endif
