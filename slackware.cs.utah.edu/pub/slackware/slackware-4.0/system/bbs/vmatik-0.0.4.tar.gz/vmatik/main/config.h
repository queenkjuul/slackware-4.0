/*
 * A very small VMatik config file...
 *
 */

#ifndef VMATIK_CONFIG_H
#define VMATIK_CONFIG_H
 
/********** Enable USE_SGTTY if you use *bsd ***********************/
 
// #define USE_SGTTY 1
 
/********** Enable NO_VFS if your system doesn't have sys/vfs.h ****/

// #define NO_VFS 1

/********** The temporary directory location ***********************/

#define VMTMP "/tmp/vmatik/"

/********** Name of the Yell Daemon socket *************************/
 
#define YELLD_SOCKET "/tmp/vmatik_yelld"


#endif
