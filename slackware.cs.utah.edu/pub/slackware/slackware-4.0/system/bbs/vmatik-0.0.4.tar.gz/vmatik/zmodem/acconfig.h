/* define this if you have a reliable ftime function */
#undef HAVE_FTIME

/* define this if you have the timezone variable */
#undef HAVE_TIMEZONE_VAR
