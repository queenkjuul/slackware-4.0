/*
 * Message base reading
 *
 */
#include "proto.h"
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>


int seekpoint=0;
int oldseekpoint;
char rbuffer[500];
int msgdatfd;
int msgbasesize;
struct VMatik_Message *msgbuf;
int bread;
int msgnum;
struct VMatik_Message *daheader=0;

int getsizesize(char *);
int showmsg(int, int);
int deletemsg(int);
int keepmsg(int);
int replymsg(int);
void readmsgdatas();


int readmessages(int cseekp, int premsg)
{
	int dir;
	int tnum;
	int oldmsg;
	int rval=0;
					
	changenodestatus("Reading messages");
	
	daheader=0;
	
	getmsgptrs();
	
	sprintf(rbuffer,"%smessages/base%3.3d/msgbase.dat",conf->CONF_PATH,base->MSGBASE_NUMBER);

	msgbasesize=getfilesize(rbuffer);
	if (!msgbasesize) {
		if (!premsg) DDPut(sd[rmnomsgsstr]);
		return 0;
	}

	msgbuf=(struct VMatik_Message *)malloc(sizeof(struct VMatik_Message)*101);
	
	if (cseekp!=-1) 
		seekpoint=cseekp;
	else
		seekpoint=msgbasesize-(100*sizeof(struct VMatik_Message));
	if (seekpoint < 0) seekpoint=0;

	readmsgdatas();
	dir=1;
	
	if (premsg > 0) msgnum=premsg; else msgnum=base->MSGBASE_LRP.lrp_read;
	
	while(1)
	{
		char dirc;
		
		if (dir==1) dirc='+'; else dirc='-';
		 
		if (premsg > 0) showmsg(msgnum,1);
	
		if (premsg == -1) {
			rbuffer[0]=0;
			premsg=0;
		} else {
			sprintf(rbuffer,sd[rmpromptstr],msgnum,highest,dirc);
			DDPut(rbuffer);
			rbuffer[0]=0;
			if (!(Prompt(rbuffer,5,PROMPT_NOCRLF))) return 0;
		}
		if (rbuffer[0]==0) {
			if (cseekp!=-1) {
				base->MSGBASE_LRP.lrp_scan=msgnum;
				free(msgbuf);
				return 0;
			}
			msgnum=msgnum+dir;
			if (msgnum > highest) break;
			if (msgnum < lowest) msgnum=lowest;
			else {
				while(showmsg(msgnum,0)!=1)
				{
					msgnum=msgnum+dir;
					if (msgnum > highest) goto pois;
					if (msgnum < lowest) {
						msgnum=lowest;
						break;
					}				
				}
			}
		} else if (!strcasecmp(rbuffer,"a")) {
			showmsg(msgnum,0);
		} else if (!strcasecmp(rbuffer,"d")) {
			deletemsg(msgnum);
		} else if (!strcasecmp(rbuffer,"e")) {
			editmsg(msgnum);
		} else if (!strcasecmp(rbuffer,"eh")) {
			editmsghdr(msgnum);
		} else if (!strcasecmp(rbuffer,"k")) {
			keepmsg(msgnum);
		} else if ((!strcasecmp(rbuffer,"r")) || (!strcasecmp(rbuffer,"re"))) {
			replymsg(msgnum);
		} else if (!strcasecmp(rbuffer,"c")) {
			DDPut("\n");
			TypeFile("msgreadcommands",TYPE_MAKE|TYPE_WARN);
		} else if (!strcasecmp(rbuffer,"q")) {
			rval=2;
			break;
		} else if (!strcasecmp(rbuffer,"-")) {
			dir=-1;
		} else if (!strcasecmp(rbuffer,"+")) {
			dir=1;
		} else {
			tnum=atoi(rbuffer);
			if (tnum) {
				if (tnum > highest || tnum < lowest) {
					DDPut(sd[rmoutstr]);
				
				} else {
					if (cseekp!=-1) {
						if (tnum > base->MSGBASE_LRP.lrp_scan) 
							base->MSGBASE_LRP.lrp_scan=tnum;
						free(msgbuf);
						return 0;
					}
					oldmsg=msgnum;
					msgnum=tnum;
					switch(showmsg(msgnum,0))
					{
						case 0:
							DDPut(sd[rmoutstr]);			// Outside range
							if(msgnum>highest)
								msgnum=highest;
							else
							if(msgnum<lowest)
								msgnum=lowest;
							break;
						case 1:
							break;
						case 2:
							DDPut(sd[rmdeletestr]);			// Deleted
							break;
						case 3:
							DDPut(sd[rmprivatestr]);		// Private
							break;
					}
				}
			}
		}
	}		
pois:
	DDPut("\n\n");
	free(msgbuf);	
	return rval;
}

void updatemsgdatas(void)
{
	int msgdatfd;
	
	sprintf(rbuffer,"%smessages/base%3.3d/msgbase.dat",conf->CONF_PATH,base->MSGBASE_NUMBER);
	msgdatfd=open(rbuffer,O_WRONLY);
	if(msgdatfd!=-1)
	{
		lseek(msgdatfd,oldseekpoint,SEEK_SET);
		write(msgdatfd,msgbuf,bread);
		close(msgdatfd);	
	}
}

int showmsg(int showme, int mode)
{

	int hinkmode=0;
	int msghandle=0;
	int lowmode=0;		
	char *msgstatus;
	int sublen;
	FILE *msgfd;
	int screenl;
	int l;
					
	daheader=msgbuf;

	if (!showme) return 0;
	while (1)
	{
		if (daheader->MSG_NUMBER==showme) break;
		if (daheader->MSG_NUMBER==65535 && daheader->MSG_NEXTREPLY==65535) {
			if ((lowest > showme) || (highest < showme)) {
				return 0;
			}
			if (!hinkmode) {
				seekpoint=msgbasesize-((10+(highest-msgnum))*sizeof(struct VMatik_Message));
				if (seekpoint < 0) seekpoint=0;
				readmsgdatas();
				hinkmode=1;			
			} else {
				sprintf(rbuffer,"%smessages/base%3.3d/msg%5.5d",conf->CONF_PATH,base->MSGBASE_NUMBER,showme);
				msghandle=open(rbuffer,O_RDONLY);
				if (msghandle==-1) {
					return 2;
				}				
				close(msghandle);
				if (showme < msgbuf->MSG_NUMBER) {
					lowmode=1;
					if (!oldseekpoint) return 2;
					seekpoint=seekpoint-100*sizeof(struct VMatik_MsgBase);
					if (seekpoint < 0) seekpoint=0;
					readmsgdatas();
					if (!bread) return 2;
				} else {
					if (lowmode) return 2;
					readmsgdatas();
					if (!bread) return 2;
				}
			}
			daheader=msgbuf;
		} else daheader++;
	}

	if (daheader->MSG_FLAGS & MSG_FLAGS_DELETED) 
		return 2;
	
	if (base->MSGBASE_LRP.lrp_read < showme && (mode==0)) {
		base->MSGBASE_LRP.lrp_read=showme;
	}
	msgstatus="Public";
	if (daheader->MSG_FLAGS & MSG_FLAGS_PRIVATE) {
		msgstatus="Private";

		if ((!strcasecmp(daheader->MSG_AUTHOR,user.user_realname)) || (!strcasecmp(daheader->MSG_AUTHOR,user.user_handle)) || (!strcasecmp(daheader->MSG_RECEIVER,user.user_handle)) || (!strcasecmp(daheader->MSG_RECEIVER,user.user_realname)) || (access_flags & SECB_READALL)) {
		
		
		} else {
			return 3;
		}
	}		
	

	sprintf(rbuffer,"%smessages/base%3.3d/msg%5.5d",conf->CONF_PATH,base->MSGBASE_NUMBER,showme);
	msgfd=fopen(rbuffer,"r");
	if (msgfd==0) {
		return 2;
	}				

	if (base->MSGBASE_LRP.lrp_read > showme) daheader->MSG_READCOUNT++;
	
	sprintf(rbuffer,sd[rmhead1str],daheader->MSG_AUTHOR,msgstatus);
	DDPut(rbuffer);
	if (daheader->MSG_RECEIVER[0]==0) {
		msgstatus=sd[rmallstr];
	} else if (daheader->MSG_RECEIVER[0]==-1) {
		msgstatus=sd[rmeallstr];
	} else msgstatus=daheader->MSG_RECEIVER;
	
	sprintf(rbuffer,sd[rmhead2str],msgstatus,ctime(&daheader->MSG_CREATION));
	DDPut(rbuffer);
	if (daheader->MSG_RECEIVED==0) {
		msgstatus="-\n";
	} else {
		msgstatus=ctime(&daheader->MSG_RECEIVED);
	}
	sprintf(rbuffer,sd[rmhead3str],base->MSGBASE_NAME,msgstatus);
	DDPut(rbuffer);
	sprintf(rbuffer,sd[rmhead4str],daheader->MSG_READCOUNT);
	DDPut(rbuffer);
	sprintf(rbuffer,sd[rmhead5str],daheader->MSG_SUBJECT);
	sublen=strlen(daheader->MSG_SUBJECT);
	sublen=73-sublen;
	while(sublen)
	{
		strcat(rbuffer,"-");
		sublen--;
	}
	strcat(rbuffer,"\n\n[0m");
	DDPut(rbuffer);
	
	screenl=user.user_screenlength-8;
	
	l=0;
	while(fgets(rbuffer,490,msgfd))
	{
		char *s;
		int ih=0;
		
		s=rbuffer;
		
		if (*rbuffer==1 && toupper(base->MSGBASE_FN_FLAGS)!='L') continue;
		if (l==0 && toupper(base->MSGBASE_FN_FLAGS)=='E' && !strncmp("AREA:",rbuffer,5)) continue;
		l++;
		if (!strncmp("SEEN-BY:",rbuffer,8)) break;
		
		if (toupper(base->MSGBASE_FN_FLAGS)!='L') while( strlena(s) > 79 ) {
			char *t=&s[79];
			while(*t!=' ') {
				t--;
				if (t==s) {
					DDPut(s);
					*s=0;
					t=s;
					ih=1;
					break;
				}
			}
			if (!ih) {
				*t=0;
				DDPut(s);
				DDPut("\n");
				s=&t[1];
			}
			screenl--;

			if (screenl==1) {
				int hot;
					
                       		DDPut(sd[morepromptstr]);
				hot=HotKey(0);
				DDPut("\r                                                         \r");
				if (hot=='N'||hot=='n'||!checkcarrier()) break;
				if (hot=='C'||hot=='c') {
					screenl=20000000;
				} else {
					screenl=user.user_screenlength;
				}
			}
		}
		
		DDPut(s);
		screenl--;

		if (screenl==1) {
			int hot;
				
                        DDPut(sd[morepromptstr]);
			hot=HotKey(0);
			DDPut("\r                                                         \r");
			if (hot=='N'||hot=='n'||!checkcarrier()) break;
			if (hot=='C'||hot=='c') {
				screenl=20000000;
			} else {
				screenl=user.user_screenlength;
			}
		}
	}
	if (*daheader->MSG_ATTACH) {
		char fabuf[1024];
		char buf2[1024];
		FILE *atlist;
		
		sprintf(fabuf,"%smessages/base%3.3d/msf%5.5d",conf->CONF_PATH,base->MSGBASE_NUMBER,daheader->MSG_NUMBER);
		atlist=fopen(fabuf,"r");
		if (atlist) {
			if (screenl < 5) {
				int hot;
				
				DDPut(sd[morepromptstr]);
				hot=HotKey(0);
				DDPut("\r                                                         \r");
				if (hot=='N'||hot=='n'||!checkcarrier()) goto pom;
				if (hot=='C'||hot=='c') {
					screenl=20000000;
				} else {
					screenl=user.user_screenlength;
				}
			}
			DDPut(sd[attachhdstr]);
			screenl-=3;
			while(fgetsnolf(fabuf,1024,atlist))
			{
				int hot;
				struct stat st;
				
				sprintf(buf2,"%smessages/base%3.3d/fa%5.5d/%s",conf->CONF_PATH,base->MSGBASE_NUMBER,daheader->MSG_NUMBER,fabuf);
				if (stat(buf2,&st)==-1) continue;
				
				sprintf(buf2,sd[attachestr],fabuf,st.st_size);
				DDPut(buf2);
				screenl--;
				
				if (screenl < 2) {
		            DDPut(sd[morepromptstr]);
					hot=HotKey(0);
					DDPut("\r                                                         \r");
					if (hot=='N'||hot=='n'||!checkcarrier()) break;
					if (hot=='C'||hot=='c') {
						screenl=20000000;
					} else {
						screenl=user.user_screenlength;
					}
				}
			}
			DDPut(sd[attachtstr]);
			if (HotKey(HOT_NOYES)==1) {
				char olddir[1024];
				
				getcwd(olddir,1024);
				sprintf(fabuf,"%smessages/base%3.3d/fa%5.5d",conf->CONF_PATH,base->MSGBASE_NUMBER,daheader->MSG_NUMBER);
				chdir(fabuf);
				sprintf(fabuf,"../msf%5.5d",daheader->MSG_NUMBER);
				dl_sendfiles(fabuf,NULL,NULL);
				chdir(olddir);
			}
pom:
			fclose(atlist);
		}
	}
	DDPut("\n");
	fclose(msgfd);
	return 1;
}

int deletemsg(int delme)
{
	if (!daheader) {
		DDPut(sd[rmdeletewhatstr]);
		return 0;
	}

	if (daheader->MSG_FLAGS & MSG_FLAGS_DELETED) {
		DDPut(sd[rmdeletealrstr]);
		return 0;
	}
	
	if ( (access_flags & SECB_DELETEANYMSG) || 
		(!strcasecmp(user.user_handle,daheader->MSG_AUTHOR)) || 
		(!strcasecmp(user.user_realname,daheader->MSG_AUTHOR)) || 
		(!strcasecmp(user.user_handle,daheader->MSG_RECEIVER)) || 
		(!strcasecmp(user.user_realname,daheader->MSG_RECEIVER))) 
	{
		sprintf(rbuffer,"%smessages/base%3.3d/msg%5.5d",
				conf->CONF_PATH,base->MSGBASE_NUMBER,daheader->MSG_NUMBER);
		unlink(rbuffer);
		daheader->MSG_FLAGS |= MSG_FLAGS_DELETED;
		if (*daheader->MSG_ATTACH == 1) {
			sprintf(rbuffer,"%smessages/base%3.3d/fa%5.5d",
					conf->CONF_PATH,base->MSGBASE_NUMBER,daheader->MSG_NUMBER);
			deldir(rbuffer);
			unlink(rbuffer);
			sprintf(rbuffer,"%smessages/base%3.3d/msf%5.5d",
					conf->CONF_PATH,base->MSGBASE_NUMBER,daheader->MSG_NUMBER);
			unlink(rbuffer);
		}
		DDPut(sd[rmdeletedstr]);
	} else {
		DDPut(sd[rmdelnostr]);
	} 
	return 0;
}

int editmsg(int editme)
{
	if (!daheader || (daheader->MSG_FLAGS & MSG_FLAGS_DELETED)) 
		return 0;

	if (( !strcasecmp(user.user_handle,daheader->MSG_AUTHOR)) ||
		(!strcasecmp(user.user_realname,daheader->MSG_AUTHOR)) ||
		user.user_securitylevel == 31) 
	{
		sprintf(rbuffer,"%smessages/base%3.3d/msg%5.5d",conf->CONF_PATH,base->MSGBASE_NUMBER,daheader->MSG_NUMBER);
		DDPut("\r                                                                 \r");
		editfile(rbuffer);
	}
	return 1;
}

int editmsghdr(int editme)
{
	if (!daheader || (daheader->MSG_FLAGS & MSG_FLAGS_DELETED)) 
		return 0;

	if (( !strcasecmp(user.user_handle,daheader->MSG_AUTHOR)) || 
		(!strcasecmp(user.user_realname,daheader->MSG_AUTHOR)) || 
		user.user_securitylevel == 31) 
	{
		char foobuf[1024];
		DDPut("\n\n");
		if (user.user_securitylevel==31) {
			DDPut(sd[edhfstr]);
			if (!(Prompt(daheader->MSG_AUTHOR,25,0))) return 0;
		}
		DDPut(sd[edhtstr]);
		if (*daheader->MSG_RECEIVER==-1) {
			strcpy(foobuf,"EAll");
		} else if (*daheader->MSG_RECEIVER==0) {
			strcpy(foobuf,"All");
		} else {
			strcpy(foobuf,daheader->MSG_RECEIVER);
		}
		if (!(Prompt(foobuf,25,0))) return 0;
		if (!strcasecmp(foobuf,"eall")) {
			if (!(access_flags & SECB_EALLMESSAGE)) {
				*daheader->MSG_RECEIVER=0;
			} else {
				*daheader->MSG_RECEIVER=-1;
			}
		} else if (!strcasecmp(foobuf,"all")) {
			*daheader->MSG_RECEIVER=0;
		} else {
			strcpy(daheader->MSG_RECEIVER,foobuf);
		}
		DDPut(sd[edhsstr]);
		if (!(Prompt(daheader->MSG_SUBJECT,67,0))) return 0;
		if ((base->MSGBASE_FLAGS & MSGB_ALLOW_PUBLIC) && 
			(base->MSGBASE_FLAGS & MSGB_ALLOW_PRIVATE)) 
		{
			DDPut(sd[edhpstr]);
			if (HotKey(HOT_NOYES)==2) {
				daheader->MSG_FLAGS &= ~MSG_FLAGS_PRIVATE;
			} else {
				daheader->MSG_FLAGS |= MSG_FLAGS_PRIVATE;
			}
		}
		updatemsgdatas();
	}	
	return 1;
}

/*
 * BUGS: Hard-coded msg size! CHANGE! 
 *
 */
int editfile (char *file) 
{
	char *s;
	int edtype=0;
	int hola;
	char *lineedmem;
	int res;
	int rep=0;
	FILE *wu, *tang;
	char readbuf[1024];
	char mbuf[1024];
					
	edtype=0;
	if (user.user_toggles & TOGGLE_ASK_EDITOR) {
		DDPut(sd[emfsedstr]);
		hola=HotKey(HOT_YESNO);
		if (hola==0) return 0;
		if (hola==1) edtype=1;
	} else if (user.user_toggles & TOGGLE_FSED) {
		edtype=1;
	}

	lineedmem=(char *)malloc(40000);

	wu=fopen(file,"r");
	if (wu) {
		rep=1;
		sprintf(mbuf,"%sVMatik%d.msg",VMTMP,node);
		tang=fopen(mbuf,"w");
		while(fgets(readbuf,1024,wu)) 
			fputs(readbuf,tang);
		fclose(wu); 
		fclose(tang);
	}	
	memset(lineedmem,0,40000);
	
	if (edtype) {
		res=fsed(lineedmem,rep,0);
	} else {
		res=lineed(lineedmem,rep,0);
	}
	if (res) {
		wu=fopen(file,"w");
		if (wu) {
			s=lineedmem;
			while(res--) {
				fprintf(wu,"%s\n",s);
				s=&s[80];
			}
			fclose(wu);
			
		}
	}
	free(lineedmem);
	
	unlink(mbuf);
	
	return(1);
}

int replymsg(int delme)
{
	updatemsgdatas();
	
	if (!daheader) {
		DDPut(sd[rmreplynostr]);
		return 0;
	}
	replymessage(daheader);
	
	seekpoint=oldseekpoint;
	readmsgdatas(daheader);
	
	return 1;
}

void readmsgdatas(void)
{
	int msgdatfd;
	struct VMatik_Message *kalamsg;
	int moffset;
	
	sprintf(rbuffer,"%smessages/base%3.3d/msgbase.dat",conf->CONF_PATH,base->MSGBASE_NUMBER);
	msgdatfd=open(rbuffer,O_RDONLY);
	lseek(msgdatfd,seekpoint,SEEK_SET);
	bread=read(msgdatfd,msgbuf,100*sizeof(struct VMatik_Message));
	moffset=bread/sizeof(struct VMatik_Message);
	kalamsg=msgbuf+moffset;
	kalamsg->MSG_NUMBER=65535;
	kalamsg->MSG_NEXTREPLY=65535;
	oldseekpoint=seekpoint;
	seekpoint=seekpoint+bread;
	close(msgdatfd);	
}

int globalread(void)
{
	int oldconf,oldarea;
	struct VMatik_Conference *mconf;
	struct VMatik_MsgBase *mbase;
	int go=1;

	oldarea=user.user_defarea_id;
	oldconf=user.user_defconf_id;
	mconf=(struct VMatik_Conference *)confs->lh_Head;

	while(go && mconf->chead.ln_Succ)
	{
		if (jc_joinconf(mconf->CONF_NUMBER,JC_QUICK|JC_SHUTUP)) 
		{
			int bcnt,b=0;
		
			bcnt=mconf->CONF_MSGBASES;
			
			while (bcnt)
			{
				mbase=&(mconf->Conf_MsgBases[b]);
			
				jc_changemsgbase(mbase->MSGBASE_NUMBER,MC_QUICK|MC_NOSTAT);
				if (highest > base->MSGBASE_LRP.lrp_read && 
					isbasetagged(mconf->CONF_NUMBER,mbase->MSGBASE_NUMBER)) 
				{
					if (readmessages(-1,-1)==2) 
					{
						go=0;
						break;
					}
				}
				b++;
				bcnt--;
			}
		}
		mconf=(struct VMatik_Conference *)mconf->chead.ln_Succ;
	}
	jc_joinconf(oldconf,JC_QUICK|JC_SHUTUP);
	jc_changefilearea(oldarea, JC_SHUTUP|JC_ABSOLUTE);
	return 1;
}

int getfilesize(char *pathi)
{
	struct stat fib;
	int sizefd;
	
	sizefd=open(rbuffer,O_RDONLY);
	if (sizefd==-1) return 0;
	fstat(sizefd,&fib);
	close(sizefd);
	return fib.st_size;
}

int strlena(char *s)
{
	int i=0;
	
	while(*s) 
	{
		if (*s==27) {
			s++;
			while( isdigit(*s) || *s==';') {
				s++;
				if (*s==0) return i;
			}
			s++;
		} else {
			i++;
			s++;
		}
	}
	return i;
}

int keepmsg(int msgnum)
{
	struct VMatik_Message msg;
	char buf1[512], buf2[512];
	int msgfd;
	
	updatemsgdatas();
	
	if (!daheader) {
		return 0;
	}
	if ( (!strcasecmp(msg.MSG_RECEIVER,user.user_handle))
	    || (!strcasecmp(msg.MSG_RECEIVER,user.user_realname))
	    || user.user_securitylevel >= maincfg.CFG_COSYSOPLEVEL) {

		msg=*daheader;

		msg.MSG_RECEIVED=0;
		daheader->MSG_FLAGS |= MSG_FLAGS_DELETED;
	
		msg.MSG_FLAGS |= MSG_FLAGS_FIDOMSG;
		getmsgptrs();
		highest++;
		msg.MSG_NUMBER=highest;
		setmsgptrs();
		
		sprintf(buf1,"%smessages/base%3.3d/msg%5.5d",conf->CONF_PATH,base->MSGBASE_NUMBER,daheader->MSG_NUMBER);
		sprintf(buf2,"%smessages/base%3.3d/msg%5.5d",conf->CONF_PATH,base->MSGBASE_NUMBER,msg.MSG_NUMBER);
		newrename(buf1,buf2);
		
		sprintf(buf1,"%smessages/base%3.3d/msgbase.dat",conf->CONF_PATH,base->MSGBASE_NUMBER);

		if ((msgfd=open(buf1,O_RDWR|O_CREAT,0664)) < 0) return 0;

		lseek(msgfd,0,SEEK_END);
		write(msgfd,&msg,sizeof(struct VMatik_Message));
		close(msgfd);

		seekpoint=oldseekpoint;
		readmsgdatas();
		return 1;
	}
	return 0;
}
