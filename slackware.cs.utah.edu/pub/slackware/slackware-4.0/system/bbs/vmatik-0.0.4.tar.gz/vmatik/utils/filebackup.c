/*
 *
 * VuohiMatik filebase backupper v0.02
 *
 * Files which have "file_backup==0" [or the value specified
 * with "-r" on the commandline] will be included in the backup.
 * Included files will be set a new file_backup ID [or the one 
 * specified with "-r"] ... 
 *
 * Files will be included until media size is reached. Media
 * size can be specified on the commandline (in Megabytes).
 * 
 * Then a shadow directory of the included files is created
 * to a specified location ("-p path"). You can then create 
 * an ISO-image out of the created directory structure, 
 * stream it to tape or whatever.
 *
 * Note1: Without "-n", this utility tries to fill the backup media 
 *        to the brim. In any case, it can't know which files should 
 *        go together. For example, disk archives belonging to the 
 *        same product may end up on different backups.
 *
 * Note2: After using this utility, its suggested to do atleast 
 *        "du -L" in the destination directory to see that everything
 *        went ok.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include "proto.h"

#define DEFAULT_MEDIA_SIZE		630
#define DEFAULT_LOCATION 		"/tmp/test"

int be_nice=0;					// Do not fill backup media to the brim? 

struct arealist					// Skip these fileareas
{
	char area_id;
	struct arealist *next;
};

struct areadata
{
	int area_id;
	char area_path[PATH_MAX];
};

struct arealist *alist=NULL;

int output_formatted_row(FILE *dp, MYSQL_ROW sql_row);

int usage(char *prg_name)
{
	fprintf(stderr, "Usage: %s [-s size] [-p path] [-r ID] [-n]\n\n%s",	prg_name,
	"-n             Be nice, stop at first file not fitting on backup\n"
	"-p <path>      Path to make the shadow directory into\n"
	"-r <ID>        Specify an explicit backup ID number\n"
	"-c <area_id>   Skip this file area\n"
	"-s <size>      Media size in megabytes (1MB==1024*1024 bytes)\n");

	return(1);
}

/*
 * Returns the location of last component
 *
 */
int mymkdir(char *component, char *dest_path, char *new_path)
{
	char temp[PATH_MAX];
	int i;
	
	strcpy(temp, component);

	i=strlen(temp)-1;
	if(temp[i]=='/')
	{
		temp[i]=0;
		i--;
	}
		
	while(i>0 && temp[i]!='/')
		i--;
	i++;
	
	if(dest_path[strlen(dest_path)]=='/')
		sprintf(new_path, "%s%s", dest_path, &temp[i]); 
	else
		sprintf(new_path, "%s/%s", dest_path, &temp[i]);

	mkdir(new_path, 0644);
	return(i);
}

/*
 * Makes the backup.
 *
 */
int make_backup(int backup_id, int media_size, char *dest_path)
{
	struct areadata *areas=NULL;
	int i,area_amount=0, go=1;
	int total_bytes=0,total_files=0, total_dirs=0;
	int old_id=0;
	MYSQL db;
	MYSQL_RES *sql_result;
	MYSQL_ROW sql_row;
	char query[QUERY_MAX];
	char new_path[PATH_MAX];
	char new_whole[PATH_MAX];
	char old_whole[PATH_MAX];
	struct arealist *tmp;
	FILE *dp;

	media_size=media_size*1024*1024;

	mysql_connect(&db, NULL, "bbs", NULL);
	if(mysql_error(&db)[0])
	{
		fprintf(stderr, "%s\n", mysql_error(&db));
		return(0);
	}
	mysql_select_db(&db, "vmatik");
	if(mysql_error(&db)[0])
	{
		fprintf(stderr, "%s\n", mysql_error(&db));
		mysql_close(&db);
		return(0);
	}

	tmp=alist;
	old_whole[0]=0;
	i=0;
	while(tmp)
	{
		i+=sprintf(&old_whole[i], "area_id!=%d AND ", tmp->area_id);
		tmp=tmp->next;
	}

	sprintf(query, "SELECT area_id, area_filepath FROM vmatik_fileareas WHERE %s 1 ORDER BY area_displayat", old_whole);

	mysql_query(&db, query);
	if(mysql_error(&db)[0])
		fprintf(stderr, "%s\n", mysql_error(&db));
	
	sql_result=mysql_store_result(&db);
	if(sql_result)
	{
		area_amount=mysql_num_rows(sql_result);
		areas=malloc(area_amount*sizeof(struct areadata));
		if(!areas)
		{
			mysql_free_result(sql_result);
			mysql_close(&db);
			return(0);
		}
			
		for(i=0;i<area_amount;i++)
		{
			sql_row=mysql_fetch_row(sql_result);
			areas[i].area_id=atoi(sql_row[0]);
			strcpy(areas[i].area_path, sql_row[1]);
//			printf("%d %s\n", areas[i].area_id, areas[i].area_path);
		}

		mysql_free_result(sql_result);
	}

	if(backup_id==0)						// Get new ID
	{
		mysql_query(&db, "SELECT max(file_backup)
					FROM vmatik_filelist");
		sql_result=mysql_store_result(&db);
		if(sql_result)
		{
			sql_row=mysql_fetch_row(sql_result);
			if(sql_row)
				backup_id=atoi(sql_row[0]);
			mysql_free_result(sql_result);
		}

		backup_id++;
		fprintf(stderr, "New backup ID is %d\n", backup_id);
	}
	else
		old_id=backup_id;

	sprintf(query, "%s/allfiles.txt", dest_path);
	dp=fopen(query, "w");
	if(!dp)
	{
		fprintf(stderr, "Unable to open %s\n", query);
		mysql_close(&db);
		return(1);
	}

	while(go)
	{
		for(i=0;i<area_amount && total_bytes<media_size;i++)
		{
			sprintf(query, "SELECT file_id, file_name, file_size, 
							file_uldate, file_description
							FROM vmatik_filelist
							WHERE file_area=%d AND file_backup=%d 
							(AND NOT file_flags & %ld) 
							AND file_integrity!=%d
							ORDER BY file_name", 
							areas[i].area_id, old_id,
							FILE_OFFLINE, INTEGRITY_FAILED);
			mysql_query(&db, query);
			if(mysql_error(&db)[0])
				fprintf(stderr, "%s\n", mysql_error(&db));
		
			sql_result=mysql_store_result(&db);
			if(sql_result)
			{
				int temp_size, dir_made=0;
			
				while((sql_row=mysql_fetch_row(sql_result)) && 
						total_bytes<media_size)
				{
					temp_size=atoi(sql_row[2]);
					if(total_bytes+temp_size<media_size)
						total_bytes+=temp_size;
					else
					{
						if(be_nice)						// Quit here
						{
							go=0;
							i=area_amount;
							break;
						}
						else		       // Try to find small files that fit	
							continue;
					}
		
					if(!dir_made)
					{
						int lastcomploc;
						
						lastcomploc=mymkdir(areas[i].area_path, 
									dest_path, new_path);
						dir_made=1;
						fprintf(dp, "\n\n%s\n\n", 
								&(areas[i].area_path[lastcomploc]));
						total_dirs++;
					}
					
					output_formatted_row(dp, sql_row);
			
					sprintf(query, "UPDATE vmatik_filelist
								SET file_backup=%d
								WHERE file_id=%s",
								backup_id, sql_row[0]);
					mysql_query(&db, query);
				
					sprintf(new_whole, "%s/%s", new_path, sql_row[1]);
					sprintf(old_whole, "%s%s", areas[i].area_path, sql_row[1]);
//					printf("%s %s\n", old_whole, new_whole);
//					printf("%s%s %d\n", areas[i].area_path,
//							sql_row[1], total_bytes);
//					sprintf(query, "cp %s %s", old_whole, new_whole);
//					system(query);
					symlink(old_whole, new_whole);

					total_files++;
				}
				mysql_free_result(sql_result);
			}
		}

		if(!old_id)
			go=0;
		else
			old_id=0;			// See if we can add new stuff to the backup
	}

	fclose(dp);
	mysql_close(&db);

	if(areas)
		free(areas);

	fprintf(stderr, "Total: %d dirs, %d files and %d bytes added.\n",
	total_dirs, total_files, total_bytes);

	return(1);
}

int main(int argc, char *argv[])
{
	int go=1;
	char dest_path[PATH_MAX];
	int media_size=DEFAULT_MEDIA_SIZE;		// In Megabytes
	int backup_id=0;						// Get new ID

	strcpy(dest_path, DEFAULT_LOCATION);

	while(go)
	{
		switch(getopt(argc, argv, "c:hnr:s:p:"))
		{
			case 'c':
			{
				struct arealist *tmp;
				
				tmp=malloc(sizeof(struct arealist));
				tmp->area_id=atoi(optarg);
				tmp->next=NULL;

				if(!alist)
					alist=tmp;
				else
				{
					tmp->next=alist;
					alist=tmp;
				}
				printf("Skipping area %d\n", tmp->area_id);
			}
			break;
			case 'n':
				fprintf(stderr, "Ok, were nice today, stopping at the first nonfitting file.\n");
				be_nice=1;
				break;
			case 'r':
				backup_id=atoi(optarg);
				if(backup_id>0)
					fprintf(stderr, "Replacing/updating backup #%d\n", 
							backup_id);
				break;
			case 's':
				media_size=atoi(optarg);
				if(!media_size)
					media_size=DEFAULT_MEDIA_SIZE;
				break;
			case 'p':
				strcpy(dest_path, optarg);
				break;
			case -1:
				go=0;
				break;
			case 'h':
			default:
				go=0;
				usage(argv[0]);
				return(0);
				break;
		}
	}

	fprintf(stderr, "Creating shadow (max %dMB) to %s...\n", 
			media_size, dest_path);
	make_backup(backup_id, media_size, dest_path);

	return(1);
}

/*
 *			sprintf(query, "SELECT file_id, file_name, file_size
 *									file_uldate, file_description
 *
 */
int output_formatted_row(FILE *dp, MYSQL_ROW sql_row)
{
	int kilobytes,i=0,c=0;
	char kbs_string[20];

	kilobytes=atoi(sql_row[2])/1000;
	if(kilobytes<1000)
		sprintf(kbs_string, "%dk", kilobytes);
	else
	{	
		kilobytes=kilobytes/1000;
		sprintf(kbs_string, "%3dM", kilobytes);
	}

	sql_row[3][4]=0;			// To display date in euro format DD-MM-YYYY
	sql_row[3][7]=0;
					
	fprintf(dp, "%-19.19s %4.4s %2.2s-%2.2s-%4.4s ",
				sql_row[1], kbs_string, 
				&sql_row[3][8], &sql_row[3][5], sql_row[3]);

	while(sql_row[4][i])
	{
		if(sql_row[4][i]=='\n' || c==45)
		{	
			fprintf(dp,"\n                                    ");
			c=0;
		}
		if(sql_row[4][i]!='\n')
			fputc(sql_row[4][i], dp);
		i++;c++;
	}
	fprintf(dp, "\n");
	
	return(1);
}
	
