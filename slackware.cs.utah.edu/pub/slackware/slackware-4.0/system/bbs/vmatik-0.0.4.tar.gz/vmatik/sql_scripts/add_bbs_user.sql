USE mysql;
INSERT INTO user (Host, User, Select_priv, Insert_priv,
				Update_priv,Delete_priv,Create_priv,Drop_priv) VALUES 
				("localhost", "bbs", 'Y', 'Y',
				'Y','Y','Y','Y');
INSERT INTO db (Host, Db,User,Select_priv, Insert_priv,
				Update_priv,Delete_priv,Create_priv,Drop_priv) VALUES
				("%", "vmatik", "bbs", 'Y','Y',
				'Y','Y','Y','Y');
