/*
 *
 * Converts filenames of entire filebase to lowercase
 *
 */

#include "proto.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

char *str2lc(char *src)
{
	char *temp=src;

	if(!temp)
		return(0);
	
	while(*temp)
	{
		*temp=tolower(*temp);
		temp++;
	}

	return(src);
}

int main()
{
	MYSQL db;
	MYSQL_RES *sql_result;
	MYSQL_ROW sql_row;
	char query[QUERY_MAX];
	char newname[QUERY_MAX];

	mysql_connect(&db, NULL, "bbs", NULL);
	if(mysql_error(&db)[0])
	{
		printf("%s\n", mysql_error(&db));
		return(0);
	}
	mysql_select_db(&db, "vmatik");
	if(mysql_error(&db)[0])
	{
		printf("%s\n", mysql_error(&db));
		mysql_close(&db);
		return(0);
	}

	mysql_query(&db, "SELECT file_id, file_name FROM vmatik_filelist");
	sql_result=mysql_store_result(&db);
	if(sql_result)
	{
		while((sql_row=mysql_fetch_row(sql_result)))
		{
			str2lc(sql_row[1]);
			mysql_escape_string(newname, sql_row[1], strlen(sql_row[1]));
		
			sprintf(query, "UPDATE vmatik_filelist 
							SET file_name='%s'
							WHERE file_id=%s",
							newname, sql_row[0]);
			mysql_query(&db, query);
		}
		mysql_free_result(sql_result);
	}

	mysql_close(&db);
	
	return(1);
}
	
