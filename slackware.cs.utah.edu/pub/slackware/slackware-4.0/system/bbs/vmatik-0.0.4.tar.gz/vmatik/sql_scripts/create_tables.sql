# MySQL dump 5.10
#
# Host: localhost    Database: vmatik
#--------------------------------------------------------
# Server version	3.22.14-gamma

USE vmatik;

#
# Table structure for table 'vmatik_fileareas'
#
CREATE TABLE vmatik_fileareas (
  area_id mediumint(8) unsigned DEFAULT '0' NOT NULL auto_increment,
  area_name varchar(50) DEFAULT '' NOT NULL,
  area_filepath varchar(255) DEFAULT '' NOT NULL,
  area_access int(10) unsigned DEFAULT '0' NOT NULL,
  area_flags int(10) unsigned DEFAULT '0' NOT NULL,
  area_newestfile datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
  area_lasttouch datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
  area_displayat mediumint(8) unsigned DEFAULT '0' NOT NULL,
  area_conf smallint(5) unsigned DEFAULT '0' NOT NULL,
  area_ul_redir mediumint(8) unsigned DEFAULT '0' NOT NULL,
  area_sortorder tinyint(3) unsigned DEFAULT '1' NOT NULL,
  PRIMARY KEY (area_id),
  UNIQUE unique_path (area_filepath)
);

#
# Table structure for table 'vmatik_filelist'
#
CREATE TABLE vmatik_filelist (
  file_id int(10) unsigned DEFAULT '0' NOT NULL auto_increment,
  file_name varchar(255) DEFAULT '' NOT NULL,
  file_size int(10) unsigned DEFAULT '0' NOT NULL,
  file_byid mediumint(8) unsigned DEFAULT '0' NOT NULL,
  file_toid mediumint(8) unsigned DEFAULT '0' NOT NULL,
  file_area mediumint(8) unsigned DEFAULT '0' NOT NULL,
  file_downloads smallint(5) unsigned DEFAULT '0' NOT NULL,
  file_flags int(10) unsigned DEFAULT '0' NOT NULL,
  file_integrity tinyint(4) DEFAULT '0' NOT NULL,
  file_uldate datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
  file_dldate datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
  file_bytes2uler int(10) unsigned DEFAULT '0' NOT NULL,
  file_files2uler tinyint(3) unsigned DEFAULT '0' NOT NULL,
  file_backup smallint(5) unsigned DEFAULT '0' NOT NULL,
  file_description text NOT NULL,
  PRIMARY KEY (file_id),
  KEY index_file_name (file_name),
  KEY index_file_area (file_area),
  KEY index_file_uldate (file_uldate)
);

#
# Table structure for table 'vmatik_flagged'
#
CREATE TABLE vmatik_flagged (
  flagged_id int(10) unsigned DEFAULT '0' NOT NULL,
  flagged_user mediumint(8) unsigned DEFAULT '0' NOT NULL,
  flagged_dled tinyint(4) DEFAULT '0' NOT NULL,
  PRIMARY KEY (flagged_id,flagged_user)
);

#
# Table structure for table 'vmatik_lrp'
#
CREATE TABLE vmatik_lrp (
  lrp_user mediumint(8) unsigned DEFAULT '0' NOT NULL,
  lrp_area mediumint(8) unsigned DEFAULT '0' NOT NULL,
  lrp_conf smallint(5) unsigned DEFAULT '0' NOT NULL,
  lrp_read smallint(5) unsigned DEFAULT '0' NOT NULL,
  lrp_scan smallint(5) unsigned DEFAULT '0' NOT NULL,
  PRIMARY KEY (lrp_user,lrp_area,lrp_conf)
);

#
# Table structure for table 'vmatik_msgareas'
#
CREATE TABLE vmatik_msgareas (
  base_id mediumint(8) unsigned DEFAULT '0' NOT NULL auto_increment,
  base_conf smallint(5) unsigned DEFAULT '0' NOT NULL,
  base_name varchar(21) DEFAULT '' NOT NULL,
  base_lowest smallint(5) unsigned DEFAULT '0' NOT NULL,
  base_highest smallint(5) unsigned DEFAULT '0' NOT NULL,
  base_msglimit smallint(5) unsigned DEFAULT '0' NOT NULL,
  base_fn_tag varchar(26) DEFAULT '' NOT NULL,
  base_fn_origin varchar(58) DEFAULT '' NOT NULL,
  base_fn_flags tinyint(4) DEFAULT '0' NOT NULL,
  base_fn_zone smallint(5) unsigned DEFAULT '0' NOT NULL,
  base_fn_net smallint(5) unsigned DEFAULT '0' NOT NULL,
  base_fn_node smallint(5) unsigned DEFAULT '0' NOT NULL,
  base_fn_point smallint(5) unsigned DEFAULT '0' NOT NULL,
  base_read_acc int(10) unsigned DEFAULT '0' NOT NULL,
  base_write_acc int(10) unsigned DEFAULT '0' NOT NULL,
  PRIMARY KEY (base_id)
);

#
# Table structure for table 'vmatik_order'
#
CREATE TABLE vmatik_order (
  order_user mediumint(8) unsigned DEFAULT '0' NOT NULL,
  order_area mediumint(8) unsigned DEFAULT '0' NOT NULL,
  order_type tinyint(3) unsigned DEFAULT '0' NOT NULL,
  PRIMARY KEY (order_user,order_area)
);

#
# Table structure for table 'vmatik_precalc'
#
CREATE TABLE vmatik_precalc (
  precalc_user int(10) unsigned DEFAULT '0' NOT NULL,
  precalc_area int(10) unsigned DEFAULT '0' NOT NULL,
  precalc_date timestamp(14),
  PRIMARY KEY (precalc_user,precalc_area)
);

#
# Table structure for table 'vmatik_state'
#
CREATE TABLE vmatik_state (
  state_name varchar(40) DEFAULT '' NOT NULL,
  state_value bigint(20) unsigned DEFAULT '0' NOT NULL,
  PRIMARY KEY (state_name)
);

#
# Table structure for table 'vmatik_user'
#
CREATE TABLE vmatik_user (
  user_id int(10) unsigned DEFAULT '0' NOT NULL auto_increment,
  user_name varchar(26) DEFAULT '' NOT NULL,
  user_handle varchar(26) DEFAULT '' NOT NULL,
  user_city varchar(21) DEFAULT '' NOT NULL,
  user_org varchar(26) DEFAULT '' NOT NULL,
  user_email varchar(40) DEFAULT '' NOT NULL,
  user_voicephone varchar(21) DEFAULT '' NOT NULL,
  user_dataphone varchar(21) DEFAULT '' NOT NULL,
  user_password varchar(16) binary DEFAULT '' NOT NULL,
  user_screenlength tinyint(3) unsigned DEFAULT '0' NOT NULL,
  user_protocol tinyint(3) unsigned DEFAULT '0' NOT NULL,
  user_toggles int(10) unsigned DEFAULT '0' NOT NULL,
  user_bytesup bigint(20) unsigned DEFAULT '0' NOT NULL,
  user_bytesup_bad bigint(20) unsigned DEFAULT '0' NOT NULL,
  user_bytesdn bigint(20) unsigned DEFAULT '0' NOT NULL,
  user_filesup mediumint(8) unsigned DEFAULT '0' NOT NULL,
  user_filesup_bad mediumint(8) unsigned DEFAULT '0' NOT NULL,
  user_filesdn mediumint(8) unsigned DEFAULT '0' NOT NULL,
  user_filecred mediumint(9) DEFAULT '0' NOT NULL,
  user_bytecred bigint(21) DEFAULT '0' NOT NULL,
  user_pubmessages smallint(5) unsigned DEFAULT '0' NOT NULL,
  user_prvmessages smallint(5) unsigned DEFAULT '0' NOT NULL,
  user_calls smallint(5) unsigned DEFAULT '0' NOT NULL,
  user_fileratio1 tinyint(3) unsigned DEFAULT '0' NOT NULL,
  user_byteratio1 tinyint(3) unsigned DEFAULT '0' NOT NULL,
  user_fileratio2 tinyint(3) unsigned DEFAULT '0' NOT NULL,
  user_byteratio2 tinyint(3) unsigned DEFAULT '0' NOT NULL,
  user_fileratio3 tinyint(3) unsigned DEFAULT '0' NOT NULL,
  user_byteratio3 tinyint(3) unsigned DEFAULT '0' NOT NULL,
  user_seclevel tinyint(3) unsigned DEFAULT '0' NOT NULL,
  user_secflags bigint(20) unsigned DEFAULT '0' NOT NULL,
  user_confacc bigint(20) unsigned DEFAULT '0' NOT NULL,
  user_timelimit smallint(5) unsigned DEFAULT '5' NOT NULL,
  user_timeremain smallint(5) unsigned DEFAULT '0' NOT NULL,
  user_defconf_id mediumint(8) unsigned DEFAULT '0' NOT NULL,
  user_defarea_id mediumint(8) unsigned DEFAULT '0' NOT NULL,
  user_firstcall datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
  user_lastcall datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
  PRIMARY KEY (user_id),
  KEY user_name (user_name),
  KEY user_handle (user_handle)
);

