/*
 * The "Bulletins" submenu handling
 *
 */
#include "proto.h"
#include <fcntl.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>

int bulletins(char *params)
{
	char bdir[200];
	char menunam[240];
	char bullb[500];
	char tbuf[400];
	char nbu[240];
	int first=0;
	int menfd;
	char *srcstrh;
	
	changenodestatus("Viewing bulletins");
	
	sprintf(bdir,"%sbulletins/",conf->CONF_PATH);
	sprintf(menunam,"%sbulletinmenu.%s",bdir,ansi ? "gfx" : "txt" );
	DDPut(menunam);

	menfd=open(menunam,O_RDONLY);
	if (menfd==-1) {
		sprintf(menunam,"%sbulletinmenu.%s",bdir,ansi ? "txt" : "gfx");
		DDPut(menunam);
		menfd=open(menunam,O_RDONLY);
		if (menfd==-1) {
			DDPut(sd[bunobullsstr]);
			return 0;
		}
	}
	close(menfd);
	srcstrh=params;
	
	while(1)
	{
		int bulnum;
		if (!(srcstrh=strspa(srcstrh,bullb))) {
			if (!first) TypeFile(menunam,TYPE_WARN);
			DDPut(sd[bumenustr]);
			*tbuf=0;
			if (!(Prompt(tbuf,60,0))) return 0;
			srcstrh=tbuf;
			srcstrh=strspa(srcstrh,bullb);
			if (!srcstrh) return 0;
		}
		first=1;
		if (*bullb=='q' || *bullb=='Q') return 0;
		if (*bullb=='l' || *bullb=='L' || *bullb=='?') {
			TypeFile(menunam,TYPE_WARN);
		} else if ((bulnum=atoi(bullb))) 
		{
			sprintf(nbu,"%sbulletin.%d.%s",bdir,bulnum,ansi ? "gfx" : "txt");
			writelog("Viewed ");
			writelog(nbu);
			writelog("\n");
			if (TypeFile(nbu,0)) {
				if (!(user.user_toggles & TOGGLE_EXPERT)) {
					DDPut(sd[pause2str]);
					HotKey(0);
				}
			}
			else
			{
				sprintf(nbu,"%sbulletin.%d.%s",
						bdir,bulnum,ansi ? "txt" : "gfx");
				if (TypeFile(nbu,TYPE_WARN)) 
				{
					if (!(user.user_toggles & TOGGLE_EXPERT)) 
					{
						DDPut(sd[pause2str]);
						HotKey(0);
					}
				}
			}
		}
	}
}
