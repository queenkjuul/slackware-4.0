/*
 * Displays version information.
 *
 */
#include "proto.h"
#include <sys/utsname.h>

void versioninfo(void)
{
	struct utsname pilu;
	char verbuf[500];

	uname(&pilu);
	sprintf(verbuf,"\n\033[0;33mVuohiMatik %s\n\n\033[0mRunning on %s/%s %s\n\n",versionstring,pilu.sysname,pilu.machine,pilu.release);
	DDPut(verbuf);

}
