/*
 * Hmm, this has something to do with the messagebases.
 * Don't execute yet, unless you know what you're doing.
 * I don't. =)
 *
 */

#include "../lib/ddlib.h"
#include <stdio.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include "struct.h"

int main(int argc, char *argv[])
{
	struct VMatik_Conference *confs;
	struct VMatik_Conference *conf;
	struct VMatik_MsgBase *base;
		
	confs=(struct VMatik_Conference *)VMatik_getconfdata();
	
	if (!confs) exit (0);
	conf=confs;

	while(1)
	{
		struct stat st;
		struct VMatik_Message msg;
		int bcnt;
		
		if (conf->CONF_NUMBER==255) break;
		
		(struct VMatik_Conference *)base=conf+1;
		bcnt=conf->CONF_MSGBASES;

		for(bcnt=conf->CONF_MSGBASES;bcnt;bcnt--,base++)
		{
			int basefd;
			struct VMatik_MsgPointers mp;
			
			char wubuf[1024];
			
			sprintf(wubuf,"%smessages/base%3.3d/msgbase.dat",conf->CONF_PATH,base->MSGBASE_NUMBER);			

			stat(wubuf,&st);
			if (st.st_size < sizeof(struct VMatik_Message)) continue;

			basefd=open(wubuf,O_RDONLY);
			if (basefd < 0) continue;
			
			read(basefd,&msg,sizeof(struct VMatik_Message));
			mp.msp_low=msg.MSG_NUMBER;
			lseek(basefd,-(sizeof(struct VMatik_Message)),SEEK_END);
			read(basefd,&msg,sizeof(struct VMatik_Message));
			mp.msp_high=msg.MSG_NUMBER;

			close(basefd);

			sprintf(wubuf,"%smessages/base%3.3d/msgbase.ptr",conf->CONF_PATH,base->MSGBASE_NUMBER);
			basefd=open(wubuf,O_WRONLY);
			if (basefd < 0) continue;
			write(basefd,&mp,sizeof(struct VMatik_MsgPointers));
			close(basefd);

		}
		(struct VMatik_MsgBase *)conf=base;
	}

	return(1);
}
