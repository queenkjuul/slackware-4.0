#include "../lib/ddlib.h"
#include <stdio.h>
#include <stdlib.h>

struct dif *d;

void main(int argc, char *argv[])
{
	struct VMatik_LRP lp;
	char buf[1024];
	
	if (argc==1) {
		printf("This program requires MS Windows!\n");
		exit(1);
	}
	d=VMatik_initdoor(argv[1]);
	if (d==0) {
		printf("Couldn't find socket!\n");
		exit(1);
	}
	VMatik_sendstring(d,"\n[35mWU-LRP! V1.0\n\n[0mGimme new lrp, nigga! (preferably 187!): [36m");
	VMatik_getlprs(d,&lp);
	sprintf(buf,"%d",lp.lrp_read);
	VMatik_prompt(d,buf,5,0);
	lp.lrp_read=atoi(buf);
	VMatik_setlprs(d,&lp);
	VMatik_sendstring(d,"[35m\nThank you for using WU-LRP! WU-Tang clan is nuthing to fuck w/!!!! <grin>\n");
	VMatik_close(d);
}
