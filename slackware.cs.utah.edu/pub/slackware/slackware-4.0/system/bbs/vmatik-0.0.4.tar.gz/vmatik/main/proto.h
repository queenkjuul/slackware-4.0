/*
 * Contains prototype definitions, extern variables
 *
 */

#ifndef VMATIK_PROTO_H
#define VMATIK_PROTO_H

#include <sys/types.h>
#include <stdio.h>
#include <time.h>
#include <signal.h>
#include <mysql.h>
#include <utmp.h>
#include "global.h"
#include "md5.h"
#include "strf.h"

#include "struct.h"
#include "config.h"

/*
 * Routine definitions
 *
 */

void dpause(void);
int dp_rundoor(char *, char *);
unsigned char HotKey(int);
void smallstatus(void);
int runstdio(char *, char *, int);
int newrename(char *, char *);
bint getfreesp(char *);
char *currt(void);
bint eb_getsec(MYSQL *db, int user_id);
int handlectrl(int);
int jc_changemsgbase(int, int);
void writelog(char *);
void changenodestatus(char *);
void DDPut(unsigned char *);
void LineChat(void);
int TypeFile(char *, int);
int Prompt(char *, int, int);
void StripAnsi(unsigned char *);
int iswilds(char *);
int mi_cmppasswds(char *, unsigned char *);
void carrieroff(int);
void clear(void);

// in archives.c

struct VMatik_Archiver *ar_getarchiver(char *wholename);
int ar_transform_archive(char *pathname, struct VMatik_Archiver *arc,
						char *new_name);
int ar_test_archive(char *pathname, struct VMatik_Archiver *arc);
int ar_viewfile(char *params);


// in areaedit.c
int ae_add_filearea(MYSQL *db);
int ae_move_filearea(MYSQL *db, char *params);

// in bgchecker.c
int bg_handledownload(MYSQL *db, char *filename, int fsize);
int bg_handleupload(MYSQL *db, char *upname);
pid_t bg_bgchecker(void);
int bg_checkfilename(char *name);
int bg_getdszstuff(char *logline, char *filename, int *fsize, int *cps);

// in enterbbs.c
int eb_enterbbs(void);
int eb_checkforftp(int mode, char *dp, char *log);

int domenu(int);
int st_userstats(int user_id);
int st_show_credits(int user_id);
void questionnaire(void);
void stripansi(char *);
void versioninfo(void);

// in main.c
int checkcarrier(void);
int ma_visitbbs(int m);

extern MYSQL vm_database;

// in newuser.c
struct VMatik_Seclevel *nu_setaccess(struct userbase *dst, int new_level);
int nu_ask_handle(char *handle, int size);
int nu_ask_name(char *name, int size);
int nu_ask_screenl(void);
int nu_create_account(MYSQL *db);
void nu_testscreenl(void);

// in domenu.c
int dm_makemainprompt(char *buf);

// in usered.c
int ue_set_secdata_to_db(struct userbase *luser);
int ue_parse_orders(char *orders);

// in editown.c
int eo_editown(int);
void eo_changesortorder(int neworder, int area_id);
char *strspa(char *, char *);
char *strspa_ext(char *, char *);

void userlist(MYSQL *db, char *);
char *nextword(char *);
int getnodeinfo(void);
void usered(void);

// in joinconf.c
struct VMatik_Conference *jc_findconf(int);
int jc_joinconf(int, int);
int jc_nextconf(void);
int jc_prevconf(void);
int jc_joinconfmenu(char *);
int jc_changefilearea(int newarea, int mode);
int jc_checkconfaccess(int confn, struct userbase *usa);
int jc_showfileareas(MYSQL *db, int mode);

// in entermsg.c

int entermsg(struct VMatik_Message *, int, char *);
int em_askqlines(void);
int em_getreplyid(int msg, char *de);

void getmsgptrs(void);
int setmsgptrs(void);
int readmessages (int, int);
int getfizesize(char *);
int replymessage(struct VMatik_Message *);
int lineed(char *, int, struct VMatik_Message *);
int cmbmenu(char *);
int nextbase(void);
int prevbase(void);
int pa_pagesysop(char *);
int globalread(void);
int isbasetagged(int, int);
int isanybasestagged(int);
int newcopy(char *old, char *new);

// in upload.c

int ul_upload(int);
int ul_getfreeulp(char *fi, char *gna, int mode);
void ul_cleandir(char *pathname);
int ul_freespace(char *path);
int ul_localupload(MYSQL *db, int area_id);
int ul_recfiles(char *rec_path, char *pathlist_fname);
int ul_gen_pathlist(char *filename);
int ul_add_file(MYSQL *db, struct FileType *new_file, int area_id);

// in filelist.c

int fl_browselist(char *params, struct SystemFunctions *func,
				  char *what_is_it, int mode, MYSQL *db);
int fl_killfile(MYSQL *db, MYSQL_ROW sql_row);
int fl_flagfile(MYSQL *db, MYSQL_ROW sql_row);
int fl_describefile(MYSQL *db, MYSQL_ROW sql_row);
int fl_describefile_bulk(MYSQL *db, MYSQL_ROW sql_row);
int fl_movefile(MYSQL *db, MYSQL_ROW sql_row);
int fl_show_verbose(MYSQL *db, MYSQL_ROW sql_row);
int fl_testfile(MYSQL *db, MYSQL_ROW sql_row);
int fl_touchfile(MYSQL *db, MYSQL_ROW sql_row);
int fl_transformfile(MYSQL *db, MYSQL_ROW sql_row);
int fl_validatefile(MYSQL *db, MYSQL_ROW sql_row);
int fl_viewfile(MYSQL *db, MYSQL_ROW sql_row);
int fl_init_describe_bulk(MYSQL *db);
int fl_init_kill(MYSQL *db);
int fl_exit_describe_bulk(MYSQL *db);
int fl_exit_move(MYSQL *db);
int fl_exit_touch(MYSQL *db);
int fl_init_move(MYSQL *db);
int fl_touch_currentarea(MYSQL *db);
int fl_filelist(struct SystemFunctions *func, char *where, 
				struct List *itemrange, char *what_is_it, int mode, MYSQL *db);
int fl_parsearg_newscan(void);
int fl_parsearg_zippy(void);
int fl_parseareas(void);
int fl_display_normal(char *display, char *filename, struct cursordat *cdat,
struct cursordat *currc);
int fl_display_ask(char *display, char *filename, struct cursordat *cdat,
struct cursordat *currc);
int fl_display_dummy(char *display, char *filename, struct cursordat *cdat,
struct cursordat *currc);
int fl_globalnewscan(void);
int fl_makeprec(MYSQL *db, int area_id);
int fl_free_precalcs(MYSQL *db, int user_id);
int fl_touch_filearea(MYSQL *db, int area_id);

void multibackspace(int bscnt);
int ms_scanfornewmail(void);
void strcupr(char *, char *);
int mktempdir(void);
int getdisplaymode(char *, int);
int syspw(void);

// in main.c
int ma_dropcarrier(void);
int ma_install_conferences(char *filename);

// in misc.c

int mi_add_user(MYSQL *db, struct userbase *to_save);
int mi_is_range(char *string);
struct List *mi_make_range(char *string);
ULONG mi_range2long(struct List *range);
void mi_strcupr_skip1null(char *dest, char *src);
int mi_isonline(int id);
int mi_isonck(int num, int id);
char *mi_nextword(char *string);
int mi_wildcmp(char *, char *);
int mi_loaduser(int serial_id, struct userbase *to_load);
char *mi_filepart(char *path);
int mi_loadflaglist(void);
int mi_saveflaglist(void);
void mi_strupr(char *string);
void mi_strlwr(char *string);
int mi_sql_getstr(MYSQL *db, char *column, char *tables, char *where,
				char *result);
int mi_sql_setstr(MYSQL *db, char *column, char *table, char *where,
				char *to_set);
ULONG mi_sql_getnum(MYSQL *db, char *column, char *tables, char *where);
int mi_sql_setval(MYSQL *db, char *column, char *table, char *where,
				char rel_type, ULONG rel_value);
ULONG mi_sql_getuser(MYSQL *db, char *column, int user_id);
int mi_sql_setuser(MYSQL *db, char *column, int user_id, char rel_type,
				ULONG value);
bint mi_sql_getuserb(MYSQL *db, char *column, int user_id);
int mi_correct_path(char *path);
struct VMatik_Seclevel *mi_findsecdata(int sec_level);
int mi_long2ascii_range(ULONG input_val, char *outbuf);
int mi_runlogoffbatch(void);
bint mi_atob(char *str);
ULONG mi_findusername(char *name);
int mi_checklogon(char *name);
int mi_dumpuser(char *params);
int mi_ask_user_reload(char *params);
int mi_wild2sql(char *sqlstring, char *wildstring);

void removespaces(char *);
int docmd(char *, int);
int processmsg(struct VMatik_nodemessage *);
void Remove(struct Node *);
int getfreetnode(char *mytty);
int getfreelnode(void);
int isnode(int, struct VMatik_NodeInfo *);
int setprotocol(void);

// in doorport.c 
int dp_rundoorbatch(char *batch, char *fn);

int checkforpartialuploads(int);
int copypartial(void);
int dm_isaccess(bint flag, bint access);
int logoff(char *);

// in download.c
int dl_download(char *params, int mode);
void dl_killflood(void);
int dl_freebstr(char *db);
int dl_freefstr(char *db);
int dl_sendfiles(char *list, char *skiplist, char *lastf);

int bulletins(char *);
int comment(void);
int tagmessageareas(void);
int tagconfs(void);
int prevconf(void);
void who(void);
int ol_olmsg(char *params);
int ol_send_defined(int dnode, struct VMatik_nodemessage *msg);
int ol_privateolm(int dnode, int receiver_id, char *msg);
int isconftagged(int);
int ue_seceditor(struct userbase *euser);
int genstdiocmdline(char *dest, char *src, char *arg1, char *arg2, 
					char *arg3, char *arg4, char *no);

// in tagedit.c
int te_findfilestolist(char *file, char *dna);
int te_flagfile(char *file, int mode);
int te_flagsingle(struct FileType *entry, char *filename, int res);
int te_isfiletagged(char *fn);
int te_unflagfile(char *filename);
int te_taged(MYSQL *db, char *params, int mode);
int te_listflagged(MYSQL *db);
int te_clearflagged(MYSQL *db, int user_id);
void te_recountfiles(void);

// in unix.c
int un_getcmdline(int args, char *argi[]);
void un_sigpipe_handler(int value);
void un_sigint_handler(int value);

// in who.c
int wh_ispid(pid_t pid);

int fileattach(void);
int edfile(char *, int , struct VMatik_Message *);
int getfidounique(void);
void deldir(char *);
int getfilesize(char *);
int editmsg(int);
int editmsghdr(int);
int strlena(char *);
int editfile (char *);
int fsed(char *, int, struct VMatik_Message *);
int autodisconnect(void);
int getpath(struct VMatik_Conference *, char *, int);
int findfile(char *, char *, struct VMatik_Conference *);
int estimsecs(int);
int flagres(int , char *, int);
int makepartial(char *);
int who_show(struct VMatik_Node *, int);
int di_changemode(int mode);
int largestmode(void);
int di_loadstrings(int fi);
int lscpy(char *, char *);
int olmall(int, char *);
int lineolm(int, char *);
int sendtosock(int, struct VMatik_nodemessage *);
int bigolm(int, int, char *);
int ltosdesc(char *, char *);
int stoldesc(char *, char *);
int initterm(void);

// in lists.c
struct List *NewList(void);
void AddTail(struct List *, struct Node *);
void AddHead(struct List *, struct Node *);
void Remove(struct Node *myn);
struct Node *RemTail(struct List *myl);
int ClearList(struct List *myl);
struct List *CopyList(struct List *myl);

char *fgetsnolf(char *, int, FILE *);
void MD5Init (MD5_CTX *);                                        /* context */
void MD5Update (MD5_CTX *, unsigned char *,unsigned int);
void MD5Final (unsigned char[16],MD5_CTX *);

/*
Global Variables
*/

extern int   bgmode;
extern int   dsockfd;
extern int   conin;
extern int   conout;
extern int   serhandle;
extern int   node;
extern char  keysrc;
extern int   ansi;
extern int   carrier;
extern int   conon;
extern int   timeleft;
extern time_t endtime;
extern int   bpsrate;
extern int   highest;
extern int   lowest;
extern int   bgdone;
extern char  remotehost[UT_HOSTSIZE];

extern struct List *confs;
extern int Current_FileAreaID;
extern int Current_FileAreaNumber;

extern struct VMatik_MainConfig maincfg;
extern struct VMatik_Conference *conf;
extern struct VMatik_MsgBase *base;
extern struct VMatik_DisplayMode *displays;
extern struct VMatik_DisplayMode *display;
extern struct VMatik_Seclevel *secs;
extern struct VMatik_Archiver *arcs;
extern struct VMatik_Node *nodes;
extern struct VMatik_Node *currnode;
extern struct VMatik_Protocol *protocols;
extern struct VMatik_Protocol *protocol;
extern struct callerslog clog;
extern char reason[100];
extern int pages;
extern bint access_flags;
extern int onlinestat;
extern int userinput;
extern struct VMatik_ExternalCommand *exts;
extern int delayt;
extern struct userbase user;
extern int pageflag;
extern time_t last;
extern int bytestagged, fbytestagged;
extern UWORD filestagged, ffilestagged;
extern char origdir[PATH_MAX];
extern char wrapbuf[80];
extern unsigned char inconvtab[256];
extern unsigned char outconvtab[256];
extern char *sd[MAXSTRS];
extern struct List *olms;
extern struct List *SelectList;

#define MD_CTX MD5_CTX
#define MDInit MD5Init
#define MDUpdate MD5Update
#define MDFinal MD5Final

#endif
