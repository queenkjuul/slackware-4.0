/*
 * Really small lib test thingy for debugging ... :) 
 *
 */

#include <stdio.h>

#include "ddlib.h"

struct dif *d;

void main(int argc, char *argv[])
{
	if (argc==1) {
		printf("This program requires Microsoft Windows!\n");
		exit(1);
	}
	d=VMatik_initdoor(argv[1]);
	if (d==0) {
		printf("Couldn't find socket!\n");
		exit(1);
	}
	sleep(2);
	
	VMatik_sendstring(d,"Olet SILM�!!!!!!\n");
	VMatik_close(d);
}
