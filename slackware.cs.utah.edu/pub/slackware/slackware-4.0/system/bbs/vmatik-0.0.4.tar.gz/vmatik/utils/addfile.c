/* 
 * Quick hack to add a file to the system. Note that most of the 
 * file datas will be invalid!
 *
 */

#include <mysql.h>
#include <stdio.h>
#include "proto.h"
#include "struct.h"

int main(int argc, char *argv[])
{
	char query[QUERY_MAX];
	MYSQL vm_database;
	
	if(argc!=4)
	{
		printf("Usage: %s <file_name> <file_area> <file_size>\n", argv[0]);
		return(0);
	}
	
	mysql_connect(&vm_database, NULL, "bbs", NULL);
	mysql_select_db(&vm_database, "vmatik");

	sprintf(query, "INSERT INTO vmatik_filelist (file_name, file_area, file_size, file_uldate)
					VALUES ('%s',%s,%s,NOW())", argv[1], argv[2], argv[3]);
	mysql_query(&vm_database, query);

	sprintf(query, "UPDATE vmatik_fileareas SET area_lasttouch=NOW()
					WHERE area_id=%s", argv[2]);
	mysql_query(&vm_database, query);
		
	mysql_close(&vm_database);
	
	return(0);
}


			
