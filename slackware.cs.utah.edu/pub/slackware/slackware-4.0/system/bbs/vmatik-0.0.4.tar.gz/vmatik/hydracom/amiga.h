/*
**	Amiga support module for HYDRA protocol sample implementation.
**
**	Written by	Olaf Barthel
**			Brabeckstrasse 35
**			D-30559 Hannover
**
**			eMail: olsen@sourcery.han.de
**
**	Freely distributable.
*/

#include <exec/libraries.h>

extern struct IOStdReq	*FileRequest,
			*RemoteRequest,
			*LocalRequest,
			*LogRequest;

extern VOID __stdargs	 ConPrintf(struct IOStdReq *,STRPTR,...);
extern VOID __stdargs	 ConPutc(struct IOStdReq *Request,UBYTE Char);
VOID			 ConPuts(struct IOStdReq *Request,STRPTR String);
extern VOID		 ConMove(struct IOStdReq *Request,LONG x,LONG y);
extern VOID		 ConClear(struct IOStdReq *Request);
extern int		 ConGetKey(VOID);
extern int		 ConScanKey(VOID);
