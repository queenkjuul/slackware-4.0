/* cgi-register.c */

/*
 * 03/11/1995 c.e. prelz
 * Copyright (C) 1995 c.e. prelz
 * Redistributable according to the GNU public licence Ver. 2
 *
 * CGI program to perform registration of new users. Called by
 * register.html. Simply appends a text line with the parameter data
 * that was received, either to the OK file or to the KO file, according
 * to a few simple tests.
 *
 * The form must include the field LOGINNAME, that is used to check if
 * the user is acceptable. Also, all fields in array req_fields need to be present
 * and not null.
 *
 * $Log: cgi-register.c,v $
 * Revision 1.1  1995/11/03  15:36:24  karl
 * Initial revision
 *
 */

static unsigned char rcsid[]={"$Id: cgi-register.c,v 1.1 1995/11/03 15:36:24 karl Exp $"};

#define OK_FILE "/etc/bbs/OK"
#define KO_FILE "/etc/bbs/KO"
#define SEPARATOR "#"

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <pwd.h>
#include <sys/types.h>

static char *req_fields[]={"PASSWORD","FULLNAME","ADDRESS","TELNO",NULL};
static char *err_desc[]={"LOGINNAME not in form","Empty LOGINNAME",
			 "LOGINNAME already in use","Required field not defined",
			 "Empty required field"}; 

void *safalloc(int howmany);
void *safrealloc(void *ptr,int howmany);
void chop(char *bfr);
void reconvert(unsigned char *in);
int get_args(unsigned char *argbfr,unsigned char ***array);
char *strtokk(char *ptr1,char *ptr2);
void errpage(const unsigned char *text);

void main(int argc,char *argv[])
{
  int i,j,k,n_largs,err=0;
  unsigned char *in_line,**largs,bfr[1024],*ptr,user[256];
  struct passwd *pwdp;
  FILE *fop;
  
/*
 * Here we get the arguments that were passed by the html page
 */
  
  if((ptr=getenv("CONTENT_LENGTH"))==NULL || sscanf(ptr,"%d",&i)<1 | i<=0)
  {
    errpage("<h1>Missing input data!!!</h1>");
    exit(1);
  }
  
  in_line=safalloc(i+2);
  fgets(in_line,i+1,stdin);
  in_line[i+1]='\0';
  n_largs=get_args(in_line,&largs);
  free(in_line);

/*
 * Search for the LOGINNAME field: it must not be there already
 */

  strcpy(bfr,"LOGINNAME=");
  for(i=0;i<n_largs;i++)
    if(!strncmp(largs[i],bfr,strlen(bfr)))
      break; /* found */

  if(i>=n_largs)
  {
    errpage("<h1>Field <strong>LOGINNAME</strong> not defined</h1>");
    err=1;
  }
  else
  {
    ptr=largs[i]+strlen(bfr); /* points to beginning of name */
    for(j=strlen(ptr)-1;ptr[j]==' ' && j>=0;j--)
      ptr[j]='\0'; /* remove trailing spaces */
    if(!strlen(ptr)) /* no name inserted */
    {
      errpage("<h1>You <strong>must</strong> insert a login name!</h1>");
      err=2;
    }
    else if((pwdp=getpwnam(ptr))!=NULL) /* name already there */
    {
      sprintf(bfr,"<h2>Name <i>%s</i> is already in use on this system!<p>Please retry.</h2>",
	      ptr);
      errpage(bfr);
      err=3;
    }
    else
      strcpy(user,ptr);
  }
    
  if(!err)
    for(i=0;req_fields[i]!=NULL;i++)
    {
      strcpy(bfr,req_fields[i]);
      strcat(bfr,"=");
      
      for(j=0;j<n_largs;j++)
	if(!strncmp(largs[j],bfr,strlen(bfr)))
	  break; /* found */
      if(j>=n_largs)
      {
	sprintf(bfr,"<h1>Field <strong>%s</strong> not defined</h1>",req_fields[i]);
	errpage(bfr);
	err=4;
      }
      else
      {
	ptr=largs[j]+strlen(bfr); /* points to beginning of name */
	for(k=strlen(ptr)-1;ptr[k]==' ' && k>=0;k--)
	  ptr[k]='\0'; /* remove trailing spaces */
	if(!strlen(ptr)) /* no name inserted */
	{
	  sprintf(bfr,"<h1>You <strong>must</strong> insert data in field <i>%s</i> !</h1>",
		  req_fields[i]);
	  errpage(bfr);
	  err=5;
	}
      }
    }

/*
 * prepare the string with info data
 */

  bfr[0]='\0';
  for(i=0;i<n_largs;i++)
  {
    if(i)
      strcat(bfr,SEPARATOR);
    strcat(bfr,largs[i]);
  }

  if(err)
  {
    if((fop=fopen(KO_FILE,"a"))==NULL)
    {
      sprintf(bfr,"<h1>Could not open file <i>%s</i> (error: <code>%s</code>)</h1>",
	      KO_FILE,strerror(errno));
      errpage(bfr);
    }
    else
    {
      fprintf(fop,"%s%s%s\n",err_desc[err-1],SEPARATOR,bfr);
      fclose(fop);
    }
  }
  else
  {
    if((fop=fopen(OK_FILE,"a"))==NULL)
    {
      sprintf(bfr,"<h1>Could not open file <i>%s</i> (error: <code>%s</code>)</h1>",
	      OK_FILE,strerror(errno));
      errpage(bfr);
    }
    else
    {
      fprintf(fop,"%s\n",bfr);
      fclose(fop);
    }

/*
 * This page tells the user that her request passed the first test
 */
    
    printf("Content-type: text/html\n\n");
    printf("<html><head><title>Data OK</title></head>\n");
    printf("<body>\n");
    printf("Your request to add user <strong>%s</strong> was found valid. Your personal login will be activated in a few days.<br><hr><br><h1>Thanks!</h1></body>\n",
	   user);
  }  
}


void *safalloc(int howmany)
{
  void *ptr;

  if(!howmany)
  {
    fprintf(stderr,"ERROR!!! Zero-length alloc req.\n");
    exit(1);
  }

  if((ptr=(void *)malloc(howmany))==NULL)
  {
    perror("safalloc");
    exit(1);
  }
  return ptr;
}

void *safrealloc(void *ptr,int howmany)
{
  void *lptr;

  if(ptr==NULL)
    return safalloc(howmany);

  if((lptr=(void *)realloc(ptr,howmany))==NULL)
  {
    perror("safrealloc");
    exit(1);
  }
  return lptr;
}

void chop(char *bfr)
{
  char *ptr;
  
  if((ptr=strrchr(bfr,'\n'))!=NULL)
    *ptr='\0';
}

void reconvert(unsigned char *in)
{
  int i;
  unsigned char *ptr=in,chr[3];

  while((ptr=strchr(ptr,'+'))!=NULL)
    *ptr=' ';
  ptr=in;
  
  chr[2]='\0';
  while((ptr=strchr(ptr,'%'))!=NULL)
  {
    strncpy(chr,ptr+1,2);
    sscanf(chr,"%x",&i);
    *ptr=(unsigned char)i;
    i=strlen(ptr+3)+1;
    memmove(ptr+1,ptr+3,i);
  }
}

int get_args(unsigned char *argbfr,unsigned char ***array)
{
  int n_args=0;
  unsigned char *ptr,*ptr2;

  (*array)=NULL;

  ptr=argbfr;
  while(1)
  {
    if((ptr2=strchr(ptr,'&'))!=NULL)
      *ptr2='\0';
    
    reconvert(ptr);
    (*array)=safrealloc((*array),sizeof(unsigned char *)*(n_args+1));
    (*array)[n_args]=safalloc(strlen(ptr)+1);
    strcpy((*array)[n_args],ptr);
    n_args++;

    if(ptr2==NULL)
      break;
    ptr=ptr2+1;
  }
  return n_args;
}

void errpage(const unsigned char *text)
{
  printf("Content-type: text/html\n\n");
  printf("<html><head><title>Form processing error!</title></head>\n");
  printf("<body>\n%s\n</body>\n",text);
}
