/* ix/MBox definitions file (defs.h) */

/* You have no duty reading the following. There is no way improving anything
   by fiddling around with one of the defintions! */
  
#ifndef EXTERN
#define EXTERN extern
#endif

#ifndef UNSIGNED
#if !defined(_MINIX) || defined(_ESTDIO)
#define UNSIGNED unsigned
#else
#define UNSIGNED
#endif
#endif

#if defined(linux) && !defined(_LINUX)
#define _LINUX
#endif

/* --------------------------- HANDS OFF !!! ---------------------------- */

#include "proto.h"

#define STRING	     81
#define LSTRING	     STRING + 4
#define LONGSTRING  256
#define BS            8
#define CR           13
#define FF	     12
#define LF           10
#define TAB           9
#define BELL          7
#define DEL         127 
#define CTRL_X	     24
#define CTRL_E	      5
#define CTRL_Z       26
#define CTRL_D        4
#define ESC          27

#define ISO6429       5
#define INTEL_INSIDE  2

/*
#if defined(_SYS7) || defined(_SCO)
*/
#if defined(_SYS7)
#define ENTER        13
#else
#define ENTER        10
#endif

#define fix( II )  ( II / 100 )
#define flt( II )  ( II - (fix( II ) * 100 ))

#define MAKRO_MAX_REK 30

#define DEF_MAX_SCR_LINES 23

EXTERN int MAX_SCR_LINES;

EXTERN int OLDUID;
EXTERN int OLDGID;

EXTERN UNSIGNED char PROMPT[STRING];
EXTERN UNSIGNED char TERMINAL[STRING];

EXTERN UNSIGNED char EDDY[STRING];

EXTERN UNSIGNED char BRETT[STRING];
EXTERN UNSIGNED char INHALT[STRING];
EXTERN UNSIGNED char NG[STRING];

EXTERN UNSIGNED char UGROUPS[STRING];
EXTERN UNSIGNED char SGROUPS[STRING];
EXTERN UNSIGNED char MAKRO[STRING];

EXTERN UNSIGNED char MYNAME[STRING];

EXTERN long LASTLOG;
EXTERN int LASTTIME;
EXTERN int THISTIME;

EXTERN int IS_BUFFERED;

EXTERN int SHORT_HEADER;

EXTERN long IDX_SIZE;
EXTERN int  MBD_SIZE;

EXTERN struct userdaten {
	int id;
	UNSIGNED char name[31];
	UNSIGNED char passwort[11];
	UNSIGNED char sh_name[15];
	UNSIGNED char nick[31];
	UNSIGNED char wohnort[31];
	UNSIGNED char strasse[31];
	UNSIGNED char telefon1[31];
	UNSIGNED char telefon2[31];
	UNSIGNED char geburtsdatum[31];
        int terminal;
	int editor;
	int level;
        int bell;
	int prompt;
	int more;
	UNSIGNED char lastlog[11]; 
	int seq;
        int intro;
	int lasttime;
 	int lastmode;
	int leserichtung;
	int tlines;
	long upratio;
	long downratio;
	long elapsed;
	UNSIGNED char newsgrps[STRING];
	UNSIGNED char schluessel[STRING];
	UNSIGNED char abused[STRING];
	UNSIGNED char account[STRING]; 		
} USER;



#define MAX_BEF 160

EXTERN struct bef_struct {
	int id;
	int in;
 	int ex;
	int prototyp;
	UNSIGNED char befehl[(STRING/2)];
	UNSIGNED char pfad[STRING];
} BEF[MAX_BEF];


#define MAX_MAK 50

EXTERN struct mak_struct {
	UNSIGNED char makname[STRING];
	UNSIGNED char makwert[(STRING * 2)];
} MAK[MAX_MAK];


EXTERN struct teca_struct {
	UNSIGNED char entry[STRING];
	UNSIGNED char name[STRING];
	UNSIGNED char desc[STRING];
} TECA[4];


#define MAX_NEWSGRPS 300 

EXTERN UNSIGNED char newsgrp[MAX_NEWSGRPS][(STRING/3)];
EXTERN int newsgrpptr;

EXTERN int MAILOUT_LEV;
EXTERN int ADMIN_LEV;
EXTERN int WRITE_EX_LEV;
EXTERN int WRITE_IN_LEV;
EXTERN int WRITE_INTERNAT;
EXTERN int PD_D_LEV;
EXTERN int PD_U_LEV;
EXTERN int EXE_LEV; 
EXTERN int GUEST_LEV;

EXTERN UNSIGNED char CONSOLE_REDIRECT[STRING];

EXTERN int BB1;
EXTERN int BB2;
EXTERN int BB3;
EXTERN int BB4;
EXTERN int BB5;
EXTERN int BB6;
EXTERN int BB7;
EXTERN int BB8;
EXTERN int BB9;

EXTERN UNSIGNED char UUCPID[STRING];

EXTERN int BAUDRATE;

EXTERN int UMLAUT;

EXTERN int UMLAUT_MODUS;

EXTERN int ROT13_MODUS;

EXTERN int fetch_local;
EXTERN UNSIGNED char fetch_subj[STRING];

EXTERN int DISKUSSION;
EXTERN UNSIGNED char DIS_subject[STRING];

EXTERN int OFFERED_EDITORS;

EXTERN int TOUT_TIME;
EXTERN int TOUT_CALLS;

EXTERN UNSIGNED char BEFEHLE[STRING];
EXTERN UNSIGNED char HILFE[STRING];
EXTERN UNSIGNED char KURZHILFE[STRING];


EXTERN int IP_CAUSED_HUP;


EXTERN UNSIGNED char ORGANIZATION[STRING];
EXTERN UNSIGNED char SYSTEM[STRING];
EXTERN UNSIGNED char UUCPSITE[STRING];
EXTERN UNSIGNED char UUCPID2[STRING];
EXTERN UNSIGNED char UUCPID1[STRING];
EXTERN UNSIGNED char NAT_DOMAIN1[STRING];
EXTERN UNSIGNED char NAT_DOMAIN2[STRING];
EXTERN UNSIGNED char NAT_DOMAIN3[STRING];
EXTERN UNSIGNED char UUCPBANG[STRING];
EXTERN UNSIGNED char PHONE[STRING];
EXTERN UNSIGNED char LOCATION[STRING];
EXTERN UNSIGNED char SMARTHOST[STRING];
EXTERN UNSIGNED char NEWS_MINIMUM[STRING];
EXTERN UNSIGNED char NEWS_LEVEL1[STRING];
EXTERN UNSIGNED char PMS_TTY[STRING];
EXTERN UNSIGNED char GREP[STRING];
EXTERN UNSIGNED char UUX[STRING];
EXTERN UNSIGNED char TAR[STRING];
EXTERN UNSIGNED char SORTEDCUT[STRING];
EXTERN UNSIGNED char SECONDCUT[STRING];
EXTERN UNSIGNED char THIRDCUT[STRING];
EXTERN UNSIGNED char FOURTHCUT[STRING];
EXTERN int TARIF;
EXTERN int NZNT;
EXTERN int NZBT;
EXTERN int RZNT;
EXTERN int RZBT;
EXTERN int WZNT;
EXTERN int WZBT;
EXTERN UNSIGNED char REFLECT_NG[STRING];


EXTERN int DOWN_PROT;
EXTERN int DOWN_PACK;

EXTERN int G94ACTIVE;

EXTERN UNSIGNED char VAR_NAME[STRING];
EXTERN UNSIGNED char VAR_ME[STRING];

EXTERN int MENUE_USING;
EXTERN int MENUE_STAGE;
EXTERN int fido_fast;
EXTERN int fido_msg;

EXTERN int yet_adult;
EXTERN int adult_run;

#define MAX_AREACONT	20

EXTERN int USE_AREAS;
EXTERN UNSIGNED char AREA[STRING];
EXTERN UNSIGNED char AREACONT[MAX_AREACONT][STRING]; 

EXTERN UNSIGNED char frwd_host[STRING];
