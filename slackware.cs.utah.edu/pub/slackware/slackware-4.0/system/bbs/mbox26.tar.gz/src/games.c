/* ix/MBox (games.c) by Volker Schuermann, 04.12.1993

   This C source code contains the following functions:

   #GA games()            list and start games	

   Contact <volkers@unnet.wupper.de> for help! */










#include <stdio.h>
#include "mbox.h"

/* #GA - List and start a few boring games. */

games()
{
  FILE *fp;
  int i, c;

  UNSIGNED char s[STRING];
  UNSIGNED char GAME[MAX_GAMES][STRING];


  headline( GA01_MSG );
  printf("\n");


  fp = fopen(GAMES, "r");
  if (fp == NULL) {
	nerror("games.c", 19, "games", "Can't read", GAMES);
  }
  i = 0;
  while((fgets(s, STRING, fp) != NULL) && (s[0] != '='));
  while((i < MAX_GAMES) && (fscanf(fp, "%s %s", s, GAME[i]) > 0)){
	i++;
	printf("  %d - %s\n\n", i, s); 
  }
  fclose(fp);

  ansi2("md", 0, 0);
  printf("\n%s > ", GA02_MSG);
  ansi2("me", 0, 0);

  c = getint();
  if(c > 32) printf("%c", c);
  c -= 49;

  if((c >= 0) && (c < i)){
	printf("\n\n");
	sprintf(s, "%s %s %d %d", RSH, GAME[c], OLDUID, OLDGID);
	system(s);	
  }
  else{
	ansi2("md", 0, 0);
	printf(" %s\n", GA03_MSG);
	ansi2("me", 0, 0);
  }
}

