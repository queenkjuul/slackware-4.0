
/* ix/MBox (config.c) by Volker Schuermann, 07.07.1994 

   This C source code contains the following functions:

   #GC get_cfg()	  get BBS configuration     
   #WC write_cfg()	  write BBS configuration
   #CF configure()	  interactivly configure your BBS

   Contact <volkers@unnet.wupper.de> for help! */








#include <stdio.h>

#include "mbox.h"




UNSIGNED char *cfgr( fp )
FILE *fp;
{ 
  UNSIGNED char s[STRING];

  fgets(s, STRING, fp); fgets(s, STRING, fp);
  strcpy(s, (UNSIGNED char *) stripped( s ));

  return (UNSIGNED char *) s;
}


int get_cfg()
{
  UNSIGNED char s[STRING];
  FILE *fp;

  fp = fopen( MBOX_CFG, "r" );
  if(fp == NULL){
	return -1;
  }

  (void) cfgr( fp );

  strcpy(ORGANIZATION, cfgr( fp ));
  strcpy(SYSTEM, cfgr( fp ));
  strcpy(UUCPSITE, cfgr( fp ));
  strcpy(UUCPID2, cfgr( fp ));
  strcpy(UUCPID1, cfgr( fp ));
  strcpy(NAT_DOMAIN1, cfgr( fp ));
  strcpy(NAT_DOMAIN2, cfgr( fp ));
  strcpy(NAT_DOMAIN3, cfgr( fp ));
  strcpy(UUCPBANG, cfgr( fp ));
  strcpy(PHONE, cfgr( fp ));
  strcpy(LOCATION, cfgr( fp ));
  strcpy(SMARTHOST, cfgr( fp ));
  strcpy(NEWS_MINIMUM, cfgr( fp ));
  strcpy(PMS_TTY, cfgr( fp ));
  strcpy(GREP, cfgr( fp ));
  strcpy(UUX, cfgr( fp ));
  strcpy(TAR, cfgr( fp ));
  strcpy(SORTEDCUT, cfgr( fp ));
  strcpy(SECONDCUT, cfgr( fp ));
  strcpy(THIRDCUT, cfgr( fp ));
  strcpy(s, cfgr( fp )); TARIF = atoi( s );
  strcpy(s, cfgr( fp )); NZNT  = atoi( s ); 
  strcpy(s, cfgr( fp )); NZBT  = atoi( s );
  strcpy(s, cfgr( fp )); RZNT  = atoi( s );
  strcpy(s, cfgr( fp )); RZBT  = atoi( s );
  strcpy(s, cfgr( fp )); WZNT  = atoi( s );
  strcpy(s, cfgr( fp )); WZBT  = atoi( s );
  strcpy(REFLECT_NG, cfgr( fp ));
  strcpy(NEWS_LEVEL1, cfgr( fp ));

  fclose(fp);

  return 0;
}




void write_cfg()
{
  FILE *fp;

  fp = fopen( MBOX_CFG, "w" );
  if(fp == NULL){   
	printf("??? %s ???\n", MBOX_CFG);
  	exit(0);
  }
  fprintf(fp, "DO NOT TOUCH THIS - MEANS: HANDS OFF! (HAENDE WEG!!!)\n\n");
  fprintf(fp, "----------------------------------------->>  ORGANIZATION ():\n%s\n", ORGANIZATION);
  fprintf(fp, "----------------------------------------->>  SYSTEM ():\n%s\n", SYSTEM);
  fprintf(fp, "----------------------------------------->>  UUCPSITE ():\n%s\n", UUCPSITE);
  fprintf(fp, "----------------------------------------->>  UUCPID2 ():\n%s\n", UUCPID2);
  fprintf(fp, "----------------------------------------->>  UUCPID1 ():\n%s\n", UUCPID1);
  fprintf(fp, "----------------------------------------->>  NAT_DOMAIN1 ():\n%s\n", NAT_DOMAIN1);
  fprintf(fp, "----------------------------------------->>  NAT_DOMAIN2 ():\n%s\n", NAT_DOMAIN2);
  fprintf(fp, "----------------------------------------->>  NAT_DOMAIN3 ():\n%s\n", NAT_DOMAIN3);
  fprintf(fp, "----------------------------------------->>  UUCPBANG ():\n%s\n", UUCPBANG);
  fprintf(fp, "----------------------------------------->>  PHONE ():\n%s\n", PHONE); 
  fprintf(fp, "----------------------------------------->>  LOCATION ():\n%s\n", LOCATION);
  fprintf(fp, "----------------------------------------->>  SMARTHOST ():\n%s\n", SMARTHOST);
  fprintf(fp, "----------------------------------------->>  NEWS_MINIMUM ():\n%s\n", NEWS_MINIMUM);
  fprintf(fp, "----------------------------------------->>  PMS_TTY ():\n%s\n", PMS_TTY);
  fprintf(fp, "----------------------------------------->>  GREP ():\n%s\n", GREP);
  fprintf(fp, "----------------------------------------->>  UUX ():\n%s\n", UUX);
  fprintf(fp, "----------------------------------------->>  TAR ():\n%s\n", TAR);
  fprintf(fp, "----------------------------------------->>  SORTEDCUT ():\n%s\n", SORTEDCUT);
  fprintf(fp, "----------------------------------------->>  SECONDCUT ():\n%s\n", SECONDCUT);
  fprintf(fp, "----------------------------------------->>  THIRDCUT ():\n%s\n", THIRDCUT);
  fprintf(fp, "----------------------------------------->>  TARIF ():\n%d\n", TARIF);
  fprintf(fp, "----------------------------------------->>  NZNT ():\n%d\n", NZNT);
  fprintf(fp, "----------------------------------------->>  NZBT ():\n%d\n", NZBT);
  fprintf(fp, "----------------------------------------->>  RZNT ():\n%d\n", RZNT);
  fprintf(fp, "----------------------------------------->>  RZBT ():\n%d\n", RZBT);
  fprintf(fp, "----------------------------------------->>  WZNT ():\n%d\n", WZNT);
  fprintf(fp, "----------------------------------------->>  WZBT ():\n%d\n", WZBT);
  fprintf(fp, "----------------------------------------->>  REFLECT_NG ():\n%s\n", REFLECT_NG);
  fprintf(fp, "----------------------------------------->>  NEWS_LEVEL1 ():\n%s\n", NEWS_LEVEL1);

  fclose(fp);
}



void configure()
{
  UNSIGNED char s[STRING];
  int c;


  STARTUP:

  sprintf(s, " %s  [%s] ", CON01_MSG, SYSTEM );
  headline( s );

  printf("\n  1 - %s\n", CON02_MSG);
  printf("\n  2 - %s\n", CON03_MSG);
  printf("\n  3 - %s\n", CON04_MSG);
  printf("\n  4 - %s\n", CON05_MSG);  

  ansi2( "md", 0, 0 );
  printf("\n\n%s ", CON06_MSG);
  ansi2( "me", 0, 0 );

  c = getch();

  if((c < '1') || (c > '4')){
	printf("\n");
	write_cfg();
	return;
  }  

  sprintf(s, " %s  [%s] ", CON01_MSG, SYSTEM );
  headline( s );

  if(c == '1'){
	printf("\n%s", CON07_MSG );
	strcpy(ORGANIZATION, (UNSIGNED char *) getline( 58, 1011, '.', ORGANIZATION));
	printf("\n%s", CON08_MSG );
	strcpy(SYSTEM,       (UNSIGNED char *) getline( 58, 1011, '.', SYSTEM));
 	printf("\n%s", CON09_MSG ); 
    	strcpy(LOCATION,     (UNSIGNED char *) getline( 58, 1011, '.', LOCATION));
	printf("\n%s", CON10_MSG );
	strcpy(PHONE,        (UNSIGNED char *) getline( 58, 1011, '.', PHONE));
	printf("\n");
	printf("\n%s", CON11_MSG );
	strcpy(UUCPSITE,     (UNSIGNED char *) getline( 58, 1011, '.', UUCPSITE));
	printf("\n%s", CON12_MSG );
	strcpy(UUCPID1,	     (UNSIGNED char *) getline( 58, 1011, '.', UUCPID1));
	printf("\n%s", CON13_MSG );
	strcpy(UUCPID2,      (UNSIGNED char *) getline( 58, 1011, '.', UUCPID2));
	printf("\n%s", CON14_MSG );
	strcpy(UUCPBANG,     (UNSIGNED char *) getline( 58, 1011, '.', UUCPBANG));
	printf("\n")


;
  }
  if(c == '2'){
	printf("\n%s", CON15_MSG );
	strcpy(GREP,         (UNSIGNED char *) getline( 58, 1011, '.', GREP));
	printf("\n%s", CON16_MSG );
	strcpy(TAR,          (UNSIGNED char *) getline( 58, 1011, '.', TAR));
	printf("\n%s", CON17_MSG );
	strcpy(UUX,          (UNSIGNED char *) getline( 58, 1011, '.', UUX));
	printf("\n");
	printf("\n%s", "SORTEDCUT ->\n");
	strcpy(SORTEDCUT,    (UNSIGNED char *) getline( 79, 1011, '.', SORTEDCUT));
	printf("\n\n%s", "SECONDCUT ->\n");
	strcpy(SECONDCUT,    (UNSIGNED char *) getline( 79, 1011, '.', SECONDCUT));
	printf("\n\n%s", "THIRDCUT ->\n");
	strcpy(THIRDCUT,     (UNSIGNED char *) getline( 79, 1011, '.', THIRDCUT));
 	printf("\n"); 
  }
  if(c == '3'){
	printf("\n%s", CON18_MSG );
	strcpy(SMARTHOST,    (UNSIGNED char *) getline( 58, 1011, '.', SMARTHOST));
	printf("\n");
	printf("\n%s", CON19_MSG );
	strcpy(PMS_TTY,      (UNSIGNED char *) getline( 58, 1011, '.', PMS_TTY));
	printf("\n");
	printf("\n%s", CON20_MSG );
	strcpy(NEWS_MINIMUM, (UNSIGNED char *) getline( 58, 1011, '.', NEWS_MINIMUM));
	printf("\n");
	printf("\n%s", CON20aMSG );
	strcpy(NEWS_LEVEL1, (UNSIGNED char *) getline( 58, 1011, '.', NEWS_LEVEL1));
	printf("\n");
	printf("\n%s", CON21_MSG ); 
	strcpy(REFLECT_NG,   (UNSIGNED char *) getline( 58, 1011, '.', REFLECT_NG));
	printf("\n");
  }
  if(c == '4'){
	printf("\n%s", CON22_MSG );
	sprintf(s, "%d", TARIF);
	strcpy(s, (UNSIGNED char *) getline(10, 1110, '.', s ));
	TARIF = atoi(s);

	printf("\n");

	printf("\n%s", CON23_MSG );	
	sprintf(s, "%d", NZNT);
	strcpy(s, (UNSIGNED char *) getline(10, 1110, '.', s ));
	NZNT = atoi(s);	
	printf("\n%s", CON24_MSG );	
	sprintf(s, "%d", NZBT);
	strcpy(s, (UNSIGNED char *) getline(10, 1110, '.', s ));
	NZBT = atoi(s);	
	printf("\n%s", CON25_MSG );	
	sprintf(s, "%d", RZNT);
	strcpy(s, (UNSIGNED char *) getline(10, 1110, '.', s ));
	RZNT = atoi(s);	
	printf("\n%s", CON26_MSG );	
	sprintf(s, "%d", RZBT);
	strcpy(s, (UNSIGNED char *) getline(10, 1110, '.', s ));
	RZBT = atoi(s);	
	printf("\n%s", CON27_MSG );	
	sprintf(s, "%d", WZNT);
	strcpy(s, (UNSIGNED char *) getline(10, 1110, '.', s ));
	WZNT = atoi(s);	
	printf("\n%s", CON28_MSG );	
	sprintf(s, "%d", WZBT);
	strcpy(s, (UNSIGNED char *) getline(10, 1110, '.', s ));
	WZBT = atoi(s);	
  }

  goto STARTUP; 
}
