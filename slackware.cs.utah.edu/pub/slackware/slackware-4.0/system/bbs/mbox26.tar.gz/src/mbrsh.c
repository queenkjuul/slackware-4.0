/* ix/MBox (mbrsh.c) by Volker Schuermann, 04.12.1993

   This C source code contains the following functions:

   #MA main()          BBS shell which handles permissions properly

   Contact <volkers@unnet.wupper.de> for help! */







#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>

#ifndef _MINIX
#define UNSIGNED unsigned
#else
#define UNSIGNED
#endif

#define LONGSTRING 256

int main(argc, argv)
int argc;
UNSIGNED char *argv[];
{
  UNSIGNED char s[LONGSTRING];
  int i, j;

 
  setgid( atoi(argv[argc -1]) );
  setuid( atoi(argv[argc -2]) );

  strcpy(s, "exec ");
  j = argc -2;

  for(i = 1; i < j; i++){
	strcat(s, argv[i]);
	strcat(s, " ");
  }
  system( s );

  return 0;
}
