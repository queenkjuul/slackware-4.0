/* ix/MBox prototype file (proto.h) */

/* Some compilers might need this. 
   Mine doesn't, so this file isn't uptodate!!! */


#if defined(__STDC__) || defined(__cplusplus)
# define P_(s) s
#else
# define P_(s) ()
#endif

/*
#ifndef _MINIX
#define UNSIGNED unsigned
#else
#define UNSIGNED
#endif
*/

/* admin.c */
void user_aendern P_((void));
void user_anzeigen P_((void));
void user_loeschen P_((void));
int setup_get P_((int max));
void wait_until_keypressed P_((void));
void admin P_((void));
void setup P_((void));

/* befehl.c */
int bef P_((UNSIGNED char befehl[], UNSIGNED char arg[]));

/* baudrate.c */
int baudrate P_((int try));

/* control.c */
void control P_((UNSIGNED char text[], int mode));
void whodo P_((UNSIGNED char text[]));

/* coreleft.c */
int coreleft P_((void));

/* ctrlx.c */
void ctrlx P_((void));
void noctrlx P_((void));

/* derror.c */
void nerror P_((UNSIGNED char file[], int line, UNSIGNED char function[], UNSIGNED char descr[], UNSIGNED char er[]));

/* games.c */
int games P_((void));

/* getch.c */
int getch P_((void));

/* getline.c */
UNSIGNED char *getline P_((int len, int mode, int bsc, UNSIGNED char deftext[]));
int getint P_((void));
int yesno P_((void));

/* help.c */
int help P_((UNSIGNED char cmd[]));

/* intro.c */
void intro P_((int mode));
void init_user P_((UNSIGNED char info[], int mode));

/* lesen.c */
UNSIGNED char *getsite P_((UNSIGNED char arg[]));
int checkdomaintype P_((UNSIGNED char arg[]));
void ansage P_((void));
void unterschrift P_((void));
void lesen P_((UNSIGNED char arg[]));

/* lesen2.c */
int anzeigen P_((int art, int von, int bis));
void lesen2 P_((UNSIGNED char arg[], int mode));
void inhalt2 P_((UNSIGNED char arg[], int mode));
void loeschen2 P_((UNSIGNED char arg[], int mode));

/* loop.c */
void sigcatch P_((int sig));
UNSIGNED char *cut_bef P_((UNSIGNED char s[]));
UNSIGNED char *cut_arg P_((UNSIGNED char s[]));
UNSIGNED char *rates P_((void));
void loop P_((void));

/* mail.c */
UNSIGNED char *fetch_reciepy P_((UNSIGNED char REP[]));
int brief P_((UNSIGNED char arg[]));

/* main.c */
void logout P_((void));
void init P_((void));
void fixoutput P_((void));
/* int main P_((void)); */

/* makro.c */
UNSIGNED char *makro P_((UNSIGNED char s[]));
void set_makros P_((void));
void get_makros P_((void));
void add_makro P_((UNSIGNED char s[]));
int makro_definition P_((UNSIGNED char s[]));

/* mb-daemon.c */
int reflector P_((UNSIGNED char arg[], UNSIGNED char msg[]));
int pdsize P_((UNSIGNED char arg[]));
UNSIGNED char *scan P_((UNSIGNED char arg[]));
void mix P_((UNSIGNED char s[], UNSIGNED char t[]));
int main P_((int argc, UNSIGNED char *argv[]));

/* mbrsh.c */
int main P_((int argc, UNSIGNED char *argv[]));

/* misc.c */
void scanner P_((int mode));
void schreiben P_((UNSIGNED char arg[]));
int prf P_((UNSIGNED char arg[]));
int pruefe P_((UNSIGNED char arg[]));

/* misc2.c */
int chk_newsgrp P_((UNSIGNED char s[]));
int subb P_((UNSIGNED char s[]));
void loeschen P_((UNSIGNED char arg[]));
int brett P_((UNSIGNED char arg[]));

/* nerror.c */
void nerror P_((UNSIGNED char file[], int line, UNSIGNED char function[], UNSIGNED char descr[], UNSIGNED char er[]));

/* outdial.c */
void outdial P_((void));

/* pd.c */
void pd P_((UNSIGNED char arg[], UNSIGNED char keywds[]));
void status P_((void));
void mkix P_((UNSIGNED char pfad[]));
void statistik P_((void));
void download P_((UNSIGNED char arg[]));

/* portinfo.c */
void port P_((UNSIGNED char arg[]));
void show_level P_((UNSIGNED char arg[]));
void userliste P_((UNSIGNED char arg[]));
void finger P_((UNSIGNED char arg[]));

/* postfach.c */
void postfach P_((UNSIGNED char arg[]));

/* show.c */
int show P_((UNSIGNED char fname[], int maxlines, int mode));
int more P_((void));

/* suchen.c */
void suchen P_((UNSIGNED char muster[]));

/* tools.c */
UNSIGNED char *whoami P_((void));
UNSIGNED char *stripped P_((UNSIGNED char st[]));
UNSIGNED char *upcased P_((UNSIGNED char st[]));
int length P_((UNSIGNED char st[]));
UNSIGNED char *strcopy P_((UNSIGNED char st[], int v, int b));
UNSIGNED char *bigcopy P_((UNSIGNED char st[], int v, int b));
int strcomp P_((UNSIGNED char s[], UNSIGNED char t[]));
int ansi P_((UNSIGNED char code[]));
int ansi2 P_((UNSIGNED char code[], int x, int y));
/* UNSIGNED char *termansi P_((UNSIGNED char code[])); */
UNSIGNED char *mydate P_((int mode));
UNSIGNED char *mytime P_((int mode));
UNSIGNED char *crypted P_((UNSIGNED char s[]));
long dateconv P_((UNSIGNED char d[]));
UNSIGNED char *datereconv P_((long l));
int timeconv P_((UNSIGNED char t[]));
UNSIGNED char *timereconv P_((int i));
UNSIGNED char *shortname P_((UNSIGNED char longname[]));
int maybe_locked P_((UNSIGNED char name[], UNSIGNED char mode[]));
UNSIGNED char *numstripped P_((UNSIGNED char s[]));
void headline P_((UNSIGNED char line[]));
void mblock P_((UNSIGNED char path[]));
void mbunlock P_((UNSIGNED char path[]));
int tty P_((void));
UNSIGNED char *ttyna P_((void));
void clearline P_((void));
int isin P_((UNSIGNED char pattern[], int c)); 

/* weiterl.c */
void weiterleiten P_((UNSIGNED char arg[]));
void carboncopy P_((UNSIGNED char cc[], UNSIGNED char bcc[]));

/* xmd.c */
int brief P_((UNSIGNED char arg[]));
int mailing P_((void));
int main P_((int argc, UNSIGNED char *argv[]));

#undef P_



