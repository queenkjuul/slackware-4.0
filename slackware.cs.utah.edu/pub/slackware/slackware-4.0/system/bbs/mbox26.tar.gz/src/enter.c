#include <stdio.h>

#include "getch.c"

main( argc, argv )
int argc;
unsigned char *argv[];
{
  int c;

  printf("\nPress ENTER key, please ...");

  c = getch();

  if((c == 10) || (c == 13))
	 printf("\n\nFor [defs.h] use:\n\n#define ENTER     %d\n", c);

  printf("\n");
}
