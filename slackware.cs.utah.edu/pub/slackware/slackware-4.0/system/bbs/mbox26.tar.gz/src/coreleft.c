/* ix/MBox (coreleft.c) by Volker Schuermann, 04.12.1993

   This C source code contains the following functions:

   #CL coreleft()          find out how many memory is still available

   Contact <volkers@unnet.wupper.de> for help! */





#ifdef _SYS7
#include <stdlib.h>
#else
#include <stdio.h>
#include <malloc.h>
#endif

#include "mbox.h"


/* #CL - Keep track of remaining memory. */

int coreleft()
{
  UNSIGNED char *buffer;
  long size = 32L;

  do{
	size *= 2;
	buffer = malloc(size);
	if(buffer != NULL) free( buffer );
  }while(buffer != NULL);

  return (int) size;
}

