/* ix/MBox (derror.c) by Volker Schuermann, 04.12.1993

   This C source code contains the following functions:

   #NR nerror()           catching bugs (MB-DAEMON version of nerror())

   Contact <volkers@unnet.wupper.de> for help! */









#include <stdio.h>

#include "mbox.h"
#include "mbox.msg"


/* #NR - Catching bugs and doing the reporting.

   [file] tells in which file the error occured,
   [line] specifies the code line,
   [function] names the C function,
   [descr] contains a description and
   [er] gives further information. */

void nerror(file, line, function, descr, er)
unsigned char file[];
int line;
unsigned char function[], descr[], er[];
{
  FILE *fp;

  unsigned char s[STRING];

  printf("%c%s %s (%s) - %s \"%s\"\n", CR, DER01_MSG, function, file, descr, er);

  fp = fopen( MBD_ERROR, "a" );
  fprintf(fp, "[%s] %s, %d\n***** %s, %s, %s ... %s !!!",
	DER02_MSG, file, line, function, descr, er, DER03_MSG);
  fclose(fp); 
}


void g94()
{
  printf("Just a dummy!");
}
