/* ix/MBox patchlevel file (patchlevel.h) */

#define PATCHLEVEL	"PL5.1"

/* 

   New since PL10r (20.06.1993):

   intro.c
   mbox.h


   New since PL10r2 (27.06.1993):

   mbox.msg (deutsch, english, french)
   pd.c
   getline.c

  
   New since PL10r4 (17.07.1993):

   tools.c (Error report on STRINGLAENGENFEHLER)


   New since PL10r5 (19.07.1993):

   mbox.h, loop.c, uudecode.c (!)

   
   New since PL10r7 (01.08.1993):

   *.c, subscribe.c (!)


   New since PL11r1 (05.08.1993):

   *.c, SGROUPS

   
   New since PL11r5 (22.08.1993):

   misc2.c

   
   New since PL11r6 (24.10.1993):

   show.c, loop.c, subscribe.c, lesen2.c, ... ROT13 (!)


   New since PL11r7 (13.11.1993):

   show.c, wendy/rtf.c: bigcopy()

   
   New since PL11r8 (14.11.1993):

   getline.c, intro.c


   New since PL11r9 (15.11.1993):

   intro.c, pd.c

  
   New since PL12r2 (24.11.1993):

   intro.c, mail.c, smalltalk.c, smalltext.c ... LISA (!)

  
   New since PL12r3 (26.11.1993):

   dstock.c, weiterl.c ... BOERSE (!)


   New since PL12r4 (01.12.1993):

   xmd.c, misc.c

   
   New since PL12r5 (04.12.1993):

   *.c, *.h ... english versions allover (!)


   New since 2.0 PL10r3 (12.12.1993):

   subscribe.c, loop.c, uudecode.c ... PREVIEW (!)


   New since 2.0 PL10r4f (02.01.1994):

   uudecode.c ... ScreenScaver (for INTELs)


   New since 2.0 PL10r5 (03.01.1994):

   intro.c, admin.c ... additional terminals emulations (!)


   New since 2.0 PL10r5c (08.01.1994):

   loop.c, show.c, uudecode.c, portinfo.c, help.c ... ANSI logos f. IBM (!)


   New since 2.1 PL1r4 (30.01.1994):

   cdrom.c ... CDROM support (!)


   New since 2.1 PL1r5 (05.02.1994):

   uudecode.c ... automagically finding, sorting and uudecoding (!)


   New since 2.1 PL1r6 (12.02.1994):

   cdrom.c, misc2.c, lesen2.c, lesen.c ... CDROM included in BBS' filesystem (!)


   New since 2.1 PL10r5 (22.02.1994)

   mb-daemon.c ... works properly w/o flag '-x' (!) 

  
   New since 2.1 PL94(fz)3 (27.02.1994)

   *.c, *.* ... frozen for official LINUX support release in march '94 (!)


   New since 2.1 PL94(fz)4d (06.03.1994)

   First patches after delivering international release (!)
   Kent Landfield applied them before distributing the package ... thanx to him!


   New since 2.1 PL94(fz)4i (07.04.1994)

   uudecode.c ... made up to compile on SCO Unix (!)
   xmd.c ... works finally ok (!)


   New since 2.1 PL94.5 (25.04.1994)

   First patches posted to 'mboxpatch' (!)  


   New since 2.1 PL94.6 (01.05.1994)

   makro.c ...

  
   New since 2.1 PL94.7 (08.05.1994)

   loop.c ...


   New since 2.1 PL94.8 (12.05.1994)

   xmd.c ...


   New since 2.1 PL94.9 (15.05.1994)

   mb-daemon.c, loop.c, intro.c, ... level dep. timeouts (!)


   New since 2.2 PL0.1 (29.05.1994)

   uptodate.c ... weather report (!)


   New since 2.2 PL0.1i (05.06.1994)

   intermediate release ... distributed via mailing list (!)


   New since 2.2 PL5.8 (21.07.1994)

   g94.c ... first release with G94 support (!)


   New since 2.2 PL6.5 (10.09.1994)

   pd.c ... offer uploaded pd stuff immediately (!)


   New since 2.2 PL6.8 (01.10.1994)

   postfach.c, xmd.c, intro.c, show.c ... header problem and postfach problem fixed (!)

   
   New since 2.2 PL7.0 (01.11.1994)

   show.c ... implemented a simple HTML converter (!)


   New since 2.2 PL8.5i (07.01.1995)

   ip.c, suchen.c, uudecode.c, loop.c ... IP accounting, BINFILE security gap (!)


   New since 2.2 PL9.0i (06.02.1995)

   loop.c, intro.o, subscribe.c ... ONLINE (!) updating ONLINE (!) user immediately (!)


   New since 2.3 PL1.0i (08.02.1995)

   loads ... FIDO MENU for all languages (!)

   
   New since 2.5 PL3.3(Linux) (25.02.1995)

   loads ... AREA system implemented, ENVIRONMENT vars problem fixed (!)

   
   New since 2.6 PL3.8(Linux) (29.03.1995)

   g94.c ... WWW server/client for local/international use made up (!)


   New since 2.6 PL4.0 (01.04.1995)

   weiterl.c ... forward (weiterleiten) complete new, deputy (Vertreter) implemented (!)


   New since 2.6 PL4.1 (08.04.1995)

   main.c ... the end of the d... GID misunderstandings (!)


   New since 2.6 PL4.2 (09.04.1995)

   befehl.c ... first implementation of xtensions (!)
*/
