/* ix/MBox (faces.c) by Volker Schuermann, 04.12.1993

   This C source code contains the following functions:

   #FA faces()          try to read the "X-Face:" header lines

   Contact <volkers@unnet.wupper.de> for help! */








#include <stdio.h>

#include "mbox.h"

#define a1	219
#define a2	223
#define a3	220
#define a4	32

#define b1	'8'
#define b2	'9'
#define b3	'6'
#define b4	32




/* #FA - There were plans to implement the "X-Face:" header lines, but the 
   resulting overhead is far too big to realize it! */

void faces( fname )
UNSIGNED char fname[];
{
  int x, y;
  int x1, y1;
  int Z1, Z2, Z3, Z4;
  FILE *fp;
  int c, i;
  UNSIGNED char s[STRING];
  int tog = 0;
  UNSIGNED char t[STRING];



  ansi2("mr", 0, 0);
  printf("[Bild des Autors ansehen?] G, A, %c, ? > ", GBL07_MSG);
  ansi2("me", 0, 0);
  printf("G%c", BS);

  do {
	c = getint();
	if (c >= 97) c -= 32;
	if (c == ENTER) c = 'G';
	if (c == '?') {
		clearline();
		ansi2("mr", 0, 0);
		printf("%c%s > ", CR, "Bild des Autors anzeigen als Grafik, Ascii-Bild oder lieber Nicht ?");
		ansi2("me", 0, 0);
	}
	if ((c != 'G') && (c != 'A') && (c != GBL07_MSG)) c = 0;
  } while (c == 0);

  printf("%c\n\n", c);

  if (c == GBL07_MSG) return;

  if(c == 'G'){
	Z1 = a1;
	Z2 = a2;
	Z3 = a3;
	Z4 = a4;
  }
  if(c == 'A'){
	Z1 = b1;
	Z2 = b2;
	Z3 = b3;
	Z4 = b4;
  }

  sprintf(s, "%s/etc/face.put", HOME);

  fp = fopen( s, "r" );
  
  x1 = fgetc(fp); c = fgetc(fp);
  y1 = fgetc(fp); c = fgetc(fp);

  for(y = 0; y < y1; y++){
	i = 0;
	for(x = 0; x < x1; x += 8){
		c = fgetc(fp);
		if(tog == 0) s[i] = c;
		else t[i] = c;
		i++;
	}
	tog++;
	if(tog == 2){
		tog = 0;
		i = (int) x/8;
		for(x = 0; x < i; x ++){
			if( (s[x] & 128) &&  (t[x] & 128)) printf("%c", Z1);
			if( (s[x] & 128) && !(t[x] & 128)) printf("%c", Z2);
			if(!(s[x] & 128) &&  (t[x] & 128)) printf("%c", Z3);
			if(!(s[x] & 128) && !(t[x] & 128)) printf("%c", Z4);

			if( (s[x] & 64) &&  (t[x] & 64)) printf("%c", Z1);
			if( (s[x] & 64) && !(t[x] & 64)) printf("%c", Z2);
			if(!(s[x] & 64) &&  (t[x] & 64)) printf("%c", Z3);
			if(!(s[x] & 64) && !(t[x] & 64)) printf("%c", Z4);

			if( (s[x] & 32) &&  (t[x] & 32)) printf("%c", Z1);
			if( (s[x] & 32) && !(t[x] & 32)) printf("%c", Z2);
			if(!(s[x] & 32) &&  (t[x] & 32)) printf("%c", Z3);
			if(!(s[x] & 32) && !(t[x] & 32)) printf("%c", Z4);

			if( (s[x] & 16) &&  (t[x] & 16)) printf("%c", Z1);
			if( (s[x] & 16) && !(t[x] & 16)) printf("%c", Z2);
			if(!(s[x] & 16) &&  (t[x] & 16)) printf("%c", Z3);
			if(!(s[x] & 16) && !(t[x] & 16)) printf("%c", Z4);

			if( (s[x] & 8) &&  (t[x] & 8)) printf("%c", Z1);
			if( (s[x] & 8) && !(t[x] & 8)) printf("%c", Z2);
			if(!(s[x] & 8) &&  (t[x] & 8)) printf("%c", Z3);
			if(!(s[x] & 8) && !(t[x] & 8)) printf("%c", Z4);

			if( (s[x] & 4) &&  (t[x] & 4)) printf("%c", Z1);
			if( (s[x] & 4) && !(t[x] & 4)) printf("%c", Z2);
			if(!(s[x] & 4) &&  (t[x] & 4)) printf("%c", Z3);
			if(!(s[x] & 4) && !(t[x] & 4)) printf("%c", Z4);

			if( (s[x] & 2) &&  (t[x] & 2)) printf("%c", Z1);
			if( (s[x] & 2) && !(t[x] & 2)) printf("%c", Z2);
			if(!(s[x] & 2) &&  (t[x] & 2)) printf("%c", Z3);
			if(!(s[x] & 2) && !(t[x] & 2)) printf("%c", Z4);

			if( (s[x] & 1) &&  (t[x] & 1)) printf("%c", Z1);
			if( (s[x] & 1) && !(t[x] & 1)) printf("%c", Z2);
			if(!(s[x] & 1) &&  (t[x] & 1)) printf("%c", Z3);
			if(!(s[x] & 1) && !(t[x] & 1)) printf("%c", Z4);
		}
		printf("\n");
	}
  }
  fclose(fp);

  c = getint();
}



