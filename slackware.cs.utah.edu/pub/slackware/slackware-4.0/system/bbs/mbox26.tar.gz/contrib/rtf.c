/*
   Use this to delete RTF codes from textfiles.

   EXAMPLE:  rtf < ../etc/sysinfo > sysinfo.clean

   You have to delete "Content-Type:" lines all
   by yourself afterwards.
*/

#include <stdio.h>

main()
{
  int c;
  int rtf = 0;

  while(read(0, &c, 1) == 1){

	c &= 255;

	if(c == '<') rtf = 1;

	if(rtf){
		if((c == '>') || (c == 10) || (c == 13)) rtf = 0;
	}
	else{
		printf("%c", c);
	}
  }
}
