#include <stdio.h>

/*

	modem /dev/cua? ats0=0

*/

main( argc, argv )
int argc;
char *argv[];
{
  FILE *fp;

  char s[85];

  fp = fopen( argv[1], "a" );
  if(fp == NULL){
  }
  printf("[%s > %s]\n", argv[2], argv[1]);
  fprintf(fp, "%s%c", argv[2], 13 );
  fclose(fp);  
}
