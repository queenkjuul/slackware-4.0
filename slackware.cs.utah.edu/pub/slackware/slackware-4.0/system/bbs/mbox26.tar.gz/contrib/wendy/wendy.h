#include <stdio.h>
#include <signal.h>

#ifndef EXTERN
#define EXTERN extern
#endif

#ifdef _MBOX
#undef _MBOX
#endif

#ifdef _LOCAL
#	define HILFE	  	"/local/mbox/contrib/wendy/wendy.hlp"
#	define VERSION   	" WENDY 1.2g  -  Simple (MIME) RichTextFormat Editor  -  HILFE: CTRL-O "
#else
#	define HILFE		"/local/mbox/contrib/wendy/english.hlp"
#	define VERSION   	" WENDY 1.2e  -  Simple (MIME) RichTextFormat Editor  -  HELP: CTRL-O "
#endif

#define RULERLINE 	"1...5...10...15...20...25...30...35...40...45...50...55...60...65...70...75...80"

#define CR		13
#define LF		10
#define BS		8
#define TAB		9
#define ESC		27

#ifdef _SYS7
#define ENTER   	13
#else
#define ENTER		10
#endif

#define CTRL_A		1
#define CTRL_B  	2
#define CTRL_C		3
#define CTRL_D  	4
#define CTRL_E		5
#define CTRL_F  	6
#define CTRL_G  	7
#define CTRL_H  	8

#define CTRL_J  	10  
#define CTRL_K		11
#define CTRL_L		12

#define CTRL_N		14
#define CTRL_O		15
#define CTRL_P		16
#define CTRL_Q		17
#define CTRL_R		18
#define CTRL_S		19
#define CTRL_T  	20
#define CTRL_U		21
#define CTRL_V  	22
#define CTRL_W  	23
#define CTRL_X  	24
#define CTRL_Y		25
#define CTRL_Z  	26

#define UP		9165
#define DOWN		9166
#define LEFT		9168
#define RIGHT		9167

#define PGUP		9186
#define PGDN		9185

#define PGUP_LI		9153
#define PGDN_LI		9154

#define END 		9189
#define HOME		9172	

#define DEL		9152
#define INS		9151

#define DELD            1111

#define HOME_LI		9226

#define NUM5		9171


#define TLX_END		9175	/* TELIX 3.11  &  PROCOMM 2.4.1 */
#define TLX_DEL		127
#define TLX_INS		0

#define TEM_INS 	22	/* TELEMATE 2.11 */
#define TEM_DEL 	7

#define	BLANK		127

#define STRING 		140
#define LONGSTRING	700

#define MAXLINES 	2000

#define LINELENGTH	250	

#define is_centered	1
#define is_richtext	2
#define is_plain	4

#define BLOCKMODE	2

int wBS, wDEL, wINS, wEND;

FILE *ROLLBACK;

unsigned char SCREEN[27][STRING];
unsigned char ATTRIB[27][STRING];

unsigned char TEXT[MAXLINES][LINELENGTH];
int  FLAG[MAXLINES];

unsigned char version[STRING];

unsigned char umlaut[STRING], terminal[STRING];

int x, y, ypos, lastline, xruler;

int NEU, CHANGED, REALLY, MARK, RULER, STATUSM, FORMATTER;
int MAXX, MAXY, START;

int RTF_attrib;
int RTF_toggle;
int INS_mode;

struct block{
	int status;
	int x1;
	int y1;
	int x2;
	int y2;
	int y;
	int ypos;
} BLOCK;

int UMLAUT;

int SCANTEST;
