#---------------------------------------------------------------------------
#
#                      ix/MBox  I N E W S . SH
#             Bulletin Board System for UNIX(-Derivations)
#
#                          Volker Schuermann
#                     Wuppertal, FRG, 04.12.1993
#
#---------------------------------------------------------------------------
# This file forwards a new article to INEWS. The article yet includes a
# fairly complete header.
#---------------------------------------------------------------------------
# Dieses Script uebergibt einen neuen Artikel an INEWS. Dieser Artikel
# enthaelt bereits einen (fast) kompletten Header.
#---------------------------------------------------------------------------
# Parameters:
#
# $1  ->  Newsgroup the article should be published in
# $2  ->  File including the new article (see above)
# 
# Example:
#
# /usr/local/lib/news/inews -h < $2
#
#---------------------------------------------------------------------------

/usr/local/lib/news/inews -h < $2

