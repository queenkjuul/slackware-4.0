#---------------------------------------------------------------------------
#
#                      ix/MBox  R M A I L . S H
#             Bulletin Board System for UNIX(-Derivations)
#
#                          Volker Schuermann
#                     Wuppertal, FRG, 04.12.1993
#
#---------------------------------------------------------------------------
# Dieses Script uebergibt eine "persoenliche Mail" und eine Empfaenger-
# Adresse an das Programm RMAIL. Die "persoenliche Mail" enthaelt bereits
# einen (fast) kompletten Header !
#
# Bei Verwendung von SMAIL sollte "config.mbox" speziell fuer die Unter-
# drueckung der SMAIL-Message-ID etc. konfiguriert werden.
#---------------------------------------------------------------------------
# This is the interface between ix/MBox's internal mailer and your systems
# mailer RMAIL. The mail (i.e. the file, containing the mail) has yet a
# nearly complete header.
#
# If you are using SMAIL (a link of SMAIL to RMAIL), than you should con-
# figure "config.mbox" to stop SMAIL message IDs etc. (see below)
#---------------------------------------------------------------------------
# Parameters:
#
# $1  ->  File containing the mail
# $2  ->  Receiver of the mail
# 
# Example:
#
# rmail -d -i $1 $2
#
# Or:
# 
# smail -i -C /usr/local/lib/smail/config.mbox $2 < $1
#
# config.mbox ->
# received_field
# error_copy_postmaster   

smail -i $2 < $1 
