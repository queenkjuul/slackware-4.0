#---------------------------------------------------------------------------
#
#                      ix/MBox  A L I A S . S H
#             Bulletin Board System for UNIX(-Derivations)
#
#                          Volker Schuermann
#                     Wuppertal, FRG, 04.12.1993
#
#---------------------------------------------------------------------------
# This script appends an entry for every new ix/MBox user to the aliases 
# file of SMAIL (etc.) and rebuilds the aliases database.
#
# If you are using UMAIL instead of SMAIL, you should comment out every
# line of the following script.
#---------------------------------------------------------------------------
# Dieses Script fuegt einen Eintrag fuer jeden neuen User der ix/MBox an die
# Alias-Datei von SMAIL (etc.) an und erzeugt einen neue Alias-Datenbank. 
#
# Wird UMAIL statt SMAIL verwendet, sollten alle Zeilen dieses Scripts' aus-
# kommentiert werden.
#---------------------------------------------------------------------------
# Parameters:
#
# $1  -> Name of the new BBS user (something like that: "Jack.Daniels")
# 
# Example:
#
# echo $1 "		" \"\|/usr/bin/xmd $1 -\" >> /usr/lib/smail/aliases
# /usr/lib/smail/mkaliases
#
# Double, triple and quadruple check the path to the aliases file!!!
# Especially quite a few LINUX installation have two aliases files on
# different paths but only one of them is the right one!!!
#---------------------------------------------------------------------------

echo $1 "		" \"\|/usr/bin/xmd $1 -\" >> /usr/lib/aliases
/usr/lib/smail/mkaliases
