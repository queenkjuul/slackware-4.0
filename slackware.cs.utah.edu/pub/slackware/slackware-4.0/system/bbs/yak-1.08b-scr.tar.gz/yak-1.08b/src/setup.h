/* YAK - Copyright (c) 1997 Timo Sirainen - read license.txt */

#ifndef __SETUP_H
#define __SETUP_H

void edit_setup(char *data);

#endif
