/* YAK - Copyright (c) 1997 Timo Sirainen - read license.txt */

#ifndef __NEW_USER_H
#define __NEW_USER_H

unsigned long ask_newu_questions(void);

#endif
