#ifndef __GETDESCS_H
#define __GETDESCS_H

int get_file_descriptions(void);

#endif
