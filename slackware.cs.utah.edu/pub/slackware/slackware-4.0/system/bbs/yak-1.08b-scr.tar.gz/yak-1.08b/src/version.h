/* YAK - Copyright (c) 1997 Timo Sirainen - read license.txt */

#ifndef __VERSION_H
#define __VERSION_H

#define BBS_VERSION "v1.0b-8"
#define COPYRIGHT "Copyright (c) 1997 Timo Sirainen"

#if defined (__linux__)
#  define OP_SYSTEM "L"
#elif defined (__OS2__)
#  define OP_SYSTEM "2"
#elif defined (__DOS__)
#  define OP_SYSTEM "D"
#elif defined (__NT__)
#  define OP_SYSTEM "NT"
#else
#  error Unknown platform
#endif

#endif
