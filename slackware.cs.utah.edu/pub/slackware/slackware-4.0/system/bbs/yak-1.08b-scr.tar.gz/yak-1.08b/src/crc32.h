/* YAK - Copyright (c) 1997 Timo Sirainen - read license.txt */

#ifndef __CRC32__
#define __CRC32__

unsigned long crc32(char *str);
unsigned long up_crc32(char *str);
unsigned long lo_crc32(char *str);

unsigned long crc32_block(void *ptr, int size);

#endif
