#ifndef __TOPLIST_H
#define __TOPLIST_H

void create_user_score_list(void);

#endif
