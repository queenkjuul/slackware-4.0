/* YAK - Copyright (c) 1997 Timo Sirainen - read license.txt */

#ifndef __FSED_H
#define __FSED_H

int fs_editor(char *fname);

#endif
