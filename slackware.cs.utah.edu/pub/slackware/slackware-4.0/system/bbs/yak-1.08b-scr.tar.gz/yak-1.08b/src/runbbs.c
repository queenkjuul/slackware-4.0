#include <string.h>
#include <unistd.h>

int main(void)
{
    char tty[100], n;
    char *arg[10] =
    {
        "/usr/local/bin/bbs",
        "-h:0",
        "-b:38400",
        "-n:x",
        "-t:x",
        "-c:x",
        NULL
    };
    strcpy(tty, ttyname(0));

    if (strncmp(tty, "/dev/ttyS", 9) == 0)
    {
        n = tty[9];
    }
    else if (strncmp(tty,"/dev/cua", 8) == 0)
    {
        n = tty[8];
    }
    else
    {
        /* Local login */
        arg[1] = "-l";
        arg[2] = "-n:1";
        arg[3] = "-c:1";
        arg[4] = NULL;
        n = 0;
    }

    if (n != 0)
    {
        if (n == '1')
        {
            arg[3] = "-n:2";
            arg[4] = "-t:7";
            arg[5] = "-c:2";
        }
        else
        {
            arg[3] = "-n:3";
            arg[4] = "-t:8";
            arg[5] = "-c:4";
        }
    }

    execvp(arg[0], &arg[0]);
}
