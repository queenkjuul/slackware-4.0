/* YAK - Copyright (c) 1997 Timo Sirainen - read license.txt */

#ifndef __BBS_FUNC_H
#define __BBS_FUNC_H

int yes_no(char *text, int def, char **data);
int goto_bbs(char *username);
int up_func(int chr);
int lo_func(int chr);

extern unsigned long bpsrate; /* BPS rate */
extern unsigned nodenum;   /* Current node number */

extern char menuname[256]; /* Current menu */
extern char parms[256];    /* Parameters to command */
extern int run_auto;       /* 1 = Redraw screen */

extern int logging;        /* 1 as long as not known if using VT100 keyboard */

extern char tmp1_str[256];
extern char tmp2_str[256];

extern unsigned long num1,num2,num3,num4,num5;

extern int comport;

#ifdef __linux__
extern int dosemu_pid;     /* DOS-emu process ID */
#endif

#endif
