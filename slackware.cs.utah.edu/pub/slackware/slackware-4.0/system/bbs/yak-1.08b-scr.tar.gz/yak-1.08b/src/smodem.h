#ifndef __SMODEM_H
#define __SMODEM_H

void execute_smodem(char *dszlog, char *dllist, unsigned long bpsrate, int passive);

#endif
