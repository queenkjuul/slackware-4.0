/* YAK - Copyright (c) 1997 Timo Sirainen - read license.txt */

#ifndef __SCRSAVER_H
#define __SCRSAVER_H

extern int inactivity,told_inactivity;
extern time_t last_tim,last_min;

void init_timer(void);
void give_timeslice(void);

#if !defined (__OS2__) && !defined (__NT__) && !defined (__linux__)
int opsysDetect(void);
#endif

#endif
