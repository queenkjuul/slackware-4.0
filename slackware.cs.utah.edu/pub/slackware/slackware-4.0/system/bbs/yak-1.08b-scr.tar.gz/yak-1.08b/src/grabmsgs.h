/* YAK - Copyright (c) 1997 Timo Sirainen - read license.txt */

#ifndef __GRABMSGS_H
#define __GRABMSGS_H

int grab_messages(char *data);
int toss_bw_packet(char *fname);
int toss_qwk_packet(char *fname);

#endif
