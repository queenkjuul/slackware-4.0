/* YAK - Copyright (c) 1997 Timo Sirainen - read license.txt */

#ifndef __OUTPUT_H
#define __OUTPUT_H

#include <stdio.h>

extern int scrlength, scrwidth;
extern int ttynum;

extern unsigned short *screen;

extern FILE *Fout;
extern char *month[12];
extern int wherex, wherey;

extern unsigned char chr_out[256];
extern unsigned char chr_in[256];
extern unsigned char local_out[256];
extern unsigned char local_in[256];

char *conv_macros(char *input, char *output);
int output(char *format, ...);
int outtext(char *text);
void outchr(char chr);

void loc_output(char *format, ...);
void loc_outchr(char chr);

int init_output(void);
void deinit_output(void);

void load_charset(char key);

#endif
