/* YAK - Copyright (c) 1997 Timo Sirainen - read license.txt */

#ifndef __DOWNLOAD_H
#define __DOWNLOAD_H

#include <stdlib.h>

int download_files(char *__parms);
void upload_files(int start_proto);

#ifdef __linux__
void execute_protocol(char *path, int usestd);
#elif defined (__OS2__)
#  define execute_protocol(a,b) { flush_transmit(); block_thread = 1; system(a); block_thread = 0; }
#else
#  define execute_protocol(a,b) system(a)
#endif

#endif
