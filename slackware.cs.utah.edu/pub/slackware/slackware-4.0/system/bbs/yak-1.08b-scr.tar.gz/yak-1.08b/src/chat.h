/* YAK - Copyright (c) 1997 Timo Sirainen - read license.txt */

#ifndef __CHAT_H
#define __CHAT_H

void yell_sysop(char *data);
void line_chat(void);
void split_screen_chat(void);

#endif
