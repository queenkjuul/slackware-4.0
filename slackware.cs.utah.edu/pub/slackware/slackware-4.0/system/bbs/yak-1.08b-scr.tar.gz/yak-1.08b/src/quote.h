/* YAK - Copyright (c) 1997 Timo Sirainen - read license.txt */

#ifndef __QUOTE_H
#define __QUOTE_H

#define QUOTE_MAX 7

void quote_message(char *fname);

#endif
