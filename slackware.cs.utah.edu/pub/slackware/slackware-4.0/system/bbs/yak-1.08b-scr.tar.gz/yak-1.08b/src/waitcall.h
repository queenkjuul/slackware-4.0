#ifndef __WAITCALL_H
#define __WAITCALL_H

int wait_caller(void);

#endif
