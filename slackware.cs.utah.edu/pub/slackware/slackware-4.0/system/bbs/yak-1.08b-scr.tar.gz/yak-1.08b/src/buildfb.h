#ifndef __BUILDFB_H
#define __BUILDFB_H

int build_filebase(int argc, char *argv[]);
int join_filebase(int argc, char *argv[]);

#endif
