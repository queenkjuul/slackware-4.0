/* YAK - Copyright (c) 1997 Timo Sirainen - read license.txt */

#ifndef __KEYB_H
#define __KEYB_H

#ifdef __linux__
int kbhit_nowait(void);
int local_kbhit(void);
#else
#  define kbhit_nowait() kbhit()
#  define local_kbhit() kbhit()
#endif
int kbhit(void);
int getch(void);

#ifdef __linux__
int KbdInit(void);
void KbdDeInit(void);
#endif

#endif
