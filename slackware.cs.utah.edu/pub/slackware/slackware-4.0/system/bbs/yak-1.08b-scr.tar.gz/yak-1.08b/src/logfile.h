/* YAK - Copyright (c) 1997 Timo Sirainen - read license.txt */

#ifndef __LOGFILE_H
#define __LOGFILE_H

int open_logfile(int nodenum);
void close_logfile(void);

void write_log(char *text, ...);

#endif
