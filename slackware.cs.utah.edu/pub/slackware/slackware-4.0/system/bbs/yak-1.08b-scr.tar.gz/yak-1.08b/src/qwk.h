/* YAK - Copyright (c) 1997 Timo Sirainen - read license.txt */

#ifndef __QWK_H
#define __QWK_H

typedef struct
{
    unsigned long pos;
    unsigned char conf;
}
NDX_REC;

typedef struct
{
    char flag;
    char num[7];
    char date[8];
    char time[5];
    char mto[25];
    char mfrom[25];
    char subj[25];
    char passw[12];
    char reply[8];
    char blocks[6];
    unsigned char active;
    unsigned short conf;
    unsigned short lognum;
    char network;
}
QWK_REC;

#endif
