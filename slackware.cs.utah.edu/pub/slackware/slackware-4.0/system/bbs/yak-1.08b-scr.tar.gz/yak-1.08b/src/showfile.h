/* YAK - Copyright (c) 1997 Timo Sirainen - read license.txt */

#ifndef __SHOWFILE_H
#define __SHOWFILE_H

void show_file(char *fname);

#endif
