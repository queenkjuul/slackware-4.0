/* YAK - Copyright (c) 1997 Timo Sirainen - read license.txt */

#ifndef __ASK_STR_H
#define __ASK_STR_H

int ask_string(char *text, char *str, int len, char outchar, char **data);

#endif
