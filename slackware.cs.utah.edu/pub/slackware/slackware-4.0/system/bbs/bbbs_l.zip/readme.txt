Some basic commands:

bcfg4.exe 1          - Configure BBBS. Only things that you need to change are
                       sysop_name and bbbs_name in global:general screen.
bag.exe sysop.gui    - Read sysop manual.
bbbs.exe 0           - Local login (configure first!).


Quick startup: Run "bcfg4.exe 1", change sysop_name and bbbs_name, exit&save.
               Then run "bbbs.exe 0".


You can also convert sysop.gui to ascii/html by entering following commands:

copy bag.exe ag2html.exe
copy bag.exe ag2doc.exe
copy bag.exe ag2txt.exe
ag2html.exe sysop.gui >sysop.htm
ag2doc.exe sysop.gui >sysop.doc
ag2txt.exe sysop.gui >sysop.txt
