/* $Id: setpass.c,v 1.1 1996/11/05 18:49:48 b Exp $ */

#include <stdio.h>
#include <string.h>

int main(void) {
  FILE *f;
  /* "I_PROMISE_I_DONT_FORGET_MY_PASSWORD_AGAIN" */
  unsigned char pass[16] = {205,196,208,184,158,248,81,51,116,170,41,0,105,218,202,84};

  if ((f=fopen("bbbsuser.dat","r+b"))==NULL) {
    fprintf(stderr,"Can't open bbbsuser.dat");
    return(2);
  }
  fseek(f,30L,SEEK_SET);
  fwrite(pass,1,16,f);
  return(0);
}
