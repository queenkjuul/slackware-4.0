  -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  =                     Parlor House BBS for Linux                      = 
  =                              Version 3.0                            =
  =                     By Asu Pala and Loreen Lacy                     =
  =                             Copyright 1995                          =
  -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

Getting started:

1. Run the exec file "PHBBS" using the -bg or & parameter to put it in 
the background.  The BBS is default to port 1900.  read "manual.txt" to 
see how to change to a different port if needed.

2. Telnet to the BBS port.

3. Type "new" at the prompt.

4. When prompted for name, type "Operator" (no quotes).

5. Enter the prompted information.

The BBS will give you Level 7 and enter you in to the main channel.  Have 
fun!


Note: The passwords for all the "testusers" are test.
