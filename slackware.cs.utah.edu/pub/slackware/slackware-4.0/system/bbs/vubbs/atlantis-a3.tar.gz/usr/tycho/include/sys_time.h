#include <time.h>

#ifndef	__PROTOTYPES_H__
#include <prototypes.h>
#endif

IMPORT	time_t	getudate PROTO((char *s));
IMPORT	char	*usdate PROTO((time_t *));
IMPORT	char	*umdate PROTO((time_t *));
IMPORT	char	*uldate PROTO((time_t *));
IMPORT	void	year_adjust PROTO((time_t *now, int adj));
IMPORT	void	year_align PROTO((time_t *now, int align));
IMPORT	void	month_adjust PROTO((time_t *now, int adj));
IMPORT	void	month_align PROTO((time_t *now, int align));
IMPORT	void	week_adjust PROTO((time_t *now, int adj));
IMPORT	void	week_begin PROTO((time_t *now, int span));
IMPORT	void	day_adjust PROTO((time_t *now, int adj));
IMPORT	void	day_ending PROTO((time_t *now));
IMPORT	void	year_ending PROTO((time_t *now, time_t *base));
IMPORT	time_t	str2date PROTO((char *s));
IMPORT	char	*date2str PROTO((time_t *now));