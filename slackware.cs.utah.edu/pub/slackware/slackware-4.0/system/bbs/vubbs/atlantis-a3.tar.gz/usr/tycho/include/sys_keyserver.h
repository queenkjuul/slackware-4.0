#ifndef	 __PROTOTYPES__
#include <prototypes.h>
#endif

IMPORT	unsigned char *init_keyserver PROTO((unsigned char *key, int len));
IMPORT	unsigned char *next_keyserver PROTO((unsigned char *key, int len));
IMPORT	int exec_keyserver PROTO((char **argv, unsigned char *key, int len));
IMPORT	unsigned char *recv_keyserver PROTO((int len));
