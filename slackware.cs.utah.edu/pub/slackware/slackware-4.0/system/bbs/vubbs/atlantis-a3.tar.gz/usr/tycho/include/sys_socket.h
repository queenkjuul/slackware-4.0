#ifndef __SOCKET_H__
#define __SOCKET_H__

#ifndef __PROTOTYPES_H__
#include <prototypes.h>
#endif

#ifndef __STREAM_H__
#include <sys_stream.h>
#endif

#include <bool.h>

#include <sys/types.h>
#include <sys/socket.h>
#ifdef  COHERENT
#include <netinet/in.h>
#else
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#endif


#define INET_NETSTAT_PORT       15
#define INET_FTP_PORT           21
#define INET_TELNET_PORT        23
#define INET_SNMP_PORT          25
#define INET_TIME_PORT          37
#define INET_BIND_PORT          42
#define INET_WHOIS_PORT         43
#define INET_FINGER_PORT        79
#define INET_POP_PORT           109
#define INET_AUTH_PORT          113
#define INET_NNTP_PORT          119
#define INET_SPEAK_PORT         800
#define INET_USAGE_PORT         801
#define INET_FLASH_PORT         801
#define INET_NETCHAT_PORT       880

#define disconnect_socket(so)   close(so)
#define create_socket()         socket(AF_INET, SOCK_STREAM, 0)
#define destroy_socket(so)      release_socket(so)
#define send_udp(udp, buf, len) sendto(udp->udp_so, buf, len, 0, &udp->udp_addr, sizeof(udp->udp_addr))
#define recv_udp(udp, buf, len) recvfrom(udp->udp_so, buf, len, 0, &udp->udp_addr, &udp->udp_alen)
#define test_udp(udp, timeout)  (iskey(udp->udp_so, timeout))

typedef struct
{
	int                     udp_so;
	struct  sockaddr        udp_addr;
	int                     udp_alen;
}       UDP;

IMPORT  struct  hostent *get_hostent PROTO((char *host));
IMPORT  int     connect_socket PROTO((char *host, int port));
IMPORT  int     bind_socket PROTO((int port, int backlog));
IMPORT  int     release_socket PROTO((int so));
IMPORT  STREAM  *accept_socket PROTO((int so, int size));
IMPORT  STREAM  *open_socket PROTO((char *host, int port, int size));
IMPORT  STREAM  *speak_socket PROTO((char *client));
IMPORT  void close_socket PROTO((STREAM *sp));
IMPORT  BOOL iolink_socket PROTO((char *host, int port));
IMPORT  char *name_socket PROTO((int so));
IMPORT  char *addr_socket PROTO((int so));
IMPORT  BOOL test_socket PROTO((int so, char *name));
IMPORT  struct  in_addr *in_addr_socket PROTO((int so));
IMPORT  STREAM  *open_socket_by_addr PROTO((struct in_addr *addr, int port, int size));

IMPORT  UDP     *create_udp PROTO((char *host, int port));
IMPORT  UDP     *bind_udp PROTO((int port));
IMPORT  void    destroy_udp PROTO((UDP *udp));
IMPORT  char    *name_udp PROTO((UDP *udp));
IMPORT  struct  in_addr *in_addr_udp PROTO((UDP *udp));
IMPORT  UDP     *assign_udp PROTO((UDP *udp, char *host, int port));
IMPORT  UDP     *dup_udp PROTO((UDP *udp));

#endif
