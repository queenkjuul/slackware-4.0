#ifndef	__LOCKING_H__

#ifdef	QNX
#ifdef	__ANSI__
#define	share(path, mode)	sopen(path, O_RDWR | O_CACHE | mode, SH_DENYNO)
#else
#define	share(path, mode)	open(path, O_RDWR | O_CACHE | mode)
#endif

#define	lock(fd, size)		lockf(fd, F_LOCK, size)
#define	ulock(fd, size)		lockf(fd, F_ULOCK, size)
#define	test(fd, size)		lockf(fd, F_TEST, size)

#define	__LOCKING_H__
#endfif


#endif
