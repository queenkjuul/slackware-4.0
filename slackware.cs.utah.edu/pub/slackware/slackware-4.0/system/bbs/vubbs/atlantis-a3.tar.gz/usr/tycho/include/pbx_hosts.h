typedef	struct
{
	int		np_interchange;		/* -1 = local pbx ext			*/
	long	np_number;			/*	number						*/
}	pbxnbr;

typedef	struct
{
	char	*pbx_id;			/*	effective id				*/
	char	*pbx_domain;		/*	dialing domain logical		*/
	char	*pbx_host;			/*	host ip interface server	*/
	int		pbx_port;			/* 	port(s)	interface bound to	*/
	pbxnbr	pbx_first;			/*	first control number		*/
	pbxnbr	pbx_last;			/*	last control number			*/	
}	PBXENT;

typedef	struct
{
	char	*ip_host;			/* reference host				*/
	char	*ip_device;			/* reference device				*/
	char	*ip_public;			/* public tel number			*/
	char	*ip_domain;			/* pbx domain					*/
	char	*ip_ext;			/* pbx extension				*/
}	IPTEL;

int		cvt_num2pbxnbr PROTO((pbxnbr *target, char *num));
PBXENT	*get_pbxbyname PROTO((char *pbx_id));
PBXENT	*get_pbxbynum PROTO((char *domain, char *num));
PBXENT	*get_pbxbyiptel PROTO((IPTEL *host_tel));
IPTEL	*get_ipteldir PROTO((char *host, char *device)); 
char	*get_iptelnum PROTO((PBXENT *pbx, char *host, char *device));
