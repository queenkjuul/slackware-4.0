
typedef	struct
{
	enum
	{
		P_LOGIN,
		P_POST,
		P_LOGOUT
	}	p_cmd;
	char	p_user[17];
	char	p_buf[128];
	int		p_pid;
}	PARTY;
