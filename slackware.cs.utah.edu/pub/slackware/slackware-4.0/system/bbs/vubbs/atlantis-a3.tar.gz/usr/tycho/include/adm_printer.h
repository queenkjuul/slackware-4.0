#ifndef	  __TASKS_H__
#include <sys_tasks.h>
#endif

#define	PRINTERS	"/etc/VUprinter"

typedef	struct
{
	char	lpt_name[33];
	int	lpt_xsize;
	int	lpt_ysize;
	int	lpt_ffmode;
	char	*lpt_spool[16]
	char	lpt_buf[0];
}	PRINTERS;

IMPORT	FILE	*open_printer PROTO((PRINTER *rec));
IMPORT	void	close_printer PROTO((FILE *lpt));
IMPORT	FILE	*open_viewer PROTO((void));
IMPORT	void	close_viewer PROTO((FILE *view));
IMPORT	void	formfeed_printer PROTO((PRINTER *rec, int line));

