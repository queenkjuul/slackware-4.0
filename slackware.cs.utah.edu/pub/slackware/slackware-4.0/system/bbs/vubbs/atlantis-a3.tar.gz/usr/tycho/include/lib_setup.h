#include <stdio.h>
#ifndef	__VU_H__
#include <vu.h>
#endif

FIXEDWINDOW(AdminDesktop);
WINDOW(SetupProfile);
FIXEDWINDOW(SetupDisplay);
FIXEDWINDOW(SetupAddress);
FIXEDWINDOW(SetupAddress1);
FIXEDWINDOW(SetupXferProtocol);
FIXEDWINDOW(SetupXferNewline);
FIXEDWINDOW(SetupXferArchive);
FIXEDWINDOW(SetupDesktop);
FIXEDWINDOW(SetupPassword);
FIXEDWINDOW(SetupLocation);
FIXEDWINDOW(SetupLanguage);
WINDOW(GetProfile);

PORT(LocationPort);

IMPORT	int	create_setup PROTO((char *path, char *title));
IMPORT	FILE	*rewrite_setup PROTO((char *path));
IMPORT	void	close_setup PROTO((FILE *fp));
IMPORT	FILE	*begin_rewrite PROTO((char *pwdfile, char *id));
IMPORT	void	end_rewrite PROTO((char *pwdfile));
IMPORT	void	reset_location PROTO((char **argv, char *title));
IMPORT	void	reset_session PROTO((char *msg));
