#ifndef		NEWS_HASH_SIZE
#define	ACTIVENEWS	"/usr/lib/news/active"
#define	ACTIVETIMES	"/usr/lib/news/active.times"
#define	NEWSLOCK "/usr/lib/news/active.lock"
#define	HISTORY	"/usr/lib/news/tracking"
#define	NEWS_HASH_SIZE	512

IMPORT	BOOL	initnews PROTO((void));
IMPORT	int	newskey PROTO((char *s));
#endif
