#ifndef	__SOCKET_H__
#include <sys_socket.h>
#endif

#define	TSI_RESOURCE_PORT	9600	/* main session server */
#define	TSI_SESSION_PORT	9601	/* info session server */
#define	TSI_SERVICE_COUNT	398	/* number of services supported */

enum
{
	TSI_NOTFOUND = 1,	/* invalid resource name used */
	TSI_OFFLINE,		/* requested service is unavailable */
	TSI_INVALID,		/* invalid service name used */

	TSI_FAILED		/* operation failed */
};

enum
{
	TSILP_ANNOUNCE= 0,	/* broadcast by announcing server */
	TSILP_REQUEST,		/* request lookup */
	TSILP_ADVERTISE,	/* advertise resource */
	TSILP_STATUS,		/* request resource status */
	TSILP_RESTART,		/* restart stopped resource */
	TSILP_STOP,		/* stop unused resource */
};

typedef	struct
{
	char	lp_mode;
	char	lp_seq;
	char	lp_secret[16];
	char	lp_resource[16];
	char	lp_reference[128];
}	TSILP;

#define	close_tsisp(sp)	close_socket(sp)
#define	close_tsirp(sp) close_socket(sp)
#define	disconnect_tsixp(so) disconnect_socket(so)

int	start_tsilp PROTO((char *resource));	/* start a resource/service */
int	stop_tsilp PROTO((char *resource)); 	/* stop a resource/service */
int	stat_tsilp PROTO((char *resource)); 	/* stat */
char	*find_tsilp PROTO((char *resource));	/* find host for resource */
STREAM	*open_tsisp PROTO((char *resource, char *facility));
STREAM	*open_tsirp PROTO((char *resource, char *protocol));
int	connect_tsixp PROTO((char *resource, char *protocol));