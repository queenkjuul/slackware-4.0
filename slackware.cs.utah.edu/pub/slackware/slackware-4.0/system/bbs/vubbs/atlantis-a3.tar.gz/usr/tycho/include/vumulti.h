
#ifdef	__ISO8
#define	__MULTINATIONAL
#define	NR_DEFAULT	NR_ENGLISH
#define	NR_DEFAULT_LANG	"LANG=english_us"
#define	NR_DATE_FORMAT	0
#define	NR_TIME_FORMAT	0
#define	NR_ABBRV_FORMAT	0
#define	NR_SUPPORT	0x000F	/* 0x0008 = spanish mask */
#define	NR_COUNT	4	/* count 4 with spanish */

/*	define translated vector resources	*/

enum
{
	NR_ENGLISH = 0,
	NR_ITALIAN,
	NR_ROMANIAN,
	NR_SPANISH,	
	NR_NONE
};
#endif

#ifndef	__MULTINATIONAL
#define	NR_ENGLISH	0
#define	NR_DEFAULT	NR_ENGLISH
#define	NR_SUPPORT	0x0001
#define	NR_COUNT	1
#define	NR_DATE_FORMAT	0
#define	NR_TIME_FORMAT	0
#define	NR_ABBRV_FORMAT	0
#endif

extern	int	replacement_language;
extern	unsigned	long	replacement_support[];
extern	int	vu_national_date;
extern	int	vu_national_time;
extern	int	vu_national_abbrv;

#define	REPLACE_ENGLISH(str, a)			{CNULL - 1,      str,0,0,0,0, NR_ENGLISH, 0, a},
#define	REPLACE_ITALIAN(str, a)			{CNULL - 1,      str,0,0,0,0, NR_ITALIAN, 0, a},
#define	REPLACE_ROMANIAN(str, a)		{CNULL - 1,	 str,0,0,0,0, NR_ROMANIAN, 0, a},
#define	REPLACE_DEFAULT()			{CNULL - 1,	 NULL,0,0,0,0,-1,         0,NULL},

#ifdef	__MULTINATIONAL
#define	VU_MARKER_CELL	0x7f

IMPORT	void	GetVUMulti PROTO((int nr));
IMPORT	unsigned char VUToLower PROTO((unsigned char c));
IMPORT	unsigned char VUToUpper PROTO((unsigned char c));
IMPORT	char	*VUStrLower PROTO((unsigned char *s));
IMPORT	char	*VUStrUpper PROTO((unsigned char *s));
IMPORT	char	*VUStrProper PROTO((unsigned char *s));
IMPORT	int	VUStrcmp PROTO((unsigned char *s1, unsigned char *s2));
IMPORT	int	VUStrncmp PROTO((unsigned char *s1, unsigned char *s2, int len));
IMPORT	int	VUStricmp PROTO((unsigned char *s1, unsigned char *s2));
IMPORT	int	VUStrnicmp PROTO((unsigned char *s1, unsigned char *s2, int len));
IMPORT	BOOL	VUStrTrue PROTO((unsigned char *s));
IMPORT	BOOL	VUValidText PROTO((unsigned char c));

IMPORT	char	*VUMultiDow PROTO((int d, BOOL abbr));
IMPORT	char	*VUMultiMonth PROTO((int m, BOOL abbr));
IMPORT	char	*VUDateDMY PROTO((time_t *time));
IMPORT	char	*VUDateMDY PROTO((time_t *time));
IMPORT	int	VUMultiCentury PROTO((time_t *time));
IMPORT	struct	tm* VULocalTime PROTO((time_t *time));
IMPORT	STRING	VUTextString PROTO((STRING s));
IMPORT	STRING	VUTextCString PROTO((STRING s));
IMPORT	int	VULoadMsgText PROTO((char *id, char **msgs, int count));
IMPORT	int	VUStrLength PROTO((STRING s));
IMPORT	char	*VUShortDate PROTO((time_t *time));
IMPORT	char	*VUMixedDate PROTO((time_t *time));
IMPORT	char	*VUUnixDate PROTO((time_t *time));
IMPORT	char	*VULongDate PROTO((time_t *time));
#else
#include <ctype.h>
#define	VU_MARKER_CELL	'~'
#define	VUToLower(c)	tolower(c)
#define	VUToUpper(c)	toupper(c)
#define	VUStrLower(s)	strlwr(s)
#define	VUStrUpper(s)	strupr(s)
#define	VUStrcmp		strcmp
#define	VUStricmp		stricmp
#define	VUStrncmp		strncmp
#define	VUStrnicmp		strnicmp
#define	VUValidText(p)	((p1 > 31 && p1 < 127))
#define	VULocalTime(time)	localtime(time)
#define	VUTextString(s)		(s)
#define	VUTextCtrlString(s)	(s)
#define	VUStrLength(s)		strlen(s)
#endif


