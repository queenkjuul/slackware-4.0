#ifndef	__PROTOTYPES_H__
#include <prototypes.h>
#endif

#define	ARTICLE_GROUPS	64

typedef	struct
{
	char	*n_groups[ARTICLE_GROUPS + 1];
	char	*n_from;
	char	*n_name;
	char	*n_subject;
	char	*n_tag;
	char	*n_date;
	time_t	n_posted;
	STREAM	*n_fp;
	char	n_buf[4096];
}	NEWS;

#define	stream_article(a)	(a->n_fp)

IMPORT	NEWS	*open_article PROTO((NEWSGRP *grp, long article));
IMPORT	NEWS	*scan_article PROTO((NEWS *article));
IMPORT	void	close_article PROTO((NEWS *article));
IMPORT	NEWS	*get_article PROTO((NEWSGRP *grp, long article));


