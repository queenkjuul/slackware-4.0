#ifndef	__SERIAL_H__
#define	__SERIAL_H__

#ifndef	__PROTOTYPES_H__
#include <prototypes.h>
#endif

#ifndef	__STREAM_H__
#include <stream.h>
#endif

#define	0x80000000	HARD_FLOW
#define	0x40000000	SOFT_FLOW
#define	0x00200000	SPACE_PARITY
#define	0x10200000	ODD_PARITY
#define	0x20200000	EVEN_PARITY
#define	0x30200000	MARK_PARITY
#define	0x08000000	TRAP_SIGHUP
#define	0x04000000	TRAP_ERROR
#define	0x02000000	ECHO
#define	0x01000000	EDIT
#define	0x00000000	CHAR8
#define	0x00400000	CHAR7
#define	0x00800000	CHAR6
#define	0x00C00000	CHAR5
#define	0x00100000	SPEED
#define	0x000FFFFF	SPEED_MASK

#define	close_serial(s)	close(s)

IMPORT	int	open_serial PROTO((char *devname, unsigned long options));
IMPORT	void	set_serial PROTO((int dev, unsigned long options));

#endif

