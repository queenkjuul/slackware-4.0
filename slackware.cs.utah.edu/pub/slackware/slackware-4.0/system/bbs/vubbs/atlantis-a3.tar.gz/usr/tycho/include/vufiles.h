/*  Copyright (c) 1993 by Tycho Softworks.  All rights reserved.

	Include file to define directory control structure for standard
	file dialog routines.
*/

#ifndef	__VU_H__
#include <vu.h>
#endif

#ifndef DIR_ENTRIES
#ifdef  __SMALL__
#define DIR_ENTRIES 64
#else
#define DIR_ENTRIES 512
#endif
#endif


typedef struct
{
	short	dir_entries;
	char    *dir_pat;
	CITEM   *dir_fname;
	char    dir_fnbuf[18];
	char    dir_name[128];
	char    dir_prev[128];
#ifdef  __MSDOS__
	char    dir_scan[128];
#endif
	BOOL    dir_flag;
	BOOL    dir_include_flag;
	BOOL    dir_exclude_flag;
	short   dir_group, dir_owner;
	short   dir_attrib;
	char    *dir_list[DIR_ENTRIES + 2];
	char    dir_data;
}   DIR;

PORT(VUStdFilePort);
WINDOW(VUStdFile);


