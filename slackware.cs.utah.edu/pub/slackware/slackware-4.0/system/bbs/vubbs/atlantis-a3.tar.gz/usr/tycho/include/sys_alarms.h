typedef	struct	_alarm
{
	struct	_alarm	*prev, *next;
	time_t	expires;
	int	reset;
	int	repeat;
	int	counter;
	int	seqid;
	void	(*proc) PROTO((struct _alarm *));
}	ALARM;

IMPORT	void	enable_alarms PROTO((void));
IMPORT	void	disable_alarms PROTO((void));

IMPORT	ALARM	*create_alarm PROTO((int time, int repeat, void (*proc) PROTO((struct _alarm *)));
IMPORT	void	destroy_alarm PROTO((ALARM *ref));
IMPORT	void	hold_alarm PROTO((ALARM *ref));
IMPORT	void	cont_alarm PROTO((ALARM *ref));
IMPORT	void	restart_alarm PROTO((ALARM *ref));
IMPORT	void	trigger_alarm PROTO((ALARM *ref));
