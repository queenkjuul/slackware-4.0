#include <sys_socket.h>

enum
{
	NET_IDLE_SERVER = 0,
	NET_LOGIN_USER,
	NET_LOGOUT_USER,
	NET_EXPIRE_USER,
	NET_ANNOUNCE_SERVER,
	NET_LOGOUT_SERVER,
	NET_SELF_SYNC
};

typedef struct
{
	char    u_flag;
	char    u_name[13];
	char    u_node[13];
	char    u_lang[13];
	time_t  u_login;
	time_t  u_expire;
}       NETUSER;

typedef struct
{
	char    n_flag;
	char    n_name[13];
	time_t  n_update;
	struct  in_addr n_addr;
}       NETNODE;

typedef struct
{
	char    ncu_name[13];
	char    ncu_type;
	char    ncu_size;
	char    ncu_used;
	short   ncu_port;
}       NETCHAT_UDP;

typedef struct
{
	char    nc_text[40];
	char    nc_host[13];
	char    nc_type;
	char    nc_size;
	char    nc_userd;
	short   nc_port;
}       NETCHAT;

#define NETCHAT_NAMED           0x01
#define NETCHAT_PASSWORD        0x02
#define NETCHAT_CLOSED          0x04
#define NETCHAT_FIXED           0x08    /* cannot change name */

#define NETUSERS        "/usr/tycho/spool/usage/netusers"
#define NETNODES        "/usr/tycho/spool/usage/netnodes"
#define NETCHATS        "/usr/tycho/spool/usage/netchats"

IMPORT  NETNODE *find_netnode PROTO((STREAM *fp));
IMPORT  NETNODE *lookup_netnode PROTO((char *name));

