#ifndef	__PROTOTYPES_H__
#include <prototypes.h>
#endif

#ifndef	NEWS_SPOOL_DIR
#define	NEWS_SPOOL_DIR	"/usr/spool/news"
#endif

#ifndef	NEWS_LIB_DIR
#define	NEWS_LIB_DIR	"/usr/lib/news"
#endif	

#define	newsdpath(ng)		newspath(ng, 0l)

char	*newspath PROTO((char *newspath, long id));



