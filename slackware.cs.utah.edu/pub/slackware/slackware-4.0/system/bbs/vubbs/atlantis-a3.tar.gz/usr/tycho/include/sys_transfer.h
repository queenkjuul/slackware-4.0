#include <sys_config.h>

IMPORT	int		get_protocol PROTO((CONFIG *cfg, char *proto));
IMPORT	int		download_file PROTO((char *fname));
IMPORT	int		upload_file PROTO((char *fname));
IMPORT	FILE	*pipe_download PROTO((char *name));

IMPORT	int		get_archive PROTO((CONFIG *cfg, char *archiver));
IMPORT	int		get_extract PROTO((CONFIG *cfg, char *archiver));
IMPORT	int		batch_archive PROTO((char *aname, char **flist));
IMPORT	int		burst_archive PROTO((char *aname));

