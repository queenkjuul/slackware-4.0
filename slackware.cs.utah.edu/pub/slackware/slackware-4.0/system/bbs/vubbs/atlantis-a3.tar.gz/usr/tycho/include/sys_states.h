#ifndef	__PROTOTYPES_H__
#include <prototypes.h>
#endif

/*	state transition table	*/

struct	_EVENTTAB;
struct	_STATETAB;

typedef	struct	_EVENTTAB
{
	int		event_id;
	struct	_STATETAB	*state_id;	
} EVENTTAB;

typedef	struct	_STATETAB
{
	struct		_STATETAB	*parent;		
	EVENTTAB	*events;
	int			(*handler)();
}	STATETAB;

#define	identify_state(table, ptr)	((int)(ptr - table))

IMPORT	STATETAB	*switch_state PROTO((STATETAB *state, int event));


