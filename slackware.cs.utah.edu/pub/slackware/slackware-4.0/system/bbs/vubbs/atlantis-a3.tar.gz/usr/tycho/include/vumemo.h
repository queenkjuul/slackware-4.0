
#ifndef	__VU_H__
#include <vu.h>
#endif

typedef	struct
{
	short	edit_left;
	char	edit_move_v;
	char	edit_move_h;
	int		edit_base;
	int		edit_size;
	int		edit_mark_start;
	int		edit_mark_stop;
	char	**edit_idx;
	char	*edit_last;
}	*EDITOR;

typedef struct
{
	short   memo_mark;                  /* editor mark line  */
	short   memo_char;                  /* editor cursor position */
	short   memo_width;                 /* editor width of line */
	short   memo_space;                 /* last space field */
	int     memo_base;                  /* current base in list */
	int     memo_size;                  /* size of memo list */
	char    **memo_idx;                 /* pointers to text  */
}   *MEMO;

PORT(VUBrowsePort);

IMPORT  int PASCAL  VUBuildBrowseList PROTO((char **ptrs, char *text, int max));

