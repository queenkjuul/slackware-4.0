#define	CALLS	"/usr/tycho/spool/calls/active"
#define	CALLARC	"/usr/tycho/spool/calls/archive/"

typedef	struct
{
	char	c_type;
	char	c_date[8];
	char	c_time[6];
	char	c_duration[6];
	char	c_trunk[5];
	char	c_extension[5];
	char	c_telephone[14];
	char	c_account[8];
	char	c_cityst[30];
	char	c_name[30];
	char	c_newline;
}	CALL;
