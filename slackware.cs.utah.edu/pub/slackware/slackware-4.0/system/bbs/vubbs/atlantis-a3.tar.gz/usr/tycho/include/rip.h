/* in libvu, base VU generic support */

extern	BOOL	rip_mode;

IMPORT	BOOL	PASCAL	RipStartup PROTO((TERMDEF *term));
IMPORT	void	PASCAL	RipShutdown PROTO((void));
IMPORT	int	PASCAL	RipResetDisplay PROTO((void));	/* reset for suspend */
IMPORT	int	PASCAL	RipUpdateRegions PROTO((void)); /* map mouse regions */

/* remaining functions in librip, for graphic viewport operations */

IMPORT	void	PASCAL	RipViewport PROTO((RECT *rc));	/* map rect to viewport */
	