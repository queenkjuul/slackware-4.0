#ifndef	__FIXED_H__
#define	__FIXED_H__

#ifndef	__PROTOTYPES_H__
#include <prototypes.h>
#endif

#ifndef	__PAGER_H__
#include <sys_pager.h>
#endif


typedef	struct
{
	PAGE	m_page;
	int		m_count;
	char	m_msgs[0];
}	MSGPAGE;

typedef	struct
{
	PAGER	q_pager;
	int		q_headpos;
	int		q_tailpos;
}	MSGQUE;

#define	destroy_msgque(p)	destroy_pager((PAGER *)p)
#define	realloc_msgque(p)	realloc_pager((PAGER *)p)

IMPORT	MSGQUE	*create_msgque PROTO((int pagesize, int maxpages));
IMPORT	PTR		next_msg PROTO((MSGQUE *msgque, int size));
IMPORT	PTR		last_msg PROTO((MSGQUE *msgque, int size));
IMPORT	PTR		first_msg PROTO((MSGQUE *msgque));
#endif
