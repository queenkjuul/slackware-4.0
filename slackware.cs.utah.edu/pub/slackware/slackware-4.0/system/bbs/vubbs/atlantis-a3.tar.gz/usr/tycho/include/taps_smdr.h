#ifndef	  __STREAM_H__
#include <sys_stream.h>
#endif

#define	close_smdr(s)	close_socket(s)
STREAM	*open_smdr PROTO((char *pbxid));



