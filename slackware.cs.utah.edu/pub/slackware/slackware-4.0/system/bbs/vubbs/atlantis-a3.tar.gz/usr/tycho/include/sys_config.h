/*	$Header$
	Copyright (c) 1993 by Tycho Softworks.  All rights reserved.

Created by:

	David Sugar, Tycho Softworks
   	E-Mail: dyfet@aol.com, BBS: 201-858-3429

Synopsis:

	Accesses system configuration database files.  These files are generally
	kept in a single global directory and have entries grouped by sections.
	Each section is marked with a special header ([header-name]).  Blank
	lines and comments are ignored.

History:

	$Log$
*/

#ifndef	__CONFIG_H__
#define	__CONFIG_H__

#include <stdio.h>

#ifndef	__PROTOTYPES_H__
#include <prototypes.h>
#endif

typedef	struct
{
	char	acs_flag;
	char	acs_id[31];
	char	acs_member[32];
	int		acs_uid;
}	ACS;

typedef	struct
{
	char	cfg_name[16];
	int		cfg_flag;
	FILE	*cfg_fp;
	char	cfg_lbuf[0];
}	CONFIG;

IMPORT	CONFIG *open_config PROTO((char *name));
IMPORT	CONFIG *user_config PROTO((CONFIG *cfg, char *name));
IMPORT	char	*first_config PROTO((CONFIG *cfg));
IMPORT	char	*this_config PROTO((CONFIG *cfg));
IMPORT	char	*next_config PROTO((CONFIG *cfg));
IMPORT	int	seek_config PROTO((CONFIG *cfg, char *name));
IMPORT	char *read_config PROTO((CONFIG *cfg));
IMPORT	void close_config PROTO((CONFIG *cfg));
IMPORT	char *get_config PROTO((CONFIG *cfg, char *option));
IMPORT	int add_bookmark PROTO((char *bookmark));
IMPORT	long update_since PROTO((char *fileset, char *entry, long value));
#endif
