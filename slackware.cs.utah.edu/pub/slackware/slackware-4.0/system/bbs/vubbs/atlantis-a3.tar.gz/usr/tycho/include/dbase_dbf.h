#ifndef	__DBF__

#ifndef	 __STREAM__
#include <sys_stream.h>
#endif

#define	DBF_SHARED	0
#define	DBF_EXCLUSIVE	1
#define	DBF_SYNC	2	/* locked record access */

#define	DBF_MAX_FIELDS	128
#define	dbf_fields(dbf)	 ((dbf->db_header.db_hdrsize - 33) / 32)
#define	dbf_records(dbf) (dbf->db_header.db_records)
#define	dbf_record(dbf)	 (dbf->db_recbuf)
#define	dbf_recpos(dbf)	 (dbf->db_header.db_hdrsize + (dbf->db_record * dbf->db_header.db_recsize))
#define	dbf_recsize(dbf) (dbf->db_header.db_recsize)

typedef	struct
{
	unsigned 	char	db_flag;
	unsigned	char	db_year;
	unsigned	char	db_month;
	unsigned	char	db_day;
	unsigned	long	db_records;
	unsigned	short	db_hdrsize;
	unsigned	short	db_recsize;
	unsigned	char	db_unused[20];
}	DBFHDR;

typedef	struct
{
	char	f_name[11];
	char	f_type;
	char	f_unused0[4];
	unsigned	char	f_length;
	unsigned	char	f_decimal;
	char	*f_offset;
	PTR	*f_link;
	char	f_unused1[14 - sizeof(char *) - sizeof(PTR)];	
}	DBFIELD;

typedef	struct
{
	short	_pid;
	char	_time[3];
	char	_date[3];
	char	_owner[0];
}	DBLOCK;

typedef	struct
{
	int	fd;
	int	mode;
	char	path[128];
	char	db_exclusive;	/* exclusive access required */
	char	db_sync;	/* sync/auto lock records */
	char	db_update;	/* update current record flag */
	char	db_skip_delete;	/* skip deleted records	      */
	long	db_record;
	PTR	db_memo;
	DBFIELD	*db_lock;
	DBFHDR	db_header;
	DBFIELD	db_fields[DBF_MAX_FIELDS];
	char	db_recbuf[1];	/* marker first */
}	DBF;

extern	DBF	*_create_dbf;

#define	DEFINE_DBASE(name, mode)	if(NULL !=(_create_dbf = create_dbf(name, mode))) {
#define	FIELD_CHAR(name, size)		define_dbfield(_create_dbf, name, 'C', size, 0);
#define	FIELD_NUMBER(name, size, dec)	define_dbfield(_create_dbf, name, 'N', size, dec);
#define	FIELD_DATE(name)		define_dbfield(_create_dbf, name, 'D', 8, 0);
#define	FIELD_BOOL(name)		define_dbfield(_create_dbf, name, 'L', 1, 0);
#define	FIELD_MEMO(name)		define_dbfield(_create_dbf, name, 'M', 10, 0);
#define	FIELD_LOCK(size)		define_dbfield(_create_dbf, "_dbaselock", 'C', size + sizeof(DBLOCK), 0);  
#define	ENDDEF_DBASE()			close_dbf(_create_dbf); }

#define	isdel_dbf(dbf)	(dbf->db_recbuf[0] == '*')
#define	tell_dbf(dbf)	(dbf->db_record + 1)

/*	dbf specific operations		*/

DBF	*create_dbf PROTO((char *name, int mode));
DBF	*update_dbf PROTO((DBF *db, char *date));
DBF	*open_dbf PROTO((char *name, int exclusive));
void	cancel_dbf PROTO((DBF *db));
void	flush_dbf PROTO((DBF *db));
void	close_dbf PROTO((DBF *db));
char	*date_dbf PROTO((DBF *db));
DBF	*append_dbf PROTO((DBF *db, int count));
DBF	*resize_dbf PROTO((DBF *db, long size));
DBF	*seek_dbf PROTO((DBF *db, long recno, int mode));
DBF	*blank_dbf PROTO((DBF *db));
DBF	*delete_dbf PROTO((DBF *db));
DBF	*lock_dbf PROTO((DBF *db));
DBF	*ulock_dbf PROTO((DBF *db));
DBF	*dup_dbf PROTO((DBF *dest, DBF *src));
DBF	*get_dbf PROTO((DBF *dbf, char *buf));
DBF	*put_dbf PROTO((DBF *dbf, char *buf));
int	gets_dbf PROTO((DBF *dbf, char *fldname, char *buf));
int	puts_dbf PROTO((DBF *dbf, char *fldname, char *buf));
DBLOCK	*change_dbf PROTO((DBF *dbf));
void	cancel_dbf PROTO((DBF *dbf));
void	end_dbf PROTO((DBF *dbf));
DBLOCK	*begin_dbf PROTO((DBF *dbf));

/*	field specific operations	*/

DBFIELD	*define_dbfield PROTO((DBF *db, char *fname, char ftype, int len, int dec));
DBFIELD	*get_dbfield PROTO((DBF *db, char *fldname));
DBFIELD *put_dbfield PROTO((DBF *db, DBFIELD *fld));
int	cmp_dbfield PROTO((DBFIELD *fld, char *mask));
int	gets_dbfield PROTO((DBFIELD *fld, char *buf));
int	puts_dbfield PROTO((DBFIELD *fld, char *buf));

/*	special header operations	*/

void	lockhdr_dbf PROTO((DBF *db));
void	ulockhdr_dbf PROTO((DBF *db));
void	bwrite_dbf PROTO((int fd, unsigned long val, int size));
unsigned long bread_dbf PROTO((int fd, int size));

#endif
