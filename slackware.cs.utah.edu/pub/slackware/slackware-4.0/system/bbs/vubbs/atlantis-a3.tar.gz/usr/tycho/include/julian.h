/*  Julian date conversion for VU database storage. */

#ifndef	__PROTOTYPES_H__
#include <prototypes.h>
#endif

typedef long    julian_t;

#define J1900   2415021L
#define J1980   2444240L

IMPORT  struct  tm  * PASCAL julian PROTO((julian_t juldate));  
IMPORT  julian_t    PASCAL mkjulian PROTO((struct tm *date));


