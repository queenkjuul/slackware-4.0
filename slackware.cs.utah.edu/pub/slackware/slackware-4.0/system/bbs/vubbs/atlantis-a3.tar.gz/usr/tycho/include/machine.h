/*	$Header$
	Copyright (c) 1994 by Tycho Softworks.  All rights reserved.

Created by:

	David Sugar, Tycho Softworks
    E-Mail: dyfet@aol.com, BBS: 201-858-3429

Synopsis:

History:

	$Log$
*/

#ifndef	__MACHINE_H__
#define	__MACHINE_H__	

#ifndef	__PROTOTYPES_H__
#include <prototypes.h>
#endif

typedef	unsigned char	BYTE;
typedef	unsigned short	WORD;
typedef unsigned long	LONG;

#define	SWAP_WORD(n)
#define	SWAP_LONG(n)

IMPORT	void	swap_word PROTO((WORD *obj));
IMPORT	void	swap_long PROTO((LONG *obj));

#endif
