#ifndef	__MACROS_H__
#define	__MACROS_H__

#ifdef	abs
#undef	abs
#endif

#define abs(x) ((x)<0?-(x):(x))
#define max(a,b) ((a)>(b)?(a):(b))
#define min(a,b) ((a)<(b)?(a):(b))
#define	qdif(h, t, q)	((h)>(t)?(q)-(h)+(t):(t)-(h))
#define offsetof(s_type, memb) ((size_t) ((char *)&((s_type *)0)->memb - (char *)0))

#define	ABS_INT	((unsigned)(-1))
#define	MAX_INT	(ABS_INT / 2)	
#define	MIN_INT	(-1 - MAX_INT)

#define	ABS_SHORT	((unsigned short)(-1))
#define	MAX_SHORT	((short)(ABS_INT / (short)2))	
#define	MIN_SHORT	((short)-1 - MAX_INT)

#define	ABS_LONG	((unsigned long)(-1))
#define	MAX_LONG	((long)(ABS_INT / (long)2))	
#define	MIN_LONG	((long)-1 - MAX_INT)

#endif
