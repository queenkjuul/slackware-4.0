#ifndef	 __PROTOTYPES__
#include <prototypes.h>
#endif

typedef	struct
{
	int	dbt_fd;
	int	dbt_psize;
	long	dbt_pages;
	char	dbt_buf[0];
}	DBT;

#define	dbt_buffer(dbt)	(dbt->dbt_buf)

extern	int	dbt_pagesize;

#define	size_dbt(dbt, pos)	read_dbt(dbt, NULL, pos)

DBT	*create_dbt PROTO((char *name, int mode));
DBT	*open_dbt PROTO((char *name));
void	close_dbt PROTO((DBT *dbt));
int	append_dbt PROTO((DBT *dbt, char *buf));
int	read_dbt PROTO((DBT *dbt, char *buf, long pos));
int	write_dbt PROTO((DBT *dbt, char *buf, long pos));

