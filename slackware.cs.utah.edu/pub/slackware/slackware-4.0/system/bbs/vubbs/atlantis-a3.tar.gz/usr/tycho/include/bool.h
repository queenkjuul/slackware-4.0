/*	$Header$
	Copyright (c) 1994 by Tycho Softworks.  All rights reserved.

Created by:

	David Sugar, Tycho Softworks
    E-Mail: dyfet@aol.com, BBS: 201-858-3429

Synopsis:

History:

	$Log$
*/

#ifndef	__BOOL_H__
#define	__BOOL_H__	

typedef	char bool;
typedef	int	BOOL;

#define	TRUE	1
#define	FALSE	0
#endif

