/*	Copyright (c) 1993 by Tycho Softworks.  All rights reserved.

	Defines all structures related to spying under VU.
*/
#ifdef	QNX

typedef	struct
{
	unsigned	char	spy_cmd;
	unsigned	short	spy_segment;
	unsigned	short	spy_offset;
	unsigned	short	spy_rows,spy_cols;
	unsigned	spy_tid;
}	VUSPY;

#define	SPY_CLR	0
#define	SPY_SET	1
#define	SPY_GET	2

#define	SPY_NAME	"vu_spy"

#endif

