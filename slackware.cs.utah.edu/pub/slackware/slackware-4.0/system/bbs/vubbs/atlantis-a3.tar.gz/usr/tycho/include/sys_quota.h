#include <sys_socket.h>

enum
{
	LOGIN_NOT_QUOTA_LIMITED = 0,
	LOGIN_TIME_QUOTA_EXPIRED,
	LOGIN_COUNT_QUOTA_EXPIRED
};

IMPORT	int	get_time_quota PROTO((char *userid));
IMPORT	int	get_login_quota PROTO((void));	
