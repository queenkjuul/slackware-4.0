/*	Copyright (c) 1993 by Tycho Softworks.  All rights reserved.

	Defines structure of help file index entries.
*/

#ifndef __VU_H__
#include <vu.h>
#endif

typedef	struct
{
	unsigned	short	help_resid;
	unsigned	short	help_event;
	char				help_title[32];
	long				help_offset;
	short				help_length;
}	HELP_INDEX;

typedef	struct
{
	unsigned	short	help_resid;
	unsigned	short	help_event;
	char				*help_title;
	char				*help_text;
}	HELP_MEMIDX;

