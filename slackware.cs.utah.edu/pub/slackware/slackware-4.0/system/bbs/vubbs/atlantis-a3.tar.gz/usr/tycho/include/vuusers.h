/* managed by usersd. */

typedef	struct
{
	time_t	login;		/* login time (0 = empty) */
	char	line[9];	/* login line 	 */
	char	node[17];	/* login node id */
	char	user[13];	/* login user id */
	char	lang[16];	/* LANG setting	*/
	char	menu[16];	/* VU_MENU setting */
	char	other[32];	/* future use	*/
}	USERS;	

