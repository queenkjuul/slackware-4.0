#include <stdio.h>
#ifndef	__VU_H__
#include <vu.h>
#endif

WINDOW(AdminDesktop);
WINDOW(SetupProfile);
WINDOW(SetupDisplay);
WINDOW(SetupAddress);
WINDOW(SetupXferProtocol);
WINDOW(SetupXferNewline);
WINDOW(SetupXferArchive);
WINDOW(SetupDesktop);
WINDOW(SetupPassword);


int		create_setup PROTO((char *path, char *title));
FILE	*rewrite_setup PROTO((char *path));
void	close_setup PROTO((FILE *fp));
FILE	*begin_rewrite PROTO((char *pwdfile, char *id));
void	end_rewrite PROTO((char *pwdfile));

