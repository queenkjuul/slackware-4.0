/*	$Header$
	Copyright (c) 1994 by Tycho Softworks.  All rights reserved.

Created by:

	David Sugar, Tycho Softworks
    E-Mail: dyfet@aol.com, BBS: 201-858-3429

Synopsis:

History:

	$Log$
*/


#ifndef	__PROTOTYPES_H__	
#define	__PROTOTYPES_H__

#ifdef	QNX
#ifdef	C86
#define	__ANSI__
#endif
#endif

#ifndef	__ANSI__
#ifdef	__STDC__
#if		__STDC__ != 0
#define	__ANSI__
#endif
#endif
#endif

#ifdef	PROTO
#undef	PROTO
#endif

#ifdef	IMPORT
#undef	IMPORT
#endif

#ifdef	FORWARD
#undef	FORWARD
#endif

#ifdef	__ANSI__
#define	PROTO(s)	s
#define	IMPORT
#define	FORWARD		static
typedef	void *		PTR;
#else
#define	PROTO(s)	()
#define	IMPORT		extern
#define	FORWARD		static
typedef	char *		PTR;
#endif

#ifndef	PASCAL
#define	PASCAL
#endif

#ifdef	__ANSI__
#define	__STDARG__
#else
#ifdef	COHERENT
#define	__STDARG__
#endif
#endif

#endif

