extern	int	visor_key;
extern	char visor_topic[33];

WINDOW(VUVisorTopic);
WINDOW(VUVisorIndex);
PORT(VUVisorTPort);
PORT(VUVisorIPort);
