/*	Diskette based operations through VU interface.
*/

#ifndef __VU_H__
#include <vu.h>
#endif

#define	DISK_EXIT_SUCCESS 	0
#define	DISK_EXIT_FAILURE	1
#define	DISK_EXIT_ABORTED	2

typedef	struct
{
	char	fd_device[8];
	char	fd_text[40];
	char	fd_skip;
	char	fd_heads;
	short	fd_tracks;
	short	fd_sectors;
	short	fd_block;
	short	fd_devno;
}	FDFORMAT;

typedef	struct
{
    BOOL	dsk_timer_save;
	short	dsk_status;
	short	dsk_track;
	long	dsk_block;
}	*	DISKOPTS;

extern	FDFORMAT	fd_fmttab[];
extern	int			fd_fmtcnt;
extern	char		fd_fmt_title[];
extern	char		fd_fmt_text[];
extern	char		fd_fmt_format[];

WINDOW(VUFormatDisk);
PORT(VUFormatDiskPort);



