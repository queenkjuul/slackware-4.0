/*	Copyright (c) 1993 by Tycho Softworks.  All rights reserved.

	Defines VU site information record.
*/
typedef	struct
{
	char	site_name[33];
	char	site_organization[65];
	char	site_phone[17];
	char	site_owner[33];
	int		site_country;
	char	site_node[13];
	char	site_domain[33];
}	SITE;

IMPORT	SITE	*	PASCAL VUSiteInfo P((void));

