#ifndef	__FIXED_H__
#define	__FIXED_H__

#ifndef	__PROTOTYPES_H__
#include <prototypes.h>
#endif

#ifndef	__PAGER_H__
#include <sys_pager.h>
#endif

typedef	struct
{
	PAGER	t_pager;
	int		t_tabsize;
	int		t_lasttab;
	PTR		t_free;
}	TABLE;

#define	destroy_table(p)	destroy_pager((PAGER *)p)

IMPORT	TABLE	*create_table PROTO((int tabsize, int tabperpage, int maxpages));
IMPORT	void	realloc_table PROTO((TABLE *table));
IMPORT	PTR		request_table PROTO((TABLE *table));
IMPORT	void	release_table PROTO((TABLE *table, PTR buf));

#endif
