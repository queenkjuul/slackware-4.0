
#define	_COM_CHR5	0
#define	_COM_CHR6	1

#define	_COM_FOSSIL_ON	4
#define	_COM_FOSSIL_OFF	5
#define	_COM_X00_ON		0x1c
#define	_COM_X00_OFF	0x1d
#define	_COM_19200		_COM_110
#define	_COM_38400		_COM_150

#define	_COM_PS2_INIT	4

#define	_COM_FOSSIL_PURGE	0x0a
#define	_COM_FOSSIL_DTR		0x06
#define	_COM_FOSSIL_FLOW	0x0f

#define	_COM_HW_FLOW		0x02
#define	_COM_SW_FLOW		0x09

typedef	enum
{
	PORT,
	BIOS,
	X00,
	FOSSIL,
	PS2
}	PORT_TYPE;	

extern	PORT_TYPE	port_type;

extern	int	portid;
extern  int ser_data;           /* Uart data register */
extern  int ser_stat;           /* Uart line-status register */
extern  int ser_ctrl;           /* Uart line-control register */
