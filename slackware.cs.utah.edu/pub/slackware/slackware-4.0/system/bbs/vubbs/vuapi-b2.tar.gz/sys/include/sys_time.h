#include <time.h>

#ifndef	__PROTOTYPES_H__
#include <prototypes.h>
#endif

IMPORT	time_t	getudate PROTO((char *s));
IMPORT	char	*usdate PROTO((time_t *));
IMPORT	char	*umdate PROTO((time_t *));
IMPORT	char	*uldate PROTO((time_t *));


