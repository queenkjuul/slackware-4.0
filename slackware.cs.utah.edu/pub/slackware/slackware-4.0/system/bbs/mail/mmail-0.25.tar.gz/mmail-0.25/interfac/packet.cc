/*
 * MultiMail offline mail reader
 * packet list window, vanity plate

 Copyright (c) 1996 Kolossvary Tamas <thomas@vma.bme.hu>
 Copyright (c) 1997 John Zero <john@graphisoft.hu>
 Copyright (c) 1999 William McBrine <wmcbrine@clark.net>

 Distributed under the GNU General Public License.
 For details, see the file COPYING in the parent directory. */

#include "interfac.h"

void Welcome::MakeActive()
{
	window = new ShadowedWin(6, 50, 2, C_WBORDER);
	window->attrib(C_WELCOME1);
	window->put(1, 7,
		"Welcome to " MM_NAME " Offline Reader!");
	window->attrib(C_WELCOME2);
	window->put(3, 2,
		"Copyright (c) 1999 William McBrine, Kolossvary"); 
	window->put(4, 7,
		"Tamas, Toth Istvan, John Zero, et al.");
	window->touch();
}

void Welcome::Delete()
{
	delete window;
}

PacketListWindow::PacketListWindow()
{
	sorttype = mm.resourceObject->getInt(PacketSort);
	newList();
}

PacketListWindow::~PacketListWindow()
{
	delete packetList;
}

void PacketListWindow::newList()
{
	packetList = new file_list(mm.resourceObject->get(PacketDir),
		sorttype);

	if (!NumOfItems())
		error();
}

void PacketListWindow::error()
{
	char tmp[512];

	sprintf(tmp, "No packets found.\n\n"
		"Please place any packets to be read in:\n%s",
		mm.resourceObject->get(PacketDir));
	fatalError(tmp);
}

void PacketListWindow::MakeActive()
{
	welcome.MakeActive();
	const int stline = 9;
	list_max_y = LINES - (stline + 9);
	list = new InfoWin(list_max_y + 3, 50, stline, C_PBBACK);
	list->attrib(C_PHEADTEXT);
	list->put(1, 3, "Packet            Size    Date");
	list->touch();
	DrawAll();
}

int PacketListWindow::NumOfItems()
{
	return packetList->getNoOfFiles();
}

void PacketListWindow::Delete()
{
	delete list;
	welcome.Delete();
}

void PacketListWindow::oneLine(int i)
{
	char *tmp = list->lineBuf;

	packetList->gotoFile(position + i);

	const char *tmp2 = packetList->getName();
	time_t tmpt = packetList->getDate();

	strcpy(tmp, "          ");

	for (int j = 2; *tmp2 && (*tmp2 != '.') && (j < 10); j++)
		tmp[j] = *tmp2++;

	sprintf(&tmp[10], "%-4.4s%12u", tmp2,
		(unsigned) packetList->getSize());

	strftime(&tmp[26], 24, "  %b %d %Y  %H:%M  ",
		localtime(&tmpt));

	DrawOne(i, C_PLINES);
}

bool PacketListWindow::oneSearch(int x, const char *item)
{
	packetList->gotoFile(x);
	return !(!searchstr(packetList->getName(), item));
}

void PacketListWindow::Select()
{
	packetList->gotoFile(active);
}

void PacketListWindow::extrakeys(int key)
{
	switch (key) {
	case 'K':
		char tmp[128];

		Select();
		sprintf(tmp, "Do you really want to delete %s?",
			packetList->getName());
		if (interface->WarningWindow(tmp))
			packetList->kill();
		if (NumOfItems())
			interface->changestate(packetlist);
		else
			error();
		break;
	case MM_MINUS:
		Move(UP);
		Draw();
		break;
	case MM_PLUS:
		Move(DOWN);
		Draw();
		break;
	case 'S':
	case '$':
		packetList->resort();
		sorttype = !sorttype;
		DrawAll();
		break;
	case 'U':
		delete packetList;
		newList();
		DrawAll();
	}
}

int PacketListWindow::OpenPacket()
{
	Select();
	return mm.selectPacket(packetList->getName());
}
