/*
 * MultiMail offline mail reader
 * some routines common to both sides

 Copyright (c) 1999 William McBrine <wmcbrine@clark.net>

 Distributed under the GNU General Public License.
 For details, see the file COPYING in the parent directory. */

#include "interfac.h"
#include "mysystem.h"

extern void fatalError(const char *description);

int mysystem(const char *cmd)
{
	if (!isendwin())
		endwin();
#if defined (__PDCURSES__) && !defined (XCURSES)
	// Restore original cursor
	PDC_set_cursor_mode(curs_start, curs_end);
#endif
	int result = system(cmd);
	keypad(stdscr, TRUE);
#if defined (__PDCURSES__) && defined (__RSXNT__)
	typeahead(-1);
#endif
	return result;
}

void mytmpnam(char *name)
{
/* EMX doesn't return an absolute pathname from tmpnam(), so we create one
   ourselves. Otherwise, use the system's version, and make sure it hasn't
   run out of names.
*/
#ifdef __EMX__
	const char *tmp = getenv("TEMP");

	if (!tmp) {
		tmp = getenv("TMP");
		if (!tmp)
			tmp = mm.resourceObject->get(mmHomeDir);
	}
	sprintf(name, "%s/%s", tmp, tmpnam(0));
#else
	if (!tmpnam(name))
		fatalError("Out of temporary filenames");
#endif
}
