/*
 * MultiMail offline mail reader
 * protos for mysystem.cc

 Copyright (c) 1999 William McBrine <wmcbrine@clark.net> 

 Distributed under the GNU General Public License.
 For details, see the file COPYING in the parent directory. */

/* Why is this a separate file? Mainly so it can be included by source 
   files under mmail/, without also including curses.h. */

#ifndef MYSYSTEM_H
#define MYSYSTEM_H

extern int mysystem(const char *);
extern void mytmpnam(char *);

#endif
