/*
 * MultiMail offline mail reader
 * conversion tables ISO 8859-1 <-> IBM codepage 437

 Copyright (c) 1996 Peter Karlsson <dat95pkn@idt.mdh.se>,
                    Toth Istvan <stoty@vma.bme.hu>
 Copyright (c) 1999 William McBrine <wmcbrine@clark.net>

 Distributed under the GNU General Public License.
 For details, see the file COPYING in the parent directory. */

#ifndef CONVTAB_H
#define CONVTAB_H

extern bool isoConsole; // ISO8859-1 <--> CP437 (DOS) conversion?

extern const char *dos2isotab;
extern const char *iso2dostab;

#define CC_ISOTO437	1
#define CC_437TOISO   	2	
extern char *charconv_in(char *);
extern char *charconv_out(char *);
extern char *letterconv_in(char *);
extern char *letterconv_out(char *);
extern char *areaconv_in(char *);
extern char *areaconv_out(char *);

#endif
