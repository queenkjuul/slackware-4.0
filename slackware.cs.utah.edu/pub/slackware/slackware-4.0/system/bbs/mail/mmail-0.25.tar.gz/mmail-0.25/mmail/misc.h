/*
 * MultiMail offline mail reader
 * miscellaneous routines (global)

 Copyright (c) 1996 Toth Istvan <stoty@vma.bme.hu>
 Copyright (c) 1999 William McBrine <wmcbrine@clark.net>

 Distributed under the GNU General Public License.
 For details, see the file COPYING in the parent directory. */

#ifndef MISC_H
#define MISC_H

char *cropesp(char *);
char *unspace(char *);
char *strdupplus(const char *);
const char *findBaseName(const char *);
char *stripre(char *);
void clearDirectory(const char *);
const char *searchstr(const char *, const char *);
const char *fromAddr(const char *);
const char *sysname();

#if defined (__MSDOS__) || defined (__EMX__)
extern const char *canonize(const char *);
#else
# define canonize(x) x
#endif

void fatalError(const char *);	// actually in ../interfac/main.cc!

#endif
