/*
 * MultiMail offline mail reader
 * tagline selection, editing

 Copyright (c) 1996 Kolossvary Tamas <thomas@vma.bme.hu>
 Copyright (c) 1999 William McBrine <wmcbrine@clark.net>

 Distributed under the GNU General Public License.
 For details, see the file COPYING in the parent directory. */

#include "interfac.h"

tagline::tagline(const char *tag)
{
	if (tag)
		strncpy(text, tag, TAGLINE_LENGTH);
	next = 0;
}

TaglineWindow::TaglineWindow()
{
	nodraw = true;
	NumOfTaglines = 0;
}

TaglineWindow::~TaglineWindow()
{
	DestroyChain();
}

void TaglineWindow::MakeActive()
{
	nodraw = false;

	srand((unsigned) time(0));

	list_max_y = LINES - 15;
	list = new InfoWin(LINES - 10, COLS - 2, 5, C_TBBACK,
		"Select tagline", C_TTEXT, 5, 1);

	int x = (COLS - 2) / 3 + 1;
	int y = list_max_y + 1;

	list->attrib(C_TKEYSTEXT);
	list->horizline(y, COLS - 4);
	list->put(++y, 2, "Q");
	list->put(y, x, "R");
	list->put(y, x * 2, "Enter");
	list->put(++y, 2, "K");
	list->put(y, x, "E");
	list->put(y, x * 2, " /, .");
	list->attrib(C_TTEXT);
	list->put(y, 3, ": Kill current tagline");
	list->put(y, x + 1, ": manual Enter tagline");
	list->put(y, x * 2 + 5, ": search / next");
	list->put(--y, 3, ": don't apply tagline");
	list->put(y, x + 1, ": Random select tagline");
	list->put(y, x * 2 + 5, ": apply tagline");
	DrawAll();
}

void TaglineWindow::Delete()
{
	delete list;
	nodraw = true;
}

void TaglineWindow::extrakeys(int key)
{
	switch (key) {
	case '\r':
	case '\n':
		if (NumOfTaglines)
			interface->letterwindow.set_Tagline(
				taglist[active]->text);
		break;
	case 'E':
		EnterTagline();
		break;
	case 'R':
		RandomTagline();
		break;
	case 'K':
		if (highlighted)
			kill();
		break;
	case MM_PLUS:
		Move(DOWN);
		Draw();
		break;
	case MM_MINUS:
		Move(UP);
		Draw();
	}
}

void TaglineWindow::RandomTagline()
{
	int i = rand() / (RAND_MAX / NumOfTaglines);

	Move(HOME);
	for (int j = 1; j <= i; j++)
		Move(DOWN);
	DrawAll();
}

void TaglineWindow::EnterTagline(const char *tag)
{
	FILE *fd;
	char newtagline[TAGLINE_LENGTH + 1];
	int y;

	Move(END);
	if (NumOfTaglines >= list_max_y) {
		y = list_max_y;
		position++;
	} else
		y = NumOfTaglines + 1;
	active++;

	if (!nodraw) {
		NumOfTaglines++;
		Draw();
		NumOfTaglines--;
	} else {
		list = new InfoWin(5, COLS - 2, 10, C_TBBACK);
		list->attrib(C_TTEXT);
		list->put(1, 1, "Enter new tagline:");
		list->update();
	}

	strcpy(newtagline, tag ? tag : "");

	if (list->getstring(nodraw ? 2 : y, 1, newtagline,
	    TAGLINE_LENGTH, C_TENTER, C_TENTERGET)) {

		cropesp(newtagline);

		if (newtagline[0]) {

			//check dupes; also move curr to end of list:
			bool found = false;

			curr = &head;
			while (curr->next && !found) {
				curr = curr->next;
				found = !strcmp(newtagline, curr->text);
			}

			if (!found) {
				curr->next = new tagline(newtagline);
				if ((fd = fopen(tagname, "at"))) {
					fputs(newtagline, fd);
					fputc('\n', fd);
					fclose(fd);
				}
				NumOfTaglines++;

				delete[] taglist;
				MakeChain();
			} else
				interface->nonFatalError("Already in file");
		}
	}
	Move(END);

	if (!nodraw) {
		DrawAll();
		doupdate();
	} else
		list->update();
}

void TaglineWindow::kill()
{
	if (interface->WarningWindow("Remove this tagline?")) {
		if (active)
			taglist[active - 1]->next = highlighted->next;
		else
			head.next = highlighted->next;

		if (position)
			position--;

		NumOfTaglines--;

		delete highlighted;
		delete[] taglist;

		MakeChain();

		WriteFile(false);
	}
	Delete();
	MakeActive();
}

bool TaglineWindow::ReadFile()
{
	FILE *fd;
	char newtag[TAGLINE_LENGTH + 1];
	bool flag = (fd = fopen(tagname, "rt"));

	if (flag) {
		bool end = false;

		curr = &head;
		while (!end) {
			end = !fgets(newtag, sizeof newtag, fd);

			if (!end) {
				strtok(newtag, "\n");
				curr->next = new tagline(newtag);
				curr = curr->next;
				NumOfTaglines++;
			}
		}
		fclose(fd);
	}
	return flag;
}

void TaglineWindow::WriteFile(bool message)
{
	FILE *tagx;

	if (message)
		printf("Creating %s...\n", tagname);

	if ((tagx = fopen(tagname, "wt"))) {
		for (int x = 0; x < NumOfTaglines; x++) {
			fputs(taglist[x]->text, tagx);
			fputc('\n', tagx);
		}
		fclose(tagx);
	}
}

void TaglineWindow::MakeChain()
{
	taglist = new tagline *[NumOfTaglines + 1];

	if (NumOfTaglines) {
		curr = head.next;
		int c = 0;
		while (curr) {
			taglist[c++] = curr;
			curr = curr->next;
		}
	}

	taglist[NumOfTaglines] = 0;	// hack for EnterTagline
}

void TaglineWindow::DestroyChain()
{
	while (NumOfTaglines)
		delete taglist[--NumOfTaglines];
	delete[] taglist;
}

void TaglineWindow::oneLine(int i)
{
	int z = position + i;
	curr = (z < NumOfTaglines) ? taglist[z] : 0;

	if (z == active)
		highlighted = curr;

	sprintf(list->lineBuf, "%-76.76s", curr ? curr->text : " ");

	DrawOne(i, C_TLINES);
}

bool TaglineWindow::oneSearch(int x, const char *item)
{
	return !(!searchstr(taglist[x]->text, item));
}

int TaglineWindow::NumOfItems()
{
	return NumOfTaglines;
}

// Create tagline file if it doesn't exist.
void TaglineWindow::Init()
{
	// Default taglines:
#include "tagline.h"

	tagname = mm.resourceObject->get(TaglineFile);

	bool useDefault = !ReadFile();

	if (useDefault) {
		curr = &head;
		for (const char **p = defaultTags; *p; p++) {
			curr->next = new tagline(*p);
			curr = curr->next;
			NumOfTaglines++;
		}
	}

	MakeChain();

	if (useDefault)
		WriteFile(true);
}
