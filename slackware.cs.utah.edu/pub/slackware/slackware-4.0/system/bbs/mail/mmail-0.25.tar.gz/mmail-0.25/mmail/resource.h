/*
 * MultiMail offline mail reader
 * resource class

 Copyright (c) 1996 Toth Istvan <stoty@vma.bme.hu>
 Copyright (c) 1999 William McBrine <wmcbrine@clark.net>

 Distributed under the GNU General Public License.
 For details, see the file COPYING in the parent directory. */

#ifndef RESOURCE_H
#define RESOURCE_H

#include <cstdio>

const int	homeDir = 0,
		mmHomeDir = 1,
		PacketDir = 2,
		WorkDir = 3,
		UncompressCommand = 4,
		PacketName = 5,
		UserName = 6,
		BBSName = 7,
		SysOpName = 8,
		ReplyDir = 9,
		LoginName = 10,
		AliasName = 11,	
		CompressCommand = 12,
		UpWorkDir = 13,
		editor = 14,
		SaveDir = 15,
		AddressFile = 16,
		TaglineFile = 17,
		arjUncompressCommand = 18,
		zipUncompressCommand = 19,
		lhaUncompressCommand = 20,
		rarUncompressCommand = 21,
		unknownUncompressCommand = 22,
		arjCompressCommand = 23,
		zipCompressCommand = 24,
		lhaCompressCommand = 25,
		rarCompressCommand = 26,
		unknownCompressCommand = 27,
		sigFile = 28,
		ColorFile = 29,
		oldPacketName = 30,
		noOfStrings = oldPacketName + 1;

const int	PacketSort = noOfStrings,
		LetterSort = noOfStrings + 1,
		Charset = noOfStrings + 2,
		noOfResources = Charset + 1;

class baseconfig
{
 protected:
	const char **names, **comments, **intro;
	int configItemNum;

	bool parseConfig(const char *);
	void newConfig(const char *);
	virtual void processOne(int, const char *) = 0;
	virtual const char *configLineOut(int) = 0;
};

class resource : baseconfig
{
	static const char *rc_names[], *rc_intro[], *rc_comments[];
	static const int startUp[];
 
	char basedir[256];

	char *resourceData[noOfStrings];
	int resourceInt[noOfResources - noOfStrings];

	void homeInit();
	void mmEachInit(int, const char *);
	void subPath(int, const char *);
	void initinit();
	void mmHomeInit();
	void processOne(int, const char *);
	const char *configLineOut(int);
	const char *fixPath(const char *);
	bool checkPath(const char *, bool);
	bool verifyPaths();
 public:
	resource();
	virtual ~resource();
	const char *get(int) const;
	int getInt(int) const;
	void set(int, const char *);
	void set(int, int);
};
	  
#endif
