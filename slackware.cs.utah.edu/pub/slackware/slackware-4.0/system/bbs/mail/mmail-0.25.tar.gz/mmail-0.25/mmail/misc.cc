/*
 * MultiMail offline mail reader
 * miscellaneous routines (global)

 Copyright (c) 1996 Toth Istvan <stoty@vma.bme.hu>
 Copyright (c) 1999 William McBrine <wmcbrine@clark.net>

 Distributed under the GNU General Public License.
 For details, see the file COPYING in the parent directory. */

#include "mmail.h"

extern "C" {
#include <dirent.h>
#include <sys/utsname.h>
}

// takes off the spaces from the end of a string
char *cropesp(char *st)
{
	char *p;

	for (p = st + strlen(st) - 1; (p > st) && (*p == ' '); p--);
	*++p = '\0';
	return st;
}

// converts spaces to underline characters
char *unspace(char *source)
{
	for (unsigned c = 0; c < strlen(source); c++)
		if (source[c] == ' ')
			source[c] = '_';
	return source;
}

char *strdupplus(const char *original)
{
	char *tmp;

	if (original) {
		tmp = new char[strlen(original) + 1];
		strcpy(tmp, original);
	} else
		tmp = 0;

	return tmp;
};

const char *findBaseName(const char *fileName)
{
	int c, d;
	static char tmp[13];

	for (c = 0; (fileName[c] != '.') && (fileName[c]); c++);

	for (d = 0; d < c; d++)
		tmp[d] = tolower(fileName[d]);
	tmp[d] = '\0';

	return tmp;
};

char *stripre(char *subject)
{
        if (!strncasecmp(subject, "re: ", 4))
                subject += 4;
	return subject;
}

void clearDirectory(const char *DirName)
{
	DIR *Dir;
	struct dirent *entry;

	if ((Dir = opendir(DirName))) {
		if (!mychdir(DirName))
			while ((entry = readdir(Dir)))
				if (entry->d_name[0] != '.')
					remove(entry->d_name);
	closedir(Dir);
	}
}

// basically the equivalent of "strcasestr()", if there were such a thing
const char *searchstr(const char *source, const char *item)
{
	const char *s, *s2;
	int ilen = strlen(item) - 1;
	bool found = false;

	char lower = tolower(*item), upper = toupper(*item);

	item++;

	do {
		s = strchr(source, lower);
		s2 = strchr(source, upper);
		if (s2 && ((s2 < s) || !s))
			s = s2;
		if (s) {
			source = s + 1;
			found = !strncasecmp(source, item, ilen);
		}
	} while (s && !found && *source);

	return found ? s : 0;
}

// Find the address in "Foo <foo@bar.baz>" or "foo@bar.baz (Foo)"
const char *fromAddr(const char *source)
{
	static char tmp[100];
	const char *index, *end = 0;

	index = strchr(source, '<');
	if (index) {
		index++;
		end = strchr(index, '>');
	} else {	// too simple-minded?
		index = source;
		end = strchr(index, ' ');
	}

	if (end) {
		int len = end - index;
		if (len > 99)
			len = 99;
		strncpy(tmp, index, len);
		tmp[len] = '\0';
		return tmp;
	}

	return source;
}

// system name -- results of uname()
const char *sysname()
{
	static struct utsname buf;

	if (!buf.sysname[0])
#if defined(__WIN32__) && defined(__RSXNT__)
		// uname() returns "MS-DOS" in RSXNT, so hard-wire it here
		strcpy(buf.sysname, "Win32");
#else
		uname(&buf);
#endif
	return buf.sysname;
}

/* Convert pathnames to "canonical" form (change slashes to backslashes).
   The "nospace" stuff leaves any parameters unconverted.
   Don't call this twice in a row without first copying the result! D'oh!
*/

#if defined (__MSDOS__) || defined (__EMX__)

const char *canonize(const char *sinner)
{
	static char saint[256];
	int i;
	bool nospace = true;

	for (i = 0; sinner[i]; i++) {
		saint[i] = (nospace && (sinner[i] == '/')) ?
			'\\' : sinner[i];
		if (nospace && (saint[i] == ' '))
			nospace = false;
	}
	saint[i] = '\0';
	return saint;
}

#endif
