/*
 * MultiMail offline mail reader
 * area list

 Copyright (c) 1996 Kolossvary Tamas <thomas@vma.bme.hu>
 Copyright (c) 1999 William McBrine <wmcbrine@clark.net>

 Distributed under the GNU General Public License.
 For details, see the file COPYING in the parent directory. */

#include "interfac.h"

//**************        LittleAreaListWindow    *****************

void LittleAreaListWindow::MakeActive()
{
	int dest;

	position = active = 0;
	areanum = -1;

	disp = 0;
	do
		mm.areaList->gotoArea(disp++);
	while (mm.areaList->isCollection());
	disp--;

	list_max_y = (NumOfItems() < LINES - 10) ? NumOfItems() : LINES - 10;
	list = new InfoWin(list_max_y + 4, 25, 2, C_LALBTEXT, 0, 0, 4, 3);
	dest = mm.letterList->getAreaID() - disp;
	while (active != dest)
		Move(DOWN);
	list->put(1, 2, "Reply goes to area:");

	DrawAll();
}

void LittleAreaListWindow::Delete()
{
	delete list;
}

int LittleAreaListWindow::getArea()
{
	return areanum;
}

int LittleAreaListWindow::NumOfItems()
{
	return mm.areaList->noOfAreas() - disp;
}

void LittleAreaListWindow::oneLine(int i)
{
	mm.areaList->gotoArea(position + i + disp);
	sprintf(list->lineBuf, " %-21.21s ", mm.areaList->getDescription());
	areaconv_in(list->lineBuf);
	DrawOne(i, C_LALLINES);
}

bool LittleAreaListWindow::oneSearch(int x, const char *item)
{
	mm.areaList->gotoArea(x + disp);
	return !(!searchstr(mm.areaList->getDescription(), item));
}

void LittleAreaListWindow::extrakeys(int key)
{
	if (key == '\n')
		areanum = active + disp;
}

//*************         AreaListWindow          ******************

void AreaListWindow::ReDraw()
{
	list->touch();
	info->touch();
}

void AreaListWindow::FirstUnread()
{
	int i;

	position = active = 0;
	for (i = 0; i < NumOfItems(); i++) {
		mm.areaList->gotoActive(i);
		if (!mm.areaList->getNoOfUnread())
			Move(DOWN);
		else
			break;
	}
	if (i == NumOfItems()) {
		position = active = 0;
		for (i = 0; i < NumOfItems(); i++) {
			mm.areaList->gotoActive(i);
			if (!mm.areaList->getNoOfLetters())
				Move(DOWN);
			else
				break;
		}
	}
}

int AreaListWindow::NumOfItems()
{
	return mm.areaList->noOfActive();
}

void AreaListWindow::oneLine(int i)
{
	char *p = list->lineBuf;

	mm.areaList->gotoActive(position + i);

	if (position + i == active) {
		sprintf(p, "%-20.20s", mm.areaList->getAreaType());
		info->put(2, 8, p);
		sprintf(p, format2, mm.areaList->getDescription());
		areaconv_in(p);
		info->put(3, 20, p);
		info->delay_update();
	}
	p += sprintf(p, format, mm.areaList->getShortName(),
		mm.areaList->getDescription());
	if (mm.areaList->getNoOfLetters())
		p += sprintf(p, "  %5d  ", mm.areaList->getNoOfLetters());
	else
		p += sprintf(p, "      .  ");
	if (mm.areaList->getNoOfUnread())
		p += sprintf(p, "  %5d   ", mm.areaList->getNoOfUnread());
	else
		p += sprintf(p, "      .   ");
	if (mode)
		if (mm.areaList->getNoOfPersonal())
			sprintf(p, "   %5d   ",
				mm.areaList->getNoOfPersonal());
		else
			sprintf(p, "       .   ");

	chtype ch = mm.areaList->isReplyArea() ? C_ALREPLINE :
		C_ALPACKETLINE;

	areaconv_in(list->lineBuf);
	DrawOne(i, mm.areaList->getNoOfUnread() ? emph(ch) : noemph(ch));
}

bool AreaListWindow::oneSearch(int x, const char *item)
{
	const char *s;

	mm.areaList->gotoActive(x);

	s = searchstr(mm.areaList->getShortName(), item);
	if (!s)
		s = searchstr(mm.areaList->getDescription(), item);

	return !(!s);
}

void AreaListWindow::Select()
{
	mm.areaList->gotoActive(active);
}

void AreaListWindow::ResetActive()
{
	active = mm.areaList->getActive();
}

void AreaListWindow::MakeActive()
{
	int padding, middle;
	char tmp[80], tpad[7];

	mode = mm.driverList->hasPersonal();

	sprintf(tmp, "Message Areas (%d)", NumOfItems());

	list_max_y = LINES - 15;
	list = new InfoWin(LINES - 12, COLS - 4, 2, C_ALBORDER,
		tmp, C_ALBTEXT);

	list->attrib(C_ALHEADTEXT);
	list->put(1, 3, "Area#  Description");
	int newloc = COLS - 21;
	if (mode)
		newloc -= 11;
	list->put(1, newloc, "Total   Unread");
	if (mode)
		list->put(1, COLS - 15, "Personal");

	info = new ShadowedWin(5, COLS - 4, LINES - 11, C_ALBORDER,
		"Info On The Specified Area", C_ALBTEXT);

	info->put(0, 0, ACS_LTEE);
	info->put(0, COLS - 5, ACS_RTEE);

	padding = COLS - 34;
	if (mode)
		padding -= 11;
	sprintf(format, " %%6s  %%-%d.%ds", padding, padding);

	middle = (COLS - 4) >> 1;

	info->attrib(C_ALINFOTEXT);
	info->put(1, 3, "BBS:");
	info->put(1, middle, " Sysop:");
	info->put(2, 2, "Type:");
	info->put(2, middle, "Packet:");
	info->put(3, 2, "Area description:");

	sprintf(tpad, "%%.%ds", (middle < 87) ? middle - 8 : 79);
	middle += 8;

	info->attrib(C_ALINFOTEXT2);
	sprintf(tmp, tpad, mm.resourceObject->get(BBSName));
	charconv_in(tmp);
	info->put(1, 8, tmp);

	sprintf(tmp, tpad, mm.resourceObject->get(SysOpName));
	charconv_in(tmp);
	info->put(1, middle, tmp);

	info->put(2, middle, mm.resourceObject->get(PacketName));

	padding = COLS - 26;
	sprintf(format2, "%%-%d.%ds", padding, padding);

	DrawAll();
	Select();
}

void AreaListWindow::Delete()
{
	delete info;
	delete list;
}

void AreaListWindow::PrevAvail()
{
	do {
		Move(UP);
		Select();
	} while (!mm.areaList->getNoOfLetters() &&
		 (mm.areaList->getActive() > 0));
	Draw();
}

void AreaListWindow::NextAvail()
{
	do {
		Move(DOWN);
		Select();
	} while (!mm.areaList->getNoOfLetters() &&
		 (mm.areaList->getActive() <
		  mm.areaList->noOfActive() - 1));
	Draw();
}

void AreaListWindow::extrakeys(int key)
{
	Select();
	switch (key) {
	case 'E':
		if (!mm.areaList->isCollection()) {
			if (mm.areaList->isEmail()) {
				interface->addressbook();
				Select();
			}
			interface->letterwindow.set_Letter_Params(
				mm.areaList->getAreaNo(), 'E');
			interface->letterwindow.EnterLetter();
			interface->changestate(arealist);
		}
		break;
	case MM_MINUS:
		PrevAvail();
		break;
	case MM_PLUS:
		NextAvail();
		break;
	case '!':
	case KEY_F(2):
		if (interface->WarningWindow(
	"This will overwrite any existing reply packet. Continue?"))
			interface->create_reply_packet();
		ReDraw();
		break;
	case 'L':
		mm.areaList->relist();
		ResetActive();
		interface->changestate(arealist);
	}
}
