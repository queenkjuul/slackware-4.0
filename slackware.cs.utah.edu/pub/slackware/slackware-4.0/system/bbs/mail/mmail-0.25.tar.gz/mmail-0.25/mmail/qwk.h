/*
 * MultiMail offline mail reader
 * QWK

 Copyright (c) 1997 John Zero <john@graphisoft.hu>
 Copyright (c) 1999 William McBrine <wmcbrine@clark.net>

 Distributed under the GNU General Public License.
 For details, see the file COPYING in the parent directory. */

#ifndef QWK_H
#define QWK_H

#include "mmail.h"

#define ndxRecLen 5

#define getQfield(d, s, l) { strncpy(d, s, l); d[l] = '\0'; }

class qheader {
	struct qwkmsg_header {
		char status;
		char msgnum[7];		// in ASCII
		char date[8];		// ASCII MM-DD-YY date
		char time[5];		// time in HH:MM ASCII
		char to[25];		// TO
		char from[25];		// FROM
		char subject[25];	// subject of message
		char password[12];	// message passw.
		char refnum[8];		// in ASCII
		char chunks[6];		// number of 128 byte chunks
		char alive;		// msg is alive/killed
		unsigned char confLSB;
		unsigned char confMSB;
		char res[3];
	};

 public:
	char from[26], to[26], subject[72], date[15];
	int msglen, msgnum, refnum, origArea;
	bool privat;
	//netaddress na;	// not yet used, but could be!

	bool init(FILE *);
	void output(FILE *);
};

class qwkpack : public specific_driver
{
	struct AREAs {
		char *name;
		int num, nummsgs, attr;
		char numA[10];	// padded to deal with alignment bug (EMX)
	} *areas;

	mmail *mm;
	FILE *msgdatFile, *ctrdatFile;
	struct bodytype **body;
	file_header **bulletins;

	char textfiles[3][13];
	char BBSID[9], *bodyString;
	int maxConf, numMsgs, ID, currentArea, currentLetter;
	bool qwke;

	void readControlDat();
	void readToReader();
	void readIndices();
	void initMessagesDat();
	unsigned long MSBINtolong(unsigned const char *);
	void init();
	void cleanup();
	int getYNum(int, unsigned long);
	char *nextLine();
	void listBulletins();
 public:
	qwkpack(mmail *);
	~qwkpack();
	int getXNum(int);
	int getNoOfAreas();
	void resetAll();
	area_header *getNextArea();
	void selectArea(int);
	int getNoOfLetters();
	void resetLetters();
	letter_header *getNextLetter();
	const char *getBody(letter_header &);
	file_header *getFileList();
	file_header **getBulletins();
	const char *getBBSID();
	bool isQWKE();
};

class qwkreply : public reply_driver
{
	struct upl_list {
		qheader qHead;
		char fname[50];
		upl_list *nextRecord;
	} *uplListHead, *uplListCurrent;
	
	mmail *mm;
	qwkpack *baseClass;

	char replyPacketName[9], *replyText;
	int currentLetter, noOfLetters;
	bool replyExists, qwke;

	void init();
	void cleanup();
	void uncompress();
	void readRep();
	void repFileName(const char *);
	bool getRep1(FILE *, upl_list *);
	void addRep1(FILE *, upl_list *);
	int monthval(const char *);
 public:
	qwkreply(mmail *, specific_driver *);
	~qwkreply();
	int getNoOfAreas();
	void resetAll();
	area_header *getNextArea();
	void selectArea(int);
	int getNoOfLetters();
	void resetLetters();
	letter_header *getNextLetter();
	const char *getBody(letter_header &);
	file_header *getFileList();
	file_header **getBulletins();
	void enterLetter(letter_header &, const char *, int);
	void killLetter(int);
	area_header *refreshArea();
	void makeReply();
};

#endif
