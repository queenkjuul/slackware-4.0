/*
 * MultiMail offline mail reader
 * compress and decompress packets

 Copyright (c) 1997 John Zero <john@graphisoft.hu>
 Copyright (c) 1999 William McBrine <wmcbrine@clark.net>

 Distributed under the GNU General Public License.
 For details, see the file COPYING in the parent directory. */

#ifndef COMPRESS_H
#define COMPRESS_H

#include "resource.h"

#define A_UNKNOWN	0
#define	A_ARJ		1
#define A_ZIP		2
#define A_LHA		3
#define A_RAR		4

int uncompressFile(resource *, const char *, const char *, bool = false);
void compressAddFile(resource *, const char *, const char *, const char *);

#endif
