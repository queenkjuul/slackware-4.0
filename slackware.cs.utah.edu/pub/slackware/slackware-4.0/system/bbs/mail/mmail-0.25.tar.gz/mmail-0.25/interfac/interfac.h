/*
 * MultiMail offline mail reader
 * most class definitions for the interface

 Copyright (c) 1996 Kolossvary Tamas <thomas@tvnet.hu>
 Copyright (c) 1997 John Zero <john@graphisoft.hu>
 Copyright (c) 1999 William McBrine <wmcbrine@clark.net>

 Distributed under the GNU General Public License.
 For details, see the file COPYING in the parent directory. */

#ifndef INTERFACE_H
#define INTERFACE_H

#define USE_SHADOWS	// "Shadowed" windows
#define MM_TOPHEADER "%s offline reader v%d.%d"

#include "../mmail/mmail.h"

#include <csignal>

extern "C" {
#include CURS_INC
}

#include "mmcolor.h"
#include "isoconv.h"

enum direction {UP, DOWN, PGUP, PGDN, HOME, END};
enum statetype {packetlist, arealist, threadlist, letterlist, letter, 
		letter_help, littlearealist, address, tagwin, ansiwin,
		ansi_help};

#if defined (SIGWINCH) && !defined (XCURSES)
extern void sigwinchHandler(int);
#endif

#define TAGLINE_LENGTH 76

/* Include Keypad keys for PDCurses */

#ifdef __PDCURSES__
# define MM_PLUS '+': case KEY_RIGHT: case PADPLUS
# define MM_MINUS '-': case KEY_LEFT: case PADMINUS
# define MM_ENTER '\r': case '\n': case PADENTER
# define MM_SLASH '/': case PADSLASH
#else
# define MM_PLUS '+': case KEY_RIGHT
# define MM_MINUS '-': case KEY_LEFT
# define MM_ENTER '\r': case '\n'
# define MM_SLASH '/'
#endif

class tagline
{
 public:
 	tagline(const char * = 0);
 	tagline *next;
 	char text[TAGLINE_LENGTH + 1];
};

class ColorClass : baseconfig
{
	static chtype allcolors[];
	static const char *col_names[], *col_intro[], *col_comments[];
	static const chtype mapped[];

	chtype colorparse(const char *);
	void processOne(int, const char *);
	const char *configLineOut(int);
	const char *findcol(chtype);
	const char *decompose(chtype);
 public:
	void Init();
};

class Win
{
 protected:
	WINDOW *win;
 public:
	Win(int, int, int, chtype);
	~Win();
	void Clear(chtype);
	void put(int, int, chtype);
	void put(int, int, char);
	void put(int, int, const chtype *, int = 0);
	int put(int, int, const char *);
	void attrib(chtype);
	void horizline(int, int);
	void update();
	void delay_update();
	void wtouch();
	void wscroll(int);
	void cursor_on();
	void cursor_off();
	bool keypressed();
	int inkey();
	void boxtitle(chtype, const char *, chtype);
};

class ShadowedWin : public Win
{
#ifdef USE_SHADOWS
	WINDOW *shadow;
#endif
 public:
	ShadowedWin(int, int, int, chtype, const char * = 0, chtype = 0);
	~ShadowedWin();
	void touch();
	int getstring(int, int, char *, int, int, int);
};

class InfoWin : public ShadowedWin
{
	Win *info;
 public:
	char *lineBuf;

	InfoWin(int, int, int, chtype, const char * = 0,
		chtype = 0, int = 3, int = 2);
	~InfoWin();
	void irefresh();
	void touch();
	void oneline(int, chtype);
	void iscrl(int);
};

class ListWindow
{
 private:
	int oldPos;	//position at last Draw()
	int oldActive;	//active at last Draw()

	void checkPos(int);
 protected:
	InfoWin *list;
  	int list_max_y, list_max_x;
	int position;	//the first element in the window
	int active;	//this is the highlited	

	void Draw();		//refreshes the window
	void DrawOne(int, chtype);
	void DrawAll();
	virtual int NumOfItems() = 0;
	virtual void oneLine(int) = 0;
	virtual bool oneSearch(int, const char *) = 0;
	virtual void extrakeys(int) = 0;
 public:
 	ListWindow();
	void Move(direction);		//scrolloz
	bool search(const char *);
	virtual void ReDraw();		//apply touchwin on the windoz
	void KeyHandle(int);
	virtual void Delete() = 0;
};

class Welcome
{
 	ShadowedWin *window;
 public:
 	void MakeActive();
 	void Delete();
};

class Person
{
	void Init(const char *);
 public:
 	Person *next;
 	char name[45];
 	net_address netmail_addr;

	Person(const char * = 0, const char * = 0);
	Person(const char *, net_address &);
	void dump(FILE *);
};

class AddressBook : public ListWindow
{
	Person head, *curr, *highlighted, **people;
	const char *addfname;
	int NumOfPersons;
	bool NoEnter, inletter;

  	int NumOfItems();
	void oneLine(int);
	bool oneSearch(int, const char *);
	void extrakeys(int);

	void AddressFromLetter();
 	void ReadFile();
 	void DestroyChain();
	friend int perscomp(Person **, Person **);
	void MakeChain();
	void ReChain();
 	void SetLetterThings();
	void kill();
public:
	AddressBook();
	virtual ~AddressBook();
	void MakeActive(bool);
	void Delete();
	void Init();
};

class TaglineWindow : public ListWindow
{
	tagline head, *curr, *highlighted, **taglist;
	const char *tagname;
  	int NumOfTaglines;
	bool nodraw;

 	int NumOfItems();
	void oneLine(int);
	bool oneSearch(int, const char *);
	void extrakeys(int);

	void kill();
	bool ReadFile();
	void WriteFile(bool);
	void DestroyChain();
	void MakeChain();
	void RandomTagline();
 public:
 	TaglineWindow();
	virtual ~TaglineWindow();
	void MakeActive();
	void Delete();
 	void EnterTagline(const char * = 0);
	void Init();
};

class LittleAreaListWindow : public ListWindow
{
	int disp, areanum;

	int NumOfItems();
	void oneLine(int);
	bool oneSearch(int, const char *);
	void extrakeys(int);
 public:
 	void MakeActive();
 	void Delete();
	int getArea();
};

class PacketListWindow : public ListWindow
{
	Welcome welcome;
	file_list *packetList;
	bool sorttype;

	int NumOfItems();
	void oneLine(int);
	bool oneSearch(int, const char *);
	void extrakeys(int);

	void newList();
	void error();
 public:
	PacketListWindow();
	virtual ~PacketListWindow();
 	void MakeActive();
 	void Delete();
	void Select();
	int OpenPacket();
};

class AreaListWindow : public ListWindow
{
 	ShadowedWin *info;
	char format[40], format2[40];
	bool mode;

 	int NumOfItems();
	void oneLine(int);
	bool oneSearch(int, const char *);
	void extrakeys(int);

	void PrevAvail();
	void NextAvail();
 public:
	void ResetActive();
 	void MakeActive();
 	void Delete();
	void Select();
	void ReDraw();
	void FirstUnread();
};

class LetterListWindow : public ListWindow
{
	char format[50];

	int NumOfItems();
	void oneLine(int);
	bool oneSearch(int, const char *);
	void extrakeys(int);

	void listSave();
	void NextUnread();
	void PrevUnread();
 public:
	LetterListWindow();
	void ResetActive();
	void MakeActive();
	void Delete();
	void Select();
	void FirstUnread();
};

class Line
{
 public:
	Line *next;
	char *text;
	unsigned length;

 	Line(int);
	~Line();
};

class LetterWindow
{
	Win *headbar, *header, *text, *statbar;
	Line **linelist;
	char key, tagline1[TAGLINE_LENGTH + 1], To[30];
	int letter_in_chain;	//0 = no letter in chain
	int position;		//which row is the first in the text window
	int NumOfLines;
	int y;			//height of the window, set by MakeActive
	int replyto_area;
	bool rot13, hidden;
	net_address NM;

	void lineCount();
	void oneLine(int);
	void Move(int);
	char *netAdd(char *);
	int HeaderLine(ShadowedWin &, char *, int, int, int);
	int EnterHeader(char *, char *, char *, bool &);
	void QuoteText(FILE *);
	void DestroyChain();
	void editletter(const char *);
	void setToFrom(char *, char *);
	void EditLetter(bool);
	long reconvert(const char *);
	void write_header_to_file(FILE *);
	void write_to_file(FILE *);
	void GetTagline();
	bool Previous();
	void NextDown();
	void MakeChain(int);
 	void DrawHeader();
 	void DrawBody();
	void DrawStat();
	bool EditOriginal();
 public:
	LetterWindow();
 	void MakeActive(bool);
 	void Delete();
	bool Next();
 	void Draw(bool = false);
	void ReDraw();
	bool Save(int);
	void EnterLetter();
	void StatToggle(int);
	net_address &PickNetAddr();
	void set_Letter_Params(int, char);
	void set_Letter_Params(net_address &, const char *);
	void set_Tagline(const char *);
	bool search(const char *);
	void KeyHandle(int);
};

class HelpWindow
{
 	Win *menu;
	int midpos, endpos, base, items;

	void newHelpMenu(const char **, const char **, int);
	void h_packetlist();
	void h_arealist();
	void h_letterlist();
	void h_letter(bool);
 public:
	HelpWindow();
	void MakeActive();
	void Delete();
	void baseNext();
	void baseReset();
};

class AnsiLine
{
 private:
	AnsiLine *prev, *next;
 public:
	AnsiLine *getprev();
	AnsiLine *getnext(int = 0);
	chtype *text;
	unsigned length;
 	AnsiLine(int = 0, AnsiLine * = 0);
	~AnsiLine();
};

class AnsiWindow
{
	bool colorsused[64];
	char escparm[256];	//temp copy of ESC sequence parameters
	const char *title;
	file_header *fromFile;
	const unsigned char *source;
	Win *header, *text, *statbar, *animtext;
	AnsiLine *head, *curr, **linelist;
	int position;		//which row is the first in the window
	int NumOfLines;
	int x, y;		//dimensions of the window
	int cpx, cpy, lpy;	//ANSI positions
	int spx, spy;		//stored ANSI positions
	int ccf, ccb, cfl, cbr, crv;	//colors and attributes
	int oldcolorx, oldcolory;
	int baseline;		//base for positions in non-anim mode
	bool anim;		//animate mode?
	bool ansiAbort, sourceDel;
	chtype attrib;		//current attribute

	void oneLine(int);
	void lineCount();
	void DrawBody();
	int getparm();
	void colreset();
	void colorset();
	const unsigned char *escfig(const unsigned char *);
	void posreset();
	void checkpos();
	void update(unsigned char);
	void ResetChain();
	void MakeChain(const unsigned char *);
	void DestroyChain();
	void animate();
	void statupdate(const char * = 0);
	void getFile();
	void Save();
 public:
	void set(const char *, const char *);
	void setFile(file_header *, const char * = 0);
	void MakeActive();
	void Delete();
	bool search(const char *);
	void KeyHandle(int);
};

class Interface
{
	PacketListWindow packets;
	AddressBook addresses;
	HelpWindow helpwindow;
	LittleAreaListWindow littleareas;

	Win *screen;
	ListWindow *currList;
 	statetype state, prevstate;
	const char *searchItem;
	file_header *newFiles, **bulletins;
	int Key;
	bool unsaved_reply, any_read, addrparm;
#ifdef SIGWINCH
	bool resized;

	void sigwinch();
#endif
	void init_colors();
	void oldstate(statetype);
	void helpreset(statetype);
	void newstate(statetype);
	void alive();
	void screen_init();
	void newpacket();
 	bool select();
	int ansiCommon();
	void searchNext();
	void TransToggle();
	void KeyHandle();
 public:
	ColorClass colorlist;
	AreaListWindow areas;
	LetterListWindow letters;
	LetterWindow letterwindow;
	TaglineWindow taglines;
	AnsiWindow ansiwindow;

 	Interface();
	~Interface();
	void main();
 	int WarningWindow(const char *, const char ** = 0, int = 2);
	int savePrompt(char *);
	void nonFatalError(const char *);
	void changestate(statetype);
 	bool back();		//returns true if we have to quit
	statetype active();
	statetype prevactive();
#ifdef SIGWINCH
	void setResized();
#endif
	void addressbook(bool = false);
	void Tagwin();
	int ansiLoop(const char *, const char *);
	int ansiFile(file_header *, const char * = 0);
	int areaMenu();
	void kill_letter();
	void create_reply_packet();
	void setUnsaved();
	void setAnyRead();
	const char *searchSet();
	void setKey(int);
};

extern mmail mm;
extern Interface *interface;

#if defined (__PDCURSES__) && !defined (XCURSES)
extern "C" {
int PDC_get_cursor_mode();
int PDC_set_cursor_mode(int, int);
}
extern int curs_start, curs_end;
#endif

#endif
