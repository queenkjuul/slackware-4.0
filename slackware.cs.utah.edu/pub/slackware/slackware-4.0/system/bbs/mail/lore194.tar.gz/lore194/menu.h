/*
 * File:        menu.h
 * Description: Symbolic names of menus
 * Author:      Ville Hallivuori, vpg@clinet.fi
 */

#ifndef _menu_h_
#define _menu_h_

//Menus while reading messages
 int mnu_root;
   int mnu_about;
   int mnu_exit;
 int mnu_file;
   int mnu_closesession;
   int mnu_removesession;
   int mnu_replypacket;
 int mnu_edit;
   int mnu_find;
   int mnu_findnext;
   int mnu_markings;
   int mnu_messagestoyou;
   int mnu_savetofile;
   int mnu_skipsubject;
   int mnu_skipwriter;
 int mnu_message;
   int mnu_folowup;
   int mnu_postmessage;
   int mnu_listwrittenmessages;
   int mnu_removemessage;
   int mnu_movemessage;
   int mnu_makeprivate;
   int mnu_index;
 int mnu_help;
   int mnu_keys;
 
//Menus on session selection screen
 int Mnu_root;
   int Mnu_about;
   int Mnu_exit;
 int Mnu_session;
   int Mnu_newsession;
   int Mnu_removesession;
 int Mnu_settings;
   int Mnu_global;
   int Mnu_thisbbs;
 int Mnu_help;
   int Mnu_keys;

#endif /*_MENU_H_*/
