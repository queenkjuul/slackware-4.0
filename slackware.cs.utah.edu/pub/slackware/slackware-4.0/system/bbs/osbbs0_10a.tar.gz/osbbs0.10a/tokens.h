#define TOKEN_EOF      1
#define TOKEN_TEXT     2
#define TOKEN_NUM      3
#define TOKEN_STRING   4
#define TOKEN_EOL      5
#define TOKEN_COMMENT  6
#define TOKEN_LABEL    7
#define TOKEN_OPERATOR 8

int read_token(FILE *);
void skip_line(FILE *);
int read_word(FILE *);
int read_line(FILE *);