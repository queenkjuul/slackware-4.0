int send_file(char *);
int download();
void init_protocols();
int upload(); 







