int mail_user();
int mail_smtp();
int check_mail();
void read_mail(int);
void edit_signature();
void load_signature(int);