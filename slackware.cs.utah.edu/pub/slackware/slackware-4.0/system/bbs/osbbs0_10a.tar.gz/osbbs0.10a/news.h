void nntp_stop();
int post_article();
int read_new_news();
int nntp_start();