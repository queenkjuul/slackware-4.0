int run_door(char *);
void kill_door();
