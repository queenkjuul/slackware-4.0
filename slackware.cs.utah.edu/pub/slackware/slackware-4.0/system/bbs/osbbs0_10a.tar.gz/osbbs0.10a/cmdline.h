#define OPTION        0
#define OPTION_INT    1
#define OPTION_STRING 2

struct option_t {
  char *name;
  char type;
};

struct value_t {
  char used;
  union { char *s; int i; };
};

int cmdline(int, char *[]);
