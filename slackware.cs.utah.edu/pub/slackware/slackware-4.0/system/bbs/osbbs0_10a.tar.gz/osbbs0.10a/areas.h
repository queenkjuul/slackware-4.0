void init_areas();
int list_files(int);

#define MAXAREAS     256
#define MAXPROTOCOLS  30

#define AREA_NATIVE  1
#define AREA_SUNSITE 2
#define AREA_UNIX    3

struct area_t {
  char *tag, *name, *index, type;
};

struct protocol_t {
  char *name;
  char *up_cmd, *down_cmd, batch;
};

struct file_t {
  char *name, marked, *list_name;
  long size, date;
  union {
    long desc;
    char *desc_txt;
  };
  struct file_t *next;
};

struct mark_t {
  char *name;
  long size;
  struct mark_t *next;
};
