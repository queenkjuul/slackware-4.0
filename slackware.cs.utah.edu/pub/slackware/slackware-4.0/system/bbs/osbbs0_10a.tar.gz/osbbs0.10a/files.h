void read_config();
void get_initstring();
int dump_file(char *);
int more_file(char *);
