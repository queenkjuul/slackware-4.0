/* Misc utility macros for afpmount  */
/* $Id: util.h,v 1.3 1993/04/16 13:02:34 tml Exp $ */

#ifndef UTIL_H_INCLUDED
#define UTIL_H_INCLUDED

#ifdef _tolower
#define TOLOWER(x) _tolower(x)
#else
#define TOLOWER(x) tolower(x)
#endif

#define HEXVAL(c) (isdigit(c) ? (c) - '0' \
		   : (isupper(c) ? (c) - 'A' : (c) - 'a') + 10)

#define ARRAYSIZE(a) (sizeof(a) / sizeof(a[0]))

#if __STDC__
#define CONCAT2(a,b) a##b
#define CONCAT3(a,b,c) a##b##c
#define STRINGIFY(id) #id
#define P(x) x
#define CONST const
#else
#define CONCAT2(a,b) a/**/b
#define CONCAT3(a,b,c) a/**/b/**/c
#define STRINGIFY(id) "id"
#define P(x) ()
#define CONST
#endif

#ifdef DONT_HAVE_STRERROR
extern int sys_nerr;
extern char *sys_errlist[];
#define strerror(n) ((n < 0 || n >= sys_nerr) ? "Unknown error" : sys_errlist[n])
#endif

#ifdef DONT_HAVE_MEMMOVE
#define memmove(dest,src,nbytes) bcopy(src,dest,nbytes)
#endif

#endif
