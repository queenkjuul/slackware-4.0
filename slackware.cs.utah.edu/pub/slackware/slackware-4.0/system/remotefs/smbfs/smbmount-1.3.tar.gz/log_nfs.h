/*
Copyright Technical Research Centre of Finland (VTT), 
Information Technology Institute (TTE) 1993, 1994 - All Rights Reserved

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that
both that copyright notice and this permission notice appear in 
supporting documentation, and that the names of VTT or TTE not be
used in advertising or publicity pertaining to distribution of the
software without specific, written prior permission. 

VTT DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING
ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL
VTT BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION,
ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
SOFTWARE.
*/

/* $Id: */

extern void (*fh_printer)();

#if __STDC__
#define PRINTER(x) void print_##x(int level, x *value)
#else
#define PRINTER(x) void print_/**/x()
#endif

#if __STDC__
char *indent(int level);
void print_auth(struct svc_req *rqstp);
#else
char *indent();
void print_auth();
#endif

#define print_void(level, value) level /* nop */
PRINTER(nfsstat);
PRINTER(nfs_fh);
PRINTER(fattr);
PRINTER(attrstat);
PRINTER(sattr);
PRINTER(sattrargs);
PRINTER(diropargs);
PRINTER(diropokres);
PRINTER(diropres);
PRINTER(readlinkres);
PRINTER(readargs);
PRINTER(readokres);
PRINTER(readres);
PRINTER(writeargs);
PRINTER(createargs);
PRINTER(renameargs);
PRINTER(linkargs);
PRINTER(linkargs);
PRINTER(symlinkargs);
PRINTER(readdirargs);
PRINTER(readdirres);
PRINTER(statfsres);

#undef PRINTER
