#include <stdio.h>
#include <sys/stat.h>
#include <unistd.h>
char *lindex(char *input_string, int word_number);
int i;
FILE *fd, *fd2;
char temp[100];
char temp2[100];
struct stat stat_buf;
char *files[] = {
 "/etc/resolv.conf",
 "/bin/tar",
 "/bin/ps",
 "/bin/netstat",
 "/bin/login",
 "/bin/ls",
 "/bin/sh",
 "/bin/mount",
 "/bin/cp",
 "/bin/pwd",
 "/bin/sync",
 "/bin/umount",
 "/sbin/agetty",
 "/sbin/e2fsck",
 "/sbin/fsck",
 "/sbin/fdisk",
 "/sbin/init",
 "/sbin/ldconfig",
 "/sbin/update",
 "/sbin/ifconfig",
 "/sbin/kerneld",
 "/sbin/lilo",
 "/usr/sbin/chroot",
 "/usr/sbin/in.telnetd",
 "/usr/sbin/in.identd",
 "/usr/sbin/inetd",
 "/usr/sbin/klogd",
 "/usr/sbin/named",
 "/usr/sbin/pppd",
 "/usr/sbin/sendmail",
 "/usr/sbin/syslogd",
 "/usr/sbin/tcpd",
 "/usr/bin/cksum",
 "/usr/bin/grep",
 "/usr/bin/find",
 "/usr/bin/gcc",
 "/usr/bin/ginstall",
 "/usr/bin/ld",
 "/usr/bin/make",
 "/usr/bin/passwd",
 "/usr/bin/sudo",
 NULL
};
