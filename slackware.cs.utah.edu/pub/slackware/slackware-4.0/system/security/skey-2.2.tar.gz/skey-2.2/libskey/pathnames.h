/* $Id: pathnames.h,v 1.2 1994/10/19 00:03:14 pst Exp $ (FreeBSD) */

#include <paths.h>

#define _PATH_SKEYACCESS        "/etc/skey.access"
#define	_PATH_SKEYFILE		"/etc/skeykeys"
