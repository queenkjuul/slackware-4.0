/* version.h */
/* Copyright (C) 1993 Eric Young - see README for more details */

static char *version="libdes v 3.06";
