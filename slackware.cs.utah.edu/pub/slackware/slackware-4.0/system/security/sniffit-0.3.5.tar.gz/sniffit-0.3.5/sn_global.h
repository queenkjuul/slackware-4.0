/* Sniffit Global File                                                        */

/* some things that are better defined before all the rest */
/* currently some option data */

char SNIFMODE, DUMPMODE, PROTOCOLS, ASC, WILDCARD, CFG_FILE, NO_CHKSUM; 
char LOGLEVEL;
                                                      /* All option shit */

