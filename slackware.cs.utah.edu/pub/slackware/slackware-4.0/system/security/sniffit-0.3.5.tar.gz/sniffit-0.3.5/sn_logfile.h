/* Sniffit Data File                                                        */

void logfile_exit (void);
char *gettime (void);
void print_logline (char *);
void print_ftp_user (char *, char *);
void print_ftp_pass(char *, char *);
void print_login (char *, char *);
void print_pwd (char *, char *);
void print_conn (char *, char *);
void open_logfile (void);
