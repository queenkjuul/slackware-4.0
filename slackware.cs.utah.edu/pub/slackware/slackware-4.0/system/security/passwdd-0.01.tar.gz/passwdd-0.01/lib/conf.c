#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "conf.h"
#include "globals.h"

#define OPEN_ERR	0
#define PARSE_ERR	1
#define MEM_ERR	2

char *szErrorMessage[] = {
	"Error opening configuration file...",
	"Parsing error on line %d...",
	"Memory allocation error...",
};

tEntry *pConfig = NULL;

bool add_entry(char *, char *, char *);
bool free_last_entry();
char *find_entry(char *, char *);

bool add_entry(char *pszKey, char *pszData, char *pszSection)
{
	tEntry *pLast = pConfig;
	
	if (NULL == pConfig) {
		pConfig = malloc(sizeof(tEntry));
		if (NULL == pConfig)
			return FALSE;
		pLast = pConfig;
	} else {
		while (NULL != pLast->pNext)
			pLast = pLast->pNext;
		pLast->pNext = malloc(sizeof(tEntry));
		if (NULL == pLast->pNext)
			return FALSE;
		pLast = pLast->pNext;
	}
	
	pLast->pszKey = NULL;
	pLast->pszData = NULL;
	pLast->pszSection = NULL;
	if (NULL != pszKey)
		pLast->pszKey = strdup(pszKey);
	if (NULL != pszData)
		pLast->pszData = strdup(pszData);
	if (NULL != pszSection)
		pLast->pszSection = strdup(pszSection);
	pLast->pNext = NULL;
	
	return TRUE;
}

char *find_entry(char *pszSection, char *pszKey)
{
	tEntry *pLast = pConfig;
	
	while (NULL != pLast) {
		if ((0 == strcmp(pszSection, pLast->pszSection)) && 
			 (0 == strcmp(pszKey, pLast->pszKey)))
			return pLast->pszData;
		pLast = pLast->pNext;
	}
	return NULL;
}

bool free_last_entry()
{
	tEntry *pLast = pConfig;
	
	if (NULL == pLast)
		return FALSE;
	
	if (NULL != pLast->pNext) {
		while (NULL != ((tEntry *)(pLast->pNext))->pNext)
			pLast = pLast->pNext;
		free(pLast->pNext);
		pLast->pNext = NULL;
		return TRUE;
	} else {
		free(pConfig);
		pConfig = NULL;
		return FALSE;
	}
}

bool init_conf(char *pszName, char **pszError)
{
	FILE *fp;
	static char szBuf[256];
	static char szTmp[256];
	static char szSection[256];
	register int i;
	int iLineNumber = 0;
	char *p, *q;
	
	if (NULL == (fp = fopen(pszName, "r"))) {
		*pszError = szErrorMessage[OPEN_ERR];
		return FALSE;
	}
	
	while (NULL != fgets(szBuf, (int)sizeof(szBuf), fp)) {
		iLineNumber += 1;
		// Strip leading white spaces and tabs
		for (i = 0; '\0' != szBuf[i]; i++)
			if ((' ' != szBuf[i]) && ('\t' != szBuf[i]))
				break;
		strcpy(szTmp, &szBuf[i]);
		// Strip trailing CRs, LFs, spaces and tabs
		for (i = strlen(szTmp) - 1; i >= 0; i--)
			if ((' ' != szTmp[i]) && 
				 ('\t' != szTmp[i]) && 
				 ('\x0a' != szTmp[i]) &&
				 ('\x0d' != szTmp[i]))
				break;
		szTmp[i + 1] = '\0';
		// Skip empty lines
		if ('\0' == szTmp[0])
			continue;
		// Skip comments
		if (('#' == szTmp[0]) || ('%' == szTmp[0]))
			continue;
		// First line must be always section entry
		if (1 == iLineNumber)
			if ('[' != szTmp[0]) {
				sprintf(szBuf, szErrorMessage[PARSE_ERR], iLineNumber);
				*pszError = szBuf;
				return FALSE;
			}
		// Check section entry
		if ('[' == szTmp[0]) {
			if (']' != szTmp[strlen(szTmp) - 1]) {
				sprintf(szBuf, szErrorMessage[PARSE_ERR], iLineNumber);
				*pszError = szBuf;
				return FALSE;
			}
			szTmp[strlen(szTmp) - 1] = '\0';
			strcpy(szSection, szTmp + 1);
			continue;
		}
		// If there is no delimter in the entry it is invalid
		if (NULL == strchr(szTmp, '=')) {
			sprintf(szBuf, szErrorMessage[PARSE_ERR], iLineNumber);
			*pszError = szBuf;
			return FALSE;
		}
		p = strtok(szTmp, "=");
		q = strtok(NULL, "");
		if (FALSE == add_entry(p, q, szSection)) {
			*pszError = szErrorMessage[MEM_ERR];
			return FALSE;
		}
	}
	
	(void)fclose(fp);
	
	return TRUE;
}

char *get_string(char *pszSection, char *pszEntry, char *pszDefault, char *pszBuffer, int iMaxLen)
{
	char *p = find_entry(pszSection, pszEntry);
	strncpy(pszBuffer, (p == NULL) ? pszDefault : p, (size_t)iMaxLen);
	return pszBuffer;
}

long get_int(char *pszSection, char *pszEntry, long lDefault)
{
	char *p = find_entry(pszSection, pszEntry);
	char *q;
	long l;
	
	if (NULL == p)
		return lDefault;
	
	l = strtol(p, &q, 10);
	
	if (('\0' == *q) && ('\0' != *p))
		return l;
	else
		return lDefault;
}

bool get_bool(char *pszSection, char *pszEntry, bool fgDefault)
{
	char *p = find_entry(pszSection, pszEntry);
	if (NULL == p)
		return fgDefault;
	if (0 == strcmp(p, "0") ||
		 0 == strcasecmp(p, "false") ||
		 0 == strcasecmp(p, "no") ||
		 0 == strcasecmp(p, "n") ||
		 0 == strcasecmp(p, "nak"))
		return FALSE;
	if (0 == strcmp(p, "1") ||
		 0 == strcasecmp(p, "true") ||
		 0 == strcasecmp(p, "yes") ||
		 0 == strcasecmp(p, "y") ||
		 0 == strcasecmp(p, "ack"))
		return TRUE;
	return fgDefault;
}

void destroy_conf()
{
	while(free_last_entry());
}