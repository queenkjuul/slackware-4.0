#ifndef __GETDEF_H__
#define __GETDEF_H__

int getdef_bool(const char *);
long getdef_long(const char *, long);
int getdef_num(const char *, int);
char *getdef_str(const char *);

#endif // __GETDEF_H__
