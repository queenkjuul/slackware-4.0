#include <pwd.h>
#include <grp.h>
#include <stdio.h>
#include <paths.h>
#include <errno.h>
#include <stdlib.h>
#include <stdarg.h>
#include <unistd.h>
#include <signal.h>
#include <syslog.h>
#include <string.h>
#include <fcntl.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <sys/wait.h>
#include <sys/socket.h>
#include <netinet/in.h>

#include "globals.h"
#include "pidfile.h"
#include "pwio.h"
#include "shadowio.h"
#include "obscure.h"
#include "salt.h"
#include "conf.h"

#define _PATH_PID _PATH_VARRUN "passwdd.pid"

#define TCP_SERV_PORT 1099

#define MAXSTR 256

// Function prototypes
void dprintf(char *, ...);
void die(int);
char *naddr2str(struct sockaddr_in *);
unsigned long int nname2h(char *, bool *);
void server(int);

int read_string(int, char *, int);
int write_string(int, char *);
bool check_login(char *, char *);
bool change_password(char *, char *);
bool allow_change(char *, char *);
bool allow_host(struct in_addr);
void read_conf();
void wait_children();
void load_conf();

// Global variables
char *pszPidFile = _PATH_PID;

char szAllowedHosts[256];
char szAllowedUsers[256];
char szPoweredUsers[256];
int iMaxProcesses;

int main(int argc, char **argv)
{
	struct sockaddr_in serv, child;
	int listenfd, sockfd, childlen;
	int pidstatus, child_process;
#ifndef DEBUG	
	register int i, j;
#endif
	pid_t pid;
	char *pszResult;

	dprintf("Checking pidfile.\n");
	if (0 == check_pid(pszPidFile)) {
#ifndef DEBUG		
		if ((pid = fork()) > 0)
			exit(0);								// Parent process
		else
			if (pid < 0) {						// An error occured in the fork
				fprintf(stderr, "passwdd: initial fork error:%s.\n", strerror(errno));
				exit(1);
			}
		i = getdtablesize();
		for (j = 0; j < i; j++)
		  close(j);
		setsid();								// Creates a session and closes the controlling tty
#endif
	} else {
		fputs("passwdd: already running.\n", stderr);
		exit(1);
	}
	dprintf("Writing pidfile.\n");
	if (0 == check_pid(pszPidFile)) {
		if (0 == write_pid(pszPidFile)) {
			dprintf("Can't write pid file.\n");
			exit(1);
		}
	} else {
		dprintf("Pidfile (and pid) already exists.\n");
		exit(1);
	}
	signal(SIGTERM, die);
	signal(SIGHUP, read_conf);
	signal(SIGCHLD, wait_children);
#ifdef DEBUG
	signal(SIGINT, die);
	signal(SIGQUIT, die);
#endif
	dprintf("Starting.\n");
	
	openlog(argv[0], LOG_PID, LOG_USER);
	syslog(LOG_USER | LOG_INFO, "passwdd: passwdd daemon starting");
	
	if (FALSE == init_conf("/etc/passwdd.conf", &pszResult)) {
		syslog(LOG_USER | LOG_INFO, "conf error: %s", pszResult);
		exit(1);
	}
	load_conf();
	
	if ((listenfd = socket(PF_INET, SOCK_STREAM, 0)) < 0) {
		syslog(LOG_USER | LOG_INFO, "socket error: %s", strerror(errno));
		exit(1);
	}
	
	memset(&serv, 0, sizeof(serv));
	serv.sin_family = AF_INET;
	serv.sin_addr.s_addr = htonl(INADDR_ANY);
	serv.sin_port = htons(TCP_SERV_PORT);
	
	if (bind(listenfd, (struct sockaddr *)&serv, sizeof(serv)) < 0) {
		syslog(LOG_USER | LOG_INFO, "bind error: %s", strerror(errno));
		exit(1);
	}
	
	if (listen(listenfd, SOMAXCONN) < 0) {
		syslog(LOG_USER | LOG_INFO, "listen error: %s", strerror(errno));
		exit(1);
	}
	
	child_process = 0;
	while (0 == child_process) {			// Loop begins here
		memset(&child, 0, sizeof(child));
		childlen = sizeof(child);
		if ((sockfd = accept(listenfd, (struct sockaddr *)&child, &childlen)) < 0) {
			if (EINTR != errno)
				syslog(LOG_USER | LOG_INFO, "accept error (%s): %s", naddr2str(&child), strerror(errno));
			continue;
		}
		syslog(LOG_USER | LOG_INFO, "passwdd: opened client connection from %s", naddr2str(&child));
		if (FALSE == allow_host(child.sin_addr)) {
			syslog(LOG_USER | LOG_INFO, "passwdd: unauthorized client connection from %s", naddr2str(&child));
			close(sockfd);
			continue;
		}
		if ((pid = fork()) == 0) {			// This is the child
			close(listenfd);
			child_process = 1;				// Exit from main loop for the child process
		} else {									// We are parent, go on listening and error checking
			if (pid < 0)
				syslog(LOG_USER | LOG_INFO, "fork error: %s", strerror(errno));
			while(waitpid(-1, &pidstatus, WNOHANG) > 0);
			close(sockfd);
			child_process = 0;
		}
	}
	close(listenfd);
	server(sockfd);
	return 0;
}

bool allow_host(struct in_addr lSource)
{
	register int i, j;
	static char szBuf[256];
	static char szTmp[256];
	char *pszHost;
	char *pszMask;
// We will compare the source address, the target address and target netmask
// all in host byte order. There is no matter what ordering we will use
// but is logically more correct to perform it in native ordering.	
	unsigned long int ulSourceHost = ntohl(lSource.s_addr);
	unsigned long int ulTargetHost;
	unsigned long int ulTargetMask;
	register unsigned long l, q;
	char *p;
	bool fgError;
	
	for (i = j = 0; szAllowedHosts[i] != '\0'; i++)
	   if (NULL == strchr(" \t\x0a\x0d", szAllowedHosts[i]))
		   szBuf[j++] = szAllowedHosts[i];
	szBuf[j] = '\0';

	if (NULL != (pszHost = strtok(szBuf, ",;")))
		do {
			pszHost = strcpy(szTmp, pszHost);
			if (NULL != (pszMask = strchr(pszHost, '/'))) {
				*pszMask = '\0';
				pszMask += 1;
			}
			ulTargetHost = nname2h(*pszHost == '!' ? pszHost + 1 : pszHost, &fgError);
			if (TRUE == fgError) {
				syslog(LOG_USER | LOG_INFO, "passwdd: configuration file error, skipping host");
				continue;
			}
			ulTargetMask = 0xFFFFFFFF;
			if (NULL != pszMask) {
				l = strtol(pszMask, &p, 10);
				if (('\0' == *p) && (l >= 0) && (l <= 32)) {
					ulTargetMask = 0;
					for (q = 0; q < l; q++) {
						ulTargetMask >>= 1;
						ulTargetMask |= 0x80000000;
					}
				} else {
					ulTargetMask = nname2h(pszMask, &fgError);
					if (TRUE == fgError) {
						syslog(LOG_USER | LOG_INFO, "passwdd: configuration file error, skipping network");
						continue;
					}
			   }
			}
			if ('!' == *pszHost)
				if ((ulSourceHost & ulTargetMask) == ulTargetHost)
					return FALSE;
			if ((ulSourceHost & ulTargetMask) == ulTargetHost)
				return TRUE;
		} while (NULL != (pszHost = strtok(NULL, ",;")));
	
	return FALSE;
}

void server(int sockfd)
{
	char szWelcome[] = "+";
	char szGoAhead[] = "!";
	char szLogin[32];
	char szOldPassword[32];
	char szTarget[32];
	char szNewPassword[32];
	char szChanged[] = "%";
	char szUnchanged[] = "^";
	char szFailedExpect[] = "^1";
	char szFailedLogin[] = "^2";
	char szFailedWeakPassword[] = "^3";
	char *pszObscure;
	bool fgCheckOnly = FALSE;

	write_string(sockfd, szWelcome);
	
	if (-1 == read_string(sockfd, szLogin, sizeof(szLogin)))
		write_string(sockfd, szFailedExpect);
	if (-1 == read_string(sockfd, szTarget, sizeof(szTarget)))
		write_string(sockfd, szFailedExpect);
	if (-1 == read_string(sockfd, szOldPassword, sizeof(szOldPassword)))
		write_string(sockfd, szFailedExpect);
	if (0 == strcmp(szTarget, "?"))
		fgCheckOnly = TRUE;
	
	if ((TRUE == check_login(szLogin, szOldPassword)) && 
		 (TRUE == allow_change(szLogin, fgCheckOnly ? szLogin : szTarget))) {
		write_string(sockfd, szGoAhead);
		if (TRUE == fgCheckOnly)
			return;
		if (-1 == read_string(sockfd, szNewPassword, sizeof(szNewPassword))) {
			write_string(sockfd, szFailedExpect);
			return;
		}
		pszObscure = obscure(szOldPassword, szNewPassword, 0 == strcmp(szLogin, szTarget));
		if (NULL != pszObscure) {
			write_string(sockfd, szFailedWeakPassword);
			write_string(sockfd, pszObscure);
			return;
		}
		if (TRUE == change_password(szTarget, szNewPassword))
		  	write_string(sockfd, szChanged);
		else 
			write_string(sockfd, szUnchanged);
	} else
		write_string(sockfd, szFailedLogin);
}

bool allow_change(char *pszLogin, char *pszTarget)
{
	static char szBuf[256];
	static char szTmp[256];
	const struct passwd *pwLogin;
	const struct group *grLogin;
	const struct passwd *pwTarget;
	const struct group *grTarget;
	register int i, j;
	char *pszAllowed;
	char *pszPowered;
	char *pszSheep;
	bool fgAllowed = FALSE;
	bool fgPowered = FALSE;
	bool fgSheep = FALSE;
	
	pw_lock();
	pw_open(O_RDWR);
	if (NULL == (pwLogin = pw_locate(pszLogin))) {
		syslog(LOG_USER | LOG_INFO, "passwdd: invalid user %s", pszLogin);
		return FALSE;
	}
	if (NULL == (pwTarget = pw_locate(pszTarget))) {
		syslog(LOG_USER | LOG_INFO, "passwdd: invalid user %s", pszTarget);
		return FALSE;
	}
	pw_close();
	pw_unlock();
	
	for (i = j = 0; szAllowedUsers[i] != '\0'; i++)
	   if (NULL == strchr(" \t\x0a\x0d", szAllowedUsers[i]))
		   szBuf[j++] = szAllowedUsers[i];
	szBuf[j] = '\0';
	for (i = j = 0; szPoweredUsers[i] != '\0'; i++)
		if (NULL == strchr(" \t\x0a\x0d", szPoweredUsers[i]))
			szTmp[j++] = szPoweredUsers[i];
	szTmp[j] = '\0';
	
	if (NULL == (grLogin = getgrgid(pwLogin->pw_gid))) {
		syslog(LOG_USER | LOG_INFO, "passwdd: invalid group for user %s", pszLogin);
		return FALSE;
	}
	if (NULL == (grTarget = getgrgid(pwTarget->pw_gid))) {
		syslog(LOG_USER | LOG_INFO, "passwdd: invalid group for user %s", pszTarget);
		return FALSE;
	}
	
	if (NULL != (pszAllowed = strtok(szBuf, ",;")))
		do {
			if ('@' == pszAllowed[0]) {
			  	if (0 == strcmp(pszAllowed + 1, grTarget->gr_name)) {
					fgAllowed = TRUE;
					break;
				}
			} else {
			   if (0 == strcmp(pszLogin, pszAllowed)) {
					fgAllowed = TRUE;
					break;
				}
			}
		} while (NULL != (pszAllowed = strtok(NULL, ",;")));
	
	if (FALSE == fgAllowed) {
		syslog(LOG_USER | LOG_INFO, "passwdd: unauthorized user %s", pszLogin);
		return FALSE;
	}
	
	if (0 != strcmp(pszLogin, pszTarget)) {
		if (NULL != (pszPowered = strtok(szTmp, ",;")))
			do {
				pszPowered = strcpy(szBuf, pszPowered);
				if (NULL == (pszSheep = strchr(szBuf, ':'))) {
					syslog(LOG_USER | LOG_INFO, "passwdd: configuration file error, skipping power users");
					continue;
				}
				*pszSheep = '\0';
				pszSheep += 1;
				if ('@' == pszPowered[0]) {
					if (0 == strcmp(pszPowered + 1, grLogin->gr_name))
						fgPowered = TRUE;
				} else {
					if (0 == strcmp(pszPowered, pszLogin))
						fgPowered = TRUE;
				}
				if (fgPowered && ('@' == pszSheep[0])) {
					if (0 == strcmp(pszSheep + 1, grTarget->gr_name)) {
						fgSheep = TRUE;
						break;
					}
				} else {
					if (0 == strcmp(pszSheep, pszTarget)) {
						fgSheep = TRUE;
						break;
					}
				}
			} while (NULL != (pszPowered = strtok(NULL, ",;")));
		if (TRUE == fgSheep) {
			syslog(LOG_USER | LOG_INFO, "passwdd: %s changes the password of %s", pszLogin, pszTarget);
			return TRUE;
		}
		syslog(LOG_USER | LOG_INFO, "passwdd: %s tried to change the password of %s without rights", pszLogin, pszTarget);
		return FALSE;
	}
	
	return TRUE;
}

bool change_password(char *pszLogin, char *pszNewPassword)
{
	bool fgResult = TRUE;
	
	uid_t i;
#ifdef SHADOWPWD
	const struct spwd *sp;
	struct spwd *nsp;
#else
	const struct passwd *pw;
	struct passwd *npw;
#endif
	
	char *p = crypt(pszNewPassword, crypt_make_salt());
	
	memset(pszNewPassword, 0, strlen(pszNewPassword));		// Clear password

	i = getuid();
	if (0 != setuid(0)) {
		syslog(LOG_USER | LOG_INFO, "passwdd: passwdd needs root privileges to change passwords setuid error: %s", strerror(errno));
		return FALSE;
	}
	
#ifdef SHADOWPWD
	spw_lock();
	spw_open(O_RDWR);
	if (NULL == (sp = spw_locate(pszLogin))) {
		fgResult = FALSE;
		goto err_exit;
	}
	
	if (NULL == (nsp = (struct spwd *)malloc(sizeof(struct spwd)))) {
		fgResult = FALSE;
		goto err_exit;
	}
	*nsp = *sp;
	if ((NULL == (nsp->sp_namp = strdup(nsp->sp_namp))) ||
	    (NULL == (nsp->sp_pwdp = strdup(p)))) {
		fgResult = FALSE;
		goto err_exit;
	}
	
	spw_update(nsp);
	
err_exit:	
	spw_close();
	spw_unlock();
#else
	pw_lock();
	pw_open(O_RDWR);
	pw = pw_locate(pszLogin);
	if (NULL == pw) {
		fgResult = FALSE;
		goto err_exit;
	}
	if (NULL == (npw = malloc(sizeof(sizeof(struct passwd))))) {
		fgResult = FALSE;
		goto err_exit;
	}
	*npw = *pw;
	if ((NULL == (npw->pw_name = strdup(pw->pw_name)))
	    || (NULL == (npw->pw_passwd = strdup(p)))
#ifdef ATT_AGE
	    || (NULL == (npw->pw_age = strdup(pw->pw_age)))
#endif
#ifdef ATT_COMMENT		 
	    || (NULL == (npw->pw_comment = strdup(pw->pw_comment)))
#endif
	    || (NULL == (npw->pw_gecos = strdup(pw->pw_gecos)))
	    || (NULL == (npw->pw_dir = strdup(pw->pw_dir)))
	    || (NULL == (npw->pw_shell = strdup(pw->pw_shell)))) {
		fgResult = FALSE;
		goto err_exit;
	}
	  
	pw_update(npw);
	
err_exit:	
	pw_close();
	pw_unlock();
#endif
	
	setuid(i);
	
	return fgResult;
}

bool check_login(char *pszLogin, char *pszPassword)
{
	const struct passwd *pw;
#ifdef SHADOWPWD
	const struct spwd *sp;
	uid_t i;
#endif
	
// Check to see if there is a valid login name
	
	pw_lock();
	pw_open(O_RDWR);
	if (NULL == (pw = pw_locate(pszLogin))) {
		syslog(LOG_USER | LOG_INFO, "invalid user: %s", pszLogin);
		return FALSE;
	}
	pw_close();
	pw_unlock();
	
#ifdef SHADOWPWD
	i = getuid();
	if (0 != setuid(0)) {
		syslog(LOG_USER | LOG_INFO, "passwdd needs root privileges to change passwords setuid error: %s", strerror(errno));
		return FALSE;
	}
	spw_lock();
	spw_open(O_RDWR);
	
	if (NULL == (sp = spw_locate(pszLogin))) {
		syslog(LOG_USER | LOG_INFO, "invalid user: %s", pszLogin);
		spw_close();
		spw_unlock();
		return FALSE;
	}
	
	spw_close();
	spw_unlock();
	
	if (0 != strcmp(sp->sp_pwdp, crypt(pszPassword, sp->sp_pwdp))) {
		syslog(LOG_USER | LOG_INFO, "invalid password for user: %s", pszLogin);
		return FALSE;
	}
#else
	if (0 != strcmp(pw->pw_passwd, crypt(pszPassword, pw->pw_passwd))) {
		syslog(LOG_USER | LOG_INFO, "invalid password for user: %s", pszLogin);
		return FALSE;
	}
#endif
#ifdef SHADOWPWD
	setuid(i);			// Return to original uid, paranoid, huh?
#endif	
	return TRUE;
}

int read_string(int sockfd, char *pszString, int iMaxLength)
{
	char c;
	int i, j;
	
// TODO - It'll be more faster to read bigger junks of data.
//	       We need also some additional error handling.	
	for (i = 0; i < iMaxLength; i++) {
		if (1 == (j = read(sockfd, &c, 1))) {
			if ('\0' == c)
				break;
			*pszString++ = c;
		} else if (0 == j)	// EOF
			break;
		else
			return -1;			// Error
	}

	*pszString = '\0';
	return i;
}

int write_string(int sockfd, char *pszString)
{
	int iResult = write(sockfd, pszString, strlen(pszString) + 1);
	
	if ((strlen(pszString) + 1) != iResult)
		syslog(LOG_USER | LOG_INFO, "write error: %s", strerror(errno));
	
	return iResult;
}

void die(int sig)
{
	destroy_conf();
	if (0 != sig)
	  dprintf("passwdd: exiting on signal %d\n", sig);
	remove_pid(pszPidFile);
	exit(0);
}

void wait_children()
{
	int pidstatus;
	while(waitpid(-1, &pidstatus, WNOHANG) > 0);	
	signal(SIGCHLD, wait_children);	// Reset to get it again	
}

void read_conf()
{
	char *pszResult;
	destroy_conf();
	init_conf("/etc/passwdd.conf", &pszResult);
	load_conf();
	syslog(LOG_USER | LOG_INFO, "passwdd: reinitializing");
	signal(SIGHUP, read_conf);			// Reset to get it again
}

void load_conf()
{
	get_string("Permissions", "hosts_allow", "localhost", szAllowedHosts, sizeof(szAllowedHosts));
	get_string("Permissions", "users_allow", "@users", szAllowedUsers, sizeof(szAllowedUsers));
	get_string("Permissions", "master", "", szPoweredUsers, sizeof(szPoweredUsers));
   iMaxProcesses = get_int("Global", "max_processes", 10);
}

void dprintf(char *fmt, ...)
{
#ifdef DEBUG	
	va_list ap;
	
	va_start(ap, fmt);
	vfprintf(stdout, fmt, ap);
	va_end(ap);
	
	fflush(stdout);
#endif
}

char *naddr2str(struct sockaddr_in *saptr) {
	static char szResult[MAXSTR];
	char	*bp, *ap;
	int l;
	struct sockaddr sa;
	
	/* check for null/zero family */
	if (saptr == NULL)
		return "NULLADDR";
	if (saptr->sin_family == 0)
		return "0";

	switch (saptr->sin_family) {
//		case AF_UNIX:
//			if (saptr->sunix.sun_path[0] != '\0')
//				snprintf(str, MAXSTR, "[UNIX: %.64s]", saptr->sunix.sun_path);
//			else
//				snprintf(str, MAXSTR, "[UNIX: localhost]");
//			return str;
		case AF_INET:
			return inet_ntoa(saptr->sin_addr);
	}

// unknown family -- just dump bytes
	memcpy(&sa, saptr, sizeof(sa));
	snprintf(szResult, MAXSTR, "Family %d: ", sa.sa_family);
   bp = &szResult[strlen(szResult)];
   ap = sa.sa_data;
   for (l = sizeof(sa.sa_data); --l >= 0; ) {
		sprintf(bp, "%02x:", *ap++ & 0377);
		bp += 3;
	}
	*--bp = '\0';
	return szResult;
}

unsigned long nname2h(char *pszName, bool *pfgError)
{
	struct hostent *pstrHost;
	
	pstrHost = gethostbyname(pszName);
	if (NULL == pstrHost) {
		*pfgError = TRUE;
		return 0;
	}
	*pfgError = FALSE;
	return ntohl(*((unsigned long int *)(pstrHost->h_addr)));
}