#!/usr/bin/perl -w
require 5.002;
use Socket;
use CGI qw(:standard);

$config_file = "/etc/passwdc.conf";
$login_defs = "/etc/login.defs";
$results_file = "/usr/local/apache/htdocs/results.html";

# You do not need to edit anything below this line

$login = param("login");
$target = param("target");
$old_password = param("old");
$new_password = param("new");
$new_password_confirm = param("verify");

$min_length = 5;
$max_length = 8;
$port = 1099;
@targets = ("localhost");				# Default value

$final_string = "";

print header();

# Parse login defs file
if (open(LOGINDEFS, "< $login_defs")) {
	while (<LOGINDEFS>) {
		chomp;
		s/^\s*|\s*$//g;					# Remove leading and trailing spaces
												# and tabs.
		if ($_ eq "") {					# Skip empty lines.
			next;
		}
		if (/^\#/) {						#Skip comments
			next;
		}
		@entry = split; 
# Skip keys only or keys with more than one values.
		if (defined($entry[2]) || !defined($entry[1])) {
			next;
		}
# Here begins program specific section.
		if (lc($entry[0]) eq "pass_min_len") {
			$min_length = int($entry[1]);
		}
		if (lc($entry[0]) eq "pass_max_len") {
			$max_length = int($entry[1]);
		}
	}
	close(LOGINDEFS);
}

if ($login eq "") {
	$final_string = "The login field is NOT optional.\n";
	display_result($final_string);
	exit;
}

if ($old_password eq "") {
	$final_string = "The old password field is NOT optional.\n";
	display_result($final_string);
	exit;
}

if ($new_password ne $new_password_confirm) {
	$final_string = "The new password and its confirmation don't match. Try again.\n";
	display_result($final_string);
	exit;
}

if ((length($new_password) < $min_length) ||
    (length($new_password) > $max_length)) {
	$final_string = "The new password doesn't meet the length criteria. Try again.";
	display_result($final_string);
	exit;
}

if ($target eq "") {
	$target = $login;
}

# Parse config file.
$section = "";
if (open(CONF, "< $config_file")) {
	while (<CONF>) {
		chomp;
		s/^\s*|\s*$//g;					# Remove leading and trailing spaces
												# and tabs.
		if ($_ eq "") {					# Skip empty lines.
			next;
		}
		if (/^[\#\%]/) {					#Skip comments
			next;
		}
		if (/^\[(.*)\]$/) {				# This is a section name because the
												# first character is '[' and the last
												# is ']'.
			$section = $_;
			next;
		}
		@entry = split(/\s*=\s*/); 
# Skip keys only or keys with more than one values.
		if (defined($entry[2]) || !defined($entry[1])) {
			next;
		}
# Here begins program specific section.
		if ((lc($section) eq "[global]") && (lc($entry[0]) eq "port")) {
			$port = int($entry[1]);
		}
		if ((lc($section) eq "[global]") && (lc($entry[0]) eq "targets")) {
			@targets = split('\s*[,;]\s*', $entry[1]);
		}
	}
	close(CONF);
}

foreach $remote (@targets) {
	$iaddr = inet_aton($remote);
	$paddr = sockaddr_in($port, $iaddr);
	$proto = getprotobyname('tcp');

	$final_string = $final_string . "Changing password of " . $target . " on ". $remote . "\n";
	unless (socket(SOCK, PF_INET, SOCK_STREAM, $proto)) {
		$final_string = $final_string . "Invalid socket call: $!\n";
		next;
	}
	unless (connect(SOCK, $paddr)) {
		$final_string = $final_string . "Invalid connect call: $!\n";
		next;
	}
	$welcome = read_string(SOCK);
	if ("+" ne $welcome) {
		$final_string = $final_string . "Invalid response from server.\n";
		next;
	}
	write_string(SOCK, $login);
	write_string(SOCK, $target);
	write_string(SOCK, $old_password);
	$go_ahead = read_string(SOCK);
	if ("!" eq $go_ahead) {
		write_string(SOCK, $new_password);
		$result = read_string(SOCK);
		if ("%" eq $result) {
			$final_string = $final_string . "Password successfully changed.\n";
		} elsif ("^" eq $result) {
			$final_string = $final_string . "Password still unchanged. Server returned error.\n";
		} elsif ("^3" eq $result) {
			$final_string = $final_string . "Bad password: %s" . read_string(SOCK);
		} else {
			$final_string = $final_string . "Invalid response from server.\n";
		}
	} else {
		if ("^2" eq $go_ahead) {
			$final_string = $final_string . "Invalid login.\n";
		} else {
			$final_string = $final_string . "Invalid response from server.\n";
		}
	}
	close(SOCK);
}
display_result($final_string);

sub read_string
{
	$result = "";
	do {
		read($_[0], $c, 1);
		if ($c ne "\0") {
			$result = $result . $c;
		}
	} while ($c ne "\0");
	return $result;
}

sub write_string
{
	$out = $_[1] . "\0";
	return syswrite($_[0], $out, length($out));
}

sub display_result
{
	if (open(RESULTS, "< $results_file")) {
		while (<RESULTS>) {
			if (/<!-- Insert result here -->/) {
				$_[0] =~ s/\n/<BR>\n/g;
				printf($_[0]);
			} else {
				printf($_);
			}
		}
		close(RESULTS);
	}	
}