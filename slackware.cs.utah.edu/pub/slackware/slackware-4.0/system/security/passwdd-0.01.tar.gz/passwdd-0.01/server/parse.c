#include <sys/types.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pwd.h>

#ifdef SHADOWPWD
#include "shadowio.h"
#endif

long nstrtol(char *, int *);
char *nltoa(long);

#define	NFIELDS	7

struct passwd *sgetpwent(const char *pszEntry)
{
	static struct passwd strResult;
	static char szBuf[1024];
	char *ppszField[NFIELDS];
	register char *p;
	register int i;
	int fgError;
	
	assert(NULL != pszEntry);

	if (strlen(pszEntry) >= sizeof(szBuf))
		return 0;
	strcpy(szBuf, pszEntry);

	for (i = 0, p = szBuf; (i < NFIELDS) && p; i++) {
	   ppszField[i] = p;
		while(*p && *p != ':')
	   	++p;
		if (*p)
	   	*p++ = '\0';
		else
	   	p = 0;
	}

	if ((i != NFIELDS) || 
		 (*ppszField[2] == '\0') || 
		 (*ppszField[3] == '\0'))
		return 0;

	strResult.pw_name = ppszField[0];		// user name
	strResult.pw_passwd = ppszField[1];		// user password
	strResult.pw_uid = nstrtol(ppszField[2], &fgError);
	if (fgError)
		return 0;									// user id
	strResult.pw_gid = nstrtol(ppszField[3], &fgError);
	if (fgError)
		return 0;									// group id
	
#ifdef ATT_AGE
	strResult.pw_age = "";
	if (NULL != strtok(strResult.pw_passwd, ","))
		strResult.pw_age = strtok(NULL, "");
	if (NULL == strResult.pw_age)
		strResult.pw_age = "";
#endif
	
	strResult.pw_gecos = ppszField[4];		// real name
	
#ifdef ATT_COMMENT
	strResult.pw_comment = "";
#endif
	
	strResult.pw_dir = ppszField[5];			// home directory
	strResult.pw_shell = ppszField[6];		// shell program
	
	return &strResult;
}

#ifdef SHADOWPWD

#define	FIELDS	9
#define	OFIELDS	5

struct spwd *sgetspent(const char *pszEntry)
{
	static char szBuf[1024];
	static struct spwd strResult;
	char	*ppszField[FIELDS];
	register char *p;
	register int i;
	int fgError;
	
	assert(NULL != pszEntry);

	if (strlen(pszEntry) >= sizeof(szBuf))
		return 0;
	strcpy(szBuf, pszEntry);

	for (i = 0, p = szBuf; (i < FIELDS) && p; i++) {
		ppszField[i] = p;
		while (*p && *p != ':')
	   	p++;
		if (*p)
			*p++ = '\0';
	}

	if (i == (FIELDS - 1))
		ppszField[i++] = p;

	if ((p && *p) || (i != FIELDS && i != OFIELDS))
		return 0;
	
	strResult.sp_namp = ppszField[0];					// user login name
	strResult.sp_pwdp = ppszField[1];					// encrypted password

	strResult.sp_lstchg = nstrtol(ppszField[2], &fgError);
	if (fgError)
		return 0;												// last password change
	strResult.sp_min = nstrtol(ppszField[3], &fgError);
	if (fgError)
		return 0;												// days until change allowed
	strResult.sp_max = nstrtol(ppszField[4], &fgError);
	if (fgError)
		return 0;												// days before change required
	
	if ('\0' == ppszField[2][0])
		strResult.sp_lstchg = -1;
	if ('\0' == ppszField[3][0])
		strResult.sp_min = -1;
	if ('\0' == ppszField[4][0])
		strResult.sp_max = -1;
	
#if 0  /* SVR4 */
	if (i == OFIELDS)
		return 0;
#else
	if (i == OFIELDS) {
		strResult.sp_warn = 
		strResult.sp_inact =
		strResult.sp_expire =
		strResult.sp_flag = -1;
		return &strResult;
	}
#endif

	strResult.sp_warn = nstrtol(ppszField[5], &fgError);
	if (fgError)
		return 0;
	strResult.sp_inact = nstrtol(ppszField[6], &fgError);
	if (fgError)
		return 0;	  
	strResult.sp_expire = nstrtol(ppszField[7], &fgError);
	if (fgError)
		return 0;
	strResult.sp_flag = nstrtol(ppszField[8], &fgError);
	if (fgError)
		return 0;
	  
	if ('\0' == ppszField[5][0])
		strResult.sp_warn = -1;
	if ('\0' == ppszField[6][0])
		strResult.sp_inact = -1;
	if ('\0' == ppszField[7][0])
		strResult.sp_expire = -1;
	if ('\0' == ppszField[8][0])
		strResult.sp_flag = -1;

	return (&strResult);
}
#endif

/*
 * This function converts given string to long integer.
 * Returns 0 and FALSE on piError if pszString is empty.
 * Returns N and FALSE on piError if pszString is valid long.
 * Returns N and TRUE on piError if pszString contains invalid
 * characters (N is formed by the first valid chars).
 */
long nstrtol(char *pszString, int *piError)
{
	char *p;
	long l = strtol(pszString, &p, 10);
	if (NULL != piError) {
		*piError = 0;
		if ((0 == l) && *p)
			*piError = 1;
	}
	  
	return l;
}

char *nltoa(long l)
{
	static char szBuf[16];
	
	szBuf[0] = '\0';
	
	if (-1 != l)
		snprintf(szBuf, 16, "%ld", l);
	
	return szBuf;
}
