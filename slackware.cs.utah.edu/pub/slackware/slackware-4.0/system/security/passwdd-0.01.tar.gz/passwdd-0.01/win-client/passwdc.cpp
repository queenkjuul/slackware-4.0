#include "passwdc.h"
#include "conf.h"

#define strzero(p) memset(p, 0, strlen(p))

int main(int argc, char **argv)
{
	static char szServers[512];
	static char szBuf[128];
	
	static char szOldPassword[128];
	static char szNewPassword1[128];
	static char szNewPassword2[128];
	
	struct sockaddr_in client;
	struct hostent *pHost;
	
	char *pszLogin;
	char *pszTarget;
	char *pszServer;
	char *pszTmp;
	char *pszOldPassword;
	char *pszNewPassword1;
	char *pszNewPassword2;
	
	int sockfd;
	
	int iMaxLen = 8;
	int iMinLen = 5;
	
	unsigned short iServerPort;
	
	int iResult = 0;

	char *pszConfig = NULL;

	if (argc > 2)
		for (int i = 1; i < argc; i++)
			if ('-' == argv[i][0])				// We have option
				if ('c' == argv[i][1]) {		// We have other config file
					if ('\0' != argv[i][2])	{	// The user has not typed space aftrt -c
						pszConfig = &argv[i][3];
						argc -= 1;
					} else {
						pszConfig = i < (argc - 1) ? argv[i + 1] : NULL;
						argc -= 2;
					}
				}

	if ((argc < 2) || (argc > 3)) {
		printf("Usage: passwdc <target> [<login>] [-c <config file>]\n");
		printf("Where: <target> is the user whose password you want to change;\n");
		printf("       <login> is your login if you are master user for the\n");
		printf("       specified target.\n");
		printf("Options: -c <config file> - Use alternate config file instead\n");
		printf("         the default 'passwdc.ini' in the windows directory.\n");
		printf("Written by: <Alexander Feldman> alex@varna.net\n\n");
		return 1;
	}

	char szConfig[MAX_PATH];
	if (NULL == pszConfig) {
		GetWindowsDirectory(szConfig, sizeof(szConfig));
		strcat(szConfig, "\\"CONF_FILE);
		pszConfig = szConfig;
	}
// The default directory for the configuration file is that in which windows is
// installed

	if (FALSE == init_conf(pszConfig, &pszTmp)) {
		printf("Error initializing configuration file.\n%s\n", pszTmp);
		return 2;
	}

	WSADATA WSAData;
	int iStatus;
	if (0 != (iStatus = WSAStartup(MAKEWORD(2, 2), &WSAData))) {
		printf("Socket init error: %s\n%s.\n", WSAData.szDescription, WSAData.szSystemStatus);
		return 1;
	}

	iServerPort = (unsigned short)get_int("Global", "port", SERV_TCP_PORT);
	get_string("Global", "targets", "localhost", szServers, sizeof(szServers));
	
	pszTarget = argv[1];
	pszLogin = (argc == 2 ? argv[1] : pszTarget);
	
	pszOldPassword = getpass("Old password:");
	strcpy(szOldPassword, pszOldPassword);
	strzero(pszOldPassword);

// In fact we don't need to check for login lengths on the source machine but
// on the target but it always better to have sample restrictions for the
// min and max lengths of a string than not to have.	
	printf("Enter the new password (minimum of %d, maximum of %d characters)\n", iMinLen, iMaxLen);
	printf("Please use combination of upper and lower case letters and numbers.\n");
	
	pszNewPassword1 = getpass("New password:");
	strcpy(szNewPassword1, pszNewPassword1);	
	strzero(pszNewPassword1);
	pszNewPassword2 = getpass("Re-enter new password:");
	strcpy(szNewPassword2, pszNewPassword2);
	strzero(pszNewPassword2);
	
// We can skip overflow and error checking from getpass(), because in all
// cases it returns valid pointer and the internal buffer is 128 bytes and
// null terminated.	
	
	if (0 != strcmp(szNewPassword1, szNewPassword2)) {
		printf("They don't match; try again.\n");
		iResult = 1;
		goto err_exit;
	}
	if ((int)strlen(szNewPassword1) < iMinLen || 
		 (int)strlen(szNewPassword1) > iMaxLen) {
		printf("They don't meet length criteria; try again.\n");		
		iResult = 2;
		goto err_exit;
	}
	printf("\n");

	pszServer = strtok(szServers, ";,");
	do {
		pszServer += strspn(pszServer, " \t");			
		printf("Changing password for %s on %s\n", pszTarget, pszServer);
	
		if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) == INVALID_SOCKET) {
			printf("Socket error: %d\n", WSAGetLastError());
			continue;
		}

		unsigned long ulHost;
		memset(&client, 0, sizeof(client));
		client.sin_family = AF_INET;
		client.sin_port = htons(iServerPort);
		if ((ulHost = inet_addr(pszServer)) == INADDR_NONE) {
			pHost = gethostbyname(pszServer);
			if (NULL == pHost) {
				printf("Resolving error: %d\n", WSAGetLastError());
				continue;
			}
			client.sin_addr.s_addr = *((unsigned long int *)(pHost->h_addr));
		} else
			client.sin_addr.s_addr = ulHost;

		if (connect(sockfd, (struct sockaddr *)&client, sizeof(client)) < 0) {
			printf("Connect error: %d\n", WSAGetLastError());
			close(sockfd);
			continue;
		}
		read_string(sockfd, szBuf, sizeof(szBuf));
		if (0 != strcmp(szBuf, "+")) {
			printf("Invalid response from server.\n");
			close(sockfd);
			continue;
		}
		if (((int)strlen(pszLogin) + 1 != write_string(sockfd, pszLogin)) ||
		    ((int)strlen(pszTarget) + 1 != write_string(sockfd, pszTarget)) ||
		    ((int)strlen(szOldPassword) + 1 != write_string(sockfd, szOldPassword))) {
			close(sockfd);
			continue;
		}
		read_string(sockfd, szBuf, sizeof(szBuf));
		if (0 == strcmp(szBuf, "^2")) {
			printf("Incorrect login or password for %s on %s.\n", pszLogin, pszServer);
			close(sockfd);
			continue;
		} else if (0 != strcmp(szBuf, "!")) {
			printf("Invalid response from server.\n");			
			close(sockfd);
			continue;
		}
		if ((int)strlen(szNewPassword1) + 1 != write_string(sockfd, szNewPassword1)) {
			close(sockfd);
			continue;
		}
		read_string(sockfd, szBuf, sizeof(szBuf));
		if (0 == strcmp(szBuf, "^3")) {
			read_string(sockfd, szBuf, sizeof(szBuf));
			printf("Bad password: %s.\n", szBuf);
		} else if (0 == strcmp(szBuf, "%")) {
			printf("Password successfully changed.\n");
		} else if (0 == strcmp(szBuf, "^")) {
			printf("Password still unchanged. Server returned error.");
		} else {
			printf("Invalid response from server.\n");
		}
		close(sockfd);
	} while (NULL != (pszServer = strtok(NULL, ";,")));

err_exit:
	destroy_conf();
	strzero(szOldPassword);
	strzero(szNewPassword1);
	strzero(szNewPassword2);

	WSACleanup();
	
	return iResult;
}

int read_string(int sockfd, char *pszString, int iMaxLength)
{
	char c;
	int i, j;
	
// TODO - It'll be more faster to read bigger junks of data.
//	       We need also some additional error handling.	
	for (i = 0; i < iMaxLength; i++) {
		if (1 == (j = recv(sockfd, &c, 1, 0))) {
			if ('\0' == c)
				break;
			*pszString++ = c;
		} else if (0 == j)	// EOF
			break;
		else
			return -1;			// Error
	}

	*pszString = '\0';
	return i;
}

int write_string(int sockfd, char *pszString)
{
	int iResult = send(sockfd, pszString, strlen(pszString) + 1, 0);
	
	if ((int)strlen(pszString) + 1 != iResult)
		printf("write error: %s\n", strerror(errno));
	
	return iResult;
}

char *getpass(char *pszPrompt)
{
	static char szPassword[32];

	printf("%s ", pszPrompt);
	int c, i = 0;
	while (('\r' != (c = _getch())) && (i < sizeof(szPassword) - 1))
		szPassword[i++] = 'c';
	szPassword[i] = '\0';
	putch('\n');
	
	return szPassword;
}