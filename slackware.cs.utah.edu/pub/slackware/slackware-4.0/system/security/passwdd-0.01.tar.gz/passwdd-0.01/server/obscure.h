#ifndef __OBSCURE_H__
#define __OBSCURE_H__

#include "globals.h"

// Function prototypes
char *obscure(const char *, const char *, bool);

#endif // __OBSCURE_H__