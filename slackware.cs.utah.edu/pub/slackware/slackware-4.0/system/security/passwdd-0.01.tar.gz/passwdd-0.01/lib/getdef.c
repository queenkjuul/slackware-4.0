#include <ctype.h>
#include <stdio.h>
#include <syslog.h>
#include <stdlib.h>
#include <string.h>

#include "getdef.h"

#ifndef LOGINDEFS
	#define LOGINDEFS "/etc/login.defs"
#endif

int getdef_bool(const char *pszWhat)
{
	char *pszString = getdef_str(pszWhat);

	if (NULL == pszString)
		return 0;

	return (0 == strcasecmp(pszString, "yes"));
}

int getdef_num(const char *pszWhat, int iDefault)
{
	char *pszString = getdef_str(pszWhat);
	
	if (NULL == pszString)
		return iDefault;

	return (int)strtol(pszString, (char **)NULL, 0);
}

long getdef_long(const char *pszWhat, long lDefault)
{
	char *pszString = getdef_str(pszWhat);
	
	if (NULL == pszString)
		return lDefault;

	return strtol(pszString, (char **)NULL, 0);
}

char *getdef_str(const char *pszWhat)
{
	FILE *fpIn;
	static char szBuf[1024];
	char *pszName;
	char *pszItem;
	register int i;

	if (NULL == (fpIn = fopen(LOGINDEFS, "r"))) {
		syslog(LOG_USER | LOG_INFO, "passwdd: cannot open login definitions %s", LOGINDEFS);
		return NULL;
	}

	while (NULL != fgets(szBuf, sizeof(szBuf), fpIn)) {
		for (i = strlen(szBuf) - 1; i >= 0; --i)
			if (!isspace(szBuf[i]))
				break;
		szBuf[++i] = '\0';

		pszName = szBuf + strspn(szBuf, " \t");
		if (*pszName == '\0' || *pszName == '#')
			continue;

		pszItem = pszName + strcspn(pszName, " \t");
		if (*pszItem == '\0')
			continue;

		*pszItem++ = '\0';
		pszItem = pszItem + strspn(pszItem, " \"\t");
		*(pszItem + strcspn(pszItem, "\"")) = '\0';
		if (0 == strcmp(pszWhat, pszName)) {
			fclose(fpIn);
			return pszItem;
		}
	}
	fclose(fpIn);
	
	return NULL;
}