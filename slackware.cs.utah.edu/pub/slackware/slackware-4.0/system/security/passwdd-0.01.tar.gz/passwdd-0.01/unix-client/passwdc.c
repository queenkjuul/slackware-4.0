#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <syslog.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

#include "globals.h"
#include "getdef.h"
#include "conf.h"

#define SERV_TCP_PORT 1099
#define CONF_FILE		 "/etc/passwdc.conf"

#define strzero(p) memset(p, 0, strlen(p))

// Function prototypes
int read_string(int, char *, int);
int write_string(int, char *);

int main(int argc, char **argv)
{
	static char szServers[512];
	static char szBuf[128];
	
	static char szOldPassword[128];
	static char szNewPassword1[128];
	static char szNewPassword2[128];
	
	struct sockaddr_in client;
	struct hostent *pHost;
	
	char *pszLogin;
	char *pszTarget;
	char *pszServer;
	char *pszTmp;
	char *pszOldPassword;
	char *pszNewPassword1;
	char *pszNewPassword2;
	
	int sockfd;
	
	int iMaxLen;
	int iMinLen;
	
	int iServerPort;
	
	int iResult = 0;
	
	register int i;
	
	char *pszConfig = getenv("PASSWDCCONF");

	if (argc > 1)
		for (i = 1; i < argc; i++)
			if ('-' == argv[i][0])				// We have option
				if ('c' == argv[i][1]) {		// We have other config file
					if ('\0' != argv[i][2]) {	// The user has not typed space aftrt -c
						pszConfig = &argv[i][3];
						argc -= 1;
					} else {
						pszConfig = i < (argc - 1) ? argv[i + 1] : NULL;
						argc -= 2;
					}
				}

	if ((argc < 1) || (argc > 3)) {
		printf("Usage: passwdc [<target>] [<login>] [-c <config file>]\n");
		printf("Where: <target> is the user whose password you want to change;\n");
		printf("       <login> is your login if you are master user for the\n");
		printf("       specified target.\n");
		printf("Options: -c <config file> - Use alternate config file instead\n");
		printf("	 the default '/etc/passwdc.ini' system wide config file.\n");
		printf("Written by: <Alexander Feldman> alex@varna.net\n\n");
		return 1;
	}

	if (NULL == pszConfig)
		pszConfig = CONF_FILE;
	
	if (FALSE == init_conf(pszConfig, &pszTmp)) {
		printf("Error initializing configuration file.\n%s\n", pszTmp);
		return 2;
	}
	
	iServerPort = get_int("Global", "port", SERV_TCP_PORT);
	get_string("Global", "targets", "localhost", szServers, sizeof(szServers));
	
	openlog(argv[0], LOG_PID, LOG_USER);
	
	pszLogin = getlogin();
	pszTarget = (argc == 2 ? argv[1] : pszLogin);
	
	pszOldPassword = getpass("Old password:");
	strcpy(szOldPassword, pszOldPassword);
	strzero(pszOldPassword);

// In fact we don't need to check for login lengths on the source machine but
// on the target but it always better to have sample restrictions for the
// min and max lengths of a string than not to have.	
	iMinLen = getdef_num("PASS_MIN_LEN", 5);
	iMaxLen = getdef_num("PASS_MAX_LEN", 8);
	printf("Enter the new password (minimum of %d, maximum of %d characters)\n", iMinLen, iMaxLen);
	printf("Please use combination of upper and lower case letters and numbers.\n");
	
	pszNewPassword1 = getpass("New password:");
	strcpy(szNewPassword1, pszNewPassword1);	
	strzero(pszNewPassword1);
	pszNewPassword2 = getpass("Re-enter new password:");
	strcpy(szNewPassword2, pszNewPassword2);
	strzero(pszNewPassword2);
	
// We can skip overflow and error checking from getpass(), because in all
// cases it returns valid pointer and the internal buffer is 128 bytes and
// null terminated.	
	
	if (0 != strcmp(szNewPassword1, szNewPassword2)) {
		printf("They don't match; try again.\n");
		iResult = 1;
		goto err_exit;
	}
	if (strlen(szNewPassword1) < iMinLen || 
		 strlen(szNewPassword1) > iMaxLen) {
		printf("They don't meet length criteria; try again.\n");		
		iResult = 2;
		goto err_exit;
	}
	printf("\n");

	pszServer = strtok(szServers, ";,");
	do {
		pszServer += strspn(pszServer, " \t");			
		printf("Changing password for %s on %s\n", pszTarget, pszServer);
	
		if ((sockfd = socket(PF_INET, SOCK_STREAM, 0)) < 0) {
			printf("Socket error: %s\n", strerror(errno));
			continue;
		}

		pHost = gethostbyname(pszServer);
		if (NULL == pHost) {
			printf("Resolving error: %s\n", pszServer);
			continue;
		}
		memset(&client, 0, sizeof(client));
		client.sin_family = AF_INET;
		client.sin_addr.s_addr = *((unsigned long int *)(pHost->h_addr));
		client.sin_port = htons(iServerPort);
	
		if (connect(sockfd, (struct sockaddr *)&client, sizeof(client)) < 0) {
			printf("Connect error: %s\n", strerror(errno));
			close(sockfd);
			continue;
		}
		read_string(sockfd, szBuf, sizeof(szBuf));
		if (0 != strcmp(szBuf, "+")) {
			printf("Invalid response from server\n");
			close(sockfd);
			continue;
		}
		if ((strlen(pszLogin) + 1 != write_string(sockfd, pszLogin)) ||
		    (strlen(pszTarget) + 1 != write_string(sockfd, pszTarget)) ||
		    (strlen(szOldPassword) + 1 != write_string(sockfd, szOldPassword))) {
			printf("Write error.\n");
			close(sockfd);
			continue;
		}
		read_string(sockfd, szBuf, sizeof(szBuf));
		if (0 == strcmp(szBuf, "^2")) {
			printf("Incorrect login or password for %s on %s.\n", pszLogin, pszServer);
			close(sockfd);
			continue;
		} else if (0 != strcmp(szBuf, "!")) {
			printf("Invalid response from server.\n");			
			close(sockfd);
			continue;
		}
		if (strlen(szNewPassword1) + 1 != write_string(sockfd, szNewPassword1)) {
			printf("Write error.\n");
			close(sockfd);
			continue;
		}
		read_string(sockfd, szBuf, sizeof(szBuf));
		if (0 == strcmp(szBuf, "^3")) {
			read_string(sockfd, szBuf, sizeof(szBuf));
			printf("Bad password: %s.\n", szBuf);
		} else if (0 == strcmp(szBuf, "%")) {
			printf("Password successfully changed.\n");
		} else if (0 == strcmp(szBuf, "^")) {
			printf("Password still unchanged. Server returned error.");
		} else {
			printf("Invalid response from server.\n");
		}
		close(sockfd);
	} while (NULL != (pszServer = strtok(NULL, ";,")));

err_exit:
	destroy_conf();
	closelog();

	strzero(szOldPassword);
	strzero(szNewPassword1);
	strzero(szNewPassword2);
	
	return iResult;
}

int read_string(int sockfd, char *pszString, int iMaxLength)
{
	char c;
	int i, j;
	
// TODO - It'll be more faster to read bigger junks of data.
//	       We need also some additional error handling.	
	for (i = 0; i < iMaxLength; i++) {
		if (1 == (j = read(sockfd, &c, 1))) {
			if ('\0' == c)
				break;
			*pszString++ = c;
		} else if (0 == j)	// EOF
			break;
		else
			return -1;			// Error
	}

	*pszString = '\0';
	return i;
}

int write_string(int sockfd, char *pszString)
{
	int iResult = write(sockfd, pszString, strlen(pszString) + 1);
	
	if (strlen(pszString) + 1 != iResult)
		syslog(LOG_USER | LOG_INFO, "write error: %s", strerror(errno));
	
	return iResult;
}
