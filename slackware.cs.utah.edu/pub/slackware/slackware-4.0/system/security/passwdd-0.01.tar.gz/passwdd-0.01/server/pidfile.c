#include <stdio.h>
#include <sys/file.h>
#include <signal.h>
#include <errno.h>
#include <unistd.h>

int read_pid(char *pidfile)
{
	FILE *fp;
	int pid;

	if (NULL == (fp = fopen(pidfile, "r")))
		return 0;
	fscanf(fp, "%d", &pid);
	fclose(fp);
	return pid;
}

int check_pid(char *pidfile)
{
	int pid = read_pid(pidfile);

/* Amazing ! _I_ am already holding the pid file... */
	if ((!pid) || (pid == getpid()))
		return 0;

/*
 * The 'standard' method of doing this is to try and do a 'fake' kill
 * of the process.  If an ESRCH error is returned the process cannot
 * be found -- GW
 */
/* But... errno is usually changed only on error.. */
	if (kill(pid, 0) && errno == ESRCH)
		return(0);

	return pid;
}

int write_pid(char *pidfile)
{
	FILE *fp;
	int fd;
	int pid;

	if (((fd = open(pidfile, O_RDWR | O_CREAT, 0644)) == -1) || 
		 ((fp = fdopen(fd, "r+")) == NULL)) {
		fprintf(stderr, "Can't open or create %s.\n", pidfile);
		return 0;
	}

	if (flock(fd, LOCK_EX | LOCK_NB) == -1) {
		fscanf(fp, "%d", &pid);
		fclose(fp);
		printf("Can't lock, lock is held by pid %d.\n", pid);
		return 0;
	}

	pid = getpid();
	if (!fprintf(fp, "%d\n", pid)) {
		printf("Can't write pid , %s.\n", strerror(errno));
		close(fd);
		return 0;
	}
	fflush(fp);

	if (flock(fd, LOCK_UN) == -1) {
		printf("Can't unlock pidfile %s, %s.\n", pidfile, strerror(errno));
		close(fd);
		return 0;
	}
	close(fd);

	return pid;
}

int remove_pid(char *pidfile)
{
	return unlink(pidfile);
}