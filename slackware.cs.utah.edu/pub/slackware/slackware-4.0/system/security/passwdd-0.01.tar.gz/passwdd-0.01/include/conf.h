#ifndef __CONF_H__
#define __CONF_H__

#include "globals.h"

// Function prototypes
bool init_conf(char *, char **);
char *get_string(char *, char *, char *, char *, int);
long get_int(char *, char *, long);
bool get_bool(char *, char *, bool);
void destroy_conf();

typedef struct {
	char *pszKey;
	char *pszData;
	char *pszSection;
	void *pNext;
} tEntry;

#endif // __CONF_H__