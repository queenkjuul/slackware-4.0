#include <assert.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>

#include "obscure.h"
#include "getdef.h"

char *obscure(const char *pszOldPassword, const char *pszNewPassword, bool fgSelfChange)
{
	char *pszDouble;
	char *pszCopy;
	register int i, j, k;
	bool fgFlag;
#ifdef HAVE_LIBCRACK
	char *pszMsg = NULL;
	char *pszDictPath;
#ifdef HAVE_LIBCRACK_PW
	char *FascistCheckPw();
#else
	char *FascistCheck();
#endif
#endif
	
	assert(pszOldPassword);
	assert(pszNewPassword);
	
	if ('\0' == *pszNewPassword)
		return "no password";
	
// In case we change our own password we check wether it is similar to the
//	old one.	
	if (fgSelfChange) {
		if (0 == strcmp(pszOldPassword, pszNewPassword))
			return "no change";
		if (0 == strcasecmp(pszOldPassword, pszNewPassword))
			return "case changes only";
		pszDouble = (char *)malloc(strlen(pszOldPassword) * 2 + 1);
		pszCopy = (char *)malloc(strlen(pszNewPassword) + 1);
		if (!pszDouble || !pszCopy) {
			fprintf(stderr, "malloc failed\n");
			exit(13);
		}
		strcpy(pszDouble, pszOldPassword);
		strcat(pszDouble, pszOldPassword);
		strcpy(pszCopy, pszNewPassword);
		for (i = 0; pszDouble[i] != '\0'; i++)
			pszDouble[i] = tolower(pszDouble[i]);
		for (i = 0; pszCopy[i] != '\0'; i++)
			pszCopy[i] = tolower(pszCopy[i]);
		fgFlag = FALSE;
		if (strstr(pszDouble, pszCopy))
			fgFlag = TRUE;
		memset(pszDouble, 0, strlen(pszDouble));
		memset(pszCopy, 0, strlen(pszCopy));
		free(pszDouble);
		free(pszCopy);
		if (TRUE == fgFlag)
			return "rotated";
		for (i = j = 0; pszNewPassword[i] && pszOldPassword[i]; i++)
			if ((NULL != strchr(pszOldPassword, tolower(pszNewPassword[i]))) ||
				 (NULL != strchr(pszOldPassword, toupper(pszNewPassword[i]))))
				j += 1;
		if (i < j * 2)
			return "too similar";
	}
	for (i = j = 0; pszNewPassword[i] != '\0'; i++)
		if (isdigit(pszNewPassword[i]))
			j |= 1;
		else if (islower(pszNewPassword[i]))
	   	j |= 2;
		else if (isupper(pszNewPassword[i]))
	  		j |= 4;
		else
			j |= 8;
	for (i = 0, k = 9; i < 4; i++)
		if (0 != (j & (1 << i)))
			k -= 1;
	i = strlen(pszNewPassword);
	if (i < k)
		return "too simple";
	
	fgFlag = TRUE;
	for (j = 0; j < i; j++)
		if (pszNewPassword[j] != pszNewPassword[i - j - 1]) {
			fgFlag = FALSE;
			break;
		}
	if (fgFlag)
		return "a palindrome";
	
#ifdef HAVE_LIBCRACK
	if (NULL != (pszDictPath = getdef_str("CRACKLIB_DICTPATH")))
		pszMsg = FascistCheck(pszNewPassword, pszDictPath);
	if (NULL != pszMsg)						// This check is to suppress compiler
		return pszMsg;							// warning.
#endif
	
	return NULL;
}