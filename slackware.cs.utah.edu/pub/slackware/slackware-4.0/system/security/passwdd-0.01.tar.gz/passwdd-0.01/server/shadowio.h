#ifndef __SHADOWIO_H__
#define __SHADOWIO_H__

#include <time.h>

// Structure definition
struct spwd 
{
	char *sp_namp;				// login name
	char *sp_pwdp;				// encrypted password
	time_t sp_lstchg;			// date of last change
	time_t sp_min;				// minimum number of days between changes
	time_t sp_max;				// maximum number of days between changes
	time_t sp_warn;			// number of days of warning before password expires
	time_t sp_inact;			// number of days after password expires unntil the account becomes unusable.
	time_t sp_expire;			// days since 1/1/70 until account expires
	unsigned long sp_flag;	// reserved for future use
};

// Function prototypes
extern struct spwd *__spw_dup(const struct spwd *);
extern void __spw_set_changed(void);
extern int spw_close(void);
extern int spw_file_present(void);
extern const struct spwd *spw_locate(const char *);
extern int spw_lock(void);
extern int spw_name(const char *);
extern const struct spwd *spw_next(void);
extern int spw_open(int);
extern int spw_remove(const char *);
extern int spw_rewind(void);
extern int spw_unlock(void);
extern int spw_update(const struct spwd *);

#endif // __SHADOWIO_H__