#ifndef __PARSE_H__
#define __PARSE_H__

#include <stdio.h>

#include "shadowio.h"
#include "pwio.h"

struct passwd *sgetpwent(const char *);
struct spwd *sgetspent(const char *);

#endif // __PARSE_H__