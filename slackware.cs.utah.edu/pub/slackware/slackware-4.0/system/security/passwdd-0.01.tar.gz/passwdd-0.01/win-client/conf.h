#ifndef __CONF_H__
#define __CONF_H__

// New data types and constants
typedef struct 
{
	char *pszSection;
	char *pszData;
	char *pszKey;
	void *pNext;
} tEntry;

// Function prototypes
bool init_conf(char *, char **);
char *get_string(char *, char *, char *, char *, int);
long get_int(char *, char *, long);
bool get_bool(char *, char *, bool);
void destroy_conf();

#endif	// __CONF_H__