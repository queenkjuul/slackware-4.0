#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/time.h>

#include "salt.h"
#include "getdef.h"

/*
 * Generate 8 base64 ASCII characters of random salt.  If MD5_CRYPT_ENAB
 * in /etc/login.defs is "yes", the salt string will be prefixed by "$1$"
 * (magic) and pw_encrypt() will execute the MD5-based FreeBSD-compatible
 * version of crypt() instead of the standard one.
 */
char *crypt_make_salt(void)
{
	struct timeval tv;
	static char result[40];

	result[0] = '\0';
	if (getdef_bool("MD5_CRYPT_ENAB"))
		strcpy(result, "$1$");  /* magic for the new MD5 crypt() */

	/*
	 * Generate 8 chars of salt, the old crypt() will use only first 2.
	 */
	gettimeofday(&tv, (struct timezone *) 0);
	strcat(result, l64a(tv.tv_usec));
	strcat(result, l64a(tv.tv_sec + getpid() + clock()));

	if (strlen(result) > 3 + 8)  /* magic+salt */
		result[11] = '\0';

	return result;
}

char *l64a(long l)
{
	static char szBuf[8];
   int i = 0;
	
	if (l < 0L)
		return NULL;
	
	do {
		szBuf[i++] = i64c((int)(l % 64));
		szBuf[i] = '\0';
	} while (l /= 64L, l > 0 && i < 6);
	
   return szBuf;
}

int i64c(int i)
{
	if (i <= 0)
		return ('.');

	if (i == 1)
		return ('/');

	if (i >= 2 && i < 12)
		return ('0' - 2 + i);

	if (i >= 12 && i < 38)
		return ('A' - 12 + i);

	if (i >= 38 && i < 63)
		return ('a' - 38 + i);

	return ('z');
}