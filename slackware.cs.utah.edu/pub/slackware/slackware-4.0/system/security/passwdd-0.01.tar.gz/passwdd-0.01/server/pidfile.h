#ifndef __PIDFILE_H__
#define __PIDFILE_H__

extern int read_pid(char *);
extern int check_pid(char *);
extern int write_pid(char *);
extern int remove_pid(char *);

#endif // __PIDFILE_H__