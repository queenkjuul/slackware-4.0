#ifndef __GLOBALS_H__
#define __GLOBALS_H__

typedef enum { FALSE, TRUE } bool;

#endif // __GLOBALS_H__