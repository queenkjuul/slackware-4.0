#ifndef __PASSWDC_H__
#define __PASSWDC_H__

#include <stdio.h>
#include <winsock.h>
#include <io.h>
#include <conio.h>

#define CONF_FILE		 "passwdc.ini"
#define SERV_TCP_PORT 1099

// Function prototypes
int write_string(int, char *);
int read_string(int, char *, int);
char *getpass(char *);

#endif // __PASSWDC_H__