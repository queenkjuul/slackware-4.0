#ifndef __SALT_H__
#define __SALT_H__

char *crypt_make_salt();
char *l64a(long);
int i64c(int);

#endif // __SALT_H__