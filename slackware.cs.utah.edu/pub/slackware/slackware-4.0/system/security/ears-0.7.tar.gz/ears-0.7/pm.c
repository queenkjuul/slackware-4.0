#include "ears.h"

#define size(p) (sizeof(p))

int dev_flags=0,
    device_flags=0,
    set_look_all=0;

int
check_pm(void) {
 struct ifreq ifreq, *ifr;
 struct ifconf ifc;
 char buf[BUFSIZ], *cp, *cplim;

 set_look_all++;

 if((dev_flags = socket(PF_INET, SOCK_DGRAM, 0)) < 0) {
        perror(EARS_PROMPT);
	return -1;
 }

 ifc.ifc_len = sizeof(buf);
 ifc.ifc_buf = buf;

 if(ioctl(dev_flags, SIOCGIFCONF, (char *)&ifc) < 0) {
        perror(EARS_PROMPT);
	return -1;
 }
 ifr = ifc.ifc_req;
 cplim=buf+ifc.ifc_len;
 for(cp = buf; cp < cplim;
                cp += sizeof (ifr->ifr_name) + size(ifr->ifr_addr))
 {
                ifr = (struct ifreq *)cp;


                ifreq = *ifr;
                if(ioctl(dev_flags, SIOCGIFFLAGS, (char *)&ifreq) < 0)
                {
			perror(EARS_PROMPT);
                        continue;
                }

                device_flags=0; device_flags = ifreq.ifr_flags;
                printf("%s", ifreq.ifr_name);

                if((device_flags & IFF_PROMISC) != 0)
                        printf("\t\tYes\n");
                else
                        printf("\t\tNo\n");

                if(!set_look_all)
                        return 0; // We're finished..
                else
                        continue; // Go onto next device..

 }
	return 0;
}

