#ifndef __UWATCH_H
#define __UWATCH_H

#include "config.h"
#include "hash_func.h"

/* Flag variables */
#define RESTRICT     0x01
#define QUIET        0x02
#define QUICK        0x04
#define DEBUG        0x08
#define IN_EXPAND    0x10
#define KILL_ON_EXIT 0x20
#define NO_RUN_PROG  0x40
#define GOT_IN_MSG   0x80
#define GOT_OUT_MSG  0x100
#define GOT_IN_PROG  0x200
#define GOT_OUT_PROG 0x400

/* Global variables */
bucket *watch_list[NAME_HASH_SIZE];
char *in_format;
char *out_format;
char *in_program;
char *out_program;
char *user_tty;
int flag;
unsigned int sleep_time;

#endif  /* __UWATCH_H */
