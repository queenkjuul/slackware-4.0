#ifndef __HASH_FUNC_H
#define __HASH_FUNC_H


/* Data definitions */
typedef struct bucket_n {
	char *name;
	struct bucket_n *next;
} bucket;


/* Function prototypes */
bucket *new_name_bucket(void);
bucket *scan_name(char *);
int insert_name(char *);
void *init_name_hash(void);

#endif  /* __HASH_FUNC_H */
