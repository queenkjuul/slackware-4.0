#ifndef __UWATCH_FUNC_H
#define __UWATCH_FUNC_H

/* Flag Values */
#define COMMENTS 0x01
#define SPACE    0x02
#define TO_EOL   0x04
#define WHITE    0x08

#include <stdio.h>
#include <utmp.h>

/* Function Prototypes */
char *get_command(FILE *);
char *get_argument(FILE *);

void parse_config(char *);
void parse_name_file(char *);
void print_name (char *, struct utmp *);
void run_program(char *, struct utmp *);
void skip(FILE *, int);
void skip_line(FILE *, int);

#endif  /* __UWATCH_FUNC_H */
