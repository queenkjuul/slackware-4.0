/*
 *  webscan.c -- Gate network code
 *
 *  ORIGINAL AUTHOR: Stas Lanford (stas@netsis.com)
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */



#include "net.h"
#include "interface.h"
#include "util.h"






void phf_exploit(int sockfd, char buf[50], char *sbuf) {

	char str[50];

	memset((char *)sbuf, 0, 5000);
	sprintf(str, "%s\n\r", buf);
	if (sock_write(sockfd, str, sizeof(str)) < 0) {
		perror("sock_write");
		exit(1);
	}
	if (sock_read(sockfd, sbuf, 5000) < 0) {
		perror("sock_read");
		exit(1);
	}
}



	

int web_scan(char **host)
{

	int sockfd;
	char *sbuf;
	int index;
	FILE *log;

	log = openlog();


	 
	if ((sbuf = malloc(5000)) == NULL) {
		printf("memory allocation failure.\n");
		exit(1);
	}

	for (index=0; host[index]!=NULL; index++) { 


		close(sockfd);
		if (set_connect(host[index], 80, &sockfd) < 0) {
			fprintf(log,"%s: HTTPD not found.\n", host[index]);
			break;
		}
		else { 
			fprintf(log, "%s: HTTPD found. ", host[index]);
		}


		set_connect(host[index], 80, &sockfd);
		phf_exploit(sockfd, PHF_BUG, sbuf);
	/*	fprintf(log, "-%s-\n", sbuf); */
		if (strstr(sbuf, PHF_NEEDLE) == NULL) {
			fprintf(log, "HTTPD phf not allowed.\n"); 
		} else { 
			fprintf(log, "HTTPD phf ALLOWED.\n"); 
		}
	
	}
	fclose(log);
	dialog_clear();
	dialog_textbox(NFS_SCANRES, MAIN_LOG, 20, 60);
	return 0;
}
	

