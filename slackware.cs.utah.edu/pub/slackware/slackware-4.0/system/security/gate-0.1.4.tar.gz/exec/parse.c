#include <stdio.h>
#include <stdlib.h>
#include "net.h"


struct ipstr *copy(struct ips *ips);
struct ips *parseip(char *name);
struct tcp_scan * parsetcp(char *input);
char ** parsemain(char *input);


main(int argc, char **argv) {

	char **test;

	test = parsemain(argv[1]);
	printf("%s\n%s\n%s\n%s\n", test[0], test[1], test[2], test[3]);
}



char ** parsemain (char *input)

{

	struct ips *ips;
/*	struct ipstr *ipstr; */
	struct tcp_scan *tcpstr;
	short count3, count4;
	unsigned int point=0;
	char **range;


	if ((range = malloc(1000 * sizeof(char))) == NULL) {
		fprintf(stderr,"String memory allocation failure.\n");
		exit(1);
	}
	memset((char **)range, 0, 1000*sizeof(char));
	if (isalpha(input[0])) {
		tcpstr = parsetcp(input);
		range[0]=malloc(100);
		range[1]=malloc(10);
		range[2]=malloc(10);
		strcpy(range[0], tcpstr->host);
		strcpy(range[1], tcpstr->sport);
		strcpy(range[2], tcpstr->dport);
		free(tcpstr);
		return range;
	}

	if ((ips = parseip(input)) == (char)1) {
		printf("Invalid arguments.\n");
		return (char **)1;
	}
		for (count3=ips->p[2]; count3 <= ips->p[6]; count3++) {
			for (count4=ips->p[3]; count4 <= ips->p[7]; count4++) {
				char temp[16];
				sprintf(temp, "%d.%d.%d.%d", ips->p[0], 
					ips->p[1], count3, count4);
				if ((range[point] = malloc(20)) == NULL) {
					fprintf(stderr, "String memory allocation failure.\n");
					exit(1);
				}
				strcpy(range[point], temp);
				point++;
			}
		ips->p[3]=0; 
		}
	range[point++]=NULL;	
	return range;


}


struct ipstr *copy(struct ips *ips) {

	struct ipstr *ipstr;
	if ((ipstr = malloc(40)) == NULL) {
		fprintf(stderr, "String memory allocation failure.\n");
		exit(1);
	}
	sprintf(ipstr->sa, "%d.%d.%d.%d", ips->p[0], ips->p[1], ips->p[2], ips->p[3]);
        sprintf(ipstr->st, "%d.%d.%d.%d", ips->p[4], ips->p[5], ips->p[6], ips->p[7]);
	return ipstr;
}


struct ips *parseip(char *name) {

	int counter;	/* main array scooper */
	int counter1=0; /* increases on a new octet */
	int counter2=0; /* increases on a new character in each octet */
	int last;
	int last2;
	char octet[3];
	struct ips *ips;
	last = strlen(name);
	last2 = last;
	last=last+2;


	if (!name || isblank(name[0]) || iscntrl(name[0]) 
		|| isspace(name[0]) || ispunct(name[0])) {
		return 1;
	
	}

	ips = malloc(5 * sizeof(struct ips));
	for (counter=0; counter!=last; counter++) {
		if ((ips->p[counter] = (unsigned int)malloc(5 * sizeof(int))) == NULL) {
			fprintf(stderr, "String memory allocation failure.\n");
			exit(1);
		}

		if (name[counter] == '.' || name[counter] == '-' || counter==last2 ) {
			octet[counter2] = '\0';
			ips->p[counter1] = atoi(octet);
			counter2=0;	/* reset and start a new octet */
			counter++;	/* skip the '.' and continue */
			counter1++;	/* add new octet to the array */
		}		
		octet[counter2] = name[counter];
		counter2++;
	}
	if (ips->p[0] < 1 || ips->p[4] < 1) { 
		return (struct ips *)1;
	}
	
	ips->p[counter1++] = 911;
	for (counter2=0; ips->p[counter2] != 911; counter2++) {
		if (ips->p[counter2] > 255) {
			return (struct ips*)1;
		}
	}
	return ips;

}


	
struct tcp_scan * parsetcp(char *test) {

int counter;
int counter2;
int counter3=0;
char port1[7];
char port2[7];
char hostname[100];
struct tcp_scan *tcp;

	tcp = malloc(1*sizeof(struct tcp_scan));

        for (counter=0; test[counter]!=','; counter++) {
                hostname[counter] = test[counter];
        }
        hostname[counter] = '\0';
	counter++;		
        for (counter2=counter; test[counter2]!='-'; counter2++) {
                port1[counter3] = test[counter2];
                counter3++;
        }
        port1[counter3] = '\0';
        counter3++;
        counter2++; counter3=0;
        for (counter=counter2; test[counter]!='\0'; counter++) {
                port2[counter3] = test[counter];
                counter3++;
        }
        port2[counter3] = '\0';
	strcpy(tcp->host, hostname);
	strcpy(tcp->sport, port1);
	strcpy(tcp->dport, port2);
/*	fprintf(stderr, "-%s,%s,%s-\n", tcp->host, tcp->sport, tcp->dport); 
	getchar(); */	

	return tcp;
}

