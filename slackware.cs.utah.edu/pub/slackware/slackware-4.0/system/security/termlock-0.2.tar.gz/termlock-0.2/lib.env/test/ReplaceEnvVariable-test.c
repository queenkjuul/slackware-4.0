#include <plh_env.h>
#include <plh_ptr.h>

void main(void)
 {
   char *env[4]; 

   env[0] = MimicString("SHELL=/bin/bash");   
   env[1] = MimicString("USER=charon");   
   env[2] = MimicString("PROMPT=$P$G");
   env[3] = NULL;
   
   ReplaceEnvVariable(env, "USER", "cerebus");
   
   printf("The user should be 'cerebus'\n");
   printf("  %s\n", env[0]);   
   printf("  %s\n", env[1]);   
   printf("  %s\n", env[2]);   
 }
