#include <stdio.h>
#include <plh_bits.h>

void ShowBits(unsigned long value, char num)
 {
   bit32 bitvalues;
   
   bitvalues.dwords.dword0 = value;
   
   switch(num % 33)
    {
      case 32:	printf("%d", bitvalues.bits.bit31);
      case 31:	printf("%d", bitvalues.bits.bit30);
      case 30:	printf("%d", bitvalues.bits.bit29);
      case 29:	printf("%d", bitvalues.bits.bit28);
      case 28:	printf("%d", bitvalues.bits.bit27);
      case 27:	printf("%d", bitvalues.bits.bit26);
      case 26:	printf("%d", bitvalues.bits.bit25);
      case 25:	printf("%d", bitvalues.bits.bit24);
      case 24:	printf("%d", bitvalues.bits.bit23);
      case 23:	printf("%d", bitvalues.bits.bit22);
      case 22:	printf("%d", bitvalues.bits.bit21);
      case 21:	printf("%d", bitvalues.bits.bit20);
      case 20:	printf("%d", bitvalues.bits.bit19);
      case 19:	printf("%d", bitvalues.bits.bit18);
      case 18:	printf("%d", bitvalues.bits.bit17);
      case 17:	printf("%d", bitvalues.bits.bit16);
      case 16:	printf("%d", bitvalues.bits.bit15);
      case 15:	printf("%d", bitvalues.bits.bit14);
      case 14:	printf("%d", bitvalues.bits.bit13);
      case 13:	printf("%d", bitvalues.bits.bit12);
      case 12:	printf("%d", bitvalues.bits.bit11);
      case 11:	printf("%d", bitvalues.bits.bit10);
      case 10:	printf("%d", bitvalues.bits.bit9);
      case 9:	printf("%d", bitvalues.bits.bit8);
      case 8:	printf("%d", bitvalues.bits.bit7);
      case 7:	printf("%d", bitvalues.bits.bit6);
      case 6:	printf("%d", bitvalues.bits.bit5);
      case 5:	printf("%d", bitvalues.bits.bit4);
      case 4:	printf("%d", bitvalues.bits.bit3);
      case 3:	printf("%d", bitvalues.bits.bit2);
      case 2:	printf("%d", bitvalues.bits.bit1);
      case 1:	printf("%d", bitvalues.bits.bit0);
      case 0:	break;
    }
 }
