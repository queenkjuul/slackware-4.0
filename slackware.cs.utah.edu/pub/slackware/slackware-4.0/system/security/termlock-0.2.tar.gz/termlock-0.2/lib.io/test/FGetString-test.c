#include <stdio.h>
#include <plh_general.h>
#include <plh_io.h>

void main(void)
 {
   char buffer[LARGE_BUFFER_SIZE];
   
   printf("Type in a line and hit <enter>: ");
   printf("You typed <%s>\n", GetString(buffer));
 }
