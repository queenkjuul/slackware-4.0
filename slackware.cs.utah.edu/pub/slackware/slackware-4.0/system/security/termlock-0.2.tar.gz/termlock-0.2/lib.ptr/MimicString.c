#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <plh_ptr.h>
#include <plh_memory.h>

char *MimicString(char *s)
 {
  char *news;
  
  MemCheck(news = (char*)malloc((strlen(s)+1)*sizeof(char)));
  strcpy(news, s);
  
  return news;
 }
