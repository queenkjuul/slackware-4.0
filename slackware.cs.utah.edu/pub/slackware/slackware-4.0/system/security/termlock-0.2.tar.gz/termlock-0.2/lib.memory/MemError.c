#include <stdio.h>
#include <stdlib.h>
#include <plh_general.h>
#include <plh_memory.h>

void MemError(char error, char class)
 {
   switch(error)
    {
      case ERR_OUT_OF_MEM:	fprintf(stderr, "Out of memory.\n");
      				break;
      default:			fprintf(stderr, 
      					"Unknown memory error occured.\n");
      				break;
    }
    
   switch(class)
    {
      case FATALERROR:		exit(0);
      case NONFATALERROR:	break;
      default:			fprintf(stderr, "Unknown error class.\n");
      				exit(0);
    }
 }
