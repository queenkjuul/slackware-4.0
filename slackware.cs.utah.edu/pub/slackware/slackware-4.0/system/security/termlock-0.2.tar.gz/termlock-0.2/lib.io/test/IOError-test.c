#include <stdio.h>
#include <stdlib.h>
#include <plh_general.h>
#include <plh_io.h>

void main(void)
 {
  fprintf(stderr, "File Opening Error -> ");
  IOError(ERR_NO_FILE, NONFATALERROR);

  exit(0);
 }
 
