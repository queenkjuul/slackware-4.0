#include <stdio.h>
#include <plh_math.h>

void main(void)
 {
  int x;
  for(x = 0; x < 100; x++)
   {
    printf("Factors of %d are ", x);
    ShowAllFactors(x);
    printf("\n");
   }
 }
