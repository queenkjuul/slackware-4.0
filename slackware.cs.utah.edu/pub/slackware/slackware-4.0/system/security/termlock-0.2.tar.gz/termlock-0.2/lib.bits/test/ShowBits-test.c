#include <stdio.h>
#include <plh_bits.h>

void main(void)
 {
   int x, y, numblanks;
   
   printf("Bit colums should align:\n");
   for (x = 32; x > 0; x--)
    {
      numblanks = 34 - x;
      for(y = 0; y < numblanks; y++)
        printf(" ");
      ShowBits(3198234712, x);
      printf("\n");
    }   
 }
