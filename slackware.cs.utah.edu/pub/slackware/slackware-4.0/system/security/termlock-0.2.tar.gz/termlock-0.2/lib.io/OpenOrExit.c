#include <stdio.h>
#include <stdlib.h>
#include <plh_general.h>
#include <plh_io.h>
#include <plh_ptr.h>

FILE *OpenOrExit(char *filename, char *mode)
 {
   FILE *fileptr;
   
   fileptr = fopen(filename, mode);
   if(IS_NULL(fileptr)) IOError(ERR_NO_FILE, FATALERROR);
   
   return fileptr;
 }
 
