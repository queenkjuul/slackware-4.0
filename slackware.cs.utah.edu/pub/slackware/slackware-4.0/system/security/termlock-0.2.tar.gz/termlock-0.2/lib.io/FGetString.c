#include <plh_io.h>
#include <plh_ptr.h>
#include <string.h>

char *FGetString(char *s, int size, FILE *stream)
 {
   char *replace;
   
   if(IS_NULL(fgets(s, size, stream)))
     return NULL;
      
   if(!IS_NULL(replace = strstr(s, "\n\0")))
     *replace = '\0';

   return s;
 }
