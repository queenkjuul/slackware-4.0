#include <stdio.h>
#include <plh_ptr.h>

void main(void)
 {
   char AString[] = "\n\n\n";
   
   printf("-------3 NewLines---------\n");
   printf(AString);
   RemoveNewline(AString);
   printf("-------2 NewLines---------\n");
   printf(AString);
   RemoveNewline(AString);
   printf("-------1 NewLines---------\n");
   printf(AString);
 }
