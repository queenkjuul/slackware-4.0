#include <stdio.h>
#include <string.h>
#include <plh_ptr.h>

void main(void)
 {
   char string1[] = "        This is a string       ";
   char *string2;

   printf("  Initial string is \"%s\" and of length %d.\n",
          string1, strlen(string1));   

   string2 = MimicString(string1);
   printf("  Duplicate string is \"%s\" and of length %d.\n", 
   	  string2, strlen(string2));   

 }
