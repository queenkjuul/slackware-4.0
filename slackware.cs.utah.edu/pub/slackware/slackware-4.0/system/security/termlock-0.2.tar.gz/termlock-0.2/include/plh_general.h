/*******************************************************************************
* plh_general.h								       *
********************************************************************************
* Collection of general macros and definitions. I do not suspect there to be a *
* library associated with this one.					       *
********************************************************************************
* A word on terminology used here:					       *
*	dependant pointer	a pointer that is part of one of the passed    *
*				arguments or comes from their memory.	       *
*	independant pointer	a pointer whose memory has been separately     *
*				allocated and has no link to the arguments.    *
*******************************************************************************/

/*FLAGS************************************************************************/

/*CONSTANTS********************************************************************/

			/* Fatal error class: do not continue program	      */
#define FATALERROR	0
			/* Non fatal error class: continue processing	      */
#define NONFATALERROR	1
			/* Flags are mutually exclusive			      */

			/* Define sizes of multiple buffers for reading input */
#define SMALL_BUFFER_SIZE	128
#define BUFFER_SIZE		256
#define LARGE_BUFFER_SIZE	512
#define HUGE_BUFFER_SIZE	1024
			
/*MACROS***********************************************************************/

/*TYPE*DEFINITIONS*************************************************************/

/*EXTERNAL*GLOBAL*VARIABLES****************************************************/

/*EXTERNAL*ROUTINES************************************************************/

