#include <string.h>
#include <plh_parse.h>
#include <plh_ptr.h>

char IsDirectiveDefined(options opts, char *directive)
 {
   optdir_node *nodeptr = opts.dirs;
   
   while(!IS_NULL(nodeptr))
      if(!strcmp(nodeptr->directive, directive))
        return 1;
      else
        nodeptr = nodeptr->next;
        
   return 0;
 }
