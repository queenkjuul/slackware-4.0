#include <stdio.h>
#include <plh_ptr.h>

void main(void)
 {
   char string1[] = "   This is a string.   ";
   char string2[] = "   This is a string.   ";
   char string3[] = "   This is a string.   ";
   char string4[] = "   This is a string.   ";
   char string5[] = "   This is a string.   ";
   char string6[] = "   This is a string.   ";
   char string7[] = "   This is a string.   ";
   char string8[] = "   This is a string.   ";
   char empty[] = "";
   
   int index;
   
   printf("No opts: <%s>\n", TrimString(string1, 0));
   printf("Front only:<%s>\n", TrimString(string2, 
   				TRIM_FRONT));
   printf("Rear only: <%s>\n", TrimString(string3, 
   				TRIM_REAR));
   printf("Embed only: <%s>\n", TrimString(string4, 
   				TRIM_EMBED));
   printf("Front/Rear: <%s>\n", TrimString(string5,
   				TRIM_FRONT | TRIM_REAR));
   printf("Front/Embed: <%s>\n", TrimString(string6, 
   				TRIM_FRONT | TRIM_EMBED));
   printf("Rear/Embed: <%s>\n", TrimString(string7, 
   				TRIM_REAR | TRIM_EMBED));
   printf("All: <%s>\n", TrimString(string8, 
   				TRIM_FRONT | TRIM_REAR | TRIM_EMBED));
   printf("All for an empty string: <%s>\n", TrimString(empty,
   				TRIM_FRONT | TRIM_REAR | TRIM_EMBED));
   TrimString(NULL, TRIM_FRONT | TRIM_REAR | TRIM_EMBED);

 }
