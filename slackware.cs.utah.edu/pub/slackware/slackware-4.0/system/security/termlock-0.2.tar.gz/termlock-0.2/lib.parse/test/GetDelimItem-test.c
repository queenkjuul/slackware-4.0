#include <stdio.h>
#include <plh_parse.h>

void main(void)
 {
  int item;
  char line[] = "|happy|sad|empty|full|";
  
  printf("Line being parsed is \"%s\"\n", line);
  
  for(item = 0; item < 10; item++)
    printf("  Item #%d is %s\n", item, GetDelimItem(line, '|', item));
 }
 
