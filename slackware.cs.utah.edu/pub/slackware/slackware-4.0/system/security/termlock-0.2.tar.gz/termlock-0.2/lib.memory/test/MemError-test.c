#include <stdio.h>
#include <stdlib.h>
#include <plh_general.h>
#include <plh_memory.h>

void main(void)
 {
   printf("Error due to no more memory -> ");
   MemError(ERR_OUT_OF_MEM, NONFATALERROR);
 }
