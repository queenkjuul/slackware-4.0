unsigned long GetAFactor(unsigned long value)
{
  float result = (float) value; /* test result for division */
  unsigned testval = 2;	              /* current test value */

			               /* eliminate 1 and 0 */
  if (value < 2)
    return value;
  else
   {
			         /* check for 2 as a factor */ 
     if((result / testval) == (value / testval))
       return testval;

     for(testval = 3;  (result / testval) != (value / testval); testval += 2);
     return testval;
   }
}

