#include <plh_ptr.h>

void main(void)
 {
   char AString[] = "mississippi";
   
   printf("Initial <%s>\n", AString);
   printf("Replace first m with w <%s>\n", 
   	  CharReplace(AString, 'm', 'w', CHRREP_FRONT));
   printf("Replace last p with q <%s>\n",
   	  CharReplace(AString, 'p', 'q', CHRREP_REAR));
   printf("Replace all i with o <%s>\n",
   	  CharReplace(AString, 'i', 'o', CHRREP_ALL));
 }
