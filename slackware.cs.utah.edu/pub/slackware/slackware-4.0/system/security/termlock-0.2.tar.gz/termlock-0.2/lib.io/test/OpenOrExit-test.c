#include <stdio.h>
#include <plh_io.h>

void main(void)
 {
   FILE *testptr;
   char exists[] = "OpenOrExit-test.c";
   char notexists[] = "NotAFile.c";

   printf("This should not cause an error\n");   
   testptr = OpenOrExit(exists, "r");
   printf("Opening of %s succeeded\n", exists);

   printf("This should cause an error\n");   
   testptr = OpenOrExit(notexists, "r");
   printf("Opening of %s succeeded\n", notexists);
 }
