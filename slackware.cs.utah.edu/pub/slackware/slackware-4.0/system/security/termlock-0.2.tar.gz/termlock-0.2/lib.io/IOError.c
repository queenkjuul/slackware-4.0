#include <stdio.h>
#include <stdlib.h>
#include <plh_general.h>
#include <plh_io.h>

void IOError(char error, char class)
 {
   switch(error)
    {
      case ERR_NO_FILE:		fprintf(stderr, 
      					"No file found or error openening.\n");
      				break;
      default:			fprintf(stderr, "Unknown I/O error occured.\n");
      				break;
    }
    
   switch(class)
    {
      case FATALERROR:		exit(0);
      case NONFATALERROR:	break;
      default:			fprintf(stderr, "Unknown error class.\n");
      				exit(0);
    }
 }
