/*******************************************************************************
* template.h								       *
********************************************************************************
* HEADER:								       *
* This is a template header file for standard generation.    		       *
* Describe the purpose of the header existence here.			       *
* There should be one header file associated with each library.		       *
* Library routines should be in separate *.c files for easier replacement.     *
* This file should include no other files than those needed for types & macros.*
*******************************************************************************/

//#include <notaheader.h>

/*FLAGS************************************************************************/

			/*		FLAG COMMENT FORM		      */
//#define NOT_A_REAL_FLAG

/*CONSTANTS********************************************************************/

			/*		CONSTANT COMMENT FORM		      */
//#define REMOVE_THIS 		0

/*MACROS***********************************************************************/

			/*******************************************************
			* Put macro desciption here.			       *
			********************************************************
			* Input specifications here			       *
			*******************************************************/
//#define NOT(a)		printf("no")

/*TYPE*DEFINITIONS*************************************************************/

			/*		TYPE DESCRIPTION HERE		      */
//typedef char remove;

/*EXTERNAL*GLOBAL*VARIABLES****************************************************/

			/*		GLOBAL VARIABLE DESCRIPTION	      */
//extern char *global_variable;

/*EXTERNAL*ROUTINES************************************************************/

			/*******************************************************
			* Routine description here including output	       *
			********************************************************
			* Input specifications here			       *
			*******************************************************/
//int nothing(char *a, long b);

