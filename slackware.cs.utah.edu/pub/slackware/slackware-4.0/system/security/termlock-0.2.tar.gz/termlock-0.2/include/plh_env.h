/*******************************************************************************
* plh_env.h								       *
********************************************************************************
* Routines that manipulate the environment that is passed to the program upon  *
* execution.								       *
*******************************************************************************/

/*FLAGS************************************************************************/

/*CONSTANTS********************************************************************/

/*MACROS***********************************************************************/

/*TYPE*DEFINITIONS*************************************************************/

/*EXTERNAL*GLOBAL*VARIABLES****************************************************/

/*EXTERNAL*ROUTINES************************************************************/

			/*******************************************************
			* Routine to replace an existing environment variable  *
			* value with a new value. If the variable does not     *
			* exist, the routine does nothing (in which case it    *
			* returns NULL). Normally, it returns the original     *
			* value of the environment variable. 		       *
			********************************************************
			* env		pointer to the environment list	       *
			* label		variable label (name)		       *
			* newval	new value to assign to variable	       *
			*******************************************************/
char *ReplaceEnvVariable(char *env[], char *label, char *newval);
