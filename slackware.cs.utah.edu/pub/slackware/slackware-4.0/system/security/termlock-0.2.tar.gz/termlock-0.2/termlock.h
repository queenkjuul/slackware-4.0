/*******************************************************************************
*        Simple, crippled shell allowing only access request or logout	       *
*			      by Phil Holman				       *
*									       *
* Due to problems with login process- admin-shells package source analyzed.    *
* That source by Ken Wilcox.						       *
*******************************************************************************/
 
			/* Debuggers					      */
//#define DEBUG

			/* Options file variables		              */
#define ATTEMPT_LABEL	"MAX_ATTEMPTS"
#define FILE_LABEL	"SHELL_FILE"
#define SCRIPT_LABEL	"SCRIPT_ENTRY"
#define TPROMPT_LABEL	"TERMLOCK_PROMPT"
#define APROMPT_LABEL	"ACCESS_PROMPT"
#define EDELAY_LABEL	"ERROR_DELAY"

			/* Constants					      */
#define CONF_FILE	"/etc/termlockrc"
#define ENV_SHELL_VAR	"SHELL"
#define ENV_USER_VAR	"USER"
#define DELIMETER	':'
#define ACCESS_DELIM	':'
#define NAME_FIELD	1
#define SHELL_FIELD	2
#define DEF_EDELAY	3
#define DEF_APROMPT	"RequestAccess"
#define DEF_TPROMPT	"TermLock>"
#define DEF_SCRIPT	"shell"
#define DEF_SHFILE	"/etc/login.shells"
#define DEF_MAXATT	3
