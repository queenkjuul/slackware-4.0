#include <stdio.h>
#include <plh_bits.h>

void main(void)
 {
   bit8 chr0;
   
   chr0.nibbles.nib0 = 6;
   chr0.nibbles.nib1 = 9;

   printf("  Original: ");
   ShowBits(chr0.bytes.byte0, 8);
   printf("\n");

   printf("  Mirror: ");
   ShowBits(*BitMirror8(&(chr0.bytes.byte0)), 8);
   printf("\n");
            
 }
