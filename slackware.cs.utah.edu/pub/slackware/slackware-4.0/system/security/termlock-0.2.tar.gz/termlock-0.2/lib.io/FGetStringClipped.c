#include <stdio.h>
#include <plh_io.h>
#include <plh_ptr.h>

char *FGetStringClipped(char *s, int size, FILE *stream)
 {
   if(IS_NULL(fgets(s, size, stream)))
     return NULL;
   else
     return TrimString(s, TRIM_FRONT | TRIM_REAR);
 }
