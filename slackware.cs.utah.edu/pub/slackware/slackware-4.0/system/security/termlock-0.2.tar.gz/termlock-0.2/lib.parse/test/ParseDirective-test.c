#include <plh_parse.h>

void main(void)
 {
   char string0[] = ".BOLD";
   char string1[] = ".		white SPACE directive";
   char *direct0;
   char *direct1;
   
   ParseDirective(string0, &direct0);
   ParseDirective(string1, &direct1);
   
   printf("Directive 0: <%s>\nDirective 1: <%s>\n",
   	   direct0, direct1);
 }
