#include <stdio.h>
#include <plh_math.h>

void main(void)
 {
   int x;
   
   for(x = 0; x < 100; x++)
     printf("The first factor of %d is %lu\n", x, GetAFactor(x));
 }
