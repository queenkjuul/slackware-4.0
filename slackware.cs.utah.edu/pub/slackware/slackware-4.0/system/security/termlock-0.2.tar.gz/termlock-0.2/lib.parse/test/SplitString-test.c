#include <stdio.h>
#include <string.h>
#include <plh_parse.h>

void main(void)
 {
   char strings[4][50];
   char *filename = NULL;
   char *path = NULL;
   int x, y;
   
   strcpy(strings[0], "/usr/local/bin/happy");
   strcpy(strings[1], "");
   strcpy(strings[2], "/");
   strcpy(strings[3], "happy");

   for(x = 0; x < 4; x++)
    {
      for(y = 0; y < 8; y++)
       {
        SplitString(strings[x], '/', &path, &filename, y);
        printf("%s:\n", strings[x]);
        printf("  path: %s\n", path);
        printf("  file: %s\n", filename);
        free(filename);
        free(path);
        filename = NULL;
	path = NULL;
       }
    }

   
   SplitString(strings[0], '/', &path, NULL, SEARCH_END | DELIM_LEFT);
   printf("%s: Left only\n", strings[x]);
   printf("  path: %s\n", path);
   printf("  file: %s\n", filename);
   free(path);
   filename = NULL;
   path = NULL;

   SplitString(strings[0], '/', NULL, &filename, SEARCH_END | DELIM_LEFT);
   printf("%s: Right only\n", strings[x]);
   printf("  path: %s\n", path);
   printf("  file: %s\n", filename);
   free(filename);
   filename = NULL;
   path = NULL;

   SplitString(strings[0], '/', NULL, NULL, SEARCH_END | DELIM_LEFT);
   printf("%s: Neither\n", strings[x]);
   printf("  path: %s\n", path);
   printf("  file: %s\n", filename);
   filename = NULL;
   path = NULL;
 }
 
