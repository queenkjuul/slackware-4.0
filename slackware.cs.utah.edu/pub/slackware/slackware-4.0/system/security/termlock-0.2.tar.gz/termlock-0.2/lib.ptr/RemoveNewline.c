#include <string.h>
#include <plh_ptr.h>

char *RemoveNewline(char *s)
 {
   int len = strlen(s);
   
   if(s[len - 1] == '\n')
     s[len - 1] = '\0';
     
   return s;
 }
