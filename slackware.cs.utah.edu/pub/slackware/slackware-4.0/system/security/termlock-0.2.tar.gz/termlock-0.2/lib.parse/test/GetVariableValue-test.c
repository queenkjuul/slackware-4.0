#include <stdio.h>
#include <plh_ptr.h>
#include <plh_io.h>
#include <plh_parse.h>

#define TESTFILE	"options.testfile"

void main(void)
 {
  FILE *fptr = OpenOrExit(TESTFILE, "r");
  options *opts = ReadOptionsFile(fptr,
  	          REMOVE_COMMENTS | GET_VARS | GET_DIRS, '#', '.');
  
  printf("The value of CLEANLINESS is %s\n",
         GetVariableValue(*opts, "CLEANLINESS"));
  printf("The value of an undefined variable is %s\n",
         GetVariableValue(*opts, "COMUNISM"));
         
 }
 
