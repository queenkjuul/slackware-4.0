#include <string.h>
#include <plh_parse.h>
#include <plh_ptr.h>

void ParseVariable(char *line, char **label, char **value)
 {
			/* pointer for start of value half of assignment      */
   char *valueptr = strchr(line, '=');
   
   			/* split string in two and and trim up both halves    */
   *valueptr = '\0';
   valueptr++;
   TrimString(line, TRIM_FRONT | TRIM_REAR);
   TrimString(valueptr, TRIM_FRONT | TRIM_REAR);
   
			/* clone both halves and duplicate them for the       */
			/* pointer addresses passed.			      */
   *label = MimicString(line);
   *value = MimicString(valueptr);
 }
