#include <plh_parse.h>
#include <plh_ptr.h>

void ParseDirective(char *line, char **directive)
 {
 			/* Trim up the data part of the directive by skipping */
 			/* the delimeter (first character)		      */
   TrimString(line + 1, TRIM_FRONT | TRIM_REAR);

			/* clone the string using the passed pointer address  */   
   *directive = MimicString(line + 1);
 }
