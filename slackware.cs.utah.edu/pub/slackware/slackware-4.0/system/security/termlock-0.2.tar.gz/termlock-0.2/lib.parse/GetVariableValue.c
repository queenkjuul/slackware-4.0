#include <string.h>
#include <plh_parse.h>
#include <plh_ptr.h>

char *GetVariableValue(options opts, char *label)
 {
   optvar_node *nodeptr = opts.vars;
   
   while(!IS_NULL(nodeptr))
     if(!strcmp(nodeptr->label, label))
       return nodeptr->value;
     else
       nodeptr = nodeptr->next;
       
   return NULL;
 }
