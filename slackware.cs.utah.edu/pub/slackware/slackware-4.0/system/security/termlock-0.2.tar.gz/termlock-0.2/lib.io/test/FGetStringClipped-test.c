#include <stdio.h>
#include <plh_general.h>
#include <plh_io.h>

void main(void)
 {
   char buffer[LARGE_BUFFER_SIZE];
   
   printf("Enter a string with leading and trailing white space.\n");
   FGetStringClipped(buffer, LARGE_BUFFER_SIZE, stdin);
   printf("You typed \"%s\"\n", buffer);
 }
