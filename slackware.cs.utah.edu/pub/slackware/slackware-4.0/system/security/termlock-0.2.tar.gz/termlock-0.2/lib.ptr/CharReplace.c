#include <stdio.h>
#include <string.h>
#include <plh_ptr.h>

char *CharReplace(char *s, char rep, char repval, char mode)
 {
			/* Index variable for scanning string 		      */
   int index;

			/* Check for requested replacement of null character  */
			/* and immediately return if it occurs (invalid).     */
   if(rep == '\0') return s;
   			
   			/* Operation depends on where the replacement is to   */
   			/* occur. Code is not similar enough to factored.     */
   switch(mode)
    {
      case CHRREP_FRONT:	for(index = 0; 
      				    (s[index] != rep) && (s[index] != '\0');
      				    index++);
      				if (s[index] != '\0') s[index] = repval;
      				return s;
      case CHRREP_REAR:		for(index = strlen(s) - 1;
      				    (s[index] != rep) && (index != -1);
      				    index--);
      				if (index != -1) s[index] = repval;
      				return s;
      case CHRREP_ALL:		for(index = 0; s[index] != '\0'; index++)
      				  if(s[index] == rep) s[index] = repval;
      				return s;
      default:	fprintf(stderr, "CharReplace: Error: Unknown mode\n");
      		return s;
    }
 }
