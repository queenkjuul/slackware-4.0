#include <stdio.h>
#include <plh_bits.h>

char* BitMirror8(char *original)
{
  bit8* newbit;
  	
  MemCheck(newbit=(bit8*)malloc(sizeof(bit8)));
  
  newbit->bits.bit0 = ((bit8*)original)->bits.bit7;
  newbit->bits.bit1 = ((bit8*)original)->bits.bit6;
  newbit->bits.bit2 = ((bit8*)original)->bits.bit5;
  newbit->bits.bit3 = ((bit8*)original)->bits.bit4;
  newbit->bits.bit4 = ((bit8*)original)->bits.bit3;
  newbit->bits.bit5 = ((bit8*)original)->bits.bit2;
  newbit->bits.bit6 = ((bit8*)original)->bits.bit1;
  newbit->bits.bit7 = ((bit8*)original)->bits.bit0;

  return (char*)newbit;
}
