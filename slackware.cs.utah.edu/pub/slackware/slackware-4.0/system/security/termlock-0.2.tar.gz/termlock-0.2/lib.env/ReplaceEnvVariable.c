#include <stdio.h>
#include <string.h>
#include <plh_env.h>
#include <plh_memory.h>

char *ReplaceEnvVariable(char *env[], char *label, char *value)
{
			/* Flag to mark when the variable has been changed    */
  char done = 0;
  			/* buffer pointer for allocating memory and holding   */
  			/* the new environment entry temporarily.	      */
  char *buffer;
  			/* pointer for returning the original value of the    */
  			/* environment variable.			      */
  char *oldvalue = NULL;
  			/* Length of the variable label.		      */ 
  int labellen = strlen(label);
  			/* Index (counter) for scanning the environment list  */
  int index;

			/* Allocate memory for the new entry and copy data    */
			/* into it.					      */
  MemCheck(buffer =
      malloc((strlen(value) + labellen + 2) * sizeof(char)));
  sprintf(buffer, "%s=%s", label, value);

			/* Initialize variable for traversal of environment   */
			/* list and begin traversal for specified variable.   */
  index = 0;
  while(!done && !IS_NULL(env[index]))
   {
			/* Only compare length of strings up to end of search */
			/* variable.					      */
     if(!strncmp(env[index], label, labellen))
      {
			/* Make oldvalue point to old variable value	      */
       oldvalue = strchr(env[index], '=');
       oldvalue++;
			/* Put new buffer in environment variable list	      */
       env[index] = buffer;
       			/* Set flag to mark that variable has been found      */
       done = 1;
      }
      			/* increment index to test next variable	      */
     index++;
   }
   
  return oldvalue;
}
