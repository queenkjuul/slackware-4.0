#include <stdio.h>
#include <plh_parse.h>

void main(void)
 {
  char string0[] = "var0=one hundred";
  char string1[] = "	var1	=	234	";
  char *label0, *label1, *value0, *value1;

  ParseVariable(string0, &label0, &value0);  
  ParseVariable(string1, &label1, &value1);  

  printf("  Variable 0-	Label: <%s> Value: <%s>\n", label0, value0);
  printf("  Variable 1-	Label: <%s> Value: <%s>\n", label1, value1);
 }
