#include <stdio.h>
#include <plh_parse.h>
#include <plh_memory.h>

char* GetDelimItem(char* line, char delim, int select)
{
			/* Pointer for new string storage area		      */
  char* item_buffer = NULL;
			/* Pointer for beginning of specified item	      */
  char* start_item;
  			/* Pointer for end of specified item		      */
  char* end_item;	 
  			/* Variable to hold the storage used by the item data */ 
  unsigned long item_len;
  			/* current location (while scanning string)           */
  unsigned int place = 0;
  			/* item counter to store the current item in line     */
  int item = 0;
  
			/* this code skips all items prior to specified one   */
  while(line[place] && (item != select))
   {
    if(line[place]==delim)
      item++;

    place++;  
   }

			/* return NULL if a non-existant item is specified.   */
			/* NOTE: code assumes a line of form:		      */
			/* 	|item #1|item #2|...|item #n|		      */
  if(line[place] && (place != 0))
   {
    	           	/* code to find the end of the item and its length    */
    start_item = line + place;
    for(end_item = start_item; 
  	(*end_item != '\0') && 
        (*end_item != delim) &&
        (*end_item != '\n');
    	end_item++);
    item_len = end_item - start_item;

		        /* allocate memory for the return item buffer         */
    MemCheck(item_buffer = (char*) malloc(item_len+1));

			/* copy item into return buffer and return            */
    for(place = 0; place < item_len; place++)
      item_buffer[place] = start_item[place];
    item_buffer[item_len] = '\0';         
   }
  return item_buffer;       
}	       
