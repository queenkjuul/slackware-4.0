#include <stdio.h>
#include <plh_ptr.h>
#include <plh_io.h>
#include <plh_parse.h>

#define TESTFILE	"options.testfile"

void main(void)
 {
  FILE *fptr = OpenOrExit(TESTFILE, "r");
  options *opts = ReadOptionsFile(fptr,
  	          REMOVE_COMMENTS | GET_VARS | GET_DIRS, '#', '.');

  printf("Is <?> defined...\n");
  printf("   <%s> %d\n", "HAPPY", IsDirectiveDefined(*opts, "HAPPY"));
  printf("   <%s> %d\n", "JUMPY", IsDirectiveDefined(*opts, "JUMPY"));
 }
 
