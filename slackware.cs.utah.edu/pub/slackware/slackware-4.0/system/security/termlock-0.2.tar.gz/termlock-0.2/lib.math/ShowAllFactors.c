#include <stdio.h>
#include <plh_math.h>

void ShowAllFactors(unsigned long value)
 {
  unsigned long factor;
  
  switch(value)
   {
     case 0:
     case 1:	printf("%d", value);
     		break;
     default:	while((factor = GetAFactor(value)) != value)
     		 {
     		   printf("%d ", factor);
     		   value /= factor;
     		 }
     		printf("%d", value);
     		break;
   }
 }
