#!/bin/sh

cat <<EOF
/*
 * THIS IS A GENERATED FILE.  DO NOT EDIT!
 * Edit XOTPCalc.ad and rerun make instead.
 */

const char *defres[] = {
EOF

${AWK} -f mkdefres.awk XOTPCalc.ad
echo "0 };"
