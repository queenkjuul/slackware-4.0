/*
  Shambler.h
  $Id: shambler.h,v 1.1 1999/04/22 03:35:36 jay Exp jay $

*/

#include <sys/types.h>
#include <stdio.h>
#include <sys/stat.h>
#include <dirent.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <syslog.h>
#include <pwd.h>
#include <getopt.h>


#define PROC_DIR "/proc"
#define DEFAULT_CONF "shambler.config"

#define SYSLOG_IDENT "shambler"
#define SYSLOG_PRIORITY LOG_AUTHPRIV
#define DEFAULT_VALID_UIDS valid_uids[0]=0;valid_uids[1]=99;valid_uids[2]=500;index=3;
uid_t valid_uids[50]; 
int uid_count;



void usage(void);
int argc;
char **argv;

int mydebug;
int kidding;
static struct option long_options[]=
  {
    {"config",1,0,0},
    {"debug",0,0,0},
    {0,0,0,0}
  };
