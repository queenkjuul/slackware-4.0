#include<stdio.h>
#include<crypt.h>
void main(int argc, char **argv){
	int i,il;
	FILE *pas;
	char buf[1023];
	char buf0[1023];
	char buf1[1023];
	printf("What shall the user's CVS login name be? ");
	scanf("%s",buf);
	printf("What shall the user's SYSTEM mapped name be?\n");
	printf("(WARNING) Be careful, this controls their access to the CVS repository!\n");
	scanf("%s",buf0);
	strncpy(buf1,getpass("What is their CVS login password?"),sizeof(buf1));
	printf("Thank you, putting entry %s:NOPEEKS:%s into the passwd file\n",buf,buf0);
	pas = fopen("./passwd","a");
	fprintf(pas,"%s:%s:%s\n",buf,crypt(buf1,"aa"),buf0);
	fflush(pas);
	fclose(pas);
	printf("(Hopefully...) Removing password securly from memory\n");
	for(il=0;il!=9;il++){
		for(i=0;i!=sizeof(buf1);i++)
			buf1[i] = 'f';
	}
	printf("Happy CVS'ing :)\n");
	return;
}

