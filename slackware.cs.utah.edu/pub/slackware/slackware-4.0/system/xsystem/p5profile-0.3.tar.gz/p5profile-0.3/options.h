#ifndef __OPTIONS
#define __OPTIONS

class OptionsDialog : public QDialog {
		Q_OBJECT
	public:
		QCheckBox *c00,*c01,*c10,*c11;
		QLineEdit *sr;
		OptionsDialog(QWidget *parent=0,const char *name=0);
};

#endif

