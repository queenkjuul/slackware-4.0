#include <qdialog.h>
#include <qpushbt.h>
#include <qlabel.h>
#include <qchkbox.h>
#include <qlined.h>
#include "options.h"
#include "options.moc"

OptionsDialog::OptionsDialog(QWidget *parent=0,const char *name=0) : QDialog(parent,name,TRUE) {
	resize(335,150);

	QLabel *l1=new QLabel("Counter #0",this);
	l1->move(10,5);

	c00=new QCheckBox("in CPL!=3",this,"c00");
	c00->move(15,25);
	c01=new QCheckBox("in CPL==3",this,"c01");
	c01->move(15,45);

	QLabel *l2=new QLabel("Counter #1",this);
	l2->move(110,5);

	c10=new QCheckBox("in CPL!=3",this,"c10");
	c10->move(115,25);
	c11=new QCheckBox("in CPL==3",this,"c11");
	c11->move(115,45);

	QLabel *l3=new QLabel("Sample Rate (ms)",this);
	l3->move(220,5);

	sr=new QLineEdit(this,"sr");
	sr->setMaxLength(4);
	sr->setGeometry(220,30,100,25);

	QPushButton *ok=new QPushButton("OK",this);
	ok->move(105,105);
	connect(ok,SIGNAL(clicked()),this,SLOT(accept()));

	QPushButton *cancel=new QPushButton("Cancel",this);
	cancel->move(220,105);
	connect(cancel,SIGNAL(clicked()),this,SLOT(reject()));
}

