#ifndef __MAIN
#define __MAIN

class MainWidget : public QWidget {
		Q_OBJECT
	public:
		MainWidget(QWidget *parent=0,const char *name=0);
		void fillComboBox(QComboBox *combo);
	private:
		QComboBox *select1,*select2;
		GraphWidget *graph;
		QScrollBar *scaler;
		QLabel *scale;
		int sampleRate;
		int c00,c01,c10,c11;
		virtual void resizeEvent(QResizeEvent *event);
	public slots:
		void about();
		void options();
		void scalerChange(int);
};

#endif

