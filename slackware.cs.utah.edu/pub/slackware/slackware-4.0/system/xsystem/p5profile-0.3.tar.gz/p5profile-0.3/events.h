#ifndef __EVENTS
#define __EVENTS

#define P5EVENTS 40

struct P5Event {
	int number;
	char name[40];
};

extern P5Event p5events[];

#endif
