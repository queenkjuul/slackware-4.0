#ifndef __GRAPH
#define __GRAPH

#define MINMAX 		1
#define MAXMAX 		100

typedef unsigned long int DataPoints[1];

struct Counter {
	int index,oldCounter,mask;
	DataPoints *data;
};

class GraphWidget : public QWidget {
		Q_OBJECT
	public:
		GraphWidget(QWidget *parent=0,const char *name=0);
		~GraphWidget();
		void setMaximum(int n);
		void setActive(int c,int c0,int c1);
		void setSampleRate(int r);
	private:
		int currentWidth,currentSize,currentPosition,currentMax,handle,oldCycles,newCycles;
		Counter counters[3];   /* nr.2 => cyclediffs */
		QTimer *timer;
		void initCounter(int index);
		unsigned long int readCycles();
		virtual void paintEvent(QPaintEvent *event);
		virtual void resizeEvent(QResizeEvent *event);
	public slots:
		void setCounter1(int);
		void setCounter2(int);
		void getDataPoint();
};

#endif

