/*
 * usrmgr - Linux user manager
 * Copyright 1995 by Michael McNeil <kludge@zot.com>
 * XForms GUI adaptation by R. Mitnitksi <mitnits@shani.net>
 * Released under the GNU Public License. See COPYING for details.
 */

#ifndef FD_xfusermgr_top_h_
#define FD_xfusermgr_top_h_
/* Header file generated with fdesign. */

/**** Callback routines ****/

extern void usrselc_cb(FL_OBJECT *, long);
extern void Exit(FL_OBJECT *, long);
extern void reset_user(FL_OBJECT *, long);
extern void rem_user(FL_OBJECT *, long);
extern void dis_user(FL_OBJECT *, long);
extern void new_user(FL_OBJECT *, long);
extern void add_user(FL_OBJECT *, long);
extern void text_modify(FL_OBJECT *, long);

/**** Forms and Objects ****/

typedef struct {
	FL_FORM *xfusermgr_top;
	FL_OBJECT *users;
	FL_OBJECT *Uusrid_te;
	FL_OBJECT *Ulgname_te;
	FL_OBJECT *Ufname_te;
	FL_OBJECT *Uhmdir_te;
	FL_OBJECT *Ugroup_te;
	FL_OBJECT *Ushell_te;
	FL_OBJECT *Upasswd_te;
	FL_OBJECT *exit_b;
	FL_OBJECT *clear_b;
	FL_OBJECT *remove_b;
	FL_OBJECT *disable_b;
	FL_OBJECT *add_update_b;
	FL_OBJECT *add_button;
	void *vdata;
	long ldata;
} FD_xfusermgr_top;

extern FD_xfusermgr_top * create_form_xfusermgr_top(void);

#endif /* FD_xfusermgr_top_h_ */
